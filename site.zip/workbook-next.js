/* Revision 250: explicit population rules and shared controller specifications. */
function controllerRules250(){
 return {
  3:{equipment:9,terms:[['calc-peak-airflows',1,4]]},
  4:{equipment:10,terms:[['calc-peak-airflows',6,10],['calc-peak-airflows',14,18]]},
  5:{equipment:3,terms:[['calc-doas-zone-air-balance','ventilationEquipment','occupiedVentilation'],['calc-doas-ahu-air-balance','ventilationEquipment','occupiedVentilation']]},
  6:{equipment:7,terms:[['calc-doas-zone-air-balance','exhaustEquipment','occupiedExhaust'],['calc-doas-ahu-air-balance','exhaustEquipment','occupiedExhaust']]},
  7:{equipment:4,terms:[['calc-peak-airflows',1,4]]},
  8:{equipment:6,terms:[['calc-peak-airflows',6,10]]},
  9:{equipment:5,terms:[['calc-ahu-oa-air-balance','supplyValve','minimumOccupiedSupply'],['calc-ahu-economizing-air-balance','supplyValve','minimumOccupiedSupply']]},
  10:{equipment:5,terms:[['calc-ahu-oa-air-balance','supplyValve','minimumUnoccupiedSupply']]},
  12:{equipment:5,terms:[['calc-ahu-economizing-air-balance','supplyValve','returnToValve'],['calc-doas-ahu-air-balance','supplyValve','valveReturn']]},
  13:{space:true,terms:[['calc-air-balancing-requirements','Space','Pressurization']]},
  14:{space:true,terms:[['calc-air-balancing-requirements','Space','Transfer Air In']]},
  15:{space:true,terms:[['calc-air-balancing-requirements','Space','Transfer Air Out']]}
 };
}
function controllerColumn250(table,key){return typeof key==='number'?key:table.balanceFields?.includes(key)?table.balanceFields.indexOf(key):key==='Space'?table.spaceColumn??0:table.headers.findIndex(h=>h.label===key);}
function controllerEquation250(rule){
 const ref=(id,key)=>scheduleSourceReference(id,controllerColumn250(workbookTable(id),key)),z='calc-equipment-zoning',key=ref(z,2),list='sp_list';
 const terms=rule.terms.map(([id,k,v])=>`SUMPRODUCT((COUNTIF(${list},${ref(id,'Space')})>0)*(${ref(id,'Space')}<>"")*(${ref(id,'Space')}<>"-"),${ref(id,v)})`);
 return `=LET(${list},UNIQUE(FILTER(${key},(${ref(z,1)}=@Zone)*(${key}<>"")*(${key}<>"-"),"")),${terms.join('+')})`;
}
function configureWorkbook250(){
 for(const t of independentTables.filter(t=>t.mixedAirCalculation)){t.hiddenColumns=[...new Set([...(t.hiddenColumns||[]),...(t.mixedAirHeating?[18]:[24,30])])];}
 const balancing=workbookTable('calc-air-balancing-requirements'),old=balancing.name;
 balancing.aliases=[...new Set([...(balancing.aliases||[]),old,balancing.standard])];balancing.name=balancing.standard='Balancing Requirements';
 for(const m of modules)for(const i of m.items)if(i[3]===balancing.id)i[0]=balancing.name;
 // Keep old reference names resolvable while presenting the new name everywhere.
 for(const t of independentTables)for(const key of ['displayEquations','equations'])for(const [c,e]of Object.entries(t[key]||{}))t[key][c]=e.replaceAll('['+old+']','[Balancing Requirements]');
 const t=workbookTable('iesve-apachehvac-controllers');t.hiddenColumns=[...new Set([...(t.hiddenColumns||[]),11])];t.summaryColumns=t.summaryColumns.filter(c=>c!==11);delete t.displayEquations[11];
 for(const [c,rule]of Object.entries(controllerRules250()))t.displayEquations[c]=controllerEquation250(rule);
 t.displayEquations[16]='=@Pressurized Air + @Transfer Air In - @Transfer Air Out';
 const central=workbookTable('calc-doas-ahu-air-balance');for(const key of ['centralReturn','valveReturn'])delete central.headerLinks[central.balanceFields.indexOf(key)];
 for(const id of ['selected-lighting-loads','selected-misc-loads','selected-general-exhaust','selected-exhaust-equipment']){const s=workbookTable(id);s.dropdownColumns[0]={sourceTableId:'calc-space-condition-setpoints',sourceColumn:0,choiceKind:'space',spaceTableId:id};s.lockedColumns=(s.lockedColumns||[]).filter(c=>c!==0);s.calculatedColumns=(s.calculatedColumns||[]).filter(c=>c!==0);s.headers[0].calculated=false;s.whiteLockedColumns=(s.whiteLockedColumns||[]).filter(c=>c!==0);}
 for(const t of independentTables.filter(t=>t.averageColumns)){
  for(const c of [t.averageColumns.w,t.weightedColumns.w]){for(const key of ['zeroDecimalColumns','decimalColumns','threeDecimalColumns','fourDecimalColumns','fiveDecimalColumns'])t[key]=(t[key]||[]).filter(x=>x!==c);t.oneDecimalColumns=[...new Set([...(t.oneDecimalColumns||[]),c])];}
 }
}
function identityEquation250(table,column,project,row){
 if(table.apacheControllersCalculation&&column===0)return '=XLOOKUP(@[Zone],[Room/Zone Loads Report]@[Zone],[Room/Zone Loads Report]@[Zone Group],"")';
 if(table.apacheControllersCalculation&&column===1)return '=@[Zone]';
 const label=table.headers[column]?.label,space=table.spaceColumn??table.headers.findIndex(h=>h.label==='Space'),z='[Equipment Zoning]',eq='@[Equipment]';
 if(table.id.startsWith('selected-')&&table.dropdownColumns?.[column]?.sourceTableId==='calc-space-condition-setpoints')return '=Userinput()';
 if((label==='Zone'||label==='Zone Group')&&space>=0&&!table.apacheControllersCalculation)return `=XLOOKUP(@[Space],${table.equipmentZoningCalculation?'[Room/Zone Loads Report]':z}@[Space],${table.equipmentZoningCalculation?'[Room/Zone Loads Report]':z}@[${label}],"")`;
 if(table.thermalTemplateCalculation&&column===0)return '=@[Thermal Template]';
 if(column===space&&space>=0&&!table.id.startsWith('selected-')){
  if(table.systemAirBalanceMode){const type=Object.entries(SYSTEM_TYPES186).find(([k,v])=>systemMode186(v)===table.systemAirBalanceMode)?.[1];return `=FILTER(@[Space],XLOOKUP(@[Space],${z}@[Space],${z}@[System Type],"")="${type}","")`;}
  return '=@[Space]';
 }
 if(column!==0||!table.airsideSection)return null;
 if(table.airsideSettingsCalculation){const fields=['Ventilation Equipment','Central Equipment','Supply Air Valve','Reheat Coil','Exhaust Equipment','General Exhaust Valve','Cooling Equipment','Heating Equipment'];return `=LET(equipment,VSTACK(${fields.map(f=>`${z}@[${f}]`).join(',')},FILTER([Exhaust Equipment Requirements]@[Exhaust Equipment],COUNTIF(${z}@[Space],[Exhaust Equipment Requirements]@[Space])>0,""),FILTER([Exhaust Equipment Requirements]@[Exhaust Valve],COUNTIF(${z}@[Space],[Exhaust Equipment Requirements]@[Space])>0,"")),UNIQUE(FILTER(equipment,(equipment<>"")*(equipment<>"-"),"")))`;}
 if(table.equipmentAirflowsCalculation)return '='+eq;
 if(table.equipmentScheduleCalculation)return `=LET(equipment,${eq},quantity,XLOOKUP(equipment,[Settings]@[Equipment],[Settings]@[Quantity],0),airflow,XLOOKUP(equipment,[Airflows]@[Equipment],[Airflows]@[Supply Maximum Airflow],0),heating,XLOOKUP(equipment,[Airflows]@[Equipment],[Airflows]@[Design Heating Airflow],0),IF(OR(airflow<>0,heating<>0),IF(quantity>=1,IF(SEQUENCE(FLOOR(quantity,1))<=quantity,equipment,""),""),""))`;
 let condition;
 if(table.mixedAirCalculation)condition=`(XLOOKUP(${eq},[Settings]@[Equipment],[Settings]@[Economizer],"")<>"")*(COUNTIF(${z}@[Ventilation Equipment],${eq})>0)`+(table.mixedAirHeating?`*(XLOOKUP(${eq},[Settings]@[Equipment],[Settings]@[Preheat Coil],"")="TRUE")`:'');
 else if(table.coilCalculation==='preheat'||table.coilCalculation==='ventilation-cooling')condition=`XLOOKUP(${eq},[Settings]@[Equipment],[Settings]@[${table.coilCalculation==='preheat'?'Preheat Coil':'Ventilation Cooling Coil'}],"")="TRUE"`;
 else if(table.coilCalculation==='in-unit-reheat')condition=`XLOOKUP(${eq},[Settings]@[Equipment],[Settings]@[Associated Equipment],"")="In-Unit RHC"`;
 else if(table.coilCalculation==='downstream-reheat'||table.coilCalculation==='room-air-heating')condition=`COUNTIF(${z}@[${table.coilCalculation==='downstream-reheat'?'Reheat Coil':'Heating Equipment'}],${eq})>0`;
 else if(table.coilCalculation==='room-air-cooling')condition=`((COUNTIF(${z}@[Central Equipment],${eq})+COUNTIF(${z}@[Cooling Equipment],${eq}))>0)*(COUNTIF(${z}@[Ventilation Equipment],${eq})=0)`;
 return condition?`=FILTER(${eq},${condition},"")`:'='+eq;
}
function spaceChoiceRecords250(project,config){
 return sourceSpaceChoices(workbookTable(config.spaceTableId),project).map(({space,group})=>({value:space,label:space,group}));
}

function psychPlotLines250(lines,pressure){return lines.map(line=>({color:psychLineStyle(line).color,dashed:!!(line.mixing||psychLineStyle(line).dashed),width:line.mixing?1.7:3.5,arrowScale:line.mixing?.6:1,points:(line.cooling?psychCoolingPath(line.enter,line.leave,pressure):[line.enter,line.leave]).map(p=>psychChartPoint(p.db,p.hr))}));}
function psychMarkers250(lines){
 const markers=psychStateMarkers(lines);
 for(const m of markers){const same=s=>Math.abs(s.db-m.db)<1e-5&&Math.abs(s.hr-m.hr)<1e-7;m.mixed=lines.some(l=>l.mixing&&(same(l.enter)||same(l.leave)));m.coil=lines.some(l=>!l.mixing&&(same(l.enter)||same(l.leave)));m.coilEnter=lines.some(l=>!l.mixing&&same(l.enter));m.radius=m.coilEnter?9.5:5.15;m.innerRadius=6;m.splitColors=lines.find(l=>l.mixing&&same(l.leave))?.splitColors;}
 return markers;
}
function drawPsychProcesses250(svg,lines,pressure){
 const ns='http://www.w3.org/2000/svg',group=document.createElementNS(ns,'g');group.classList.add('psych-processes');svg.append(group);
 const add=(tag,attrs)=>{const n=document.createElementNS(ns,tag);for(const[k,v]of Object.entries(attrs))n.setAttribute(k,String(v));group.append(n);return n;};
 const markers=psychMarkers250(lines),geometry=psychProcessGeometry(psychPlotLines250(lines,pressure),markers),path=points=>points.map((p,i)=>`${i?'L':'M'}${p.x},${p.y}`).join(' ')+' Z';
 for(const s of geometry.strokes)add('line',{x1:s.a.x,y1:s.a.y,x2:s.b.x,y2:s.b.y,stroke:s.color,'stroke-width':s.width,...(s.dashed?{'stroke-dasharray':'7 5','stroke-dashoffset':s.dashOffset||0}:{})});
 for(const arrow of geometry.arrows){for(const band of arrow.bands)add('path',{d:path(band.points),fill:band.color});add('path',{d:path(arrow.points),fill:'none',stroke:'white','stroke-width':.8});}
 for(const m of markers){const p=psychChartPoint(m.db,m.hr),r=m.radius,inner=m.innerRadius||6;
  if(m.leave.length){const colors=m.splitColors||m.leave;for(let i=0;i<colors.length;i++){const offset=m.splitColors?-3*Math.PI/4:0,a=offset+i*2*Math.PI/colors.length,b=offset+(i+1)*2*Math.PI/colors.length;if(colors.length===1)add('circle',{cx:p.x,cy:p.y,r:inner,fill:colors[i]});else add('path',{d:`M${p.x},${p.y} L${p.x+inner*Math.cos(a)},${p.y+inner*Math.sin(a)} A${inner},${inner} 0 ${b-a>Math.PI?1:0} 1 ${p.x+inner*Math.cos(b)},${p.y+inner*Math.sin(b)} Z`,fill:colors[i]});}}
  const colors=m.enter;
  colors.forEach((color,i)=>{if(colors.length===1)add('circle',{cx:p.x,cy:p.y,r,fill:'none',stroke:color,'stroke-width':m.coilEnter?3:1.7});else{const a=i*2*Math.PI/colors.length,b=(i+1)*2*Math.PI/colors.length;add('path',{d:`M${p.x+r*Math.cos(a)},${p.y+r*Math.sin(a)} A${r},${r} 0 ${b-a>Math.PI?1:0} 1 ${p.x+r*Math.cos(b)},${p.y+r*Math.sin(b)}`,fill:'none',stroke:color,'stroke-width':m.coilEnter?3:1.7});}});
 }
}

function resetPsychRoute251(){
 const project=activeProject();
 if(location.hash.startsWith('#psych-chart-')&&!(project?.psychChartEquipment||[]).some(tag=>'#psych-chart-'+slugify(tag)===location.hash))history.replaceState(null,'','#section-psychrometric-calculations');
 syncPsychChartSelections(project);
}
function alignMixedPsych251(mixed){
 const table=mixed?.element?.querySelector('table');if(!table?.isConnected)return;
 const coil=referenceTable,groups=[...coil.querySelectorAll('.group-header-row th')];if(groups.length!==4)return;
 const widths=groups.map(g=>g.getBoundingClientRect().width),total=widths.reduce((a,b)=>a+b,0);
 table.style.tableLayout='fixed';table.style.width=total+'px';table.style.minWidth=total+'px';table.style.setProperty('--first-column-width',widths[0]+'px');
 [...table.querySelectorAll('col')].forEach((col,i)=>{col.style.setProperty('width',(i===0?widths[0]:widths[1+Math.floor((i-1)/4)]/4)+'px','important');});
 const rowHeight=coil.tBodies[0]?.rows[0]?.getBoundingClientRect().height;
 const rows=[...table.tBodies[0].rows];rows.forEach(row=>{if(rowHeight)row.style.height=rowHeight+'px';});
 const scroll=table.parentElement;scroll.querySelector('.psych-mixing-outlines')?.remove();
 const ns='http://www.w3.org/2000/svg',svg=document.createElementNS(ns,'svg'),box=table.getBoundingClientRect();svg.classList.add('psych-mixing-outlines');svg.setAttribute('width',box.width);svg.setAttribute('height',box.height);
 rows.forEach((row,i)=>{for(const g of mixedPsychRows(mixed)[i].outlineGroups){const a=row.cells[g.start].getBoundingClientRect(),b=row.cells[g.end].getBoundingClientRect(),rect=document.createElementNS(ns,'rect');rect.setAttribute('x',a.left-box.left+4);rect.setAttribute('y',a.top-box.top+3);rect.setAttribute('width',b.right-a.left-8);rect.setAttribute('height',a.height-6);rect.setAttribute('rx',6);rect.setAttribute('fill','none');rect.setAttribute('stroke',g.color);rect.setAttribute('stroke-width',3);if(g.dashed)rect.setAttribute('stroke-dasharray','7 5');if(g.splitColors){const xx=a.left-box.left+4,yy=a.top-box.top+3,w=b.right-a.left-8,h=a.height-6;for(const [j,d]of splitOutlinePaths255(w,h,6).entries()){const line=document.createElementNS(ns,'path');line.setAttribute('d',d);line.setAttribute('transform',`translate(${xx} ${yy})`);line.setAttribute('fill','none');line.setAttribute('stroke',g.splitColors[j]);line.setAttribute('stroke-width',3);line.setAttribute('stroke-linecap','butt');svg.append(line);}}else svg.append(rect);}});scroll.append(svg);const shared=coil.closest('.table-scroll');const clip=()=>{svg.style.clipPath=`inset(0 0 0 ${widths[0]+shared.scrollLeft}px)`;};shared.onscroll=clip;clip();
}

function psychSymbolHeader253(label){return {label:label==='V̇'?'V':label,overdot:label==='V̇',subscripts:/^(TDB|TWB|Cs|Cl|Qs|Ql|Qt)$/.test(label)?Array.from({length:label.length-1},(_,i)=>i+1):[]};}

function splitOutlinePaths255(w,h,r){
 return [`M${r/4},${r/4} Q${r/2},0 ${r},0 H${w-r} Q${w},0 ${w},${r} V${h-r} Q${w},${h-r/2} ${w-r/4},${h-r/4}`,
 `M${w-r/4},${h-r/4} Q${w-r/2},${h} ${w-r},${h} H${r} Q0,${h} 0,${h-r} V${r} Q0,${r/2} ${r/4},${r/4}`];
}
