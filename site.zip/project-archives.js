/* Archives are immutable stored snapshots; calculations run on a disposable view copy. */
let archiveView=null;
let archiveOperationPending=false;
const expandedArchiveProjects=new Set();
function isProjectArchive(){return Boolean(archiveView);}
function archiveDatabase(){
  return new Promise((resolve,reject)=>{const request=indexedDB.open('hvac-project-archives',1);request.onupgradeneeded=()=>{const db=request.result;if(!db.objectStoreNames.contains('snapshots'))db.createObjectStore('snapshots',{keyPath:'id'});};request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error);});
}
async function archiveStorage(operation,value){
  const db=await archiveDatabase();try{return await new Promise((resolve,reject)=>{const tx=db.transaction('snapshots',operation==='get'?'readonly':'readwrite'),store=tx.objectStore('snapshots'),request=operation==='get'?store.get(value):store.put(value);let result;request.onsuccess=()=>{result=request.result;};tx.oncomplete=()=>resolve(result);tx.onerror=()=>reject(tx.error||request.error);tx.onabort=()=>reject(tx.error||Error('Archive transaction cancelled.'));});}finally{db.close();}
}
function archiveTimestamp(value){return new Intl.DateTimeFormat(undefined,{year:'numeric',month:'short',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit'}).format(new Date(value));}
async function storeProjectSnapshot(master){
  const snapshot=structuredClone(master);delete snapshot.archiveEntries;delete snapshot.archives;
  if(snapshot.dateMode==='today'){snapshot.date=localToday();snapshot.dateMode='fixed';}
  const record={id:createProjectId(),projectId:master.id,createdAt:new Date().toISOString(),project:snapshot};await archiveStorage('put',record);return {id:record.id,createdAt:record.createdAt};
}
function updateArchiveControls(message=''){
  const button=document.querySelector('#archive-project');if(!button)return;
  button.textContent=isProjectDeleted()?'Restore':isProjectArchive()?'Restore':projectViewOnly?(serverLeaseStatus?.owner&&serverLeaseStatus.owner!==projectControlOwner?'Request Control':'Take Control'):'Archive';button.classList.toggle('restore-archive',isProjectArchive());button.disabled=archiveOperationPending;
  const status=document.querySelector('#archive-status');if(status){status.textContent=message||(archiveView?`Read-only archive · ${archiveTimestamp(archiveView.createdAt)}`:projectControlMessage);status.classList.toggle('archive-error',Boolean(message));}
  document.body.classList.toggle('archive-readonly',isProjectArchive());document.body.classList.toggle('workbook-readonly',isWorkbookReadOnly());
  document.body.classList.toggle('view-only',!isProjectArchive()&&!isProjectDeleted()&&projectViewOnly);document.body.classList.toggle('deleted-readonly',isProjectDeleted());updateControlCountdowns();
  const identity=document.querySelector('.browser-product-title');
  if(identity){identity.replaceChildren();for(const text of isProjectDeleted()?['DELETED',archiveTimestamp(projects.find(p=>p.id===activeProjectId).deletedAt),'Restore To Edit']:archiveView?['ARCHIVE',archiveTimestamp(archiveView.createdAt),'Restore To Edit']:projectViewOnly?['VIEW ONLY','Take/Request Control to Edit']:['HVAC Design','Workbook']){const line=document.createElement('strong');line.textContent=text;identity.appendChild(line);}}
}
async function archiveOrRestoreProject(){
  if(isProjectDeleted()){await requestDeletedProjectRestore();return;}
  if(projectViewOnly&&!archiveView){if(serverLeaseStatus?.owner&&serverLeaseStatus.owner!==projectControlOwner)await requestProjectControl();else await takeProjectControl();return;}
  if(archiveView){const savedView=archiveView;archiveView=null;const acquired=await takeProjectControl();archiveView=savedView;if(!acquired){updateArchiveControls();return;}}
  if(archiveOperationPending)return;archiveOperationPending=true;updateArchiveControls();
  const index=projects.findIndex(p=>p.id===activeProjectId),master=projects[index],oldView=archiveView;let replacement;
  try{
    if(!master)throw Error('Select a project first.');
    const entry=await storeProjectSnapshot(master),entries=[...(master.archiveEntries||[]),entry];
    replacement=oldView?Object.assign(structuredClone(oldView.snapshot),{id:master.id,number:master.number,archiveEntries:entries}):{...master,archiveEntries:entries};
    projects[index]=replacement;archiveView=null;
    const previousHistory=applyingHistory;applyingHistory=true;try{saveProjects();}finally{applyingHistory=previousHistory;}
    if(oldView){undoStack.length=0;redoStack.length=0;}
    expandedArchiveProjects.add(master.id);selectedTableCells.clear();cellSelectionAnchor=null;fillProjectFields();renderProjectList();renderTree(search.value);
  }catch(error){if(replacement)projects[index]=master;archiveView=oldView;if(oldView){releaseProjectControl();projectViewOnly=true;}updateArchiveControls(`Unable to save the archive: ${error.message}`);return;}
  finally{archiveOperationPending=false;const button=document.querySelector('#archive-project');if(button)button.disabled=false;}
  updateArchiveControls();applyArchiveReadOnly();
}
async function openProjectArchive(projectId,archiveId){
  if(projects.find(p=>p.id===projectId)?.deletedAt)return;
  if(archiveOperationPending)return;archiveOperationPending=true;updateArchiveControls();
  try{const saved=await archiveStorage('get',archiveId);if(!saved||saved.projectId!==projectId)throw Error('This archive is unavailable.');
    releaseProjectControl();projectViewOnly=true;viewOnlyProject=null;undoStack.length=0;redoStack.length=0;
    activeProjectId=projectId;archiveView={id:saved.id,createdAt:saved.createdAt,snapshot:structuredClone(saved.project),view:structuredClone(saved.project)};
    expandedArchiveProjects.add(projectId);selectedTableId='';selectedTableRowIndexes.clear();selectedTableCells.clear();cellSelectionAnchor=null;clearSelectedEquation();
    fillProjectFields();renderProjectList();renderTree(search.value);updateArchiveControls();applyArchiveReadOnly();
  }catch(error){updateArchiveControls(`Unable to open the archive: ${error.message}`);}
  finally{archiveOperationPending=false;const button=document.querySelector('#archive-project');if(button)button.disabled=false;}
}
function renderProjectArchiveList(query=''){
  const pins=pinnedProjectIds(),showDeleted=document.querySelector('#show-deleted-projects')?.checked||false;
  const matches=projects.filter(p=>projectListMatches(p,query,showDeleted)).sort((a,b)=>Number(pins.has(b.id))-Number(pins.has(a.id)));projectList.replaceChildren();
  if(!matches.length){const p=document.createElement('p');p.className='project-list-empty';p.textContent='No projects match this search.';projectList.appendChild(p);}
  for(const project of matches){
    const group=document.createElement('div'),row=document.createElement('div'),button=document.createElement('button');group.className='project-archive-group';row.className='project-master-row';row.classList.toggle('deleted-project',Boolean(project.deletedAt));button.type='button';button.className='project-list-item';button.classList.toggle('active',project.id===activeProjectId&&!isProjectArchive());
    const number=document.createElement('strong'),name=document.createElement('span');number.textContent=project.number;name.textContent=project.deletedAt?'Deleted: '+archiveTimestamp(project.deletedAt):project.name||'Untitled project';button.append(number,name);button.onclick=()=>selectProject(project.id);
    row.addEventListener('contextmenu',e=>{e.preventDefault();if(!project.deletedAt)showProjectContextMenu(e,project.id);});
    if(!project.deletedAt){
      const pin=document.createElement('button');pin.type='button';pin.className='project-pin';pin.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 3h6l-1 7 4 4v2h-5v6h-2v-6H6v-2l4-4z"/></svg>';pin.setAttribute('aria-pressed',String(pins.has(project.id)));pin.setAttribute('aria-label',(pins.has(project.id)?'Unpin ':'Pin ')+project.number);pin.title=pin.getAttribute('aria-label');pin.onclick=()=>toggleProjectPin(project.id);
      const arrow=document.createElement('button');arrow.type='button';arrow.className='project-archive-toggle';arrow.innerHTML='<svg viewBox="0 0 20 20" aria-hidden="true"><path d="m7 4 6 6-6 6"/></svg>';const expanded=expandedArchiveProjects.has(project.id);arrow.setAttribute('aria-expanded',String(expanded));arrow.setAttribute('aria-label',(expanded?'Hide':'Show')+' archives for '+project.number);arrow.onclick=()=>{expanded?expandedArchiveProjects.delete(project.id):expandedArchiveProjects.add(project.id);renderProjectList();};
      const editor=document.createElement('div');editor.className='project-editor';const label=document.createElement('span');label.textContent='Editor';editor.append(label,createUserPlaceholder('Project editor'));row.append(pin,arrow,button,editor);
      if(expanded){const list=document.createElement('div');list.className='project-archive-children';for(const entry of [...(project.archiveEntries||[])].reverse()){const item=document.createElement('button');item.type='button';item.className='project-archive-item';item.textContent=archiveTimestamp(entry.createdAt);item.title='Open read-only archive';item.classList.toggle('active',archiveView?.id===entry.id&&activeProjectId===project.id);item.onclick=()=>openProjectArchive(project.id,entry.id);item.oncontextmenu=e=>e.preventDefault();list.appendChild(item);}if(!list.children.length){const empty=document.createElement('p');empty.textContent='No archived submittals';list.appendChild(empty);}group.append(row,list);}else group.appendChild(row);
    }else{row.appendChild(button);group.appendChild(row);}projectList.appendChild(group);
  }updateArchiveControls();
}
function archiveMutableTarget(node){
  if(!node?.closest)return false;
  if(node.closest('#restore-auto-value,#copy-table-data,#export-equipment-schedules,#export-co2-monitoring,.schedule-export-button,.psych-equipment-picker,.psych-picker-popup,.space-filter,.filter-popover,.cell-dropdown-popup,#table-search,.formula-evaluator,#formula-function-view,.model-input-formula,#formula-function-detail'))return false;
  return Boolean(node.closest('#reference-table,.co2-criteria,.model-inputs-view,.equipment-zoning-view,.airside-system-view,.top-project-fields,#table-settings,#calculation-documentation,.clipboard-actions,.excel-actions,.row-actions,.cell-note-editor'));
}
function applyArchiveReadOnly(){
  const readonly=isWorkbookReadOnly();document.body.classList.toggle('archive-readonly',isProjectArchive());document.body.classList.toggle('workbook-readonly',isWorkbookReadOnly());
  document.querySelectorAll('[data-archive-disabled]').forEach(n=>{n.disabled=n.dataset.archiveDisabled==='true';delete n.dataset.archiveDisabled;});
  document.querySelectorAll('[data-archive-readonly]').forEach(n=>{n.readOnly=n.dataset.archiveReadonly==='true';delete n.dataset.archiveReadonly;});
  if(readonly){
    document.querySelectorAll('.work-area input,.work-area select,.work-area textarea,.top-project-fields input').forEach(n=>{if(!archiveMutableTarget(n))return;if(n.tagName==='SELECT'||['checkbox','file'].includes(n.type)){if(n.dataset.archiveDisabled===undefined)n.dataset.archiveDisabled=String(n.disabled);n.disabled=true;}else{n.dataset.archiveReadonly=String(n.readOnly);n.readOnly=true;}});
    document.querySelectorAll('#add-table-row,#remove-table-row,#paste-table-data,#import-excel,.documentation-heading button,.construction-add,.construction-remove,.work-area .action-add,.work-area .action-remove,.work-area .action-import,.work-area .action-paste,#reference-table .cell-dropdown-arrow,#add-spaces-control').forEach(n=>{if(n.dataset.archiveDisabled===undefined)n.dataset.archiveDisabled=String(n.disabled);n.disabled=true;});
    referenceTable.querySelectorAll('tbody td').forEach(cell=>{cell.startCellEdit=()=>{};cell.editOnClick=false;cell.setAttribute('aria-readonly','true');});clearFillHandle();
  }
  document.querySelectorAll('[data-project-field]').forEach(n=>{n.readOnly=readonly||n.dataset.projectField==='number'||n.dataset.projectField==='date'&&activeProject()?.dateMode==='today';});
  const table=independentTables.find(t=>t.id===activeTableId);if(table){addTableRowButton.disabled=readonly||Boolean(table.fixedRows);if(!readonly)delete addTableRowButton.dataset.archiveDisabled;}
  updateArchiveControls();
}
function selectWholeTableColumn(event){
  const cell=event.target.closest?.('#reference-table tbody td')||(!document.activeElement?.matches('input,textarea')&&activeCellSelection?.tableId===activeTableId?referenceTable.querySelector(`tbody tr[data-source-index="${activeCellSelection.sourceIndex}"] td[data-column-index="${activeCellSelection.columnIndex}"]`):null);
  if(!cell||cell.isContentEditable||event.target.closest?.('.table-inline-editor,.dropdown-inline-editor'))return false;
  const column=Number(cell.dataset.columnIndex);if(!Number.isInteger(column))return false;event.preventDefault();event.stopImmediatePropagation();
  selectedTableId=activeTableId;selectedTableCells=new Set([...referenceTable.querySelectorAll('tbody tr[data-source-index]')].filter(r=>!r.hidden&&workbookCell(r,column)?.style.display!=='none').map(r=>`${r.dataset.sourceIndex}:${column}`));selectedTableRowIndexes.clear();
  cellSelectionAnchor={sourceIndex:Number(cell.dataset.sourceIndex),columnIndex:column};activeCellSelection={tableId:activeTableId,...cellSelectionAnchor};wholeColumnSelection={tableId:activeTableId,anchorColumn:column,edgeColumn:column};refreshSelectedTableCells();clearFillHandle();return true;
}
function initializeArchiveUI(){
  document.querySelector('#archive-project').addEventListener('click',archiveOrRestoreProject);
  // A window capture guard runs before any table editor, paste, or restore handler.
  for(const type of ['beforeinput','input','change','paste','cut','keydown','click','dblclick','pointerdown'])window.addEventListener(type,event=>{
    if(!isWorkbookReadOnly())return;
    const target=event.target;
    if(target.closest?.('#restore-auto-value')&&typeof selectedAutoRestore==='function'){event.preventDefault();event.stopImmediatePropagation();return;}
    if(target.closest?.('.evaluate-model-formula')&&target.closest('.model-input-formula')?.restoreAutomatic){event.preventDefault();event.stopImmediatePropagation();return;}
    if(!archiveMutableTarget(target))return;
    const cell=target.closest?.('#reference-table tbody td');
    if(['click','pointerdown','dblclick'].includes(type)){
      if(cell&&!target.closest('button,.cell-note-flag,.cell-dropdown-arrow')){cell.editOnClick=false;cell.startCellEdit=()=>{};return;}
      if(target.closest('.column-sort-button,.column-sort-control,.header-link,.group-header-link,.calculated-value,.summary-equation-cell,#table-metric')||target.closest('#reference-table thead'))return;
      if(target.closest('button,.cell-note-flag,.cell-dropdown-arrow,select,input[type=checkbox]')){event.preventDefault();event.stopImmediatePropagation();}
      return;
    }
    if(type==='keydown'){
      if((event.ctrlKey||event.metaKey)&&['c','a',' ','Space'].includes(event.key.toLowerCase())||['ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Tab','Escape'].includes(event.key))return;
      if(event.key==='Enter'&&cell)return;
    }
    event.preventDefault();event.stopImmediatePropagation();
  },true);
}

// Shared editing uses an authenticated host lease API. Static hosting retains
// explicitly browser-local coordination, without authenticated heartbeat claims.
let projectViewOnly=true,viewOnlyProject=null;
let lastWorkbookActivity=Date.now(),lastHeartbeatSuccess=0,connectivityLostAt=null,heartbeatPending=false;
let projectControlMessage='',serverLease=null,serverLeaseGeneration=0,serverLeaseStatus=null;
const projectControlOwner=crypto.randomUUID();
const CONTROL_HEARTBEAT_MS=15000,CONTROL_DISCONNECT_MS=60000,CONTROL_IDLE_MS=30*60000;
function isWorkbookReadOnly(){return isProjectArchive()||projectViewOnly||isProjectDeleted();}
function leaseService(){return window.WorkbookLeaseAPI||null;}
function controlLeaseKey(id=activeProjectId){return 'hvac-project-editor-v1:'+id;}
function readControlLease(){if(leaseService())return serverLeaseStatus;try{return JSON.parse(localStorage.getItem(controlLeaseKey())||"null");}catch{return null;}}
function ownsProjectControl(){if(projectViewOnly||serverLease?.projectId!==activeProjectId||serverLease.owner!==projectControlOwner)return false;if(serverLease.mode==="local"){const held=readControlLease();return held?.owner===projectControlOwner&&Date.now()-held.at<CONTROL_DISCONNECT_MS;}return Date.now()-lastHeartbeatSuccess<CONTROL_DISCONNECT_MS;}
function releaseProjectControl(){const lease=serverLease;serverLease=null;serverLeaseGeneration++;serverLeaseStatus=null;if(lease?.mode==="local"){try{const held=JSON.parse(localStorage.getItem(controlLeaseKey(lease.projectId))||"null");if(held?.owner===lease.owner)localStorage.removeItem(controlLeaseKey(lease.projectId));}catch{}}if(lease&&leaseService()?.release)Promise.resolve(leaseService().release({...lease})).catch(()=>{});}
function refreshStoredProjects(){if(!isWorkbookReadOnly()||workbookStorage.dirty.size)return;const saved=workbookStorage.catalog();if(saved.length)projects=saved;}
function enterProjectViewOnly(message='',render=false){
 if(!projectViewOnly&&!archiveView){document.activeElement?.blur?.();workbookStorage.save(projects);}
 releaseProjectControl();projectViewOnly=true;projectControlMessage=message;
 const master=projects.find(p=>p.id===activeProjectId)||projects[0];viewOnlyProject=master?structuredClone(master):null;
 if(render){closeCellDropdown();document.querySelectorAll('.table-inline-editor,.dropdown-inline-editor,.cell-note-editor').forEach(n=>n.remove());clearSelectedEquation();undoStack.length=0;redoStack.length=0;fillProjectFields();renderTree(search.value);renderProjectList();applyArchiveReadOnly();renderChangeLog();}
}
async function probeWorkbookConnectivity(){return false;} // Never an authenticated lease acknowledgment.
async function refreshServerLeaseStatus(){const api=leaseService(),id=activeProjectId;if(!api){serverLeaseStatus=readControlLease();updateArchiveControls();return;}if(!api.status)return;try{const result=await api.status({projectId:id});if(id!==activeProjectId)return;serverLeaseStatus=result;updateArchiveControls();}catch{}}
async function takeProjectControl(){
 if(isProjectDeleted()||archiveOperationPending)return false;
 const requestedProject=activeProjectId;await workbookStorage.reload();if(requestedProject!==activeProjectId)return false;
 const api=leaseService();if(!api)return takeLocalProjectControl();if(!api?.acquire||!api?.heartbeat||!api?.release){projectControlMessage='Editing service is unavailable. The project remains View Only.';updateArchiveControls();return false;}
 const id=activeProjectId,generation=++serverLeaseGeneration;archiveOperationPending=true;updateArchiveControls();
 try{
  const result=await api.acquire({projectId:id,owner:projectControlOwner,idleMs:CONTROL_IDLE_MS,disconnectMs:CONTROL_DISCONNECT_MS});
  if(id!==activeProjectId||generation!==serverLeaseGeneration){if(result?.acquired&&result.leaseToken)await api.release({projectId:id,owner:projectControlOwner,leaseToken:result.leaseToken});return false;}
  if(!result?.acquired){serverLeaseStatus=result;projectControlMessage=result?.owner?'Another editor holds control. Use Request Control.':'Editing control was not granted.';return false;}
  if(!result.leaseToken||result.owner!==projectControlOwner||result.projectId!==id)throw Error('Editing service returned an invalid lease acknowledgment.');
  serverLease={projectId:id,owner:projectControlOwner,leaseToken:result.leaseToken};serverLeaseStatus={...serverLease};refreshStoredProjects();archiveView=null;projectViewOnly=false;viewOnlyProject=null;lastWorkbookActivity=lastHeartbeatSuccess=Date.now();connectivityLostAt=null;projectControlMessage='';fillProjectFields();renderTree(search.value);renderProjectList();applyArchiveReadOnly();return true;
 }catch(error){projectControlMessage='Unable to acquire editing control: '+error.message;return false;}finally{archiveOperationPending=false;updateArchiveControls();}
}
async function requestProjectControl(){const api=leaseService();if(!api?.requestControl){projectControlMessage='The editing service does not provide Request Control.';updateArchiveControls();return false;}try{await api.requestControl({projectId:activeProjectId,requester:projectControlOwner});projectControlMessage='Control requested from the current editor.';updateArchiveControls();return true;}catch(error){projectControlMessage='Unable to request control: '+error.message;updateArchiveControls();return false;}}
function enforceProjectControlTimeouts(now=Date.now()){
 updateControlCountdowns(now);if(isWorkbookReadOnly())return;let reason='';
 if(now-lastWorkbookActivity>=CONTROL_IDLE_MS)reason='View Only after 30 minutes without editing activity.';
 else if(serverLease?.mode!=="local"&&now-lastHeartbeatSuccess>=CONTROL_DISCONNECT_MS)reason='View Only after 60 seconds without an authenticated heartbeat acknowledgment.';
 else if(!serverLease||serverLease.projectId!==activeProjectId||serverLease.mode==='local'&&!ownsProjectControl())reason='Editing control is no longer held by this window.';
 if(reason){enterProjectViewOnly(reason,true);}
}
async function projectControlHeartbeat(){
 if(heartbeatPending||isWorkbookReadOnly()||!serverLease)return;
 if(serverLease.mode==="local"){try{if(ownsProjectControl())localStorage.setItem(controlLeaseKey(),JSON.stringify({...serverLease,at:Date.now()}));}catch{enterProjectViewOnly('Local editing lease could not be renewed.',true);}enforceProjectControlTimeouts();return;}
 heartbeatPending=true;
 const lease={...serverLease},generation=serverLeaseGeneration;
 try{const result=await leaseService().heartbeat({...lease,lastActivityAt:lastWorkbookActivity});if(generation!==serverLeaseGeneration||lease.projectId!==activeProjectId)return;
  if(result?.acknowledged&&result.owner===lease.owner&&result.projectId===lease.projectId&&result.leaseToken===lease.leaseToken){lastHeartbeatSuccess=Date.now();connectivityLostAt=null;}
  else if(result?.revoked){enterProjectViewOnly('Editing control was released by the server.',true);return;}
  else connectivityLostAt??=lastHeartbeatSuccess;
 }catch{if(generation===serverLeaseGeneration)connectivityLostAt??=lastHeartbeatSuccess;}
 finally{heartbeatPending=false;enforceProjectControlTimeouts();}
}
function createUserPlaceholder(label){const circle=document.createElement('span');circle.className='user-photo-placeholder';circle.setAttribute('role','img');circle.setAttribute('aria-label',label+' placeholder');circle.title=label;return circle;}
function pinnedProjectIds(){try{return new Set(JSON.parse(localStorage.getItem('hvac-pinned-projects-v1')||'[]'));}catch{return new Set();}}
function toggleProjectPin(id){const pins=pinnedProjectIds();pins.has(id)?pins.delete(id):pins.add(id);localStorage.setItem('hvac-pinned-projects-v1',JSON.stringify([...pins]));renderProjectList();}
function initializeProjectControl(){
 let lastMouseActivity=0;document.addEventListener('pointermove',()=>{const now=Date.now();if(now-lastMouseActivity>=1000){lastMouseActivity=now;noteQualifyingEdit();}},{passive:true});
 for(const type of ['pointerdown','keydown','selectionchange','click'])document.addEventListener(type,noteQualifyingEdit,{capture:true,passive:true});
 document.addEventListener("input",event=>{if(event.target.closest?.(".construction-grid input,.top-project-fields input,.table-inline-editor,.dropdown-inline-editor,.cell-note-editor input,.cell-note-editor textarea,.workbook-reference-table input,[data-model-input],#minimum-input,#two-value-schedule"))noteQualifyingEdit();},{capture:true});
 applyArchiveReadOnly();setInterval(projectControlHeartbeat,CONTROL_HEARTBEAT_MS);setInterval(enforceProjectControlTimeouts,100);
 window.addEventListener('online',projectControlHeartbeat);window.addEventListener('pagehide',releaseProjectControl);
 document.addEventListener('visibilitychange',()=>{if(!document.hidden){if(projectViewOnly&&!archiveView)workbookStorage.reload().then(()=>{if(projectViewOnly&&!archiveView){refreshStoredProjects();enterProjectViewOnly('',true);}});enforceProjectControlTimeouts();projectControlHeartbeat();refreshServerLeaseStatus();}});
 window.addEventListener('storage',event=>{if(event.key===controlLeaseKey()){enforceProjectControlTimeouts();refreshServerLeaseStatus();}else if(event.key==='hvac-pinned-projects-v1')renderProjectList();else if((event.key===PROJECTS_KEY||event.key==='hvac-projects-revision')&&projectViewOnly&&!archiveView){workbookStorage.reload().then(()=>{if(projectViewOnly&&!archiveView){refreshStoredProjects();enterProjectViewOnly('',true);}});}});refreshServerLeaseStatus();
}
