/* Archives are immutable stored snapshots; calculations run on a disposable view copy. */
let archiveView=null;
let archiveOperationPending=false;
const expandedArchiveProjects=new Set();
function isProjectArchive(){return Boolean(archiveView);}
function archiveDatabase(){
  return new Promise((resolve,reject)=>{const request=indexedDB.open('hvac-project-archives',1);request.onupgradeneeded=()=>{const db=request.result;if(!db.objectStoreNames.contains('snapshots'))db.createObjectStore('snapshots',{keyPath:'id'});};request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error);});
}
async function archiveStorage(operation,value){
  const db=await archiveDatabase();try{return await new Promise((resolve,reject)=>{const tx=db.transaction('snapshots',operation==='get'?'readonly':'readwrite'),store=tx.objectStore('snapshots'),request=operation==='get'?store.get(value):store.put(value);let result;request.onsuccess=()=>{result=request.result;};tx.oncomplete=()=>resolve(result);tx.onerror=()=>reject(tx.error||request.error);tx.onabort=()=>reject(tx.error||Error('Archive transaction cancelled.'));});}finally{db.close();}
}
function archiveTimestamp(value){return new Intl.DateTimeFormat(undefined,{year:'numeric',month:'short',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit'}).format(new Date(value));}
async function storeProjectSnapshot(master){
  const snapshot=structuredClone(master);delete snapshot.archiveEntries;delete snapshot.archives;
  if(snapshot.dateMode==='today'){snapshot.date=localToday();snapshot.dateMode='fixed';}
  const record={id:createProjectId(),projectId:master.id,createdAt:new Date().toISOString(),project:snapshot};await archiveStorage('put',record);return {id:record.id,createdAt:record.createdAt};
}
function updateArchiveControls(message=''){
  const button=document.querySelector('#archive-project');if(!button)return;
  button.textContent=isProjectArchive()?'Restore':'Archive Submittal';button.classList.toggle('restore-archive',isProjectArchive());button.disabled=archiveOperationPending;
  const status=document.querySelector('#archive-status');if(status){status.textContent=message||(archiveView?`Read-only archive · ${archiveTimestamp(archiveView.createdAt)}`:'');status.classList.toggle('archive-error',Boolean(message));}
  document.body.classList.toggle('archive-readonly',isProjectArchive());
  const identity=document.querySelector('.browser-product-title');
  if(identity){identity.replaceChildren();for(const text of archiveView?['ARCHIVE',archiveTimestamp(archiveView.createdAt),'Restore To Edit']:['HVAC Design','Workbook']){const line=document.createElement('strong');line.textContent=text;identity.appendChild(line);}}
}
async function archiveOrRestoreProject(){
  if(archiveOperationPending)return;archiveOperationPending=true;updateArchiveControls();
  const index=projects.findIndex(p=>p.id===activeProjectId),master=projects[index],oldView=archiveView;let replacement;
  try{
    if(!master)throw Error('Select a project first.');
    const entry=await storeProjectSnapshot(master),entries=[...(master.archiveEntries||[]),entry];
    replacement=oldView?Object.assign(structuredClone(oldView.snapshot),{id:master.id,archiveEntries:entries}):{...master,archiveEntries:entries};
    projects[index]=replacement;archiveView=null;
    const previousHistory=applyingHistory;applyingHistory=true;try{saveProjects();}finally{applyingHistory=previousHistory;}
    if(oldView){undoStack.length=0;redoStack.length=0;}
    expandedArchiveProjects.add(master.id);selectedTableCells.clear();cellSelectionAnchor=null;fillProjectFields();renderProjectList();renderTree(search.value);syncActiveState();
  }catch(error){if(replacement)projects[index]=master;archiveView=oldView;updateArchiveControls(`Unable to save the archive: ${error.message}`);return;}
  finally{archiveOperationPending=false;const button=document.querySelector('#archive-project');if(button)button.disabled=false;}
  updateArchiveControls();applyArchiveReadOnly();
}
async function openProjectArchive(projectId,archiveId){
  if(archiveOperationPending)return;archiveOperationPending=true;updateArchiveControls();
  try{const saved=await archiveStorage('get',archiveId);if(!saved||saved.projectId!==projectId)throw Error('This archive is unavailable.');
    activeProjectId=projectId;archiveView={id:saved.id,createdAt:saved.createdAt,snapshot:structuredClone(saved.project),view:structuredClone(saved.project)};
    expandedArchiveProjects.add(projectId);selectedTableId='';selectedTableRowIndexes.clear();selectedTableCells.clear();cellSelectionAnchor=null;clearSelectedEquation();
    fillProjectFields();renderProjectList();renderTree(search.value);syncActiveState();updateArchiveControls();applyArchiveReadOnly();
  }catch(error){updateArchiveControls(`Unable to open the archive: ${error.message}`);}
  finally{archiveOperationPending=false;const button=document.querySelector('#archive-project');if(button)button.disabled=false;}
}
function renderProjectArchiveList(query=''){
  const normalized=query.trim().toLowerCase(),matches=projects.filter(p=>[p.number,p.name,p.client].some(v=>String(v||'').toLowerCase().includes(normalized)));projectList.replaceChildren();
  if(!matches.length){const p=document.createElement('p');p.className='project-list-empty';p.textContent='No projects match this search.';projectList.appendChild(p);}
  for(const project of matches){const group=document.createElement('div'),row=document.createElement('div'),arrow=document.createElement('button'),button=document.createElement('button');group.className='project-archive-group';row.className='project-master-row';arrow.type=button.type='button';arrow.className='project-archive-toggle';arrow.innerHTML='<svg viewBox="0 0 20 20" aria-hidden="true"><path d="m7 4 6 6-6 6"/></svg>';const expanded=expandedArchiveProjects.has(project.id);arrow.setAttribute('aria-expanded',String(expanded));arrow.setAttribute('aria-label',(expanded?'Hide':'Show')+' archives for '+project.number);arrow.onclick=()=>{expanded?expandedArchiveProjects.delete(project.id):expandedArchiveProjects.add(project.id);renderProjectList();};button.className='project-list-item';button.classList.toggle('active',project.id===activeProjectId&&!isProjectArchive());const number=document.createElement('strong'),name=document.createElement('span');number.textContent=project.number;name.textContent=project.name||'Untitled project';button.append(number,name);button.onclick=()=>selectProject(project.id);row.append(arrow,button);group.appendChild(row);
    if(expanded){const list=document.createElement('div');list.className='project-archive-children';for(const entry of [...(project.archiveEntries||[])].reverse()){const item=document.createElement('button');item.type='button';item.className='project-archive-item';item.textContent=archiveTimestamp(entry.createdAt);item.title='Open read-only archive';item.classList.toggle('active',archiveView?.id===entry.id&&activeProjectId===project.id);item.onclick=()=>openProjectArchive(project.id,entry.id);list.appendChild(item);}if(!list.children.length){const empty=document.createElement('p');empty.textContent='No archived submittals';list.appendChild(empty);}group.appendChild(list);}projectList.appendChild(group);
  }updateArchiveControls();
}
function archiveMutableTarget(node){
  if(!node?.closest)return false;
  if(node.closest('.space-filter,.filter-popover,.cell-dropdown-popup,#table-search,.formula-evaluator,#formula-function-view,.model-input-formula,#formula-function-detail'))return false;
  return Boolean(node.closest('#reference-table,.model-inputs-view,.top-project-fields,#table-settings,#calculation-documentation,.clipboard-actions,.excel-actions,.row-actions,.cell-note-editor'));
}
function applyArchiveReadOnly(){
  const readonly=isProjectArchive();document.body.classList.toggle('archive-readonly',readonly);
  document.querySelectorAll('[data-archive-disabled]').forEach(n=>{n.disabled=n.dataset.archiveDisabled==='true';delete n.dataset.archiveDisabled;});
  document.querySelectorAll('[data-archive-readonly]').forEach(n=>{n.readOnly=n.dataset.archiveReadonly==='true';delete n.dataset.archiveReadonly;});
  if(readonly){
    document.querySelectorAll('.work-area input,.work-area select,.work-area textarea,.top-project-fields input').forEach(n=>{if(!archiveMutableTarget(n))return;if(n.tagName==='SELECT'||['checkbox','file'].includes(n.type)){n.dataset.archiveDisabled=String(n.disabled);n.disabled=true;}else{n.dataset.archiveReadonly=String(n.readOnly);n.readOnly=true;}});
    document.querySelectorAll('#add-table-row,#remove-table-row,#paste-table-data,#import-excel,.documentation-heading button,.construction-add,.construction-remove,.psych-equipment-picker button').forEach(n=>{n.dataset.archiveDisabled=String(n.disabled);n.disabled=true;});
    referenceTable.querySelectorAll('tbody td').forEach(cell=>{cell.startCellEdit=()=>{};cell.editOnClick=false;cell.setAttribute('aria-readonly','true');});clearFillHandle();
  }
  document.querySelectorAll('[data-project-field]').forEach(n=>{n.readOnly=readonly||n.dataset.projectField==='number'||n.dataset.projectField==='date'&&activeProject()?.dateMode==='today';});
  updateArchiveControls();
}
function selectWholeTableColumn(event){
  const cell=event.target.closest?.('#reference-table tbody td')||(!document.activeElement?.matches('input,textarea')&&activeCellSelection?.tableId===activeTableId?referenceTable.querySelector(`tbody tr[data-source-index="${activeCellSelection.sourceIndex}"] td[data-column-index="${activeCellSelection.columnIndex}"]`):null);
  if(!cell||cell.isContentEditable||event.target.closest?.('.table-inline-editor,.dropdown-inline-editor'))return false;
  const column=Number(cell.dataset.columnIndex);if(!Number.isInteger(column))return false;event.preventDefault();event.stopImmediatePropagation();
  selectedTableId=activeTableId;selectedTableCells=new Set([...referenceTable.querySelectorAll('tbody tr[data-source-index]')].filter(r=>!r.hidden&&r.cells[column]?.style.display!=='none').map(r=>`${r.dataset.sourceIndex}:${column}`));selectedTableRowIndexes.clear();
  cellSelectionAnchor={sourceIndex:Number(cell.dataset.sourceIndex),columnIndex:column};activeCellSelection={tableId:activeTableId,...cellSelectionAnchor};refreshSelectedTableCells();clearFillHandle();return true;
}
function initializeArchiveUI(){
  document.querySelector('#archive-project').addEventListener('click',archiveOrRestoreProject);
  // A window capture guard runs before any table editor, paste, or restore handler.
  for(const type of ['beforeinput','input','change','paste','cut','keydown','click','dblclick','pointerdown'])window.addEventListener(type,event=>{
    if(!isProjectArchive())return;
    const target=event.target;
    if(target.closest?.('#restore-auto-value')&&typeof selectedAutoRestore==='function'){event.preventDefault();event.stopImmediatePropagation();return;}
    if(!archiveMutableTarget(target))return;
    const cell=target.closest?.('#reference-table tbody td');
    if(['click','pointerdown','dblclick'].includes(type)){
      if(cell&&!target.closest('button,.cell-note-flag,.cell-dropdown-arrow')){cell.editOnClick=false;cell.startCellEdit=()=>{};return;}
      if(target.closest('.column-sort-button,.header-link,.group-header-link,.calculated-value,.summary-equation-cell,#table-metric')||target.closest('#reference-table thead'))return;
      if(target.closest('button,.cell-note-flag,.cell-dropdown-arrow,select,input[type=checkbox]')){event.preventDefault();event.stopImmediatePropagation();}
      return;
    }
    if(type==='keydown'){
      if((event.ctrlKey||event.metaKey)&&['c','a',' ','Space'].includes(event.key.toLowerCase())||['ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Tab','Escape'].includes(event.key))return;
      if(event.key==='Enter'&&cell)return;
    }
    event.preventDefault();event.stopImmediatePropagation();
  },true);
}
