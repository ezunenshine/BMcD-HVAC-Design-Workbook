/* October workbook changes. Stored column indexes remain stable for existing projects. */
function configureOctoberWorkbookUpdates(){
  const names={
    'calc-doas-zone-air-balance':'Constant Ventilation & Variable Zone Recirculation Conditioning',
    'calc-ahu-oa-air-balance':'Variable Ventilation Conditioning',
    'calc-ahu-economizing-air-balance':'Variable Ventilation/Building Recirculation Conditioning',
    'calc-doas-ahu-air-balance':'Constant Ventilation & Variable Building Recirculation Conditioning'
  };
  for(const [id,name] of Object.entries(names)){
    const table=independentTables.find(t=>t.id===id);table.aliases=[table.name,table.standard];table.name=table.standard=name;
    for(const module of modules)for(const item of module.items)if(item[3]===id)item[0]=name;
  }
  const settings=independentTables.find(t=>t.id==='airside-settings');settings.headers[1].label='Spaces Served';settings.columns[1]='Spaces Served';settings.formulaColumnAliases={...settings.formulaColumnAliases,'Rooms Served':1};
  independentTables.find(t=>t.id==='room-zone-loads-report').noSort=true;
  const coil=independentTables.find(t=>t.id==='airside-ventilation-cooling');
  coil.displayColumnOrder=[0,...Array.from({length:6},(_,i)=>i+9),...Array.from({length:8},(_,i)=>i+1),...Array.from({length:coil.headers.length-15},(_,i)=>i+15)];
  coil.headerGroups.find(g=>g.start===9).label='Leaving Condition - Normal Operation';
  coil.headerGroups.find(g=>g.start===1).label='Leaving Condition - Dehum Mode';
  coil.headerGroups.sort((a,b)=>coil.displayColumnOrder.indexOf(a.start)-coil.displayColumnOrder.indexOf(b.start));
  const normal='space-group-header',cool='sensible-cooling-header',heat='heating-load-header';
  const labels=['Zone Group','Zone','Spaces Served','Maximum','Maximum','Ventilation','Exhaust','Cooling Maximum','Heating Maximum','Occupied Minimum','Unoccupied Minimum','Required Ventilation','Maximum Valve Return','Pressurized Air','Transfer Air In','Transfer Air Out','Balanced Air'];
  const headers=labels.map((label,i)=>({label,...(i>2?{unit:'CFM'}:{})}));
  const id='iesve-apachehvac-controllers';
  independentTables.push({id,name:'ApacheHVAC Controllers',standard:'ApacheHVAC Controllers',description:'Zone controller airflows in Room/Zone Loads Report order.',headers,columns:labels,columnTypes:labels.map((_,i)=>i<2?'text':'number'),rows:[],apacheControllersCalculation:true,noSort:true,fixedRows:true,readonlyEquations:true,frozenColumns:2,identityColumns:[0,1],lockedColumns:[0,1],calculatedColumns:labels.map((_,i)=>i).slice(2),zeroDecimalColumns:labels.map((_,i)=>i).slice(2),summaryColumns:labels.map((_,i)=>i).slice(2),headerClasses:{3:cool,4:heat,5:'ventilation-header',6:'exhaust-header',7:cool,8:heat,11:'ventilation-header'},sectionStartColumns:[3,4,5,7,13],headerGroups:[{label:'General',start:0,span:3,className:normal},{label:'Cooling Zone Level Recirculation',start:3,span:1,className:cool},{label:'Heating Zone Level Recirculation',start:4,span:1,className:heat},{label:'Occupied Constant Airflows',start:5,span:2,className:normal},{label:'Variable Air Volume',start:7,span:6,className:normal},{label:'Balancing',start:13,span:4,className:normal}],displayEquations:{2:'=COUNT_SPACES_IN_ZONE(@Zone Group,@Zone)',3:'=SUM_ZONE_PEAK(@Zone Group,@Zone,"Zone Recirculation Cooling")',4:'=SUM_ZONE_PEAK(@Zone Group,@Zone,"Zone Recirculation Heating")',5:'=SUM_ZONE_AIRFLOW(@Zone Group,@Zone,"Occupied Ventilation")',6:'=SUM_ZONE_AIRFLOW(@Zone Group,@Zone,"Occupied Exhaust")',7:'=SUM_ZONE_PEAK(@Zone Group,@Zone,"Central Cooling")',8:'=SUM_ZONE_PEAK(@Zone Group,@Zone,"Reheat Heating")',9:'=SUM_ZONE_AIRFLOW(@Zone Group,@Zone,"Occupied Minimum")',10:'=SUM_ZONE_AIRFLOW(@Zone Group,@Zone,"Unoccupied Minimum")',11:'=SUM_ZONE_AIRFLOW(@Zone Group,@Zone,"Required Ventilation")',12:'=SUM_ZONE_AIRFLOW(@Zone Group,@Zone,"Maximum Valve Return")',13:'=SUM_ZONE_AIRFLOW(@Zone Group,@Zone,"Pressurized Air")',14:'=SUM_ZONE_AIRFLOW(@Zone Group,@Zone,"Transfer Air In")',15:'=SUM_ZONE_AIRFLOW(@Zone Group,@Zone,"Transfer Air Out")',16:'=@Pressurized Air + @Transfer Air In - @Transfer Air Out'}});
  modules.find(g=>g.group==='IESVE 2025').items.push(['ApacheHVAC Controllers','IESVE · Controllers','Zone controller airflow totals linked to the space filter.',id]);
}
function applyTableDisplayOrder(table,element){
  if(!table.displayColumnOrder)return;
  for(const parent of [element.querySelector('colgroup'),...element.querySelectorAll('thead tr:not(.group-header-row),tbody tr,tfoot tr')]){
    if(!parent)continue;const cells=[...parent.children];cells.forEach((cell,i)=>cell.dataset.columnIndex=String(i));
    for(const index of table.displayColumnOrder)if(cells[index])parent.appendChild(cells[index]);
  }
}
function workbookCell(row,column){return row?.querySelector(`[data-column-index="${column}"]`)||row?.cells[column];}
function controllerZoneKey(group,zone){return JSON.stringify([requirementKey(group),requirementKey(zone)]);}
function loadApacheControllerRows(project,table){
  if(!project)return [];
  const report=ensureProjectTableRows(project,independentTables.find(t=>t.id==='room-zone-loads-report')),zones=new Map();
  for(const r of report){if(!String(r[2]??'').trim())continue;const key=controllerZoneKey(r[0],r[1]);if(!zones.has(key)){const row=[r[0],r[1],...Array(15).fill(0)];row.spaces=[];zones.set(key,row);}const row=zones.get(key);if(!row.spaces.some(s=>requirementKey(s)===requirementKey(r[2])))row.spaces.push(r[2]);row[2]=row.spaces.length;}
  project.independentTables ||= {};return project.independentTables[table.id]=[...zones.values()];
}
function calculateApacheControllerTotals(rows,sources){
 const {zoning,peaks,balances,balancing}=sources;
 const sourceRows=id=>id==='calc-peak-airflows'?peaks:id==='calc-air-balancing-requirements'?balancing.rows:balances[id.replace(/^calc-/,'').replace(/-air-balance$/,'')]?.rows||[];
 for(const row of rows){row.fill(0,2);row[2]=(row.spaces||[]).length;
  const zones=zoning.filter(z=>requirementKey(z[1])===requirementKey(row[1]));
  for(const [c,rule]of Object.entries(controllerRules250())){
   const keys=new Set(zones.map(z=>requirementKey(z[2])).filter(k=>k&&k!=='-'));
   row[c]=rule.terms.reduce((total,[id,key,value])=>{const t=workbookTable(id),k=controllerColumn250(t,'Space'),v=controllerColumn250(t,value);return total+sourceRows(id).reduce((n,r)=>n+(keys.has(requirementKey(r[k]))?requirementNumber(r[v]):0),0);},0);
  }
  row[16]=row[13]+row[14]-row[15];
 }
 return rows;
}

function recalculateApacheControllers(table,rows,project){
  const get=id=>{const t=independentTables.find(t=>t.id===id),r=ensureProjectTableRows(project,t);recalculateTable(t,r,project);return {table:t,rows:r};};
  const zoning=get('calc-equipment-zoning').rows,peaks=get('calc-peak-airflows').rows,balancing=get('calc-air-balancing-requirements'),balances={};
  for(const mode of ['doas-zone','doas-ahu','ahu-oa','ahu-economizing']){const source=get('calc-'+mode+'-air-balance');balances[mode]={fields:source.table.balanceFields,rows:source.rows};}
  calculateApacheControllerTotals(rows,{zoning,peaks,balances,balancing:{...balancing.table,rows:balancing.rows}});
}
function displayedColumnIndex(column,tableId=activeTableId){const t=independentTables.find(t=>t.id===tableId);return t?.displayColumnOrder?t.displayColumnOrder.indexOf(column):column;}
function storedColumnIndex(position,tableId=activeTableId){return independentTables.find(t=>t.id===tableId)?.displayColumnOrder?.[position]??position;}
