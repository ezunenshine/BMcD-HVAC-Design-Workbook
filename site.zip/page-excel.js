/* Export exactly the visible worksheet, including displayed precision and merged headings. */
function exportCurrentPageExcel(){
 const visible=e=>!!e.getClientRects().length&&getComputedStyle(e).display!=='none';
 const tables=[...document.querySelectorAll('#psych-mixed-summary table,#reference-table')].filter(visible);
 const sheets=tables.map((table,i)=>{
  const rows=[],merges=[],occupied=new Set(),widths=[];
  [...table.rows].filter(visible).forEach((tr,r)=>{const row=[];let c=0;
   [...tr.cells].filter(visible).forEach(td=>{
    while(occupied.has(`${r},${c}`))c++;
    const control=td.querySelector('input,select,textarea');
    let value=control?(control.tagName==='SELECT'?control.selectedOptions[0]?.textContent||'':control.value):td.innerText.trim();
    const clean=value.replaceAll(',',''),percent=/^-?\d+(?:\.\d+)?%$/.test(clean),numeric=/^-?\d+(?:\.\d+)?$/.test(clean);
    const style=getComputedStyle(td);let bg=style.backgroundColor,parent=td.parentElement;
    while((bg==='rgba(0, 0, 0, 0)'||bg==='transparent')&&parent){bg=getComputedStyle(parent).backgroundColor;parent=parent.parentElement;}
    const color=v=>{const rgb=v.match(/[\d.]+/g);return rgb&&rgb.length>=3?'FF'+rgb.slice(0,3).map(n=>Math.round(Number(n)).toString(16).padStart(2,'0')).join('').toUpperCase():'FFFFFFFF';};
    row[c]={value:percent?Number(clean.slice(0,-1))/100:numeric?Number(clean):value,fill:color(bg),color:color(style.color),bold:Number(style.fontWeight)>=600,format:percent?'0'+(clean.includes('.')?'.'+'0'.repeat(clean.split('.')[1].length-1):'')+'%':numeric?'#,##0'+(clean.includes('.')?'.'+'0'.repeat(clean.split('.')[1].length):''):'General'};
    const rs=td.rowSpan||1,cs=td.colSpan||1;if(rs>1||cs>1)merges.push([r,c,r+rs-1,c+cs-1]);
    for(let y=r;y<r+rs;y++)for(let x=c;x<c+cs;x++)if(y!==r||x!==c)occupied.add(`${y},${x}`);
    if(cs===1)widths[c]=Math.max(widths[c]||0,Math.min(55,Math.max(12,td.getBoundingClientRect().width/7)));
    c+=cs;
   });rows.push(row);
  });return {name:i?'Calculation':'Worksheet',rows,merges,widths};
 });
 if(!sheets.length){const fields=[...document.querySelectorAll('#model-inputs-view input,#model-inputs-view select')].filter(visible);sheets.push({name:'Page',rows:fields.length?fields.map(e=>[e.closest('label')?.querySelector('span')?.innerText||e.dataset.modelInput||'Value',e.tagName==='SELECT'?e.selectedOptions[0]?.textContent:e.value]):[[document.querySelector('#page-title').textContent],[document.querySelector('#module-content')?.innerText||'']]});}
 downloadWorkbookFile(simpleWorkbookExcel(sheets),(document.querySelector('#page-title').textContent||'Workbook').replace(/[^a-z0-9 -]/gi,'')+'.xlsx');
}
function simpleWorkbookExcel(sheets){
 const x=v=>String(v??'').replace(/[\x00-\x08\x0b\x0c\x0e-\x1f]/g,'').replace(/[<>&"']/g,c=>({'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;',"'":'&apos;'}[c]));
 const letters=n=>{let s='';for(n++;n;n=Math.floor((n-1)/26))s=String.fromCharCode(65+(n-1)%26)+s;return s;};
 const files=[],add=(name,body)=>files.push({name,bytes:new TextEncoder().encode(body)}),styles=[],styleIds=new Map();
 const styleFor=cell=>{const st={fill:cell.fill||'FFFFFFFF',color:cell.color||'FF172D40',bold:!!cell.bold,format:cell.format||'General'},key=JSON.stringify(st);if(!styleIds.has(key)){styleIds.set(key,styles.length);styles.push(st);}return styleIds.get(key);};styleFor({});
 sheets.forEach((sheet,i)=>{add(`xl/worksheets/sheet${i+1}.xml`,`<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><cols>${(sheet.widths||[]).map((w,c)=>`<col min="${c+1}" max="${c+1}" width="${w||14}" customWidth="1"/>`).join('')}</cols><sheetData>${sheet.rows.map((row,r)=>`<row r="${r+1}" ht="${r<2?42:24}" customHeight="1">${row.map((raw,c)=>{const cell=raw&&typeof raw==='object'?raw:{value:raw},v=cell.value,st=styleFor(cell);return `<c r="${letters(c)}${r+1}" s="${st}"${typeof v==='number'&&Number.isFinite(v)?`><v>${v}</v>`:` t="inlineStr"><is><t xml:space="preserve">${x(v)}</t></is>`}</c>`;}).join('')}</row>`).join('')}</sheetData>${sheet.merges?.length?`<mergeCells count="${sheet.merges.length}">${sheet.merges.map(([r,c,rr,cc])=>`<mergeCell ref="${letters(c)}${r+1}:${letters(cc)}${rr+1}"/>`).join('')}</mergeCells>`:''}</worksheet>`);});
 add('xl/styles.xml',`<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><numFmts count="${styles.length}">${styles.map((s,i)=>`<numFmt numFmtId="${164+i}" formatCode="${x(s.format)}"/>`).join('')}</numFmts><fonts count="${styles.length}">${styles.map(s=>`<font><sz val="11"/><name val="Aptos"/><color rgb="${s.color}"/>${s.bold?'<b/>':''}</font>`).join('')}</fonts><fills count="${styles.length+2}"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>${styles.map(s=>`<fill><patternFill patternType="solid"><fgColor rgb="${s.fill}"/><bgColor indexed="64"/></patternFill></fill>`).join('')}</fills><borders count="1"><border><left style="thin"><color rgb="FFB9C7D1"/></left><right style="thin"><color rgb="FFB9C7D1"/></right><top style="thin"><color rgb="FFB9C7D1"/></top><bottom style="thin"><color rgb="FFB9C7D1"/></bottom></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="${styles.length}">${styles.map((s,i)=>`<xf numFmtId="${164+i}" fontId="${i}" fillId="${i+2}" borderId="0" applyNumberFormat="1" applyFill="1" applyFont="1" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf>`).join('')}</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>`);
 add('[Content_Types].xml',`<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${sheets.map((_,i)=>`<Override PartName="/xl/worksheets/sheet${i+1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join('')}</Types>`);
 add('_rels/.rels','<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>');
 add('xl/workbook.xml',`<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>${sheets.map((s,i)=>`<sheet name="${x(s.name.slice(0,31))}" sheetId="${i+1}" r:id="rId${i+1}"/>`).join('')}</sheets></workbook>`);
 add('xl/_rels/workbook.xml.rels',`<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${sheets.map((_,i)=>`<Relationship Id="rId${i+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i+1}.xml"/>`).join('')}<Relationship Id="rId${sheets.length+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`);
 return new Blob([WorkbookPrintPDF.zip(files)],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
}
