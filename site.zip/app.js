const modules = [
  {
    group: "Model Inputs",
    source: "Inputs",
    summary: "Project, site, climate, weather, and building inputs used throughout the workbook.",
    directView: "model-inputs",
    items: [],
  },
  {
    group: "IESVE 2025",
    source: "IES Data → IES Loads",
    summary: "Import, normalize, export, and review the IESVE 2025 space and room-load datasets used by the design workbook.",
    items: [
      ["Thermal Templates", "Thermal · B3:O115", "Map thermal space types to ventilation, occupant heat-gain, and lighting criteria.", "iesve-thermal-template"],
      ["Tabular Space Data", "IES Data · D3:AL201", "Review and edit the IESVE tabular space dataset used by downstream calculations.", "iesve-tabular-space-data"],
      ["Room/Zone Loads Report", "Room/Zone Loads · A10:U149", "Review imported room and zone sensible cooling, latent cooling, and heating loads.", "room-zone-loads-report"],
    ],
  },
  {
    group: "Space Calculations",
    source: "Inputs → IES Loads → Calc",
    summary: "Review space conditions, loads, zoning, ventilation, air balance, latent performance, baseline systems, and monitoring criteria.",
    items: [
      ["Space Condition Setpoints", "Calc · F:N", "Define heating, cooling, humidity, setback, and ventilated temperature-rise criteria.", "calc-space-condition-setpoints"],
      ["DHW", "Calc · O:V", "Calculate occupancy-driven domestic hot-water demand and schedule values.", "calc-dhw"],
      ["Lighting Gains", "Calc · W:AC", "Calculate recommended, manual, proposed, and baseline lighting gains by space.", "calc-lighting-gains"],
      ["People Gains", "Calc · AD:AK", "Calculate recommended occupancy and sensible and latent people gains by space.", "calc-people-gains"],
      ["Miscellaneous Sensible Gains", "Calc · AL:AP", "Calculate recommended, manual, and summarized miscellaneous sensible gains by space.", "calc-misc-gains"],
      ["Room Loads", "Calc · AQ:BC", "Consolidate sensible cooling, latent cooling, and heating room loads used for sizing.", "calc-room-loads"],
      ["Equipment Zoning", "Calc · BD:BQ", "Assign spaces to equipment zones and evaluate shared operating criteria.", "calc-equipment-zoning"],
      ["Heating Load Calculations", "Calc · BR:BZ", "Calculate design heating requirements while preserving workbook sizing and rounding logic.", "calc-heating-loads"],
      ["Cooling Load Calculations", "Calc · CA:CO", "Calculate design sensible, latent, and total cooling requirements.", "calc-cooling-loads"],
      ["Required Ventilation and Exhaust Rate Calculations", "Calc · CP:DH", "Determine required outdoor-air and exhaust quantities for each applicable space.", "calc-ventilation-exhaust"],
      ["Pressurization Calculations", "Calc · DI:DY", "Evaluate supply, return, exhaust, and transfer relationships for space pressure intent.", "calc-pressurization"],
      ["Non-Peak Air Balance", "Calc · DZ:EG", "Review airflow balance away from coincident peak-load conditions.", "calc-non-peak-air-balance"],
      ["Air Balance", "Calc · EH:EU", "Review the space supply, return, exhaust, transfer, and balance relationships.", "calc-air-balance"],
      ["Latent Load Calculations", "Calc · EV:FE", "Trace latent gains and moisture loads through the space calculation path.", "calc-latent-loads"],
      ["Space Condition Type and Baseline System", "Calc · FF:FQ", "Map space condition types to the workbook baseline-system logic.", "calc-condition-baseline"],
      ["CO₂ Monitoring Calculation", "Calc · FR:FY", "Identify spaces subject to carbon-dioxide monitoring criteria.", "calc-co2-monitoring"],
    ],
  },
  {
    group: "Selected Space Requirements",
    source: "Lighting → Misc → Exhaust → Transfer",
    summary: "Manage supplemental fixture, equipment, exhaust, and transfer-air requirements for the selected spaces that need added detail.",
    items: [
      ["Lighting Loads", "Lighting · E13:M235", "Add detailed lighting loads for selected spaces where fixture-level inputs are required.", "selected-lighting-loads"],
      ["Miscellaneous Sensible Loads", "Misc · E9:R72", "Add detailed plug, process, and equipment sensible loads for selected spaces.", "selected-misc-loads"],
      ["General Exhaust Requirements", "Exhaust · T9:AI89", "Apply general exhaust criteria to selected spaces.", "selected-general-exhaust"],
      ["Exhaust Equipment Requirements", "Exhaust · AK9:AT84", "Define equipment-specific exhaust demands and operating relationships.", "selected-exhaust-equipment"],
      ["Transfer Air", "Transfer · L9:V110", "Define transfer-air paths and quantities for selected spaces.", "selected-transfer-air"],
    ],
  },
  {
    group: "Airside Equipment",
    source: "Airside → Psych",
    summary: "Review airside design settings, coil duties, and psychrometric processes for the project systems.",
    items: [
      ["Settings", "Airside", "Configure shared airside design conditions and equipment assumptions."],
      ["Preheat Coils", "Airside", "Size and review preheat coil performance at workbook design conditions."],
      ["Cooling Coils", "Airside", "Size and review cooling coil sensible, latent, and total performance."],
      ["Reheat / Heating Coils", "Airside", "Size and review reheat and heating coil performance."],
      ["Psychrometric Charts", "Psych", "Visualize air-state processes used in the airside calculations."],
    ],
  },
  {
    group: "Plantside Equipment",
    source: "Plantside",
    summary: "Review the calculated cooling and heating plant design duties and equipment selections.",
    items: [
      ["Cooling Plant Equipment", "Plantside", "Review cooling plant equipment selections and calculated design duties."],
      ["Heating Plant Equipment", "Plantside", "Review heating plant equipment selections and calculated design duties."],
    ],
  },
  {
    group: "Energy",
    source: "Energy",
    summary: "Compare proposed energy performance with the four baseline building rotations used by the workbook.",
    items: [
      ["Proposed", "Energy", "Review the proposed building energy-model results."],
      ["Baseline 000deg", "Energy", "Review the baseline energy-model results at the 000-degree rotation."],
      ["Baseline 090deg", "Energy", "Review the baseline energy-model results at the 090-degree rotation."],
      ["Baseline 180deg", "Energy", "Review the baseline energy-model results at the 180-degree rotation."],
      ["Baseline 270deg", "Energy", "Review the baseline energy-model results at the 270-degree rotation."],
    ],
  },
  {
    group: "Independent Tables",
    source: "Lighting → Misc → Exhaust → ASHRAE → Water",
    summary: "Browse project schedules and the independent ASHRAE and water-property reference tables used by the workbook calculations.",
    items: [
      ["Lighting Schedule", "Lighting · O13:Q62", "Lighting fixture types, wattages, and calculated project quantities.", "schedule-lighting"],
      ["Equipment Sensible Gain Schedule", "Misc · T9:Z56", "Equipment load inputs in Btu/h and kW with efficiency, space allocation, calculated heat gain, and project quantities.", "schedule-equipment-sensible-gain"],
      ["Grouped Equipment Sensible Gain Schedule", "Misc · AA9:AE11", "Reusable equipment groups with calculated row heat gain and group heat-gain totals.", "schedule-grouped-equipment-sensible-gain"],
      ["General Exhaust Schedule", "Exhaust · AV9:BE40", "General exhaust criteria by fixture, area, and occupied or unoccupied air-change basis.", "schedule-general-exhaust"],
      ["Exhaust Equipment Schedule", "Exhaust · AV9:BE40", "Equipment-specific exhaust airflow for on and off operating conditions.", "schedule-exhaust-equipment"],
      ["Ventilation Rates", "ASHRAE · B4:E83", "Outdoor-air rates and default occupant density by occupancy category.", "ashrae-62-1-ventilation"],
      ["Baseline Lighting Power Density", "ASHRAE · G4:H108", "Baseline lighting power density by common space type.", "ashrae-90-1-baseline-lighting"],
      ["Proposed Lighting Power Density", "ASHRAE · J4:K103", "Lighting power allowances by common space type.", "ashrae-90-1-proposed-lighting"],
      ["Occupant Heat Gain", "ASHRAE · M4:O17", "Sensible and latent heat gain per person by activity level.", "ashrae-fundamentals-people-heat"],
      ["Climate Zones and Baseline Systems", "ASHRAE · T4:AD23", "Climate-zone descriptions and baseline system assignments by building type and size.", "ashrae-climate-zones"],
      ["Baseline System Descriptions", "ASHRAE · AL4:AR18", "Baseline HVAC system types, fan control, cooling source, and heating source.", "ashrae-90-1-baseline-systems"],
      ["FEMP SHW Calculator Table", "ASHRAE · AT4:AU11", "Estimated service hot-water use by building type for domestic hot-water calculations.", "femp-shw-calculator"],
      ["Ethylene Glycol Density", "Water · B9:L38", "Density of aqueous ethylene glycol solutions by temperature and volume concentration.", "water-ethylene-density"],
      ["Propylene Glycol Density", "Water · O9:Y38", "Density of inhibited aqueous propylene glycol solutions by temperature and volume concentration.", "water-propylene-density"],
      ["Ethylene Glycol Specific Heat", "Water · B44:L73", "Specific heat of aqueous ethylene glycol solutions by temperature and volume concentration.", "water-ethylene-specific-heat"],
      ["Propylene Glycol Specific Heat", "Water · O44:Y73", "Specific heat of aqueous propylene glycol solutions by temperature and volume concentration.", "water-propylene-specific-heat"],
      ["Water Properties at 14.700 psia", "Water · B89:O113", "Thermophysical properties of water at atmospheric pressure.", "water-nist-properties"],
    ],
  },
];

const independentTables = [
  ...(globalThis.INDEPENDENT_TABLES || []),
  ...(globalThis.CALC_SECTION_TABLES || []),
  ...(globalThis.SELECTED_REQUIREMENT_TABLES || []),
].filter((table) => table.id !== "calc-general");

if (!independentTables.some((table) => table.id === "femp-shw-calculator")) {
  independentTables.push({
    id: "femp-shw-calculator",
    name: "FEMP SHW Calculator Table",
    standard: "FEMP SHW Calculator Table",
    description: "Estimated hot-water use from the workbook FEMP SHW Calculator table.",
    sheet: "ASHRAE",
    range: "AT4:AU11",
    headers: [
      { label: "Building Type" },
      { label: "Estimated Hot Water Use", unit: "gal/person-day" },
    ],
    columns: ["Building Type", "Estimated Hot Water Use (gal/person-day)"],
    columnTypes: ["text", "number"],
    lockedColumns: [0, 1],
    identityColumns: [0],
    rows: [
      ["House", 15.8],
      ["Hotel/Motel", 20],
      ["Hospital", 52],
      ["Office", 1.1],
      ["Restaurant", 2.4],
      ["School", 0.5],
      ["School with Showers", 1.9],
    ],
  });
}

if (!independentTables.some((table) => table.id === "project-inputs")) {
  independentTables.unshift({
    id: "project-inputs",
    name: "Model Inputs",
    standard: "Model Inputs",
    description: "Project site, climate, weather, and building inputs from the workbook Inputs sheet.",
    sheet: "Inputs",
    range: "B19:I54",
    headers: [
      { label: "Category" }, { label: "Input" }, { label: "Value" }, { label: "Unit" },
    ],
    columns: ["Category", "Input", "Value", "Unit"],
    columnTypes: ["text", "text", "text", "text"],
    lockedColumns: [0, 1, 3],
    cellDropdownRows: { 16: { 2: ["TRUE"] } },
    frozenColumns: 2,
    identityColumns: [0, 1],
    schemaVersion: 2,
    rows: [
      ["Site", "Location", "Forest Park, Georgia", ""],
      ["Site", "Country / State", "Curry County, NM", ""],
      ["Site", "Latitude", "33.63 N", "degrees"],
      ["Site", "Longitude", "84.442 W", "degrees"],
      ["Site", "Climate Zone", "3A", ""],
      ["Site", "Elevation", 1011, "ft"],
      ["Site", "Simulation Weather Data", "USA_GA_Atlanta-Hartsfield-Jackson_Intl.AP_722190_TMY3.epw", ""],
      ["Cooling Design", "Percentile", 0.01, "%"],
      ["Cooling Design", "Dry Bulb", 91.6, "°F"],
      ["Cooling Design", "Wet Bulb", 73.6, "°F"],
      ["Dehumidification", "Dry Bulb", 80.4, "°F"],
      ["Dehumidification", "Humidity Ratio", 128.5, "gr/lb"],
      ["Heating Design", "Percentile", 0.99, "%"],
      ["Heating Design", "Dry Bulb", 27.1, "°F"],
      ["Humidification", "Dry Bulb", 32.1, "°F"],
      ["Humidification", "Humidity Ratio", 9.2, "gr/lb"],
      ["Building", "UFC", "TRUE", ""],
      ["Building", "Infiltration at 0.3 in. pressure differential", 0.25, "CFM/ft2"],
    ],
  });
}

configureCalcSectionTables();
configureSelectedRequirementTables();
configureThermalTemplate();
independentTables.filter((table) => table.id.startsWith("calc-")).forEach((table) => { table.fixedRows = true; });

function configureThermalTemplate() {
  const thermal = independentTables.find((table) => table.id === "iesve-thermal-template");
  if (!thermal) return;
  thermal.name = "Thermal Templates";
  thermal.standard = "Thermal Templates";
  thermal.headers[10] = { ...thermal.headers[10], label: "Baseline LPD" };
  thermal.headers[12] = { ...thermal.headers[12], label: "Proposed LPD" };
  thermal.columns[10] = "Baseline LPD (W/ft2)";
  thermal.columns[12] = "Proposed LPD (W/ft2)";
  thermal.equations ||= {};
  thermal.displayEquations ||= {};
  thermal.equations[1] = "=COUNTIF([Space Condition Setpoints]@Type,@Type)";
  thermal.displayEquations[1] = "=COUNTIF([Space Condition Setpoints]@Type, @Type)";
}

function configureSelectedRequirementTables() {
  const lighting = independentTables.find((table) => table.id === "selected-lighting-loads");
  if (lighting) {
    const retained = [0, 1, 2, 3, 6, 7];
    lighting.headers = [
      { label: "Space Name" }, { label: "Light" }, { label: "Quantity" },
      { label: "Wattage", unit: "W" }, { label: "Gain", unit: "W" }, { label: "Notes/Identifier" },
    ];
    lighting.columns = lighting.headers.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`);
    lighting.columnTypes = ["text", "text", "number", "number", "number", "text"];
    lighting.rows = lighting.rows.map((row) => retained.map((index) => row[index]));
    lighting.calculatedColumns = [3, 4];
    lighting.displayEquations = {
      3: "=XLOOKUP(@Light, [Lighting Schedule]@Light, [Lighting Schedule]@Wattage)",
      4: "=@Quantity * @Wattage",
    };
    lighting.equations = {
      3: "=XLOOKUP(@Light, [Lighting Schedule]@Light, [Lighting Schedule]@Wattage)",
      4: "=@Quantity*@Wattage",
    };
    lighting.preserveImportedValues = false;
    lighting.readonlyEquations = false;
    lighting.dropdownColumns = {
      0: { sourceTableId: "calc-space-condition-setpoints", sourceColumn: 0 },
      1: { sourceTableId: "schedule-lighting", sourceColumn: 0 },
    };
    lighting.schemaVersion = 3;
  }
  const misc = independentTables.find((table) => table.id === "selected-misc-loads");
  if (misc) {
    const retained = [0, 1, 2, 3, 4, 5, 6, 9, 10, 11, 12];
    misc.headers = [
      { label: "Space Name" }, { label: "Equipment" }, { label: ">1 Items" },
      { label: "Per Person" }, { label: "People" }, { label: "Quantity" },
      { label: "Sens Heat Gain", unit: "Btu/h" }, { label: "Misc", unit: "kW" },
      { label: "Misc", unit: "Btu/h" }, { label: "Gain", unit: "Btu/h" }, { label: "Notes/Identifier" },
    ];
    misc.columns = misc.headers.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`);
    misc.columnTypes = ["text", "text", "number", "text", "text", "number", "number", "number", "number", "number", "text"];
    misc.rows = misc.rows.map((row) => retained.map((index) => row[index])).map((row) => {
      row[3] = row[3] === true || String(row[3]).toUpperCase() === "TRUE" ? "TRUE" : "";
      return row;
    });
    misc.calculatedColumns = [4, 5, 6, 9];
    misc.displayEquations = {
      4: '=IF(@Per Person="TRUE", XLOOKUP(@Space Name, [People Gains]@Space, [People Gains]@Actual People), "-")',
      5: '=IF(@>1 Items="", 1, @>1 Items)',
      6: '=XLOOKUP(@Equipment, [Equipment Sensible Gain Schedule + Grouped Equipment Sensible Gain Schedule]@Equipment, @Heat Gain)',
      9: '=IF(@People="-", 1, @People) * @Quantity * @Sens Heat Gain + 3412.142 * @Misc kW + @Misc Btu/h',
    };
    misc.dropdownColumns = {
      0: { sourceTableId: "calc-space-condition-setpoints", sourceColumn: 0 },
      1: { sources: [
        { sourceTableId: "schedule-equipment-sensible-gain", sourceColumn: 0 },
        { sourceTableId: "schedule-grouped-equipment-sensible-gain", sourceColumn: 0 },
      ] },
      3: { options: ["TRUE"] },
    };
    misc.columnWidthOverrides = { 3: 94, 4: 96, 5: 96 };
    misc.miscLoadCalculation = true;
    misc.preserveImportedValues = false;
    misc.readonlyEquations = true;
    misc.schemaVersion = 3;
  }
}

function configureCalcSectionTables() {
  const general = globalThis.CALC_SECTION_TABLES?.find((table) => table.id === "calc-general");
  const generalRows = general?.rows || [];
  const bySpace = new Map(generalRows.map((row) => [String(row[0]), row]));

  const setpoints = independentTables.find((table) => table.id === "calc-space-condition-setpoints");
  if (setpoints) {
    setpoints.headers = [
      { label: "Space" },
      { label: "Type" },
      { label: "Relative Humidity", unit: "%" },
      { label: "Heating Main Setpoint", unit: "°F" },
      { label: "Heating Temperature Setback", unit: "°F" },
      { label: "Heating Humidity Ratio", unit: "lb/lb" },
      { label: "Ventilated Temperature Rise", unit: "°F" },
      { label: "Cooling Main Setpoint", unit: "°F" },
      { label: "Cooling Temperature Setback", unit: "°F" },
      { label: "Cooling Humidity Ratio", unit: "lb/lb" },
    ];
    setpoints.columns = setpoints.headers.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`);
    setpoints.columnTypes = ["text", "text", "number", "number", "number", "number", "number", "number", "number", "number"];
    setpoints.rows = setpoints.rows.map((row) => [row[0], bySpace.get(String(row[0]))?.[1] ?? "", row[1], row[2], row[3], row[4], row[5], row[7], row[8], row[9]]);
    setpoints.calculatedColumns = [5, 9];
    setpoints.lockedColumns = [0, 1];
    setpoints.identityColumns = [0, 1];
    setpoints.frozenColumns = 2;
    setpoints.fiveDecimalColumns = [5, 9];
    setpoints.conditionalCalculatedColumns = { 7: { whenColumn: 6, baseValue: 91.6 } };
    setpoints.displayEquations = {
      5: "=HUMIDITY_RATIO(@Heating Main Setpoint, @Relative Humidity, [Inputs]@Barometric Pressure)",
      7: "=[Inputs]@Cooling Design Dry Bulb + @Ventilated Temperature Rise",
      9: "=HUMIDITY_RATIO(@Cooling Main Setpoint, @Relative Humidity, [Inputs]@Barometric Pressure)",
    };
    setpoints.twoValueScheduleDefault = "System extended hours";
    setpoints.schemaVersion = 2;
  }

  const dhw = independentTables.find((table) => table.id === "calc-dhw");
  if (dhw) {
    dhw.headers = [
      { label: "Space" },
      { label: "Building Type" },
      { label: "Total People" },
      { label: "DHW Consumption", unit: "GPH" },
    ];
    dhw.columns = ["Space", "Building Type", "Total People", "DHW Consumption (GPH)"];
    dhw.columnTypes = ["text", "text", "number", "number"];
    dhw.rows = dhw.rows.map((row) => row.slice(0, 4));
    dhw.calculatedColumns = [3];
    dhw.lockedColumns = [0];
    dhw.identityColumns = [0];
    dhw.fiveDecimalColumns = [3];
    dhw.summaryColumns = [1, 2, 3];
    dhw.summaryAggregations = { 1: "count", 2: "sum", 3: "sum" };
    dhw.preserveImportedValues = false;
    dhw.readonlyEquations = false;
    dhw.dropdownColumns = { 1: { sourceTableId: "femp-shw-calculator", sourceColumn: 0 } };
    dhw.equations = { 3: "=@TotalPeople*XLOOKUP(@BuildingType, [FEMP SHW Calculator Table]@BuildingType, [FEMP SHW Calculator Table]@EstimatedHotWaterUse)/24" };
    dhw.displayEquations = { 3: "=@Total People * XLOOKUP(@Building Type, [FEMP SHW Calculator Table]@Building Type, [FEMP SHW Calculator Table]@Estimated Hot Water Use) / 24" };
    dhw.schemaVersion = 2;
  }

  const roomLoads = independentTables.find((table) => table.id === "calc-room-loads");
  if (roomLoads) {
    roomLoads.headers = [
      { label: "Space" }, { label: "Type" },
      { label: "IESVE", unit: "MBH" }, { label: "Internal Gains", unit: "MBH" }, { label: "Size per IGs" },
      { label: "Add/Subtract", unit: "MBH" }, { label: "Load", unit: "MBH" },
      { label: "IESVE", unit: "MBH" }, { label: "People", unit: "MBH" }, { label: "Size per IESVE" },
      { label: "Add/Subtract", unit: "MBH" }, { label: "Load", unit: "MBH" },
      { label: "IESVE", unit: "MBH" }, { label: "Add/Subtract", unit: "MBH" }, { label: "Load", unit: "MBH" },
    ];
    roomLoads.columns = roomLoads.headers.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`);
    roomLoads.rows = roomLoads.rows.map((row) => [row[0], bySpace.get(String(row[0]))?.[1] ?? "", ...row.slice(1)]);
    roomLoads.rows.forEach((row) => { row[4] = String(row[4]).toUpperCase() === "TRUE" ? "TRUE" : ""; row[9] = String(row[9]).toUpperCase() === "TRUE" ? "TRUE" : ""; });
    roomLoads.columnTypes = ["text", "text", "number", "number", "text", "number", "number", "number", "number", "text", "number", "number", "number", "number", "number"];
    roomLoads.calculatedColumns = [2, 3, 6, 7, 8, 11, 12, 14];
    roomLoads.lockedColumns = [0, 1]; roomLoads.identityColumns = [0, 1]; roomLoads.frozenColumns = 2;
    roomLoads.dropdownColumns = { 4: { options: ["TRUE"] }, 9: { options: ["TRUE"] } };
    roomLoads.columnWidthOverrides = { 4: 94, 9: 94 };
    roomLoads.decimalColumns = [2, 3, 5, 6, 7, 8, 10, 11, 12, 13, 14];
    roomLoads.summaryColumns = [2, 3, 5, 6, 7, 8, 10, 11, 12, 13, 14];
    roomLoads.headerGroups = [
      { label: "General", start: 0, span: 2, className: "space-group-header" },
      { label: "Cooling Sensible", start: 2, span: 5, className: "sensible-cooling-header" },
      { label: "Cooling Latent", start: 7, span: 5, className: "latent-cooling-header" },
      { label: "Heating", start: 12, span: 3, className: "heating-load-header" },
    ];
    roomLoads.headerClasses = Object.fromEntries([
      ...[2, 3, 4, 5, 6].map((index) => [index, "sensible-cooling-header"]),
      ...[7, 8, 9, 10, 11].map((index) => [index, "latent-cooling-header"]),
      ...[12, 13, 14].map((index) => [index, "heating-load-header"]),
    ]);
    roomLoads.sectionStartColumns = [7, 12];
    roomLoads.displayEquations = {
      2: '=XLOOKUP(@Space, [Room/Zone Loads Report]@Room, [Room/Zone Loads Report]@Sensible Cooling)',
      3: '=([Lighting Gains]@Proposed Lighting Gain + [People Gains]@Sensible Load + [Miscellaneous Sensible Gains]@Miscellaneous Sensible Load) / 1000',
      6: '=MAX(1.10 * (IF([Cooling Sensible]@Size per IGs="TRUE", [Cooling Sensible]@Internal Gains, [Cooling Sensible]@IESVE) + [Cooling Sensible]@Add/Subtract), 0)',
      7: '=XLOOKUP(@Space, [Room/Zone Loads Report]@Room, [Room/Zone Loads Report]@Latent Cooling)',
      8: '=[People Gains]@Latent Load / 1000',
      11: '=MAX(1.10 * (IF([Cooling Latent]@Size per IESVE="TRUE", [Cooling Latent]@IESVE, [Cooling Latent]@People) + [Cooling Latent]@Add/Subtract), 0)',
      12: '=XLOOKUP(@Space, [Room/Zone Loads Report]@Room, [Room/Zone Loads Report]@Heating)',
      14: '=MAX(1.10 * ([Heating]@IESVE + [Heating]@Add/Subtract), 0)',
    };
    roomLoads.roomLoadCalculation = true;
    roomLoads.preserveImportedValues = false;
    roomLoads.readonlyEquations = true;
  }

  const equipmentZoning = independentTables.find((table) => table.id === "calc-equipment-zoning");
  if (equipmentZoning) {
    equipmentZoning.headers = [
      { label: "Zone Group" }, { label: "Zone" }, { label: "Space" },
      { label: "Equipment" },
      { label: "Central Equipment" }, { label: "Valve" }, { label: "Reheat Coil" },
      { label: "Cooling Equipment" }, { label: "Heating Equipment" },
      { label: "Equipment" }, { label: "General Valve" },
    ];
    equipmentZoning.columns = equipmentZoning.headers.map((header) => header.label);
    equipmentZoning.columnTypes = Array(equipmentZoning.headers.length).fill("text");
    equipmentZoning.rows = equipmentZoning.rows.map((row) => [
      row[1] ?? "", "", row[0] ?? "", row[2] ?? "", "", "", row[14] === "-" ? "" : row[14] ?? "",
      row[9] === "-" ? "" : row[9] ?? "", "", row[5] === "-" ? "" : row[5] ?? "", row[4] ?? "",
    ]);
    equipmentZoning.calculatedColumns = [];
    equipmentZoning.lockedColumns = [0, 1, 2];
    equipmentZoning.identityColumns = [0, 1, 2];
    equipmentZoning.frozenColumns = 3;
    equipmentZoning.headerGroups = [
      { label: "General", start: 0, span: 3, className: "space-group-header" },
      { label: "Ventilation", start: 3, span: 1, className: "ventilation-header" },
      { label: "Building Level Circulation", start: 4, span: 3, className: "building-circulation-header" },
      { label: "Zone Level Circulation", start: 7, span: 2, className: "zone-circulation-header" },
      { label: "Exhaust", start: 9, span: 2, className: "exhaust-header" },
    ];
    equipmentZoning.headerClasses = {
      3: "ventilation-header", 4: "sensible-cooling-header", 5: "valve-header", 6: "heating-load-header",
      7: "sensible-cooling-header", 8: "heating-load-header", 9: "exhaust-header", 10: "exhaust-header",
    };
    equipmentZoning.sectionStartColumns = [4, 7, 9];
    equipmentZoning.autoColumns = [3, 4, 5, 6, 7, 8, 9];
    equipmentZoning.equipmentZoningCalculation = true;
    equipmentZoning.preserveImportedValues = false;
    equipmentZoning.readonlyEquations = true;
    equipmentZoning.schemaVersion = 2;
  }

  const gains = independentTables.find((table) => table.id === "calc-internal-gains");
  if (gains) {
    const oldCalculated = new Set(gains.calculatedColumns || []);
    const oldDisplayEquations = { ...(gains.displayEquations || {}) };
    const buildGainTable = ({ id, name, range, activeSourceIndex, sourceIndexes, headers, summarySourceIndexes = [], oneDecimalSourceIndexes = [] }) => {
      const tableHeaders = [{ label: "Space" }, { label: "Type" }, { label: "Area", unit: "ft2" }, ...headers, { label: "Active" }];
      const table = {
        id, name, standard: name, description: `${name} split from the workbook Calc table.`, sheet: "Calc", range,
        headers: tableHeaders,
        columns: tableHeaders.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`),
        columnTypes: tableHeaders.map((_, index) => index < 2 || index === tableHeaders.length - 1 ? "text" : "number"),
        rows: gains.rows.map((row) => {
          const source = bySpace.get(String(row[0])) || [];
          const active = row[activeSourceIndex] === true || String(row[activeSourceIndex]).toLowerCase() === "true";
          return [row[0], source[1] ?? "", source[3] ?? "", ...sourceIndexes.map((index) => row[index]), active ? "Yes" : "No"];
        }),
        calculatedColumns: [...sourceIndexes.map((sourceIndex, index) => oldCalculated.has(sourceIndex) ? index + 3 : -1).filter((index) => index >= 0), tableHeaders.length - 1],
        lockedColumns: [0, 1, 2], identityColumns: [0, 1, 2], frozenColumns: 3,
        summaryColumns: summarySourceIndexes.map((sourceIndex) => sourceIndexes.indexOf(sourceIndex) + 3).filter((index) => index >= 3),
        oneDecimalColumns: oneDecimalSourceIndexes.map((sourceIndex) => sourceIndexes.indexOf(sourceIndex) + 3).filter((index) => index >= 3),
        displayEquations: {}, preserveImportedValues: true, readonlyEquations: true, schemaVersion: 1,
      };
      sourceIndexes.forEach((sourceIndex, index) => {
        if (oldDisplayEquations[sourceIndex]) table.displayEquations[index + 3] = oldDisplayEquations[sourceIndex];
      });
      if (oldDisplayEquations[activeSourceIndex]) table.displayEquations[tableHeaders.length - 1] = oldDisplayEquations[activeSourceIndex];
      independentTables.push(table);
    };

    buildGainTable({
      id: "calc-lighting-gains", name: "Lighting Gains", range: "W:AC", activeSourceIndex: 1,
      sourceIndexes: [2, 3, 4, 5, 6, 7], summarySourceIndexes: [6, 7], oneDecimalSourceIndexes: [2, 3, 5],
      headers: [
        { label: "Thermal Template Lighting Power Density", unit: "W/ft2" },
        { label: "Recommended Lighting Power Density", unit: "W/ft2" },
        { label: "Detailed Lighting Load", unit: "W" },
        { label: "Manual Lighting Power Density", unit: "W/ft2" },
        { label: "Proposed Lighting Load", unit: "Btu/h" },
        { label: "Baseline Lighting Load", unit: "Btu/h" },
      ],
    });
    buildGainTable({
      id: "calc-people-gains", name: "People Gains", range: "AD:AK", activeSourceIndex: 8,
      sourceIndexes: [9, 10, 11, 12, 13, 14, 15], summarySourceIndexes: [12, 13, 14, 15],
      headers: [
        { label: "Thermal Template Sensible Heat", unit: "Btu/h-person" },
        { label: "Thermal Template Latent Heat", unit: "Btu/h-person" },
        { label: "Recommended Area per Person", unit: "ft2/person" },
        { label: "Manual People" }, { label: "People Count", unit: "people" },
        { label: "Sensible People Load", unit: "Btu/h" }, { label: "Latent People Load", unit: "Btu/h" },
      ],
    });
    buildGainTable({
      id: "calc-misc-gains", name: "Miscellaneous Sensible Gains", range: "AL:AP", activeSourceIndex: 16,
      sourceIndexes: [17, 18, 19, 20], summarySourceIndexes: [20], oneDecimalSourceIndexes: [17, 19],
      headers: [
        { label: "Thermal Template Sensible Gain Density", unit: "W/ft2" },
        { label: "Detailed Equipment Load", unit: "Btu/h" },
        { label: "Manual Sensible Gain Density", unit: "W/ft2" },
        { label: "Calculated Miscellaneous Load", unit: "Btu/h" },
      ],
    });

    const thermal = independentTables.find((table) => table.id === "iesve-thermal-template");
    const thermalByType = new Map((thermal?.rows || []).map((row) => [String(row[0]), row]));
    const activityMap = (sourceIndex) => Object.fromEntries(gains.rows.map((row) => [String(row[0]), row[sourceIndex] === true || String(row[sourceIndex]).toLowerCase() === "true"]));

    const lighting = independentTables.find((table) => table.id === "calc-lighting-gains");
    if (lighting) {
      lighting.headers = [
        { label: "Space" }, { label: "Type" }, { label: "Area", unit: "ft2" },
        { label: "Proposed LPD", unit: "W/ft2" }, { label: "Baseline LPD", unit: "W/ft2" },
        { label: "Manual Lighting Gain", unit: "W" }, { label: "Detailed Gains", unit: "W" },
        { label: "Proposed Lighting Gain", unit: "Btu/h" }, { label: "Baseline Lighting Gain", unit: "Btu/h" },
      ];
      lighting.columns = lighting.headers.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`);
      lighting.columnTypes = ["text", "text", "number", "number", "number", "number", "number", "number", "number"];
      lighting.rows = gains.rows.map((row) => {
        const source = bySpace.get(String(row[0])) || [];
        return [row[0], source[1] ?? "", source[3] ?? "", "", "", "", "", row[6], row[7]];
      });
      lighting.calculatedColumns = [3, 4, 6, 7, 8];
      lighting.lockedColumns = [0, 1, 2]; lighting.identityColumns = [0, 1, 2]; lighting.frozenColumns = 3;
      lighting.summaryColumns = [7, 8]; lighting.oneDecimalColumns = [3, 4];
      lighting.activityBySpace = activityMap(1);
      lighting.volumeBySpace = Object.fromEntries(generalRows.map((row) => [String(row[0]), row[2]]));
      lighting.gainCalculation = "lighting";
      lighting.preserveImportedValues = true; lighting.readonlyEquations = true; lighting.schemaVersion = 3;
      lighting.displayEquations = {
        3: '=IFGAINACTIVE("Lighting", XLOOKUP(@Type, [Thermal Templates]@Space Type, [Thermal Templates]@Proposed LPD))',
        4: '=IFGAINACTIVE("Lighting", XLOOKUP(@Type, [Thermal Templates]@Space Type, [Thermal Templates]@Baseline LPD))',
        6: '=IFGAINACTIVE("Lighting", SUMIF([Lighting Loads]@Space Name, @Space, [Lighting Loads]@Gain))',
        7: '=IFGAINACTIVE("Lighting", 3.412 * COALESCE(@Detailed Gains, @Manual Lighting Gain, @Proposed LPD * @Area))',
        8: '=IFGAINACTIVE("Lighting", 3.412 * @Baseline LPD * @Area)',
      };
    }

    const people = independentTables.find((table) => table.id === "calc-people-gains");
    if (people) {
      people.headers = [
        { label: "Space" }, { label: "Type" }, { label: "Area", unit: "ft2" },
        { label: "Occupant Density", unit: "people/ft2" }, { label: "Manual People", unit: "people" },
        { label: "Actual People", unit: "people" }, { label: "Sensible Heat", unit: "Btu/h-person" },
        { label: "Latent Heat", unit: "Btu/h-person" }, { label: "Sensible Load", unit: "Btu/h" },
        { label: "Latent Load", unit: "Btu/h" },
      ];
      people.columns = people.headers.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`);
      people.columnTypes = ["text", "text", "number", "number", "number", "number", "number", "number", "number", "number"];
      people.rows = gains.rows.map((row) => {
        const source = bySpace.get(String(row[0])) || [];
        return [row[0], source[1] ?? "", source[3] ?? "", "", row[12], row[13], "", "", row[14], row[15]];
      });
      people.calculatedColumns = [3, 5, 6, 7, 8, 9];
      people.lockedColumns = [0, 1, 2]; people.identityColumns = [0, 1, 2]; people.frozenColumns = 3;
      people.summaryColumns = [4, 5, 8, 9]; people.zeroDecimalColumns = [5];
      people.activityBySpace = activityMap(8); people.gainCalculation = "people";
      people.preserveImportedValues = true; people.readonlyEquations = true; people.schemaVersion = 3;
      people.displayEquations = {
        3: '=IFGAINACTIVE("People", XLOOKUP(@Type, [Thermal Templates]@Space Type, [Thermal Templates]@Occupant Density) / 1000)',
        5: '=IFGAINACTIVE("People", IF(@Manual People="", ROUND(@Occupant Density * @Area, 0), @Manual People))',
        6: '=IFGAINACTIVE("People", XLOOKUP(@Type, [Thermal Templates]@Space Type, [Thermal Templates]@Sensible Heat))',
        7: '=IFGAINACTIVE("People", XLOOKUP(@Type, [Thermal Templates]@Space Type, [Thermal Templates]@Latent Heat))',
        8: '=IFGAINACTIVE("People", @Actual People * @Sensible Heat)',
        9: '=IFGAINACTIVE("People", @Actual People * @Latent Heat)',
      };
    }

    const misc = independentTables.find((table) => table.id === "calc-misc-gains");
    if (misc) {
      misc.headers = [
        { label: "Space" }, { label: "Type" }, { label: "Area", unit: "ft2" },
        { label: "Sensible Heat Gain Density", unit: "W/ft2" },
        { label: "Detailed Equipment Load", unit: "Btu/h" }, { label: "Miscellaneous Sensible Load", unit: "Btu/h" },
      ];
      misc.columns = misc.headers.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`);
      misc.columnTypes = ["text", "text", "number", "number", "number", "number"];
      misc.rows = gains.rows.map((row) => {
        const source = bySpace.get(String(row[0])) || [];
        return [row[0], source[1] ?? "", source[3] ?? "", "", row[18], row[20]];
      });
      misc.calculatedColumns = [3, 4, 5];
      misc.lockedColumns = [0, 1, 2]; misc.identityColumns = [0, 1, 2]; misc.frozenColumns = 3;
      misc.summaryColumns = [5]; misc.oneDecimalColumns = [3];
      misc.activityBySpace = activityMap(16); misc.gainCalculation = "misc";
      misc.preserveImportedValues = true; misc.readonlyEquations = true; misc.schemaVersion = 3;
      misc.displayEquations = {
        3: '=IFGAINACTIVE("Computers", XLOOKUP(@Type, [Thermal Templates]@Space Type, [Thermal Templates]@Sensible Heat Gain Density))',
        4: '=IFGAINACTIVE("Computers", SUMIF([Miscellaneous Sensible Loads]@Space Name, @Space, [Miscellaneous Sensible Loads]@Gain))',
        5: '=IFGAINACTIVE("Computers", COALESCE(@Detailed Equipment Load, 3.412 * @Sensible Heat Gain Density * @Area))',
      };
    }
  }
}

const tabularSpaceHeaders = [
  { label: "Space ID" },
  { label: "Space Name" },
  { label: "Heating Design Supply Air Temperature", unit: "°F" },
  { label: "Cooling Design Supply Air Temperature", unit: "°F" },
  { label: "DHW Consumption Room-level Setting" },
  { label: "DHW Consumption", unit: "US gal/h" },
  { label: "DHW Consumption Pattern" },
  { label: "DHW Pattern Of Use Profile" },
  { label: "Heating Setpoint", unit: "°F" },
  { label: "Cooling Setpoint", unit: "°F" },
  { label: "Saturation Upper Limit", unit: "%" },
  { label: "Gain 1 Input Mode" },
  { label: "Gain 1 Occupancy", unit: "people" },
  { label: "Gain 1 Max. Sensible Gain", unit: "Btu/h" },
  { label: "Gain 1 Max. Sensible Gain", unit: "Btu/h·person" },
  { label: "Gain 1 Max. Latent Gain", unit: "Btu/h·person" },
  { label: "Gain 1 Max. Power Consumption", unit: "Btu/h" },
  { label: "Gain 2 Input Mode" },
  { label: "Gain 2 Occupancy", unit: "people" },
  { label: "Gain 2 Max. Sensible Gain", unit: "Btu/h" },
  { label: "Gain 2 Max. Sensible Gain", unit: "Btu/h·person" },
  { label: "Gain 2 Max. Latent Gain", unit: "Btu/h·person" },
  { label: "Gain 2 Max. Power Consumption", unit: "Btu/h" },
  { label: "Gain 3 Input Mode" },
  { label: "Gain 3 Occupancy", unit: "people" },
  { label: "Gain 3 Max. Sensible Gain", unit: "Btu/h" },
  { label: "Gain 3 Max. Sensible Gain", unit: "Btu/h·person" },
  { label: "Gain 3 Max. Latent Gain", unit: "Btu/h·person" },
  { label: "Gain 3 Max. Power Consumption", unit: "Btu/h" },
  { label: "Basis for OA Requirement" },
  { label: "Outdoor Air Req. Type" },
  { label: "Outdoor Air Req.", unit: "cfm" },
  { label: "Use Exhaust Air Change Req?" },
  { label: "Exhaust Air Change Req." },
  { label: "Exhaust Air Change Req. Unit" },
];

const tabularSpaceCsvHeaders = [
  "Space ID",
  "Space Name (Real)",
  "Heating Design Supply Air Temperature (°F) (Real)",
  "Cooling Design Supply Air Temperature (°F) (Real)",
  "DHW Consumption Room-level Setting (Real)",
  "DHW Consumption (Real)",
  "DHW Consumption Pattern (Real)",
  "DHW Pattern Of Use Profile (Real)",
  "Heating Setpoint (°F) (Real)",
  "Cooling Setpoint (°F) (Real)",
  "% Saturation Upper Limit (Real)",
  "Gain 1 Input Mode (Real)",
  "Gain 1 Occupancy (People) (Real)",
  "Gain 1 Max. Sensible Gain (Btu/h) (Real)",
  "Gain 1 Max. Sensible Gain (Btu/h·person) (Real)",
  "Gain 1 Max. Latent Gain (Btu/h·person) (Real)",
  "Gain 1 Max. Power Consumption (Btu/h) (Real)",
  "Gain 2 Input Mode (Real)",
  "Gain 2 Occupancy (People) (Real)",
  "Gain 2 Max. Sensible Gain (Btu/h) (Real)",
  "Gain 2 Max. Sensible Gain (Btu/h·person) (Real)",
  "Gain 2 Max. Latent Gain (Btu/h·person) (Real)",
  "Gain 2 Max. Power Consumption (Btu/h) (Real)",
  "Gain 3 Input Mode (Real)",
  "Gain 3 Occupancy (People) (Real)",
  "Gain 3 Max. Sensible Gain (Btu/h) (Real)",
  "Gain 3 Max. Sensible Gain (Btu/h·person) (Real)",
  "Gain 3 Max. Latent Gain (Btu/h·person) (Real)",
  "Gain 3 Max. Power Consumption (Btu/h) (Real)",
  "Basis for OA Requirement (Real)",
  "Outdoor Air Req. Type (Real)",
  "Outdoor Air Req. (cfm) (Real)",
  "Use Exhaust Air Change Req? (Real)",
  "Exhaust Air Change Req. (Real)",
  "Exhaust Air Change Req. Unit (Real)",
];

if (!independentTables.some((table) => table.id === "iesve-tabular-space-data")) {
  const numericColumns = new Set([2, 3, 5, 10, 12, 13, 14, 15, 16, 18, 19, 20, 21, 22, 24, 25, 26, 27, 28, 31, 33]);
  independentTables.unshift({
    id: "iesve-tabular-space-data",
    name: "Tabular Space Data",
    standard: "Tabular Space Data",
    description: "IESVE tabular space data structure populated from pasted source data.",
    sheet: "IES Data",
    range: "D3:AL201",
    headers: tabularSpaceHeaders,
    columns: tabularSpaceHeaders.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`),
    columnTypes: tabularSpaceHeaders.map((_, index) => numericColumns.has(index) ? "number" : "text"),
    percentageColumns: [10],
    csvHeaders: tabularSpaceCsvHeaders,
    lockedColumns: tabularSpaceHeaders.map((_, index) => index),
    frozenColumns: 2,
    rows: [],
  });
}

if (!independentTables.some((table) => table.id === "room-zone-loads-report")) {
  const headers = [
    { label: "Zone Group" },
    { label: "Zone" },
    { label: "Room" },
    { label: "Sensible Cooling (without oversizing)", unit: "MBH" },
    { label: "Latent Cooling (without oversizing)", unit: "MBH" },
    { label: "Heating (without oversizing)", unit: "MBH" },
  ];
  independentTables.unshift({
    id: "room-zone-loads-report",
    name: "Room/Zone Loads Report",
    standard: "Room/Zone Loads Report",
    description: "Room and zone loads imported from the workbook report beginning at row 10.",
    sheet: "IES Loads",
    range: "A10:U149",
    headers,
    columns: [
      "Zone Group",
      "Zone",
      "Room",
      "Sensible Cooling Load without Oversizing (MBH)",
      "Latent Cooling Load without Oversizing (MBH)",
      "Heating Load without Oversizing (MBH)",
    ],
    columnTypes: ["text", "text", "text", "number", "number", "number"],
    lockedColumns: headers.map((_, index) => index),
    decimalColumns: [3, 4, 5],
    excelImport: true,
    frozenColumns: 3,
    identityColumns: [0, 1, 2],
    headerClasses: {
      3: "sensible-cooling-header",
      4: "latent-cooling-header",
      5: "heating-load-header",
    },
    rows: [],
  });
}

const tree = document.querySelector("#project-tree");
const search = document.querySelector("#browser-search");
const browser = document.querySelector("#project-browser");
const scrim = document.querySelector("#drawer-scrim");
const moduleContent = document.querySelector("#module-content");
const summaryLinks = document.querySelector("#summary-links");
const shell = document.querySelector(".app-shell");
const projectList = document.querySelector("#project-list");
const projectSearch = document.querySelector("#project-search");
const projectDialog = document.querySelector("#project-dialog");
const projectForm = document.querySelector("#project-form");
const newProjectNumber = document.querySelector("#new-project-number");
const projectDialogError = document.querySelector("#project-dialog-error");
const projectSwitcherToggle = document.querySelector("#project-switcher-toggle");
const tableView = document.querySelector("#table-view");
const modelInputsView = document.querySelector("#model-inputs-view");
const tableScroll = document.querySelector(".table-scroll");
const referenceTable = document.querySelector("#reference-table");
const tableSearch = document.querySelector("#table-search");
const tableCount = document.querySelector("#table-count");
const tableStandard = document.querySelector("#table-standard");
const tableSettings = document.querySelector("#table-settings");
const twoValueSchedule = document.querySelector("#two-value-schedule");
const addTableRowButton = document.querySelector("#add-table-row");
const removeTableRowButton = document.querySelector("#remove-table-row");
const editableKey = document.querySelector(".editable-key");
const calculatedKey = document.querySelector(".calculated-key");
const autoKey = document.querySelector(".auto-key");
const matchKey = document.querySelector(".match-key");
const differentKey = document.querySelector(".different-key");
const formulaBar = document.querySelector("#formula-bar");
const selectedEquation = document.querySelector("#selected-equation");
const editEquationButton = document.querySelector("#edit-equation");
const saveEquationButton = document.querySelector("#save-equation");
const cancelEquationButton = document.querySelector("#cancel-equation");
const formulaError = document.querySelector("#formula-error");
const clipboardActions = document.querySelector("#clipboard-actions");
const excelActions = document.querySelector("#excel-actions");
const importExcelButton = document.querySelector("#import-excel");
const importExcelInput = document.querySelector("#import-excel-input");
const pasteDataButton = document.querySelector("#paste-table-data");
const copyDataButton = document.querySelector("#copy-table-data");
const csvFileStatus = document.querySelector("#csv-file-status");
const templateStatus = document.querySelector("#template-status");
const rowActions = document.querySelector("#row-actions");
const csvComparisonBar = document.querySelector("#csv-comparison-bar");
const csvComparisonColumn = document.querySelector("#csv-comparison-column");
const csvComparisonValue = document.querySelector("#csv-comparison-value");
const csvComparisonStatus = document.querySelector("#csv-comparison-status");
let activeTableId = "";
let tableSort = { tableId: "", column: -1, direction: "asc" };
let selectedTableId = "";
let selectedTableRowIndexes = new Set();
let selectionAnchorIndex = -1;
let selectedTableCells = new Set();
let cellSelectionAnchor = null;
let fillDrag = null;
const undoStack = [];
const redoStack = [];
let applyingHistory = false;

const PROJECTS_KEY = "hvac-projects-v1";
const ACTIVE_PROJECT_KEY = "hvac-active-project-v1";
const EQUATION_OVERRIDES_KEY = "hvac-equation-overrides-v1";
const EQUIPMENT_EQUATION_SCHEMA_KEY = "hvac-equipment-equation-schema-v1";
const tableNumberFormatter = new Intl.NumberFormat("en-US", { maximumFractionDigits: 20 });
const zeroDecimalFormatter = new Intl.NumberFormat("en-US", { maximumFractionDigits: 0 });
const oneDecimalFormatter = new Intl.NumberFormat("en-US", { minimumFractionDigits: 1, maximumFractionDigits: 1 });
const twoDecimalFormatter = new Intl.NumberFormat("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const fiveDecimalFormatter = new Intl.NumberFormat("en-US", { minimumFractionDigits: 5, maximumFractionDigits: 5 });
const calculatedBtuNumberFormatter = new Intl.NumberFormat("en-US", { maximumFractionDigits: 0 });
const projectFields = [...document.querySelectorAll("[data-project-field]")];
let projects = [];
let activeProjectId = "";
let selectedEquationContext = null;
let equationOverrides = {};
const csvImportsByProject = new Map();
const excelImportsByProject = new Map();
let selectedCsvComparisonContext = null;
try {
  equationOverrides = JSON.parse(localStorage.getItem(EQUATION_OVERRIDES_KEY) || "{}");
  if (localStorage.getItem(EQUIPMENT_EQUATION_SCHEMA_KEY) !== "4") {
    if (equationOverrides["schedule-equipment-sensible-gain"]) delete equationOverrides["schedule-equipment-sensible-gain"][5];
    if (equationOverrides["schedule-grouped-equipment-sensible-gain"]) delete equationOverrides["schedule-grouped-equipment-sensible-gain"][4];
    localStorage.setItem(EQUATION_OVERRIDES_KEY, JSON.stringify(equationOverrides));
    localStorage.setItem(EQUIPMENT_EQUATION_SCHEMA_KEY, "4");
  }
} catch {
  equationOverrides = {};
}

const slugify = (text) => text.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");

function renderTree(query = "") {
  const normalized = query.trim().toLowerCase();
  tree.innerHTML = "";
  let resultCount = 0;

  modules.forEach((section) => {
    const groupMatch = section.group.toLowerCase().includes(normalized);
    const visibleItems = section.items.filter((item) => !normalized || groupMatch || item[0].toLowerCase().includes(normalized));
    if (normalized && !groupMatch && !visibleItems.length) return;
    resultCount += visibleItems.length + 1;

    const wrapper = document.createElement("section");
    wrapper.className = "tree-group";

    const row = document.createElement("div");
    row.className = "group-row";

    if (section.items.length) {
      const expander = document.createElement("button");
      expander.className = "group-expander";
      expander.type = "button";
      expander.setAttribute("aria-label", `Collapse ${section.group}`);
      expander.setAttribute("aria-expanded", "true");
      expander.innerHTML = '<span class="chevron" aria-hidden="true">›</span>';
      expander.addEventListener("click", () => {
        wrapper.classList.toggle("collapsed");
        const expanded = !wrapper.classList.contains("collapsed");
        expander.setAttribute("aria-expanded", String(expanded));
        expander.setAttribute("aria-label", `${expanded ? "Collapse" : "Expand"} ${section.group}`);
      });
      row.appendChild(expander);
    } else {
      const spacer = document.createElement("span");
      spacer.className = "group-spacer";
      row.appendChild(spacer);
    }

    const groupLink = document.createElement(section.noSummary ? "span" : "button");
    groupLink.className = "group-link";
    if (section.directView) groupLink.classList.add("featured-group-link");
    if (section.noSummary) groupLink.classList.add("is-static");
    else {
      groupLink.type = "button";
      groupLink.dataset.id = `section-${slugify(section.group)}`;
      groupLink.dataset.title = section.group;
      groupLink.dataset.group = "Project Browser";
      groupLink.dataset.source = section.source;
      groupLink.dataset.description = section.summary;
      if (section.directTable) groupLink.dataset.table = section.directTable;
      else if (section.directView) groupLink.dataset.view = section.directView;
      else groupLink.dataset.summary = "true";
      groupLink.addEventListener("click", () => selectModule(groupLink));
    }
    groupLink.textContent = section.group;
    row.appendChild(groupLink);

    if (section.items.length) {
      const count = document.createElement("span");
      count.className = "item-count";
      count.textContent = String(section.items.length);
      row.appendChild(count);
    }

    wrapper.appendChild(row);

    if (visibleItems.length) {
      const children = document.createElement("div");
      children.className = "tree-children";
      visibleItems.forEach((item) => children.appendChild(createLeaf(item, section.group)));
      wrapper.appendChild(children);
    }
    tree.appendChild(wrapper);
  });

  if (!resultCount) {
    const empty = document.createElement("p");
    empty.className = "no-results";
    empty.textContent = "No calculations match this search.";
    tree.appendChild(empty);
  }

  syncActiveState();
}

function createLeaf(item, group) {
  const button = document.createElement("button");
  button.type = "button";
  button.className = "tree-leaf";
  button.dataset.id = slugify(item[0]);
  button.dataset.title = item[0];
  button.dataset.group = group;
  button.dataset.source = item[1];
  button.dataset.description = item[2];
  if (item[3]) button.dataset.table = item[3];
  button.textContent = item[0];
  button.addEventListener("click", () => selectModule(button));
  return button;
}

function selectModule(button) {
  history.replaceState(null, "", `#${button.dataset.id}`);
  updateWorkspace(button.dataset);
  syncActiveState();
  closeBrowser();
}

const modelInputDefaults = {
  location: "Forest Park, Georgia", countryState: "Curry County, NM", latitude: "33.63 N", longitude: "84.442 W",
  climateZone: "3A", elevation: 1011, weatherFile: "USA_GA_Atlanta-Hartsfield-Jackson_Intl.AP_722190_TMY3.epw",
  coolingPercentile: 1, coolingDb: 91.6, coolingWb: 73.6,
  dehumidificationPercentile: 1, dehumidificationDb: 80.4, dehumidificationHrGr: 128.5,
  heatingPercentile: 99, heatingDb: 27.1, heatingHrGr: 0,
  humidificationPercentile: 99, humidificationDb: 32.1, humidificationHrGr: 9.2,
  ufc: "TRUE",
  proposedWallPrescriptive: "U-", proposedWall: "U-", proposedRoofPrescriptive: "U-", proposedRoof: "U-",
  proposedSwingingDoorPrescriptive: "U-", proposedSwingingDoor: "U-", proposedNonSwingingDoorPrescriptive: "U-", proposedNonSwingingDoor: "U-",
  proposedFenestrationUPrescriptive: "U-", proposedFenestrationShgcPrescriptive: "SHGC-", proposedFenestrationVtPrescriptive: "VT-",
  proposedFenestrationU: "U-", proposedFenestrationShgc: "SHGC-", proposedFenestrationVt: "VT-",
  proposedGroundFloorPrescriptive: "F-", proposedGroundFloor: "F-",
  baselineWall: "U-", baselineRoof: "U-", baselineSwingingDoor: "U-", baselineNonSwingingDoor: "U-",
  baselineFenestrationU: "U-", baselineFenestrationShgc: "SHGC-", baselineFenestrationVt: "VT-", baselineGroundFloor: "F-",
  baselineBuildingType: "Other Nonresidential 4-5 Floors or 25,000-150,000 ft2",
};

function modelInputCalculations(values) {
  const elevation = Number(values.elevation) || 0;
  const pressure = 14.696 * Math.pow(1 - 6.8754e-6 * elevation, 5.2559);
  const weatherValues = (dryBulb, humidityRatio) => {
    const db = Number(dryBulb) || 0;
    const hr = Number(humidityRatio) || 0;
    const absoluteTemperature = db + 459.67;
    const density = 0.075 * (pressure / 14.696) * (530 / absoluteTemperature) / (1 + 1.6078 * hr);
    return {
      sensible: 60 * density * (0.241 + 0.444 * hr),
      latent: 60 * density * (1093 - 0.556 * db),
    };
  };
  const coolingDbC = ((Number(values.coolingDb) || 0) - 32) * 5 / 9;
  const coolingWbC = ((Number(values.coolingWb) || 0) - 32) * 5 / 9;
  const saturationPressureKpa = 0.61094 * Math.exp((17.625 * coolingWbC) / (coolingWbC + 243.04));
  const saturationPressurePsia = saturationPressureKpa / 6.89476;
  const saturatedHumidityRatio = 0.621945 * saturationPressurePsia / (pressure - saturationPressurePsia);
  const coolingHr = ((2501 - 2.326 * coolingWbC) * saturatedHumidityRatio - 1.006 * (coolingDbC - coolingWbC))
    / (2501 + 1.86 * coolingDbC - 4.186 * coolingWbC);
  const dehumidificationHr = (Number(values.dehumidificationHrGr) || 0) / 7000;
  const heatingHr = (Number(values.heatingHrGr) || 0) / 7000;
  const humidificationHr = (Number(values.humidificationHrGr) || 0) / 7000;
  return {
    pressure,
    coolingHr, dehumidificationHr, heatingHr, humidificationHr,
    cooling: weatherValues(values.coolingDb, coolingHr),
    dehumidification: weatherValues(values.dehumidificationDb, dehumidificationHr),
    heating: weatherValues(values.heatingDb, heatingHr),
    humidification: weatherValues(values.humidificationDb, humidificationHr),
    infiltration: String(values.ufc).toUpperCase() === "TRUE" ? 0.25 : 0.6,
  };
}

function syncModelInputsToSourceTable(project) {
  const values = project.modelInputs;
  const sourceTable = independentTables.find((table) => table.id === "project-inputs");
  if (!sourceTable) return;
  project.independentTables ||= {};
  const rows = project.independentTables[sourceTable.id] || sourceTable.rows.map((row) => [...row]);
  const assignments = [
    [0, values.location], [1, values.countryState], [2, values.latitude], [3, values.longitude], [4, values.climateZone],
    [5, values.elevation], [6, values.weatherFile], [7, (Number(values.coolingPercentile) || 0) / 100],
    [8, values.coolingDb], [9, values.coolingWb], [10, values.dehumidificationDb], [11, values.dehumidificationHrGr],
    [12, (Number(values.heatingPercentile) || 0) / 100], [13, values.heatingDb], [14, values.humidificationDb],
    [15, values.humidificationHrGr], [16, values.ufc], [17, String(values.ufc).toUpperCase() === "TRUE" ? 0.25 : 0.6],
  ];
  assignments.forEach(([index, value]) => { if (rows[index]) rows[index][2] = value; });
  project.independentTables[sourceTable.id] = rows;
  project.independentTableSchemaVersions ||= {};
  project.independentTableSchemaVersions[sourceTable.id] = sourceTable.schemaVersion;
}

function renderModelInputs() {
  const project = activeProject();
  if (!project) return;
  if (!project.modelInputs) {
    const sourceRows = project.independentTables?.["project-inputs"];
    if (Array.isArray(sourceRows) && sourceRows.length >= 18) {
      project.modelInputs = {
        ...modelInputDefaults,
        location: sourceRows[0]?.[2], countryState: sourceRows[1]?.[2], latitude: sourceRows[2]?.[2], longitude: sourceRows[3]?.[2],
        climateZone: sourceRows[4]?.[2], elevation: sourceRows[5]?.[2], weatherFile: sourceRows[6]?.[2],
        coolingPercentile: (Number(sourceRows[7]?.[2]) || 0) * 100, coolingDb: sourceRows[8]?.[2], coolingWb: sourceRows[9]?.[2],
        dehumidificationDb: sourceRows[10]?.[2], dehumidificationHrGr: sourceRows[11]?.[2],
        heatingPercentile: (Number(sourceRows[12]?.[2]) || 0) * 100, heatingDb: sourceRows[13]?.[2],
        humidificationDb: sourceRows[14]?.[2], humidificationHrGr: sourceRows[15]?.[2], ufc: sourceRows[16]?.[2],
      };
    }
  }
  project.modelInputs = { ...modelInputDefaults, ...(project.modelInputs || {}) };
  const values = project.modelInputs;
  const calculated = modelInputCalculations(values);
  modelInputsView.innerHTML = "";

  const addSection = (title, className = "") => {
    const section = document.createElement("section");
    section.className = `model-input-section ${className}`.trim();
    const heading = document.createElement("h3");
    heading.textContent = title;
    section.appendChild(heading);
    modelInputsView.appendChild(section);
    return section;
  };
  const addField = (parent, label, key, options = {}) => {
    const field = document.createElement("label");
    if (options.wide) field.classList.add("wide-field");
    if (options.className) field.classList.add(options.className);
    const caption = document.createElement("span");
    appendFormattedText(caption, label);
    const input = document.createElement(options.select ? "select" : "input");
    input.dataset.modelInput = key;
    if (options.select) {
      options.select.forEach((optionValue) => {
        const option = document.createElement("option"); option.value = optionValue; option.textContent = optionValue; input.appendChild(option);
      });
    }
    input.value = values[key] ?? "";
    input.addEventListener("change", () => {
      values[key] = options.number && input.value !== "" ? Number(input.value) : input.value;
      syncModelInputsToSourceTable(project); saveProjects(); renderModelInputs();
    });
    field.append(caption, input); parent.appendChild(field); return input;
  };
  const addCalculated = (parent, label, value, digits = 5, equation = "") => {
    const field = document.createElement("label");
    const caption = document.createElement("span"); appendFormattedText(caption, label);
    const input = document.createElement("input"); input.className = "calculated-value"; input.readOnly = true;
    input.value = typeof value === "number" && Number.isFinite(value) ? Number(value).toFixed(digits) : value ?? "";
    input.dataset.equation = equation;
    input.addEventListener("click", () => showModelInputEquation(equation));
    field.append(caption, input); parent.appendChild(field); return field;
  };

  const climateOptionsTable = independentTables.find((table) => table.id === "ashrae-climate-zones");
  const climateZoneOptions = (climateOptionsTable?.rows || []).map((row) => String(row[0] ?? "")).filter(Boolean);
  const site = addSection("Site, Location, and Climate", "site-inputs");
  addField(site, "Location & Site Data", "location", { className: "half-field" }); addField(site, "Country, State", "countryState", { className: "half-field" });
  addField(site, "Latitude", "latitude", { className: "third-field" }); addField(site, "Longitude", "longitude", { className: "third-field" }); addField(site, "Climate Zone", "climateZone", { className: "third-field", select: climateZoneOptions });
  addField(site, "Elevation [ft]", "elevation", { number: true, className: "half-field" }); addCalculated(site, "Barometric Pressure [psia]", calculated.pressure, 3, "=14.696 * (1 - 6.8754E-6 * @Elevation)^5.2559");
  addField(site, "Simulation Weather Data", "weatherFile", { wide: true });

  const design = addSection("Design Weather Data", "design-weather-inputs");
  const designHeader = document.createElement("div"); designHeader.className = "design-weather-row design-weather-header";
  ["Condition", "Percentile [%]", "DB [°F]", "WB [°F]", "HR [gr/lb]", "HR [lb/lb]", "Sensible Constant", "Latent Constant"].forEach((text) => { const span = document.createElement("span"); span.textContent = text; designHeader.appendChild(span); });
  design.appendChild(designHeader);
  const weatherRows = [
    ["Cooling", "cooling", "coolingPercentile", "coolingDb", "coolingWb", null, calculated.coolingHr],
    ["Dehumidification", "dehumidification", "dehumidificationPercentile", "dehumidificationDb", null, "dehumidificationHrGr", calculated.dehumidificationHr],
    ["Heating", "heating", "heatingPercentile", "heatingDb", null, "heatingHrGr", calculated.heatingHr],
    ["Humidification", "humidification", "humidificationPercentile", "humidificationDb", null, "humidificationHrGr", calculated.humidificationHr],
  ];
  weatherRows.forEach(([label, calcKey, percentileKey, dbKey, wbKey, grKey, hrValue]) => {
    const row = document.createElement("div"); row.className = "design-weather-row";
    const name = document.createElement("strong"); name.textContent = label; row.appendChild(name);
    [percentileKey, dbKey, wbKey, grKey].forEach((key) => {
      const input = document.createElement("input"); input.type = "text"; input.value = key ? values[key] ?? "" : ""; input.disabled = !key;
      if (key === "heatingHrGr" && Number(input.value) === 0) input.classList.add("auto-populated-input");
      if (key) input.addEventListener("change", () => { values[key] = input.value === "" ? "" : Number(input.value); syncModelInputsToSourceTable(project); saveProjects(); renderModelInputs(); });
      row.appendChild(input);
    });
    [hrValue, calculated[calcKey].sensible, calculated[calcKey].latent].forEach((value, index) => {
      const equations = [
        calcKey === "cooling" ? "=PSYCHROMETRIC_HR(@DB, @WB, @Barometric Pressure)" : "=@HR [gr/lb] / 7000",
        "=60 * @Air Density * (0.241 + 0.444 * @HR)",
        "=60 * @Air Density * (1093 - 0.556 * @DB)",
      ];
      const input = document.createElement("input"); input.readOnly = true; input.className = "calculated-value"; input.value = Number(value).toFixed(index ? 3 : 5);
      input.addEventListener("click", () => showModelInputEquation(equations[index])); row.appendChild(input);
    });
    design.appendChild(row);
  });

  const building = addSection("Proposed Building Construction", "building-inputs");
  const generalTable = independentTables.find((table) => table.id === "calc-general");
  const conditionTable = independentTables.find((table) => table.id === "calc-condition-baseline");
  const generalRows = generalTable ? projectTableRows(generalTable) : [];
  const conditionRows = conditionTable ? projectTableRows(conditionTable) : [];
  const areaBySpace = new Map(generalRows.map((row) => [String(row[0] ?? ""), Number(row[3]) || 0]));
  const areas = conditionRows.reduce((totals, row) => {
    const condition = String(row[10] ?? "Unconditioned");
    const area = areaBySpace.get(String(row[0] ?? "")) || 0;
    if (condition === "Conditioned") totals.conditioned += area;
    else if (condition === "Semiheated") totals.semiheated += area;
    else totals.unconditioned += area;
    totals.total += area;
    return totals;
  }, { conditioned: 0, semiheated: 0, unconditioned: 0, total: 0 });
  addCalculated(building, "Conditioned [ft2]", areas.conditioned, 1, '=SUMIF([Space Condition and Baseline]@Condition, "Conditioned", @Area)');
  addCalculated(building, "Semiheated [ft2]", areas.semiheated, 1, '=SUMIF([Space Condition and Baseline]@Condition, "Semiheated", @Area)');
  addCalculated(building, "Unconditioned [ft2]", areas.unconditioned, 1, '=SUMIF([Space Condition and Baseline]@Condition, "Unconditioned", @Area)');
  addCalculated(building, "Total Area [ft2]", areas.total, 1, '=SUM([Space Calculations]@Area)');
  addField(building, "UFC", "ufc", { select: ["TRUE", ""] });
  const proposedInfiltration = addCalculated(building, "Infiltration at 0.3 in. Pressure Differential [CFM/ft2]", calculated.infiltration, 2, '=IF(@UFC="TRUE", 0.25, 0.60)');
  proposedInfiltration.classList.add("infiltration-field");

  const addConstructionGrid = (parent, baseline = false) => {
    const grid = document.createElement("div"); grid.className = `construction-grid ${baseline ? "baseline-grid" : "proposed-grid"}`;
    const headings = baseline
      ? ["Assembly", "U/F", "SHGC", "VT"]
      : ["Assembly", "Prescriptive U/F", "Prescriptive SHGC", "Prescriptive VT", "Proposed U/F", "Proposed SHGC", "Proposed VT"];
    headings.forEach((heading) => { const span = document.createElement("span"); span.className = "construction-heading"; span.textContent = heading; grid.appendChild(span); });
    const definitions = baseline ? [
      ["External Walls", "baselineWall"], ["Roof", "baselineRoof"], ["Swinging Doors", "baselineSwingingDoor"],
      ["Non-Swinging Doors", "baselineNonSwingingDoor"], ["Fenestrations", "baselineFenestrationU", "baselineFenestrationShgc", "baselineFenestrationVt"],
      ["Perimeter Room Ground Floors", "baselineGroundFloor"],
    ] : [
      ["External Walls", "proposedWallPrescriptive", null, null, "proposedWall"],
      ["Roof", "proposedRoofPrescriptive", null, null, "proposedRoof"],
      ["Swinging Doors", "proposedSwingingDoorPrescriptive", null, null, "proposedSwingingDoor"],
      ["Non-Swinging Doors", "proposedNonSwingingDoorPrescriptive", null, null, "proposedNonSwingingDoor"],
      ["Fenestrations", "proposedFenestrationUPrescriptive", "proposedFenestrationShgcPrescriptive", "proposedFenestrationVtPrescriptive", "proposedFenestrationU", "proposedFenestrationShgc", "proposedFenestrationVt"],
      ["Perimeter Room Ground Floors", "proposedGroundFloorPrescriptive", null, null, "proposedGroundFloor"],
    ];
    definitions.forEach(([label, ...keys]) => {
      const name = document.createElement("strong"); name.textContent = label; grid.appendChild(name);
      const width = baseline ? 3 : 6;
      for (let index = 0; index < width; index += 1) {
        const key = keys[index];
        if (!key) {
          const empty = document.createElement("span"); empty.className = "construction-empty"; grid.appendChild(empty); continue;
        }
        const wrapper = document.createElement("label"); wrapper.className = "construction-value";
        const storedValue = String(values[key] ?? "");
        const defaultPrefix = key.toLowerCase().includes("shgc") ? "SHGC-" : key.toLowerCase().includes("vt") ? "VT-" : key.toLowerCase().includes("ground") ? "F-" : "U-";
        const prefix = ["SHGC-", "VT-", "F-", "U-"].find((candidate) => storedValue.startsWith(candidate)) || defaultPrefix;
        const prefixLabel = document.createElement("span"); prefixLabel.textContent = prefix;
        const input = document.createElement("input"); input.value = storedValue.startsWith(prefix) ? storedValue.slice(prefix.length) : storedValue;
        input.addEventListener("change", () => { values[key] = `${prefix}${input.value}`; saveProjects(); });
        wrapper.append(prefixLabel, input); grid.appendChild(wrapper);
      }
    });
    parent.appendChild(grid);
  };
  addConstructionGrid(building);

  const baseline = addSection("ASHRAE Baseline Building Construction", "baseline-building-inputs");
  addCalculated(baseline, "Infiltration at 0.3 in. Pressure Differential [CFM/ft2]", 1, 2, "=1.00");
  addConstructionGrid(baseline, true);
  const climateTable = independentTables.find((table) => table.id === "ashrae-climate-zones");
  const systemTable = independentTables.find((table) => table.id === "ashrae-90-1-baseline-systems");
  const buildingTypes = (climateTable?.headers || []).slice(2, 10).map((header) => header.label);
  if (!buildingTypes.includes(values.baselineBuildingType)) values.baselineBuildingType = buildingTypes[6] || values.baselineBuildingType;
  addField(baseline, "Building Type", "baselineBuildingType", { select: buildingTypes, wide: true });
  const climateRow = (climateTable?.rows || []).find((row) => String(row[0]) === String(values.climateZone));
  const buildingTypeIndex = (climateTable?.headers || []).findIndex((header) => header.label === values.baselineBuildingType);
  const systemNumber = climateRow?.[buildingTypeIndex] || "";
  const system = (systemTable?.rows || []).find((row) => String(row[0]) === String(systemNumber)) || [];
  [
    ["Number", systemNumber, '=XLOOKUP(@Climate Zone, [Climate Zones]@Climate Zone, [Climate Zones]@Building Type)'],
    ["System", system[1] ?? "", '=XLOOKUP(@Number, [Baseline System Descriptions]@Number, @System)'],
    ["System Type", system[2] ?? "", '=XLOOKUP(@Number, [Baseline System Descriptions]@Number, @System Type)'],
    ["Fan Control", system[3] ?? "", '=XLOOKUP(@Number, [Baseline System Descriptions]@Number, @Fan Control)'],
    ["Cooling Type", system[4] ?? "", '=XLOOKUP(@Number, [Baseline System Descriptions]@Number, @Cooling Type)'],
    ["Heating Type", system[5] ?? "", '=XLOOKUP(@Number, [Baseline System Descriptions]@Number, @Heating Type)'],
  ].forEach(([label, value, equation]) => addCalculated(baseline, label, value, 0, equation));

  const formula = document.createElement("div"); formula.className = "model-input-formula"; formula.hidden = true;
  const symbol = document.createElement("span"); symbol.textContent = "fx";
  const output = document.createElement("output");
  formula.append(symbol, output); modelInputsView.appendChild(formula);
}

function showModelInputEquation(equation) {
  const bar = modelInputsView.querySelector(".model-input-formula");
  const output = modelInputsView.querySelector(".model-input-formula output");
  if (!bar || !output) return;
  if (!equation) { bar.hidden = true; return; }
  output.textContent = equation;
  bar.hidden = false;
}

function hideModelInputEquation() {
  const bar = modelInputsView.querySelector(".model-input-formula");
  if (bar) bar.hidden = true;
}

function updateWorkspace(data) {
  const isSummary = data.summary === "true";
  const isTable = Boolean(data.table);
  const isModelInputs = data.view === "model-inputs";
  document.querySelector("#crumb-group").textContent = data.group;
  document.querySelector("#crumb-page").textContent = data.title;
  document.querySelector("#page-kicker").textContent = isSummary ? "SECTION SUMMARY" : data.group.toUpperCase();
  document.querySelector("#page-title").textContent = data.title;
  document.querySelector("#page-description").textContent = data.description;
  document.querySelector("#source-sheet").textContent = data.source;
  document.querySelector(".section-label").textContent = isSummary ? "TABLE CONTENTS" : "CURRENT MODULE";
  document.querySelector("#module-heading").textContent = data.title;
  document.querySelector("#module-status").textContent = isTable || isModelInputs ? "Migrated" : "Structure ready";
  document.querySelector("#parity-status").textContent = isTable || isModelInputs ? "Workbook data matched" : "Not tested";
  document.querySelector("#revision-status").textContent = isTable || isModelInputs ? "Workbook source preserved" : "Source preserved";
  document.querySelector("#module-action").textContent = isModelInputs ? "Project inputs" : isTable ? "Editable table" : "Calculation pending";
  document.querySelector("#empty-title").textContent = isSummary ? `${data.title} summary` : "Ready for workbook logic";
  document.querySelector("#empty-copy").textContent = isSummary
    ? data.description
    : "The navigation and source mapping are in place. Inputs, equations, units, validation, and Excel parity tests will be added in the next migration increment.";
  moduleContent.classList.toggle("is-summary", isSummary);
  shell.classList.toggle("summary-mode", isSummary);
  shell.classList.toggle("table-mode", isTable);
  shell.classList.toggle("model-inputs-mode", isModelInputs);
  moduleContent.hidden = isTable || isModelInputs || !isSummary;
  tableView.hidden = !isTable;
  modelInputsView.hidden = !isModelInputs;
  if (isTable) {
    tableSearch.value = "";
    renderReferenceTable(data.table);
  } else if (isModelInputs) {
    activeTableId = "";
    renderModelInputs();
  } else {
    activeTableId = "";
    renderSummaryLinks(isSummary ? data.title : null);
  }
  document.title = `${data.title} · HVAC Design Workbook`;
}

function updateTableSettings(table) {
  const visible = Boolean(table.twoValueScheduleDefault);
  tableSettings.hidden = !visible;
  if (!visible) return;
  const project = activeProject();
  if (!project) {
    twoValueSchedule.value = table.twoValueScheduleDefault;
    return;
  }
  project.calcSettings ||= {};
  twoValueSchedule.value = project.calcSettings.twoValueSchedule || table.twoValueScheduleDefault;
}

function isConditionalCalculatedCell(table, row, columnIndex) {
  const config = table.conditionalCalculatedColumns?.[columnIndex];
  if (!config) return false;
  const value = row[config.whenColumn];
  return value !== "" && value !== null && value !== undefined;
}

function isUnusedGainCell(table, row, columnIndex) {
  const populated = (value) => value !== "" && value !== null && value !== undefined;
  if (table.id === "calc-lighting-gains") {
    if (columnIndex === 3) return populated(row[6]) || populated(row[5]);
    if (columnIndex === 5) return populated(row[6]);
  }
  if (table.id === "calc-people-gains" && columnIndex === 3) return populated(row[4]);
  if (table.id === "calc-misc-gains" && columnIndex === 3) return populated(row[4]);
  return false;
}

function humidityRatio(dryBulbF, relativeHumidity) {
  const dryBulb = Number(dryBulbF);
  const humidity = Number(relativeHumidity);
  if (!Number.isFinite(dryBulb) || !Number.isFinite(humidity)) return "";
  const dryBulbC = (dryBulb - 32) * 5 / 9;
  const saturationPressure = 0.145038 * 0.61094 * Math.exp((17.625 * dryBulbC) / (dryBulbC + 243.04));
  const vaporPressure = saturationPressure * humidity;
  return 0.621945 * vaporPressure / (14.166979464192584 - vaporPressure);
}

function recalculateSpecialTableRow(table, row) {
  if (table.id !== "calc-space-condition-setpoints") return;
  if (isConditionalCalculatedCell(table, row, 7)) {
    const rise = Number(row[6]);
    row[7] = Number.isFinite(rise) ? 91.6 + rise : "";
  }
  row[5] = humidityRatio(row[3], row[2]);
  row[9] = humidityRatio(row[7], row[2]);
}

function clearFillPreview() {
  referenceTable.querySelectorAll(".fill-preview").forEach((cell) => cell.classList.remove("fill-preview"));
}

function clearFillHandle() {
  document.querySelectorAll("body > .fill-handle").forEach((handle) => handle.remove());
  referenceTable.querySelectorAll(".fill-source").forEach((source) => source.classList.remove("fill-source"));
}

function showFillHandle(cell, table, rows, sourceIndex, columnIndex) {
  clearFillHandle();
  if (!cell.classList.contains("editable-cell")) return;
  cell.classList.add("fill-source");
  const cellRect = cell.getBoundingClientRect();
  const handle = document.createElement("span");
  handle.className = "fill-handle";
  handle.style.left = `${cellRect.right - 7}px`;
  handle.style.top = `${cellRect.bottom - 7}px`;
  handle.setAttribute("role", "button");
  handle.setAttribute("aria-label", "Drag to fill cells below");
  handle.addEventListener("pointerdown", (event) => {
    event.preventDefault();
    event.stopPropagation();
    handle.setPointerCapture?.(event.pointerId);
    fillDrag = { table, rows, sourceIndex, columnIndex, sourceValue: rows[sourceIndex][columnIndex], targetIndexes: [] };
  });
  document.body.appendChild(handle);
}

function updateFillPreview(clientX, clientY) {
  if (!fillDrag) return;
  const target = document.elementFromPoint(clientX, clientY)?.closest?.("td");
  if (!target || Number(target.dataset.columnIndex) !== fillDrag.columnIndex) return;
  const bodyRows = [...referenceTable.querySelectorAll("tbody tr:not(.table-summary-row)")];
  const originRow = bodyRows.findIndex((row) => Number(row.dataset.sourceIndex) === fillDrag.sourceIndex);
  const targetRow = bodyRows.indexOf(target.parentElement);
  if (originRow < 0 || targetRow < 0) return;
  const [start, end] = originRow <= targetRow ? [originRow, targetRow] : [targetRow, originRow];
  fillDrag.targetIndexes = bodyRows.slice(start, end + 1).map((row) => Number(row.dataset.sourceIndex));
  clearFillPreview();
  bodyRows.slice(start, end + 1).forEach((row) => row.cells[fillDrag.columnIndex]?.classList.add("fill-preview"));
}

function finishFillDrag() {
  if (!fillDrag) return;
  const { table, rows, sourceIndex, columnIndex, sourceValue, targetIndexes } = fillDrag;
  targetIndexes.filter((index) => index !== sourceIndex).forEach((index) => {
    rows[index][columnIndex] = sourceValue;
    recalculateSpecialTableRow(table, rows[index]);
  });
  clearFillPreview();
  fillDrag = null;
  recalculateTable(table, rows);
  recalculateDependentTables(table);
  saveProjects();
  renderReferenceTable(table.id, tableSearch.value);
}

function renderReferenceTable(tableId, query = tableSearch.value) {
  const table = independentTables.find((candidate) => candidate.id === tableId);
  if (!table) return;
  clearFillHandle();
  activeTableId = tableId;
  tableStandard.textContent = table.standard;
  updateTableSettings(table);
  referenceTable.classList.toggle("two-frozen-columns", table.frozenColumns === 2);
  referenceTable.classList.toggle("three-frozen-columns", table.frozenColumns === 3);
  calculatedKey.hidden = ![...(table.calculatedColumns || []), ...(table.lockedColumns || [])].length;
  updateCsvToolbar(table);
  clearCsvComparison();
  clearSelectedEquation();
  const normalized = query.trim().toLowerCase();
  const sourceRows = projectTableRows(table);
  recalculateTable(table, sourceRows);
  const headers = displayedTableHeaders(table);
  if (selectedTableId !== tableId) {
    selectedTableId = "";
    selectedTableRowIndexes.clear();
    selectionAnchorIndex = -1;
    selectedTableCells.clear();
    cellSelectionAnchor = null;
  } else {
    selectedTableRowIndexes = new Set([...selectedTableRowIndexes].filter((index) => index < sourceRows.length));
  }
  removeTableRowButton.disabled = selectedTableRowIndexes.size === 0;
  const rows = sourceRows
    .map((row, sourceIndex) => ({ row, sourceIndex }))
    .filter(({ row }) => !normalized || row.some((value) => String(value ?? "").toLowerCase().includes(normalized)));

  if (tableSort.tableId === tableId && tableSort.column >= 0) {
    const { column, direction } = tableSort;
    rows.sort((left, right) => compareTableValues(left.row[column], right.row[column]) * (direction === "asc" ? 1 : -1));
  }

  referenceTable.innerHTML = "";
  referenceTable.setAttribute("aria-multiselectable", "true");
  const head = document.createElement("thead");
  if (table.headerGroups?.length) {
    const groupRow = document.createElement("tr");
    groupRow.className = "group-header-row";
    table.headerGroups.forEach((group) => {
      const cell = document.createElement("th");
      cell.colSpan = group.span;
      cell.scope = "colgroup";
      cell.textContent = group.label;
      if (group.className) cell.classList.add(group.className);
      if ((table.sectionStartColumns || []).includes(group.start)) cell.classList.add("section-divider");
      groupRow.appendChild(cell);
    });
    head.appendChild(groupRow);
  }
  const headerRow = document.createElement("tr");
  headers.forEach((header, columnIndex) => {
    const cell = document.createElement("th");
    cell.scope = "col";
    if ((table.calculatedColumns || []).includes(columnIndex)) cell.classList.add("calculated-header");
    if (table.headerClasses?.[columnIndex]) cell.classList.add(table.headerClasses[columnIndex]);
    if ((table.sectionStartColumns || []).includes(columnIndex)) cell.classList.add("section-divider");
    const content = document.createElement("div");
    content.className = "table-header-content";

    const label = document.createElement("span");
    label.className = "column-label";
    appendFormattedText(label, header.label);
    if (header.subscript) {
      const subscript = document.createElement("sub");
      subscript.textContent = header.subscript;
      label.appendChild(subscript);
    }
    content.appendChild(label);

    if (header.unit) {
      const unit = document.createElement("span");
      unit.className = "column-unit";
      appendFormattedText(unit, header.unit);
      content.appendChild(unit);
    }

    const sortButton = document.createElement("button");
    sortButton.type = "button";
    sortButton.className = "column-sort-control";
    sortButton.title = `Sort by ${header.label}`;
    sortButton.setAttribute("aria-label", `Sort by ${header.label}`);
    if (tableSort.tableId === tableId && tableSort.column === columnIndex) {
      sortButton.textContent = tableSort.direction === "asc" ? "↑" : "↓";
      cell.setAttribute("aria-sort", tableSort.direction === "asc" ? "ascending" : "descending");
    } else {
      sortButton.textContent = "↕";
    }
    sortButton.addEventListener("click", () => sortReferenceTable(tableId, columnIndex));
    content.appendChild(sortButton);
    cell.appendChild(content);
    headerRow.appendChild(cell);
  });
  head.appendChild(headerRow);

  const dropdownOptionsByColumn = new Map(
    Object.keys(table.dropdownColumns || {}).map((columnIndex) => {
      const index = Number(columnIndex);
      return [index, tableDropdownOptions(table, index)];
    }),
  );

  const body = document.createElement("tbody");
  rows.forEach(({ row, sourceIndex }) => {
    const tableRow = document.createElement("tr");
    tableRow.dataset.sourceIndex = String(sourceIndex);
    tableRow.classList.toggle("selected-row", selectedTableId === tableId && selectedTableRowIndexes.has(sourceIndex));
    tableRow.setAttribute("aria-selected", String(selectedTableId === tableId && selectedTableRowIndexes.has(sourceIndex)));
    tableRow.addEventListener("click", (event) => {
      if (event.target.closest("td.editable-cell")) return;
      selectTableRow(tableId, tableRow, sourceIndex, event);
    });
    row.forEach((value, index) => {
      const cell = document.createElement("td");
      cell.dataset.sourceIndex = String(sourceIndex);
      cell.dataset.columnIndex = String(index);
      if (typeof value === "number") cell.classList.add("numeric-cell");
      if ((table.sectionStartColumns || []).includes(index)) cell.classList.add("section-divider");
      if (isUnusedGainCell(table, row, index)) cell.classList.add("inactive-gain-cell");
      if ((table.id === "iesve-tabular-space-data" && index < 2) || (table.identityColumns || []).includes(index)) {
        cell.classList.add("identity-cell");
      }
      const conditionalCalculated = isConditionalCalculatedCell(table, row, index);
      const calculated = (table.calculatedColumns || []).includes(index) || conditionalCalculated;
      const dynamicLocked = table.lockedCellStates?.get(sourceIndex)?.has(index);
      const locked = (table.lockedColumns || []).includes(index) || conditionalCalculated || dynamicLocked;
      if (table.autoCellStates?.get(sourceIndex)?.has(index) && !dynamicLocked) cell.classList.add("auto-populated-cell");
      if (dynamicLocked) cell.classList.add("dynamically-locked-cell");
      if (calculated || locked) {
        cell.textContent = formatTableValue(value, table, index);
        cell.classList.add("calculated-cell");
        if (locked) cell.classList.add("locked-cell");
        cell.tabIndex = 0;
        const imported = Boolean(table.excelImport);
        cell.title = imported ? "Imported value" : dynamicLocked
          ? table.lockedCellMessages?.get(sourceIndex)?.get(index) || "Locked by the active equipment path"
          : calculated ? "Calculated value; select to view the equation" : "Calculated value";
        cell.setAttribute("aria-label", `${imported ? "Imported" : "Calculated"} ${table.headers[index].label}, row ${sourceIndex + 1}`);
        if (calculated) {
          cell.addEventListener("click", () => showSelectedEquation(table, cell, index));
          cell.addEventListener("focus", () => showSelectedEquation(table, cell, index));
        } else {
          cell.addEventListener("focus", clearSelectedEquation);
        }
        cell.addEventListener("keydown", (event) => {
          if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(event.key)) {
            event.preventDefault();
            moveToAdjacentCell(cell, event.key, event.shiftKey);
          }
        });
      } else if (table.dropdownColumns?.[index] || table.cellDropdownRows?.[sourceIndex]?.[index]) {
        cell.classList.add("editable-cell", "dropdown-cell");
        const select = document.createElement("select");
        select.className = "table-cell-select";
        select.setAttribute("aria-label", `Select ${table.headers[index].label}, row ${sourceIndex + 1}`);
        const options = table.cellDropdownRows?.[sourceIndex]?.[index] || dropdownOptionsByColumn.get(index) || [];
        const rawCurrentValue = String(value ?? "");
        const normalizedOption = options.find((option) => option.localeCompare(rawCurrentValue, undefined, { sensitivity: "base" }) === 0);
        const currentValue = normalizedOption || rawCurrentValue;
        const addOption = (optionValue) => {
          const option = document.createElement("option");
          option.value = optionValue;
          option.textContent = optionValue;
          select.appendChild(option);
        };
        addOption("");
        if (currentValue !== "") addOption(currentValue);
        select.value = currentValue;
        select.title = select.value;
        const populateDropdownOptions = () => {
          if (select.dataset.optionsLoaded === "true") return;
          const selectedValue = select.value;
          const optionValues = selectedValue !== "" && !options.includes(selectedValue)
            ? [selectedValue, ...options]
            : options;
          select.replaceChildren();
          addOption("");
          optionValues.forEach(addOption);
          select.value = selectedValue;
          select.dataset.optionsLoaded = "true";
        };
        select.addEventListener("pointerdown", populateDropdownOptions);
        select.addEventListener("focus", () => {
          populateDropdownOptions();
          clearSelectedEquation();
          showFillHandle(cell, table, sourceRows, sourceIndex, index);
        });
        select.addEventListener("change", () => {
          select.title = select.value;
          updateTableCell(table, sourceRows, sourceIndex, index, select.value);
        });
        select.addEventListener("keydown", (event) => {
          if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(event.key)) {
            event.preventDefault();
            moveToAdjacentCell(cell, event.key, event.shiftKey);
          }
        });
        cell.appendChild(select);
      } else {
        cell.textContent = formatTableValue(value, table, index);
        cell.classList.add("editable-cell");
        cell.contentEditable = "true";
        cell.spellcheck = false;
        cell.setAttribute("aria-label", `Edit ${table.headers[index].label}, row ${sourceIndex + 1}`);
        cell.addEventListener("focus", () => {
          clearSelectedEquation();
          showFillHandle(cell, table, sourceRows, sourceIndex, index);
        });
        cell.addEventListener("keydown", (event) => {
          if (event.key === "Enter") {
            event.preventDefault();
            cell.blur();
          } else if (!event.shiftKey && ["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(event.key)) {
            event.preventDefault();
            moveToAdjacentCell(cell, event.key, event.shiftKey);
          }
        });
        cell.addEventListener("blur", () => updateTableCell(table, sourceRows, sourceIndex, index, cell.textContent));
      }
      if (table.equipmentZoningCalculation && (table.autoColumns || []).includes(index) && !dynamicLocked) {
        const autoValue = activeProject()?.zoningAutoValues?.[table.id]?.[zoningCellKey(row, index)] ?? "";
        cell.title = `Autopopulated value: ${autoValue || "(blank)"}`;
      }
      decorateCsvComparisonCell(table, cell, row, sourceIndex, index);
      decorateRoomValidationCell(table, cell, value, index);
      cell.addEventListener("pointerdown", (event) => {
        if (event.button !== 0 || !(table.lockedColumns || []).includes(index)) return;
        cell.focus({ preventScroll: true });
        markSelectedTableCell(cell);
      });
      cell.addEventListener("focusin", () => {
        if ((table.lockedColumns || []).includes(index)) markSelectedTableCell(cell);
        showCsvComparison(table, sourceRows, sourceIndex, index);
      });
      cell.addEventListener("click", () => {
        if ((table.lockedColumns || []).includes(index)) {
          cell.focus({ preventScroll: true });
          markSelectedTableCell(cell);
        }
        showCsvComparison(table, sourceRows, sourceIndex, index);
      });
      cell.addEventListener("pointerdown", (event) => {
        if (event.button !== 0 || !cell.classList.contains("editable-cell")) return;
        selectTableCell(tableId, sourceIndex, index, event);
      });
      if (selectedTableCells.has(`${sourceIndex}:${index}`)) cell.classList.add("multi-cell-selected");
      tableRow.appendChild(cell);
    });
    body.appendChild(tableRow);
  });

  let foot = null;
  if ((table.summaryColumns || []).length) {
    foot = document.createElement("tfoot");
    const summaryRow = document.createElement("tr");
    summaryRow.className = "table-summary-row";
    headers.forEach((_, columnIndex) => {
      const cell = document.createElement("td");
      if (columnIndex === 0) cell.textContent = "Total";
      if ((table.summaryColumns || []).includes(columnIndex)) {
        const aggregation = table.summaryAggregations?.[columnIndex] || "sum";
        const total = aggregation === "count"
          ? sourceRows.filter((row) => row[columnIndex] !== "" && row[columnIndex] !== null && row[columnIndex] !== undefined).length
          : sourceRows.reduce((sum, row) => sum + (Number(row[columnIndex]) || 0), 0);
        cell.textContent = formatTableValue(total, table, columnIndex);
        cell.classList.add("numeric-cell");
      }
      if ((table.identityColumns || []).includes(columnIndex)) cell.classList.add("identity-cell");
      summaryRow.appendChild(cell);
    });
    foot.appendChild(summaryRow);
  }

  const widths = calculateColumnWidths(table, headers, sourceRows);
  const columnGroup = document.createElement("colgroup");
  widths.forEach((width) => {
    const column = document.createElement("col");
    column.style.width = `${width}px`;
    columnGroup.appendChild(column);
  });
  referenceTable.append(columnGroup, head, body, ...(foot ? [foot] : []));
  referenceTable.style.width = `${widths.reduce((total, width) => total + width, 0)}px`;
  referenceTable.style.setProperty("--first-column-width", `${widths[0]}px`);
  referenceTable.style.setProperty("--second-column-width", `${widths[1] || 0}px`);
  tableCount.textContent = rows.length === sourceRows.length
    ? `${sourceRows.length} rows`
    : `${rows.length} of ${sourceRows.length} rows`;
}

function appendFormattedText(element, text) {
  String(text).split(/(ft[23])/gi).forEach((part) => {
    if (/^ft[23]$/i.test(part)) {
      element.append("ft");
      const superscript = document.createElement("sup");
      superscript.textContent = part.slice(-1);
      element.appendChild(superscript);
    } else {
      element.append(part);
    }
  });
}

function ensureProjectTableRows(project, table) {
  if (!project) return table.rows;
  project.independentTables ||= {};
  project.independentTableSchemaVersions ||= {};
  let savedRows = project.independentTables[table.id];
  if (table.schemaVersion && project.independentTableSchemaVersions[table.id] !== table.schemaVersion) {
    project.independentTables[table.id] = table.rows.map((row) => [...row]);
    project.independentTableSchemaVersions[table.id] = table.schemaVersion;
    savedRows = project.independentTables[table.id];
    saveProjects();
  }
  if (!Array.isArray(savedRows) && table.sourceTableId && Array.isArray(project.independentTables[table.sourceTableId])) {
    const sourceRows = project.independentTables[table.sourceTableId];
    if (sourceRows.every((row) => row.length >= Math.max(...table.sourceColumnIndexes) + 1)) {
      savedRows = sourceRows.map((row) => table.sourceColumnIndexes.map((index) => row[index]));
      project.independentTables[table.id] = savedRows;
      saveProjects();
    }
  }
  if (table.id === "schedule-equipment-sensible-gain" && project.independentTableSchemaVersions[table.id] !== 3) {
    if (Array.isArray(savedRows)) {
      project.independentTables[table.id] = savedRows.map((row) => {
        if (row.length === 6) return [row[0], row[1], row[2] ?? "", row[3] ?? "", "", row[4], row[5]];
        const kilowatts = row[2] !== "" && row[2] !== null && row[2] !== undefined
          ? numberFromTableValue(row[2]) / 1000
          : row[3] ?? "";
        return [row[0], row[1], kilowatts, row[4] ?? "", "", row[5], row[6]];
      });
    } else {
      project.independentTables[table.id] = table.rows.map((row) => [...row]);
    }
    project.independentTableSchemaVersions[table.id] = 3;
    savedRows = project.independentTables[table.id];
    saveProjects();
  }
  if (table.id === "iesve-tabular-space-data" && project.independentTableSchemaVersions[table.id] !== 2) {
    project.independentTables[table.id] = [];
    project.clipboardImports ||= {};
    delete project.clipboardImports[table.id];
    project.independentTableSchemaVersions[table.id] = 2;
    savedRows = project.independentTables[table.id];
    saveProjects();
  }
  if (table.id === "room-zone-loads-report" && project.independentTableSchemaVersions[table.id] !== 1) {
    project.independentTables[table.id] = [];
    project.excelImports ||= {};
    delete project.excelImports[table.id];
    project.independentTableSchemaVersions[table.id] = 1;
    savedRows = project.independentTables[table.id];
    saveProjects();
  }
  if (table.id === "calc-room-loads" && Array.isArray(savedRows)) {
    const typeBySpace = new Map(table.rows.map((row) => [String(row[0] ?? ""), row[1] ?? ""]));
    if (savedRows.some((row) => row.length === 14)) {
      savedRows = savedRows.map((row) => [row[0], typeBySpace.get(String(row[0] ?? "")) || "", ...row.slice(1)]);
    }
    savedRows.forEach((row) => {
      row[4] = String(row[4] ?? "").toUpperCase() === "TRUE" ? "TRUE" : "";
      row[9] = String(row[9] ?? "").toUpperCase() === "TRUE" ? "TRUE" : "";
    });
    project.independentTables[table.id] = savedRows;
  }
  if (table.id === "ashrae-90-1-baseline-systems" && Array.isArray(savedRows) && savedRows.some((row) => row.length === 7)) {
    project.independentTables[table.id] = savedRows.map((row) => row.length === 7 ? row.filter((_, index) => index !== 2) : row);
    saveProjects();
  } else if (!Array.isArray(savedRows) || savedRows.some((row) => row.length !== table.columns.length)) {
    project.independentTables[table.id] = table.rows.map((row) => [...row]);
    saveProjects();
  }
  return project.independentTables[table.id];
}

function projectTableRows(table) {
  return ensureProjectTableRows(activeProject(), table);
}

function ensureProjectTableHeaders(project, table) {
  if (!project) return table.headers;
  project.independentTableHeaders ||= {};
  let savedHeaders = project.independentTableHeaders[table.id];
  if (!Array.isArray(savedHeaders) && table.sourceTableId && Array.isArray(project.independentTableHeaders[table.sourceTableId])) {
    const sourceHeaders = project.independentTableHeaders[table.sourceTableId];
    if (sourceHeaders.length >= Math.max(...table.sourceColumnIndexes) + 1) {
      savedHeaders = table.sourceColumnIndexes.map((index) => ({ ...sourceHeaders[index] }));
      project.independentTableHeaders[table.id] = savedHeaders;
      saveProjects();
    }
  }
  if (table.id === "ashrae-90-1-baseline-systems" && Array.isArray(savedHeaders) && savedHeaders.length === 7) {
    project.independentTableHeaders[table.id] = savedHeaders.filter((_, index) => index !== 2);
    saveProjects();
  } else if (!Array.isArray(savedHeaders) || savedHeaders.length !== table.headers.length) {
    project.independentTableHeaders[table.id] = table.headers.map((header) => ({ ...header }));
    saveProjects();
  }
  return project.independentTableHeaders[table.id];
}

function projectTableHeaders(table) {
  return table.headers;
}

function displayedTableHeaders(table) {
  return projectTableHeaders(table);
}

function isPercentageColumn(table, columnIndex) {
  return table.headers[columnIndex]?.unit === "%";
}

function formatTableValue(value, table, columnIndex) {
  if (typeof value === "boolean") return value ? "TRUE" : "";
  if (typeof value === "number" && Number.isFinite(value) && table && Number.isInteger(columnIndex)) {
    if ((table.zeroDecimalColumns || []).includes(columnIndex)) return zeroDecimalFormatter.format(value);
    if ((table.oneDecimalColumns || []).includes(columnIndex)) return oneDecimalFormatter.format(value);
    if ((table.fiveDecimalColumns || []).includes(columnIndex)) return fiveDecimalFormatter.format(value);
    if ((table.decimalColumns || []).includes(columnIndex)) return twoDecimalFormatter.format(value);
    if (isPercentageColumn(table, columnIndex)) return `${tableNumberFormatter.format(value * 100)}%`;
    if ([...(table.calculatedColumns || []), ...(table.lockedColumns || [])].includes(columnIndex)
      && String(table.headers[columnIndex]?.unit || "").startsWith("Btu/h")) {
      return calculatedBtuNumberFormatter.format(value);
    }
  }
  return typeof value === "number" && Number.isFinite(value) ? tableNumberFormatter.format(value) : value ?? "";
}

function updateTableCell(table, rows, rowIndex, columnIndex, rawValue) {
  const value = rawValue.trim();
  const percentage = isPercentageColumn(table, columnIndex);
  const normalizedNumber = value.replace(/,/g, "").replace(/\s*%$/, "");
  recordZoningOverride(table, rows[rowIndex], columnIndex, value, activeProject());
  rows[rowIndex][columnIndex] = table.columnTypes[columnIndex] === "number" && normalizedNumber !== "" && Number.isFinite(Number(normalizedNumber))
    ? Number(normalizedNumber) / (percentage ? 100 : 1)
    : value;
  recalculateSpecialTableRow(table, rows[rowIndex]);
  recalculateTable(table, rows);
  recalculateDependentTables(table);
  saveProjects();
  if (table.conditionalCalculatedColumns || table.equipmentZoningCalculation) renderReferenceTable(table.id, tableSearch.value);
  else {
    refreshRenderedTableValues(table, rows);
    refreshTableSummary(table, rows);
  }
  updateCsvComparisonDecorations(table, rows);
  if (selectedCsvComparisonContext?.tableId === table.id) {
    const { rowIndex: selectedRow, columnIndex: selectedColumn } = selectedCsvComparisonContext;
    showCsvComparison(table, rows, selectedRow, selectedColumn);
  }
}

function refreshTableSummary(table, rows) {
  const summaryRow = referenceTable.querySelector("tfoot .table-summary-row");
  if (!summaryRow) return;
  (table.summaryColumns || []).forEach((columnIndex) => {
    const aggregation = table.summaryAggregations?.[columnIndex] || "sum";
    const total = aggregation === "count"
      ? rows.filter((row) => row[columnIndex] !== "" && row[columnIndex] !== null && row[columnIndex] !== undefined).length
      : rows.reduce((sum, row) => sum + (Number(row[columnIndex]) || 0), 0);
    const cell = summaryRow.cells[columnIndex];
    if (cell) cell.textContent = formatTableValue(total, table, columnIndex);
  });
}

function refreshRenderedTableValues(table, rows) {
  referenceTable.querySelectorAll("tbody tr").forEach((tableRow) => {
    const row = rows[Number(tableRow.dataset.sourceIndex)];
    if (!row) return;
    table.headers.forEach((_, columnIndex) => {
      if (!(table.calculatedColumns || []).includes(columnIndex) && !isPercentageColumn(table, columnIndex)) return;
      const cell = tableRow.cells[columnIndex];
      if (!cell) return;
      cell.textContent = formatTableValue(row[columnIndex], table, columnIndex);
      cell.classList.toggle("numeric-cell", typeof row[columnIndex] === "number");
    });
  });
  autoFitRenderedTable(table, displayedTableHeaders(table), rows);
}

function csvImportKey(table) {
  return `${activeProject()?.id || "default"}::${table.id}`;
}

function csvImportState(table) {
  if (!table?.csvHeaders) return null;
  const key = csvImportKey(table);
  if (csvImportsByProject.has(key)) return csvImportsByProject.get(key);
  const saved = activeProject()?.clipboardImports?.[table.id];
  if (!saved || !Array.isArray(saved.sourceRows) || !Array.isArray(saved.mappedColumns) || !saved.importedAt || !saved.templateType) return null;
  const state = {
    importedAt: saved.importedAt,
    mappedColumns: saved.mappedColumns,
    sourceRows: saved.sourceRows,
    templateType: saved.templateType,
  };
  csvImportsByProject.set(key, state);
  return state;
}

function excelImportState(table) {
  if (!table?.excelImport) return null;
  const key = csvImportKey(table);
  if (excelImportsByProject.has(key)) return excelImportsByProject.get(key);
  const saved = activeProject()?.excelImports?.[table.id];
  if (!saved?.importedAt || !saved?.fileName) return null;
  const state = {
    importedAt: saved.importedAt,
    fileName: saved.fileName,
    simulationRunAt: saved.simulationRunAt || "",
    simulationRunPrecision: saved.simulationRunPrecision || "time",
  };
  excelImportsByProject.set(key, state);
  return state;
}

function setCsvFileStatus(message, isError = false) {
  csvFileStatus.textContent = message;
  csvFileStatus.title = message;
  csvFileStatus.classList.toggle("is-error", isError);
}

function updateCsvToolbar(table) {
  const supportsCsv = Array.isArray(table.csvHeaders);
  const supportsExcel = Boolean(table.excelImport);
  templateStatus.classList.toggle("simulation-status", supportsExcel);
  clipboardActions.hidden = !supportsCsv;
  excelActions.hidden = !supportsExcel;
  rowActions.hidden = supportsCsv || supportsExcel || table.fixedRows;
  csvFileStatus.hidden = !supportsCsv && !supportsExcel;
  templateStatus.hidden = !supportsCsv && !supportsExcel;
  editableKey.hidden = supportsCsv || supportsExcel;
  autoKey.hidden = !table.equipmentZoningCalculation;
  matchKey.hidden = !supportsCsv;
  differentKey.hidden = !supportsCsv;
  editableKey.lastChild.textContent = table.equipmentZoningCalculation ? "Override" : "Editable";
  calculatedKey.lastChild.textContent = table.equipmentZoningCalculation ? "Locked" : supportsCsv ? "Not in source" : supportsExcel ? "Imported" : "Calculated";
  if (!supportsCsv && !supportsExcel) {
    copyDataButton.disabled = true;
    setCsvFileStatus("");
    templateStatus.textContent = "";
    return;
  }
  if (supportsExcel) {
    copyDataButton.disabled = true;
    const state = excelImportState(table);
    const importedAt = state ? new Date(state.importedAt) : null;
    const dateText = importedAt && Number.isFinite(importedAt.getTime())
      ? new Intl.DateTimeFormat(undefined, { dateStyle: "medium", timeStyle: "short" }).format(importedAt)
      : "";
    setCsvFileStatus(state ? `Last upload: ${dateText}` : "No Excel imported");
    const simulationRunAt = state?.simulationRunAt ? new Date(state.simulationRunAt) : null;
    const simulationText = simulationRunAt && Number.isFinite(simulationRunAt.getTime())
      ? new Intl.DateTimeFormat(undefined, state.simulationRunPrecision === "date"
        ? { dateStyle: "medium" }
        : { dateStyle: "medium", timeStyle: "short" }).format(simulationRunAt)
      : "";
    templateStatus.textContent = state ? `Simulation run: ${simulationText || "Not available"}` : "";
    templateStatus.title = state?.fileName || "";
    templateStatus.hidden = !state;
    return;
  }
  const state = csvImportState(table);
  copyDataButton.disabled = !state || !projectTableRows(table).length;
  const importedAt = state ? new Date(state.importedAt) : null;
  const dateText = importedAt && Number.isFinite(importedAt.getTime())
    ? new Intl.DateTimeFormat(undefined, { dateStyle: "medium", timeStyle: "short" }).format(importedAt)
    : "";
  setCsvFileStatus(state ? `Last upload: ${dateText}` : "No data pasted");
  templateStatus.textContent = state ? `${state.templateType} Template` : "";
  templateStatus.hidden = !state;
}

function clearCsvComparison() {
  selectedCsvComparisonContext = null;
  csvComparisonBar.hidden = true;
  csvComparisonBar.classList.remove("is-different", "is-unmapped");
  csvComparisonColumn.textContent = "";
  csvComparisonValue.textContent = "";
  csvComparisonStatus.textContent = "";
}

function tableValueForCsv(table, value, columnIndex) {
  if (isPercentageColumn(table, columnIndex) && typeof value === "number") return value * 100;
  return value ?? "";
}

function csvValuesMatch(table, tableValue, csvValue, columnIndex) {
  const current = tableValueForCsv(table, tableValue, columnIndex);
  const left = String(current ?? "").trim();
  const right = String(csvValue ?? "").trim();
  const leftNumber = Number(left.replace(/,/g, ""));
  const rightNumber = Number(right.replace(/,/g, ""));
  if (left !== "" && right !== "" && Number.isFinite(leftNumber) && Number.isFinite(rightNumber)) {
    return Math.abs(leftNumber - rightNumber) <= 0.001;
  }
  return left.localeCompare(right, undefined, { sensitivity: "base" }) === 0;
}

function csvComparisonForCell(table, row, sourceIndex, columnIndex) {
  const state = csvImportState(table);
  if (!state) return null;
  if (!state.mappedColumns[columnIndex]) {
    return { mapped: false, matches: false, csvValue: "" };
  }
  const csvRow = state.sourceRows[sourceIndex];
  const csvValue = csvRow?.[columnIndex] ?? "";
  return {
    mapped: true,
    linked: Boolean(csvRow),
    matches: Boolean(csvRow) && csvValuesMatch(table, row[columnIndex], csvValue, columnIndex),
    csvValue,
  };
}

function decorateCsvComparisonCell(table, cell, row, sourceIndex, columnIndex) {
  cell.classList.remove("csv-match", "csv-different");
  if (table.id === "iesve-tabular-space-data" && columnIndex < 2) return;
  const comparison = csvComparisonForCell(table, row, sourceIndex, columnIndex);
  if (!comparison?.mapped) return;
  cell.classList.add(comparison.matches ? "csv-match" : "csv-different");
}

function markSelectedTableCell(cell) {
  referenceTable.querySelectorAll(".table-cell-selected").forEach((candidate) => {
    candidate.classList.remove("table-cell-selected");
    candidate.removeAttribute("aria-current");
  });
  cell.classList.add("table-cell-selected");
  cell.setAttribute("aria-current", "true");
}

function decorateRoomValidationCell(table, cell, value, columnIndex) {
  if (table.id !== "room-zone-loads-report" || columnIndex !== 2) return;
  const tabularTable = independentTables.find((candidate) => candidate.id === "iesve-tabular-space-data");
  const tabularRows = tabularTable ? projectTableRows(tabularTable) : [];
  const room = String(value ?? "").trim();
  const exists = tabularRows.some((row) => String(row[1] ?? "").trim().localeCompare(room, undefined, { sensitivity: "base" }) === 0);
  if (exists) return;
  cell.classList.add("room-not-in-tabular");
  cell.title = "Room not in Tabular Space Data";
  cell.setAttribute("aria-label", `${cell.getAttribute("aria-label")}. Room not in Tabular Space Data`);
}

function updateCsvComparisonDecorations(table, rows) {
  if (!table.csvHeaders) return;
  referenceTable.querySelectorAll("tbody tr").forEach((tableRow) => {
    const sourceIndex = Number(tableRow.dataset.sourceIndex);
    const row = rows[sourceIndex];
    if (!row) return;
    [...tableRow.cells].forEach((cell, columnIndex) => {
      decorateCsvComparisonCell(table, cell, row, sourceIndex, columnIndex);
    });
  });
}

function showCsvComparison(table, rows, sourceIndex, columnIndex) {
  const state = csvImportState(table);
  if (!state) {
    clearCsvComparison();
    return;
  }
  const row = rows[sourceIndex];
  if (!row) return;
  selectedCsvComparisonContext = { tableId: table.id, rowIndex: sourceIndex, columnIndex };
  const header = table.headers[columnIndex];
  csvComparisonColumn.textContent = `${header.label}${header.unit ? ` (${header.unit})` : ""}`;
  const comparison = csvComparisonForCell(table, row, sourceIndex, columnIndex);
  csvComparisonBar.hidden = false;
  csvComparisonBar.classList.toggle("is-unmapped", !comparison?.mapped);
  csvComparisonBar.classList.toggle("is-different", Boolean(comparison?.mapped && !comparison.matches));
  if (!comparison?.mapped) {
    csvComparisonValue.textContent = "Not included in the pasted source data";
    csvComparisonStatus.textContent = "Not in source";
  } else {
    csvComparisonValue.textContent = comparison.linked
      ? (String(comparison.csvValue) || "(blank)")
      : "No source row";
    csvComparisonStatus.textContent = comparison.matches ? "Matches source" : "Differs from source";
  }
}

function csvHeaderForTemplate(header, templateType) {
  if (!header || header === "Space ID") return header;
  return header.replace(/ \(Real\)$/, ` (${templateType})`);
}

function detectTemplateType(headers) {
  if (CsvTools.normalizeHeader(headers[0]) !== "space id") {
    throw new Error("The first pasted column must be Space ID.");
  }
  const spaceName = String(headers[1] ?? "").trim();
  const match = spaceName.match(/^Space Name \((Real|Proposed|Baseline)\)$/i);
  if (!match) throw new Error("The second pasted column must be Space Name (Real), Space Name (Proposed), or Space Name (Baseline).");
  const templateType = match[1][0].toUpperCase() + match[1].slice(1).toLowerCase();
  const suffix = ` (${templateType})`.toLowerCase();
  const invalidHeader = headers.slice(1).find((header) => {
    const value = String(header ?? "").trim();
    return value !== "" && !value.toLowerCase().endsWith(suffix);
  });
  if (invalidHeader !== undefined) {
    throw new Error(`Every pasted header after Space ID must end with (${templateType}). Check: ${invalidHeader}`);
  }
  return templateType;
}

function csvColumnMap(table, headers, templateType) {
  const headerIndexes = new Map();
  headers.forEach((header, index) => {
    const normalized = CsvTools.normalizeHeader(header);
    if (normalized && !headerIndexes.has(normalized)) headerIndexes.set(normalized, index);
  });
  return table.csvHeaders.map((header) => header === null
    ? -1
    : (headerIndexes.get(CsvTools.normalizeHeader(csvHeaderForTemplate(header, templateType))) ?? -1));
}

function saveClipboardImport(table, state) {
  const project = activeProject();
  if (!project) return;
  project.clipboardImports ||= {};
  project.clipboardImports[table.id] = {
    importedAt: state.importedAt,
    mappedColumns: state.mappedColumns,
    sourceRows: state.sourceRows,
    templateType: state.templateType,
  };
  saveProjects();
}

function pasteTabularData(text) {
  const table = independentTables.find((candidate) => candidate.id === activeTableId);
  if (!table?.csvHeaders) return;
  const grid = CsvTools.parseClipboard(text);
  const headerRowIndex = grid.findIndex((row) => CsvTools.normalizeHeader(row[0]) === "space id");
  if (headerRowIndex < 0) throw new Error("The pasted header row must begin with Space ID and Space Name.");
  const headers = grid[headerRowIndex];
  const templateType = detectTemplateType(headers);
  const columnMap = csvColumnMap(table, headers, templateType);
  if (columnMap[0] < 0 || columnMap[1] < 0) throw new Error("Space ID or Space Name is missing from the pasted data.");

  const pastedRows = grid.slice(headerRowIndex + 1)
    .filter((row) => row.some((value) => String(value ?? "").trim() !== ""))
    .map((row) => Array.from({ length: headers.length }, (_, index) => row[index] ?? ""))
    .filter((row) => row[columnMap[0]].trim() !== "" || row[columnMap[1]].trim() !== "");
  if (!pastedRows.length) throw new Error("The pasted data does not contain any space rows.");

  const rows = projectTableRows(table);
  const existingBySpaceId = new Map(rows.map((row) => [String(row[0] ?? "").trim().toLowerCase(), row]));
  const sourceRows = pastedRows.map((pastedRow) => table.csvHeaders.map((header, columnIndex) => {
    const pastedColumnIndex = columnMap[columnIndex];
    return header && pastedColumnIndex >= 0 ? pastedRow[pastedColumnIndex] : null;
  }));
  const importedRows = sourceRows.map((sourceRow) => {
    const spaceId = String(sourceRow[0] ?? "").trim();
    const existing = existingBySpaceId.get(spaceId.toLowerCase());
    const row = existing ? [...existing] : Array(table.columns.length).fill("");
    row[0] = spaceId;
    row[1] = String(sourceRow[1] ?? "").trim();
    return row;
  });
  rows.splice(0, rows.length, ...importedRows);
  const state = {
    importedAt: new Date().toISOString(),
    mappedColumns: columnMap.map((columnIndex) => columnIndex >= 0),
    sourceRows,
    templateType,
  };
  csvImportsByProject.set(csvImportKey(table), state);
  saveClipboardImport(table, state);
  selectedTableId = "";
  selectedTableRowIndexes.clear();
  selectionAnchorIndex = -1;
  tableSearch.value = "";
  tableSort = { tableId: table.id, column: -1, direction: "asc" };
  renderReferenceTable(table.id);
}

async function pasteDataFromClipboard() {
  pasteDataButton.disabled = true;
  try {
    if (!navigator.clipboard?.readText || !window.isSecureContext) {
      throw new Error("Direct clipboard access is unavailable. Press Ctrl+V while this table is open.");
    }
    const text = await navigator.clipboard.readText();
    if (!text.trim()) throw new Error("The clipboard does not contain text data.");
    pasteTabularData(text);
  } catch (error) {
    setCsvFileStatus(error.message || "The clipboard data could not be used.", true);
  } finally {
    pasteDataButton.disabled = false;
  }
}

async function writeClipboardText(text) {
  if (navigator.clipboard?.writeText && window.isSecureContext) {
    await navigator.clipboard.writeText(text);
    return;
  }
  const helper = document.createElement("textarea");
  helper.value = text;
  helper.setAttribute("readonly", "");
  helper.style.position = "fixed";
  helper.style.opacity = "0";
  document.body.appendChild(helper);
  helper.select();
  const copied = document.execCommand("copy");
  helper.remove();
  if (!copied) throw new Error("Clipboard access was blocked by the browser.");
}

async function copyTabularData() {
  const table = independentTables.find((candidate) => candidate.id === activeTableId);
  const state = csvImportState(table);
  if (!table?.csvHeaders || !state) return;
  const rows = projectTableRows(table);
  const headers = table.csvHeaders.map((header) => csvHeaderForTemplate(header, state.templateType));
  const values = rows.map((row) => table.headers.map((_, columnIndex) => formatTableValue(row[columnIndex], table, columnIndex)));
  copyDataButton.disabled = true;
  try {
    await writeClipboardText(CsvTools.stringifyClipboard([headers, ...values]));
    copyDataButton.textContent = "Copied to clipboard";
    setTimeout(() => {
      copyDataButton.textContent = "Copy data to clipboard...";
      copyDataButton.disabled = false;
    }, 1200);
  } catch (error) {
    setCsvFileStatus(error.message || "The table could not be copied.", true);
    copyDataButton.disabled = false;
    setTimeout(() => updateCsvToolbar(table), 2500);
  }
}

function normalizedLoadHeader(value) {
  return String(value ?? "").replace(/\s+/g, " ").trim().toLowerCase();
}

function findRoomZoneLoadSheet(workbook) {
  for (const sheet of workbook.sheets) {
    let columns = null;
    const headerRowIndex = sheet.rows.findIndex((row, index) => {
      if (index > 30 || !row) return false;
      const zoneGroup = row.findIndex((value) => normalizedLoadHeader(value) === "zone group");
      const sensibleHeader = row.findIndex((value) => normalizedLoadHeader(value).includes("sensible cooling load"));
      const latent = row.findIndex((value) => normalizedLoadHeader(value).includes("latent cooling load"));
      const heating = row.findIndex((value) => normalizedLoadHeader(value).includes("heating load"));
      if (zoneGroup < 0 || sensibleHeader < 0 || latent < 0 || heating < 0) return false;
      if (normalizedLoadHeader(row[zoneGroup + 1]) !== "zone" || normalizedLoadHeader(row[zoneGroup + 2]) !== "room") return false;
      columns = {
        zoneGroup,
        zone: zoneGroup + 1,
        room: zoneGroup + 2,
        sensible: sensibleHeader + 1,
        latent,
        heating,
      };
      return true;
    });
    if (headerRowIndex >= 0) return { sheet, headerRowIndex, columns };
  }
  throw new Error("The workbook does not contain the expected Room/Zone Loads Report headers.");
}

function loadNumber(value, rowNumber, label) {
  if (value === "" || value === null || value === undefined) return "";
  if (typeof value === "number" && Number.isFinite(value)) return value;
  const number = Number(String(value).replace(/,/g, "").trim());
  if (!Number.isFinite(number)) throw new Error(`${label} is not numeric on Excel row ${rowNumber}.`);
  return number;
}

function roomZoneRowsFromWorkbook(workbook) {
  const { sheet, headerRowIndex, columns } = findRoomZoneLoadSheet(workbook);
  let zoneGroup = "";
  let zone = "";
  const rows = [];
  sheet.rows.slice(headerRowIndex + 2).forEach((sourceRow, offset) => {
    if (!sourceRow) return;
    const sourceGroup = String(sourceRow[columns.zoneGroup] ?? "").trim();
    const sourceZone = String(sourceRow[columns.zone] ?? "").trim();
    const room = String(sourceRow[columns.room] ?? "").trim();
    if (sourceGroup) zoneGroup = sourceGroup;
    if (sourceZone) zone = sourceZone;
    if (!room) return;
    const excelRow = headerRowIndex + 3 + offset;
    rows.push([
      zoneGroup,
      zone,
      room,
      loadNumber(sourceRow[columns.sensible], excelRow, "Sensible cooling load"),
      loadNumber(sourceRow[columns.latent], excelRow, "Latent cooling load"),
      loadNumber(sourceRow[columns.heating], excelRow, "Heating load"),
    ]);
  });
  if (!rows.length) throw new Error("The Room/Zone Loads Report does not contain any room rows beginning at row 10.");
  return rows;
}

async function importRoomZoneLoads(file) {
  const table = independentTables.find((candidate) => candidate.id === activeTableId);
  if (!table?.excelImport || !file) return;
  if (!/\.(xlsx|xlsm)$/i.test(file.name)) {
    setCsvFileStatus("Select an .xlsx or .xlsm Excel workbook.", true);
    importExcelInput.value = "";
    return;
  }
  importExcelButton.disabled = true;
  setCsvFileStatus("Importing Excel workbook...");
  try {
    const workbook = await XlsxReader.read(await file.arrayBuffer(), {
      sheetNamePattern: /ies loads|room.*zone.*loads|loads report/i,
    });
    const { simulationRunAt, simulationRunPrecision } = simulationRunTimeFromWorkbook(workbook, file);
    const importedRows = roomZoneRowsFromWorkbook(workbook);
    const rows = projectTableRows(table);
    rows.splice(0, rows.length, ...importedRows);
    const state = { importedAt: new Date().toISOString(), fileName: file.name, simulationRunAt, simulationRunPrecision };
    excelImportsByProject.set(csvImportKey(table), state);
    const project = activeProject();
    project.excelImports ||= {};
    project.excelImports[table.id] = state;
    selectedTableId = "";
    selectedTableRowIndexes.clear();
    selectionAnchorIndex = -1;
    tableSearch.value = "";
    tableSort = { tableId: table.id, column: -1, direction: "asc" };
    saveProjects();
    renderReferenceTable(table.id);
  } catch (error) {
    setCsvFileStatus(error.message || "The Excel workbook could not be imported.", true);
  } finally {
    importExcelButton.disabled = false;
    importExcelInput.value = "";
  }
}

function simulationRunTimeFromFile(file) {
  const relativePath = String(file.webkitRelativePath || "");
  const nativePath = String(file.path || "").replace(/\\/g, "/");
  const parentFolders = [relativePath, nativePath]
    .map((path) => path.split("/").filter(Boolean).slice(-2, -1)[0] || "")
    .filter(Boolean);
  const fileStem = String(file.name || "").replace(/\.(xlsx|xlsm)$/i, "");
  const match = [...parentFolders, fileStem]
    .map((value) => value.match(/(\d{8})[ _-](\d{6})$/))
    .find(Boolean);
  if (!match) return "";
  const [, date, time] = match;
  const year = Number(date.slice(0, 4));
  const month = Number(date.slice(4, 6));
  const day = Number(date.slice(6, 8));
  const hour = Number(time.slice(0, 2));
  const minute = Number(time.slice(2, 4));
  const second = Number(time.slice(4, 6));
  const value = new Date(year, month - 1, day, hour, minute, second);
  if (value.getFullYear() !== year || value.getMonth() !== month - 1 || value.getDate() !== day
    || value.getHours() !== hour || value.getMinutes() !== minute || value.getSeconds() !== second) {
    throw new Error("The simulation timestamp in the report folder name is not a valid date and time.");
  }
  return value.toISOString();
}

function simulationRunTimeFromWorkbook(workbook, file) {
  const createdAt = new Date(workbook.createdAt || "");
  if (Number.isFinite(createdAt.getTime())) {
    return { simulationRunAt: createdAt.toISOString(), simulationRunPrecision: "time" };
  }
  const reportDate = workbook.sheets?.[0]?.rows?.[3]?.[1];
  const dateMatch = String(reportDate || "").match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (dateMatch) {
    const value = new Date(Number(dateMatch[1]), Number(dateMatch[2]) - 1, Number(dateMatch[3]));
    return { simulationRunAt: value.toISOString(), simulationRunPrecision: "date" };
  }
  const fromPath = simulationRunTimeFromFile(file);
  return { simulationRunAt: fromPath, simulationRunPrecision: fromPath ? "time" : "date" };
}

function tableDropdownOptions(table, columnIndex) {
  const config = table.dropdownColumns?.[columnIndex];
  if (!config) return [];
  if (Array.isArray(config.options)) return config.options.map(String);
  const sources = config.sources || [config];
  return [...new Set(sources.flatMap((source) => {
    const sourceTable = independentTables.find((candidate) => candidate.id === source.sourceTableId);
    return sourceTable ? projectTableRows(sourceTable).map((row) => row[source.sourceColumn]) : [];
  })
    .filter((value) => value !== null && value !== undefined && value !== "")
    .map(String))];
}

function tableEquations(table) {
  return { ...(table.equations || {}), ...(equationOverrides[table.id] || {}) };
}

function equationColumnIndex(table, name) {
  const normalize = (value) => String(value || "").replace(/^@/, "").replace(/[^A-Za-z0-9]+/g, "").toLowerCase();
  const normalized = normalize(name);
  let index = table.headers.findIndex((header) => normalize(`${header.label || ""}${header.unit || ""}`) === normalized);
  if (index < 0) index = table.headers.findIndex((header) => normalize(header.label) === normalized);
  if (index < 0) index = (table.columns || []).findIndex((column) => normalize(column) === normalized);
  return index;
}

function tokenizeEquation(expression) {
  const source = String(expression || "").trim().replace(/^=/, "");
  const tokens = [];
  let index = 0;
  while (index < source.length) {
    const character = source[index];
    if (/\s/.test(character)) { index += 1; continue; }
    if (character === "@") {
      const reference = source.slice(index + 1).match(/^[A-Za-z_][A-Za-z0-9_]*/);
      if (!reference) throw new Error("Enter a column reference after @");
      tokens.push({ type: "reference", value: reference[0] });
      index += reference[0].length + 1;
      continue;
    }
    if (character === '"') {
      let value = "";
      index += 1;
      while (index < source.length && source[index] !== '"') value += source[index++];
      if (source[index] !== '"') throw new Error("Missing closing quote");
      tokens.push({ type: "string", value });
      index += 1;
      continue;
    }
    const number = source.slice(index).match(/^(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?/i);
    if (number) {
      tokens.push({ type: "number", value: Number(number[0]) });
      index += number[0].length;
      continue;
    }
    const identifier = source.slice(index).match(/^[A-Za-z_][A-Za-z0-9_]*/);
    if (identifier) {
      tokens.push({ type: "identifier", value: identifier[0].toUpperCase() });
      index += identifier[0].length;
      continue;
    }
    const pair = source.slice(index, index + 2);
    if ([">=", "<=", "<>", "!=", "=="].includes(pair)) {
      tokens.push({ type: "operator", value: pair });
      index += 2;
      continue;
    }
    if ("+-*/&=><(),".includes(character)) {
      tokens.push({ type: ["(", ")", ","].includes(character) ? character : "operator", value: character });
      index += 1;
      continue;
    }
    throw new Error(`Unsupported character: ${character}`);
  }
  tokens.push({ type: "end", value: "" });
  return tokens;
}

function evaluateEquation(expression, table, row) {
  const tokens = tokenizeEquation(expression);
  let position = 0;
  const current = () => tokens[position];
  const take = (type) => {
    if (current().type !== type) throw new Error(`Expected ${type}`);
    return tokens[position++];
  };
  const numeric = (value) => numberFromTableValue(value);
  const functions = {
    IF: (condition, yes, no) => condition ? yes : no,
    N: numeric,
    ROUND: (value, digits = 0) => {
      const factor = 10 ** numeric(digits);
      return Math.round(numeric(value) * factor) / factor;
    },
    MIN: (...values) => Math.min(...values.map(numeric)),
    MAX: (...values) => Math.max(...values.map(numeric)),
    ABS: (value) => Math.abs(numeric(value)),
    LOOKUP: (value) => value === "" || value === null || value === undefined ? "" : table.lookup?.[String(value)] ?? 0,
  };

  function primary() {
    const token = current();
    if (token.type === "number" || token.type === "string") { position += 1; return token.value; }
    if (token.type === "reference") {
      position += 1;
      const column = equationColumnIndex(table, token.value);
      if (column < 0) throw new Error(`Unknown column @${token.value}`);
      return row[column];
    }
    if (token.type === "identifier") {
      position += 1;
      if (token.value === "TRUE") return true;
      if (token.value === "FALSE") return false;
      const fn = functions[token.value];
      if (!fn) throw new Error(`Unsupported function ${token.value}`);
      take("(");
      const args = [];
      if (current().type !== ")") {
        args.push(comparison());
        while (current().type === ",") { position += 1; args.push(comparison()); }
      }
      take(")");
      return fn(...args);
    }
    if (token.type === "(") {
      position += 1;
      const value = comparison();
      take(")");
      return value;
    }
    throw new Error("Expected a value");
  }

  function unary() {
    if (current().type === "operator" && ["+", "-"].includes(current().value)) {
      const operator = tokens[position++].value;
      const value = numeric(unary());
      return operator === "-" ? -value : value;
    }
    return primary();
  }
  function multiply() {
    let value = unary();
    while (current().type === "operator" && ["*", "/"].includes(current().value)) {
      const operator = tokens[position++].value;
      const right = numeric(unary());
      value = operator === "*" ? numeric(value) * right : numeric(value) / right;
    }
    return value;
  }
  function add() {
    let value = multiply();
    while (current().type === "operator" && ["+", "-"].includes(current().value)) {
      const operator = tokens[position++].value;
      const right = numeric(multiply());
      value = operator === "+" ? numeric(value) + right : numeric(value) - right;
    }
    return value;
  }
  function concatenate() {
    let value = add();
    while (current().type === "operator" && current().value === "&") {
      position += 1;
      value = String(value ?? "") + String(add() ?? "");
    }
    return value;
  }
  function comparison() {
    let value = concatenate();
    if (current().type === "operator" && ["=", "==", "!=", "<>", ">", "<", ">=", "<="].includes(current().value)) {
      const operator = tokens[position++].value;
      const right = concatenate();
      if (["=", "=="].includes(operator)) return value == right;
      if (["!=", "<>"].includes(operator)) return value != right;
      if (operator === ">") return value > right;
      if (operator === "<") return value < right;
      if (operator === ">=") return value >= right;
      return value <= right;
    }
    return value;
  }

  const result = comparison();
  if (current().type !== "end") throw new Error("Unexpected text after formula");
  return result;
}

function clearSelectedEquation() {
  formulaBar.hidden = true;
  selectedEquation.value = "";
  selectedEquation.readOnly = true;
  selectedEquationContext = null;
  editEquationButton.hidden = false;
  saveEquationButton.hidden = true;
  cancelEquationButton.hidden = true;
  formulaError.hidden = true;
  formulaError.textContent = "";
  referenceTable.querySelectorAll(".equation-cell-selected").forEach((cell) => cell.classList.remove("equation-cell-selected"));
}

function showSelectedEquation(table, cell, column) {
  referenceTable.querySelectorAll(".equation-cell-selected").forEach((candidate) => candidate.classList.remove("equation-cell-selected"));
  cell.classList.add("equation-cell-selected");
  selectedEquationContext = { table, column };
  const equation = equationOverrides[table.id]?.[column]
    || table.displayEquations?.[column]
    || table.equations?.[column]
    || "";
  if (!equation) {
    clearSelectedEquation();
    return;
  }
  selectedEquation.value = equation;
  selectedEquation.readOnly = true;
  editEquationButton.hidden = Boolean(table.readonlyEquations);
  saveEquationButton.hidden = true;
  cancelEquationButton.hidden = true;
  formulaError.hidden = true;
  formulaBar.hidden = false;
}

function beginEquationEdit() {
  if (!selectedEquationContext) return;
  const { table, column } = selectedEquationContext;
  if (table.readonlyEquations) return;
  selectedEquation.value = tableEquations(table)[column] || "=0";
  selectedEquation.readOnly = false;
  editEquationButton.hidden = true;
  saveEquationButton.hidden = false;
  cancelEquationButton.hidden = false;
  formulaError.hidden = true;
  selectedEquation.focus();
  selectedEquation.select();
}

function cancelEquationEdit() {
  if (!selectedEquationContext) return;
  const { table, column } = selectedEquationContext;
  selectedEquation.value = equationOverrides[table.id]?.[column]
    || table.displayEquations?.[column]
    || table.equations?.[column]
    || "";
  selectedEquation.readOnly = true;
  editEquationButton.hidden = false;
  saveEquationButton.hidden = true;
  cancelEquationButton.hidden = true;
  formulaError.hidden = true;
}

function sourceTableForEquation(name) {
  const normalized = String(name).replace(/[^A-Za-z0-9]+/g, "").toLowerCase();
  return independentTables.find((table) => [table.id, table.name, table.standard]
    .some((value) => String(value || "").replace(/[^A-Za-z0-9]+/g, "").toLowerCase() === normalized));
}

function evaluateProjectEquation(expression, table, row, rows, project) {
  const qualifiedCountif = String(expression || "").trim().match(/^=COUNTIF\(\s*\[([^\]]+)\]@([A-Za-z_][A-Za-z0-9_]*)\s*,\s*@([A-Za-z_][A-Za-z0-9_]*)\s*\)$/i);
  if (qualifiedCountif) {
    const sourceTable = sourceTableForEquation(qualifiedCountif[1]);
    if (!sourceTable) throw new Error(`Unknown COUNTIF table [${qualifiedCountif[1]}]`);
    const sourceColumn = equationColumnIndex(sourceTable, qualifiedCountif[2]);
    let criteriaColumn = equationColumnIndex(table, qualifiedCountif[3]);
    if (criteriaColumn < 0 && table.id === "iesve-thermal-template" && qualifiedCountif[3].toLowerCase() === "type") criteriaColumn = 0;
    if (sourceColumn < 0 || criteriaColumn < 0) throw new Error("Unknown COUNTIF column reference");
    const criteria = String(row[criteriaColumn] ?? "");
    const sourceRows = sourceTable.id === table.id ? rows : ensureProjectTableRows(project, sourceTable);
    return sourceRows.filter((candidate) => String(candidate[sourceColumn] ?? "").localeCompare(criteria, undefined, { sensitivity: "base" }) === 0).length;
  }
  const qualifiedSumif = String(expression || "").trim().match(/^=SUMIF\(\s*\[([^\]]+)\]@([A-Za-z_][A-Za-z0-9_]*)\s*,\s*@([A-Za-z_][A-Za-z0-9_]*)\s*,\s*\[([^\]]+)\]@([A-Za-z_][A-Za-z0-9_]*)\s*\)$/i);
  if (qualifiedSumif) {
    const rangeTable = sourceTableForEquation(qualifiedSumif[1]);
    const sumTable = sourceTableForEquation(qualifiedSumif[4]);
    if (!rangeTable || rangeTable !== sumTable) throw new Error("SUMIF range and sum columns must use the same table");
    const rangeColumn = equationColumnIndex(rangeTable, qualifiedSumif[2]);
    const criteriaColumn = equationColumnIndex(table, qualifiedSumif[3]);
    const sumColumn = equationColumnIndex(sumTable, qualifiedSumif[5]);
    if ([rangeColumn, criteriaColumn, sumColumn].some((index) => index < 0)) throw new Error("Unknown SUMIF column reference");
    const sourceRows = rangeTable.id === table.id ? rows : ensureProjectTableRows(project, rangeTable);
    const criteria = row[criteriaColumn];
    return sourceRows.reduce((total, candidate) => candidate[rangeColumn] == criteria ? total + numberFromTableValue(candidate[sumColumn]) : total, 0);
  }
  const sumif = String(expression || "").trim().match(/^=SUMIF\(\s*@([A-Za-z_][A-Za-z0-9_]*)\s*,\s*@([A-Za-z_][A-Za-z0-9_]*)\s*,\s*@([A-Za-z_][A-Za-z0-9_]*)\s*\)$/i);
  if (sumif) {
    const rangeColumn = equationColumnIndex(table, sumif[1]);
    const criteriaColumn = equationColumnIndex(table, sumif[2]);
    const sumColumn = equationColumnIndex(table, sumif[3]);
    if ([rangeColumn, criteriaColumn, sumColumn].some((index) => index < 0)) throw new Error("Unknown SUMIF column reference");
    const criteria = row[criteriaColumn];
    return rows.reduce((total, candidate) => candidate[rangeColumn] == criteria ? total + numberFromTableValue(candidate[sumColumn]) : total, 0);
  }

  const withLookups = String(expression || "").replace(/XLOOKUP\(\s*@([A-Za-z_][A-Za-z0-9_]*)\s*,\s*\[([^\]]+)\]@([A-Za-z_][A-Za-z0-9_]*)\s*,\s*\[([^\]]+)\]@([A-Za-z_][A-Za-z0-9_]*)\s*\)/gi, (reference, currentColumnName, lookupTableName, lookupColumnName, resultTableName, resultColumnName) => {
    const lookupTable = sourceTableForEquation(lookupTableName);
    const resultTable = sourceTableForEquation(resultTableName);
    if (!lookupTable || lookupTable !== resultTable) throw new Error(`Unknown XLOOKUP table in ${reference}`);
    const currentColumn = equationColumnIndex(table, currentColumnName);
    const lookupColumn = equationColumnIndex(lookupTable, lookupColumnName);
    const resultColumn = equationColumnIndex(resultTable, resultColumnName);
    if ([currentColumn, lookupColumn, resultColumn].some((index) => index < 0)) throw new Error(`Unknown XLOOKUP column in ${reference}`);
    const sourceRows = ensureProjectTableRows(project, lookupTable);
    const lookupValue = String(row[currentColumn] ?? "");
    const sourceRow = sourceRows.find((candidate) => String(candidate[lookupColumn] ?? "").localeCompare(lookupValue, undefined, { sensitivity: "base" }) === 0);
    const value = sourceRow?.[resultColumn] ?? 0;
    return typeof value === "number" ? String(value) : JSON.stringify(String(value));
  });

  const resolved = withLookups.replace(/\[([^\]]+)\]@([A-Za-z_][A-Za-z0-9_]*)/g, (reference, tableName, columnName) => {
    const sourceTable = sourceTableForEquation(tableName);
    if (!sourceTable) throw new Error(`Unknown table [${tableName}]`);
    const sourceColumn = equationColumnIndex(sourceTable, columnName);
    const lookupColumn = equationColumnIndex(table, sourceTable.headers[0].label);
    if (sourceColumn < 0 || lookupColumn < 0) throw new Error(`Unknown reference ${reference}`);
    const sourceRows = ensureProjectTableRows(project, sourceTable);
    const lookupValue = String(row[lookupColumn] ?? "");
    const sourceRow = sourceRows.find((candidate) => String(candidate[0] ?? "").localeCompare(lookupValue, undefined, { sensitivity: "base" }) === 0);
    const value = sourceRow?.[sourceColumn] ?? 0;
    return typeof value === "number" ? String(value) : JSON.stringify(String(value));
  });
  return evaluateEquation(resolved, table, row);
}

function recalculateGainTable(table, rows, project) {
  const thermal = independentTables.find((candidate) => candidate.id === "iesve-thermal-template");
  const thermalRows = thermal ? (project ? ensureProjectTableRows(project, thermal) : thermal.rows) : [];
  const thermalByType = new Map(thermalRows.map((row) => [String(row[0]), row]));
  const lightingLoads = independentTables.find((candidate) => candidate.id === "selected-lighting-loads");
  const lightingRows = lightingLoads ? (project ? ensureProjectTableRows(project, lightingLoads) : lightingLoads.rows) : [];
  const miscLoads = independentTables.find((candidate) => candidate.id === "selected-misc-loads");
  const miscRows = miscLoads ? (project ? ensureProjectTableRows(project, miscLoads) : miscLoads.rows) : [];
  const lightingPowerDensity = (value, space, area) => {
    const numeric = Number(value);
    if (Number.isFinite(numeric)) return numeric;
    const height = area ? (Number(table.volumeBySpace?.[space]) || 0) / area : 0;
    const text = String(value || "");
    if (text.includes("0.050") && text.includes("0.025")) return 0.05 - 0.025 * height;
    if (text.includes("0.0375")) return 0.037 * height;
    return 0;
  };

  rows.forEach((row) => {
    const space = String(row[0] ?? "");
    const active = Boolean(table.activityBySpace?.[space]);
    const template = thermalByType.get(String(row[1] ?? "")) || [];
    const area = Number(row[2]) || 0;
    if (table.gainCalculation === "people") {
      if (!active) {
        [3, 5, 6, 7, 8, 9].forEach((index) => { row[index] = ""; });
        return;
      }
      row[3] = (Number(template[5]) || 0) / 1000;
      const manualPeople = row[4] !== "" && row[4] !== null && row[4] !== undefined ? Number(row[4]) : NaN;
      row[5] = Number.isFinite(manualPeople) ? manualPeople : Math.round((Number(row[3]) || 0) * area);
      row[6] = template[7] ?? "";
      row[7] = template[8] ?? "";
      row[8] = (Number(row[5]) || 0) * (Number(row[6]) || 0);
      row[9] = (Number(row[5]) || 0) * (Number(row[7]) || 0);
      return;
    }
    if (table.gainCalculation === "lighting") {
      if (!active) {
        [3, 4, 6, 7, 8].forEach((index) => { row[index] = ""; });
        return;
      }
      row[3] = template[12] ?? "";
      row[4] = lightingPowerDensity(template[10], space, area);
      const matches = lightingRows.filter((candidate) => String(candidate[0] ?? "") === space);
      row[6] = matches.length ? matches.reduce((sum, candidate) => sum + (Number(candidate[4]) || 0), 0) : "";
      const manual = row[5] !== "" && row[5] !== null && row[5] !== undefined ? Number(row[5]) : NaN;
      const proposedWatts = row[6] !== "" ? Number(row[6]) || 0 : Number.isFinite(manual) ? manual : (Number(row[3]) || 0) * area;
      row[7] = 3.412 * proposedWatts;
      row[8] = 3.412 * (Number(row[4]) || 0) * area;
      return;
    }
    if (table.gainCalculation === "misc") {
      if (!active) {
        [3, 4, 5].forEach((index) => { row[index] = ""; });
        return;
      }
      row[3] = template[13] ?? "";
      const matches = miscRows.filter((candidate) => String(candidate[0] ?? "") === space);
      row[4] = matches.length ? matches.reduce((sum, candidate) => sum + (Number(candidate[9]) || 0), 0) : "";
      row[5] = row[4] !== "" ? Number(row[4]) || 0 : 3.412 * (Number(row[3]) || 0) * area;
    }
  });
}

function recalculateMiscLoadTable(table, rows, project) {
  const peopleTable = independentTables.find((candidate) => candidate.id === "calc-people-gains");
  const equipmentTable = independentTables.find((candidate) => candidate.id === "schedule-equipment-sensible-gain");
  const groupedTable = independentTables.find((candidate) => candidate.id === "schedule-grouped-equipment-sensible-gain");
  const peopleRows = peopleTable ? ensureProjectTableRows(project, peopleTable) : [];
  if (peopleTable) recalculateGainTable(peopleTable, peopleRows, project);
  const peopleBySpace = new Map(peopleRows.map((row) => [String(row[0] ?? ""), row[5]]));
  const equipmentRows = equipmentTable ? ensureProjectTableRows(project, equipmentTable) : [];
  const groupedRows = groupedTable ? ensureProjectTableRows(project, groupedTable) : [];
  if (equipmentTable) recalculateTable(equipmentTable, equipmentRows, project);
  if (groupedTable) recalculateTable(groupedTable, groupedRows, project);
  const heatGainByEquipment = new Map(equipmentRows.map((row) => [String(row[0] ?? ""), Number(row[5]) || 0]));
  groupedRows.forEach((row) => heatGainByEquipment.set(String(row[0] ?? ""), Number(row[4]) || 0));

  rows.forEach((row) => {
    if (row[0] === "" || row[0] === null || row[0] === undefined) {
      [4, 5, 6, 9].forEach((index) => { row[index] = ""; });
      return;
    }
    const perPerson = String(row[3] ?? "").toUpperCase() === "TRUE";
    row[4] = perPerson ? (peopleBySpace.get(String(row[0])) ?? 0) : "-";
    row[5] = row[2] === "" || row[2] === null || row[2] === undefined ? 1 : Number(row[2]) || 0;
    row[6] = heatGainByEquipment.get(String(row[1] ?? "")) ?? 0;
    const peopleMultiplier = perPerson ? Number(row[4]) || 0 : 1;
    row[9] = peopleMultiplier * (Number(row[5]) || 0) * (Number(row[6]) || 0)
      + 3412.142 * (Number(row[7]) || 0) + (Number(row[8]) || 0);
  });
}

function recalculateRoomLoadTable(rows, project) {
  const reportTable = independentTables.find((candidate) => candidate.id === "room-zone-loads-report");
  const reportRows = reportTable ? ensureProjectTableRows(project, reportTable) : [];
  const reportByRoom = new Map(reportRows.map((row) => [String(row[2] ?? ""), row]));
  const gainTable = (id) => independentTables.find((candidate) => candidate.id === id);
  const lightingTable = gainTable("calc-lighting-gains");
  const peopleTable = gainTable("calc-people-gains");
  const miscTable = gainTable("calc-misc-gains");
  const lightingRows = lightingTable ? ensureProjectTableRows(project, lightingTable) : [];
  const peopleRows = peopleTable ? ensureProjectTableRows(project, peopleTable) : [];
  const miscRows = miscTable ? ensureProjectTableRows(project, miscTable) : [];
  if (lightingTable) recalculateGainTable(lightingTable, lightingRows, project);
  if (peopleTable) recalculateGainTable(peopleTable, peopleRows, project);
  if (miscTable) recalculateGainTable(miscTable, miscRows, project);
  const bySpace = (sourceRows) => new Map(sourceRows.map((row) => [String(row[0] ?? ""), row]));
  const lightingBySpace = bySpace(lightingRows);
  const peopleBySpace = bySpace(peopleRows);
  const miscBySpace = bySpace(miscRows);
  const enabled = (value) => value === true || String(value ?? "").toUpperCase() === "TRUE";

  rows.forEach((row) => {
    const space = String(row[0] ?? "");
    if (!space) {
      [2, 3, 6, 7, 8, 11, 12, 14].forEach((index) => { row[index] = ""; });
      return;
    }
    const report = reportByRoom.get(space) || [];
    const lighting = lightingBySpace.get(space) || [];
    const people = peopleBySpace.get(space) || [];
    const misc = miscBySpace.get(space) || [];
    row[2] = Number(report[3]) || 0;
    row[3] = ((Number(lighting[7]) || 0) + (Number(people[8]) || 0) + (Number(misc[5]) || 0)) / 1000;
    row[6] = Math.max(1.1 * ((enabled(row[4]) ? row[3] : row[2]) + (Number(row[5]) || 0)), 0);
    row[7] = Number(report[4]) || 0;
    row[8] = (Number(people[9]) || 0) / 1000;
    row[11] = Math.max(1.1 * ((enabled(row[9]) ? row[7] : row[8]) + (Number(row[10]) || 0)), 0);
    row[12] = Number(report[5]) || 0;
    row[14] = Math.max(1.1 * (row[12] + (Number(row[13]) || 0)), 0);
  });
}

function zoningCellKey(row, column) {
  return `${String(row[2] ?? "")}::${column}`;
}

function recordZoningOverride(table, row, column, value, project) {
  if (!table.equipmentZoningCalculation || !(table.autoColumns || []).includes(column)) return;
  project.zoningOverrides ||= {};
  project.zoningOverrides[table.id] ||= {};
  const defaults = project.zoningAutoValues?.[table.id] || {};
  const key = zoningCellKey(row, column);
  if (String(value ?? "") === String(defaults[key] ?? "")) delete project.zoningOverrides[table.id][key];
  else project.zoningOverrides[table.id][key] = true;
}

function recalculateEquipmentZoning(table, rows, project) {
  const reportTable = independentTables.find((candidate) => candidate.id === "room-zone-loads-report");
  const reportRows = reportTable ? ensureProjectTableRows(project, reportTable) : [];
  const reportByRoom = new Map(reportRows.map((row) => [String(row[2] ?? ""), row]));
  project.zoningOverrides ||= {};
  project.zoningOverrides[table.id] ||= {};
  project.zoningAutoValues ||= {};
  project.zoningAutoValues[table.id] ||= {};
  const overrides = project.zoningOverrides[table.id];
  const previousAutos = project.zoningAutoValues[table.id];
  const nextAutos = {};
  table.autoCellStates = new Map();
  table.lockedCellStates = new Map();
  table.lockedCellMessages = new Map();

  rows.forEach((row, rowIndex) => {
    const report = reportByRoom.get(String(row[2] ?? ""));
    if (report) { row[0] = report[0] ?? ""; row[1] = report[1] ?? ""; }
    const autoCells = new Set();
    const lockedCells = new Set();
    const lockMessages = new Map();
    const applyAuto = (column, defaultValue) => {
      const key = zoningCellKey(row, column);
      const normalizedDefault = defaultValue ?? "";
      if (overrides[key] && String(row[column] ?? "") === String(normalizedDefault)) delete overrides[key];
      if (!overrides[key]) {
        const previous = previousAutos[key];
        const current = row[column] ?? "";
        if (previous === undefined && current !== "" && String(current) !== String(normalizedDefault)) overrides[key] = true;
        else if (previous !== undefined && current !== "" && String(current) !== String(previous) && String(current) !== String(normalizedDefault)) overrides[key] = true;
      }
      if (!overrides[key]) {
        row[column] = normalizedDefault;
        autoCells.add(column);
      }
      nextAutos[key] = normalizedDefault;
    };

    applyAuto(3, row[1]);
    applyAuto(4, row[3]);
    if (row[4]) applyAuto(5, row[1]);
    else {
      lockedCells.add(5);
      lockMessages.set(5, "Populate Central Equipment to make this cell editable.");
      row[5] = "";
      delete overrides[zoningCellKey(row, 5)];
    }
    applyAuto(6, row[5] || "");

    if (row[4]) {
      lockedCells.add(7);
      lockMessages.set(7, "Clear Central Equipment to make this cell editable.");
      row[7] = "";
      delete overrides[zoningCellKey(row, 7)];
    } else {
      applyAuto(7, row[5] ? "" : row[1]);
      if (row[7]) {
        lockedCells.add(4);
        lockMessages.set(4, "Clear Cooling Equipment to make this cell editable.");
      }
    }

    if (row[6]) {
      lockedCells.add(8);
      lockMessages.set(8, "Clear Reheat Coil to make this cell editable.");
      row[8] = "";
      delete overrides[zoningCellKey(row, 8)];
    } else {
      applyAuto(8, row[7] || "");
      if (row[8]) {
        lockedCells.add(6);
        lockMessages.set(6, "Clear Heating Equipment to make this cell editable.");
      }
    }
    applyAuto(9, row[3]);
    table.autoCellStates.set(rowIndex, autoCells);
    table.lockedCellStates.set(rowIndex, lockedCells);
    table.lockedCellMessages.set(rowIndex, lockMessages);
  });
  project.zoningAutoValues[table.id] = nextAutos;
}

function recalculateTable(table, rows, project = activeProject()) {
  if (table.equipmentZoningCalculation) {
    recalculateEquipmentZoning(table, rows, project);
    return;
  }
  if (table.roomLoadCalculation) {
    recalculateRoomLoadTable(rows, project);
    return;
  }
  if (table.miscLoadCalculation) {
    recalculateMiscLoadTable(table, rows, project);
    return;
  }
  if (table.gainCalculation) {
    recalculateGainTable(table, rows, project);
    return;
  }
  if (table.preserveImportedValues) return;
  if (table.calculation === "grouped-equipment-schedule") {
    const equipmentTable = independentTables.find((candidate) => candidate.id === "schedule-equipment-sensible-gain");
    if (equipmentTable) recalculateTable(equipmentTable, ensureProjectTableRows(project, equipmentTable), project);
  }

  const equations = tableEquations(table);
  (table.calculatedColumns || []).slice().sort((left, right) => left - right).forEach((column) => {
    rows.forEach((row) => {
      if (row[0] === "" || row[0] === null || row[0] === undefined) {
        row[column] = "";
      } else {
        row[column] = evaluateProjectEquation(equations[column] || "=0", table, row, rows, project);
      }
    });
  });
}

function recalculateDependentTables(table, project = activeProject()) {
  if (table.id !== "schedule-equipment-sensible-gain") return;
  const groupedTable = independentTables.find((candidate) => candidate.id === "schedule-grouped-equipment-sensible-gain");
  if (groupedTable) recalculateTable(groupedTable, ensureProjectTableRows(project, groupedTable), project);
}

function saveEquationEdit() {
  if (!selectedEquationContext) return;
  const { table, column } = selectedEquationContext;
  const equation = selectedEquation.value.trim();
  if (!equation.startsWith("=")) {
    formulaError.textContent = "Equations must begin with =";
    formulaError.hidden = false;
    return;
  }

  const previous = equationOverrides[table.id]?.[column];
  equationOverrides[table.id] ||= {};
  equationOverrides[table.id][column] = equation;
  try {
    if (projects.length) {
      projects.forEach((project) => {
        recalculateTable(table, ensureProjectTableRows(project, table), project);
        recalculateDependentTables(table, project);
      });
    } else {
      recalculateTable(table, table.rows, null);
      recalculateDependentTables(table, null);
    }
  } catch (error) {
    if (previous === undefined) delete equationOverrides[table.id][column];
    else equationOverrides[table.id][column] = previous;
    formulaError.textContent = error.message || "This equation could not be calculated.";
    formulaError.hidden = false;
    return;
  }

  localStorage.setItem(EQUATION_OVERRIDES_KEY, JSON.stringify(equationOverrides));
  saveProjects();
  selectedEquation.readOnly = true;
  editEquationButton.hidden = false;
  saveEquationButton.hidden = true;
  cancelEquationButton.hidden = true;
  formulaError.hidden = true;
  refreshRenderedTableValues(table, projectTableRows(table));
}

function numberFromTableValue(value) {
  const number = Number(String(value ?? "").replace(/,/g, ""));
  return Number.isFinite(number) ? number : 0;
}

function compareTableValues(left, right) {
  const leftBlank = left === null || left === undefined || left === "";
  const rightBlank = right === null || right === undefined || right === "";
  if (leftBlank !== rightBlank) return leftBlank ? 1 : -1;
  if (typeof left === "number" && typeof right === "number") return left - right;
  return String(left ?? "").localeCompare(String(right ?? ""), undefined, { numeric: true, sensitivity: "base" });
}

function calculateColumnWidths(table, headers, rows) {
  const context = document.createElement("canvas").getContext("2d");
  return headers.map((header, index) => {
    if (table.columnWidthOverrides?.[index]) return table.columnWidthOverrides[index];
    context.font = '11px Aptos, "Segoe UI", Arial, sans-serif';
    const contentWidth = rows.reduce((maximum, row) => Math.max(maximum, context.measureText(String(formatTableValue(row[index], table, index))).width), 0);
    const dropdownWidth = table.dropdownColumns?.[index]
      ? tableDropdownOptions(table, index).reduce((maximum, option) => Math.max(maximum, context.measureText(option).width), 0)
      : 0;
    context.font = '700 12px Aptos, "Segoe UI", Arial, sans-serif';
    const labelWidth = String(`${header.label || ""}${header.subscript || ""}`)
      .split(/[\s-]+/)
      .reduce((maximum, part) => Math.max(maximum, context.measureText(part).width), 0) + 54;
    context.font = '650 10px Aptos, "Segoe UI", Arial, sans-serif';
    const unitWidth = context.measureText(header.unit || "").width + 52;
    const numericColumn = table.columnTypes[index] === "number";
    const maximumWidth = table.dropdownColumns?.[index] ? 360 : numericColumn ? 160 : 360;
    const minimumWidth = table.dropdownColumns?.[index] ? 220 : numericColumn ? 96 : 110;
    const desiredContentWidth = Math.max(contentWidth + 24, dropdownWidth + 48);
    return Math.ceil(Math.max(minimumWidth, Math.min(maximumWidth, desiredContentWidth), Math.min(maximumWidth, labelWidth), Math.min(maximumWidth, unitWidth)));
  });
}

function autoFitRenderedTable(table, headers, rows) {
  const widths = calculateColumnWidths(table, headers, rows);
  referenceTable.querySelectorAll("col").forEach((column, index) => {
    column.style.width = `${widths[index]}px`;
  });
  referenceTable.style.width = `${widths.reduce((total, width) => total + width, 0)}px`;
}

function moveToAdjacentCell(cell, key, extendSelection = false) {
  const row = cell.closest("tr");
  const body = row.parentElement;
  const rows = [...body.rows].filter((candidate) => !candidate.classList.contains("table-summary-row"));
  let rowIndex = rows.indexOf(row);
  let columnIndex = cell.cellIndex;
  const rowStep = key === "ArrowUp" ? -1 : key === "ArrowDown" ? 1 : 0;
  const columnStep = key === "ArrowLeft" ? -1 : key === "ArrowRight" ? 1 : 0;

  while (true) {
    rowIndex += rowStep;
    columnIndex += columnStep;
    const targetRow = rows[rowIndex];
    if (!targetRow || columnIndex < 0 || columnIndex >= targetRow.cells.length) return;
    let target = targetRow.cells[columnIndex];
    if (target.classList.contains("editable-cell") || target.classList.contains("calculated-cell")) {
      const targetSourceIndex = Number(targetRow.dataset.sourceIndex);
      if (cell.isContentEditable && document.activeElement === cell) {
        cell.blur();
        const refreshedRow = [...referenceTable.querySelectorAll("tbody tr")]
          .find((candidate) => Number(candidate.dataset.sourceIndex) === targetSourceIndex);
        target = refreshedRow?.cells[columnIndex] || target;
      }
      const focusTarget = target.querySelector("select") || target;
      focusTarget.focus();
      if (target.isContentEditable) {
        const selection = window.getSelection();
        const range = document.createRange();
        const textNode = [...target.childNodes].find((node) => node.nodeType === Node.TEXT_NODE);
        range.selectNodeContents(textNode || target);
        range.collapse(false);
        selection.removeAllRanges();
        selection.addRange(range);
      }
      selectTableCell(activeTableId, targetSourceIndex, target.cellIndex, {
        shiftKey: extendSelection && rowStep !== 0,
        ctrlKey: false,
        metaKey: false,
      });
      alignCellInTableViewport(target);
      return;
    }
  }
}

function alignCellInTableViewport(cell) {
  const scroll = cell.closest(".table-scroll");
  const row = cell.closest("tr");
  if (!scroll || !row) return;
  const viewport = scroll.getBoundingClientRect();
  const cellRect = cell.getBoundingClientRect();
  const activeTable = independentTables.find((table) => table.id === activeTableId);
  const frozenColumnCount = activeTable?.frozenColumns || 1;
  const frozenRect = row.cells[frozenColumnCount - 1]?.getBoundingClientRect();
  const visibleLeft = cell.cellIndex >= frozenColumnCount && frozenRect ? Math.max(viewport.left, frozenRect.right) : viewport.left;
  const visibleRight = viewport.left + scroll.clientWidth;
  if (cellRect.left < visibleLeft) {
    scroll.scrollLeft = Math.max(0, scroll.scrollLeft - (visibleLeft - cellRect.left));
  } else if (cellRect.right > visibleRight) {
    scroll.scrollLeft += cellRect.right - visibleRight;
  }
}

function sortReferenceTable(tableId, column) {
  tableSort = tableSort.tableId === tableId && tableSort.column === column
    ? { tableId, column, direction: tableSort.direction === "asc" ? "desc" : "asc" }
    : { tableId, column, direction: "asc" };
  renderReferenceTable(tableId);
}

function refreshSelectedTableCells() {
  referenceTable.querySelectorAll("tbody td").forEach((cell) => {
    cell.classList.toggle("multi-cell-selected", selectedTableCells.has(`${cell.dataset.sourceIndex}:${cell.dataset.columnIndex}`));
  });
}

function selectTableCell(tableId, sourceIndex, columnIndex, event = {}) {
  const key = `${sourceIndex}:${columnIndex}`;
  if (selectedTableId !== tableId) selectedTableCells.clear();
  selectedTableId = tableId;
  selectedTableRowIndexes.clear();
  selectionAnchorIndex = -1;
  referenceTable.querySelectorAll("tbody tr.selected-row").forEach((row) => {
    row.classList.remove("selected-row");
    row.setAttribute("aria-selected", "false");
  });
  removeTableRowButton.disabled = true;
  if (event.shiftKey && cellSelectionAnchor) {
    const visibleRows = [...referenceTable.querySelectorAll("tbody tr")];
    const anchorPosition = visibleRows.findIndex((row) => Number(row.dataset.sourceIndex) === cellSelectionAnchor.sourceIndex);
    const targetPosition = visibleRows.findIndex((row) => Number(row.dataset.sourceIndex) === sourceIndex);
    if (anchorPosition >= 0 && targetPosition >= 0) {
      selectedTableCells.clear();
      const [rowStart, rowEnd] = [Math.min(anchorPosition, targetPosition), Math.max(anchorPosition, targetPosition)];
      const [columnStart, columnEnd] = [Math.min(cellSelectionAnchor.columnIndex, columnIndex), Math.max(cellSelectionAnchor.columnIndex, columnIndex)];
      visibleRows.slice(rowStart, rowEnd + 1).forEach((row) => {
        for (let column = columnStart; column <= columnEnd; column += 1) {
          if (row.cells[column]?.classList.contains("editable-cell")) selectedTableCells.add(`${row.dataset.sourceIndex}:${column}`);
        }
      });
    }
  } else if (event.ctrlKey || event.metaKey) {
    if (selectedTableCells.has(key)) selectedTableCells.delete(key); else selectedTableCells.add(key);
    cellSelectionAnchor = { sourceIndex, columnIndex };
  } else {
    selectedTableCells = new Set([key]);
    cellSelectionAnchor = { sourceIndex, columnIndex };
  }
  refreshSelectedTableCells();
}

function clearSelectedTableCellValues() {
  const table = independentTables.find((candidate) => candidate.id === activeTableId);
  if (!table || !selectedTableCells.size) return false;
  const rows = projectTableRows(table);
  let changed = false;
  selectedTableCells.forEach((key) => {
    const [rowIndex, columnIndex] = key.split(":").map(Number);
    const row = rows[rowIndex];
    if (!row || (table.lockedColumns || []).includes(columnIndex) || (table.calculatedColumns || []).includes(columnIndex)
      || table.lockedCellStates?.get(rowIndex)?.has(columnIndex)) return;
    recordZoningOverride(table, row, columnIndex, "", activeProject());
    row[columnIndex] = "";
    changed = true;
  });
  if (!changed) return false;
  recalculateTable(table, rows);
  recalculateDependentTables(table);
  saveProjects();
  selectedTableCells.clear();
  cellSelectionAnchor = null;
  renderReferenceTable(table.id, tableSearch.value);
  return true;
}

function selectTableRow(tableId, tableRow, sourceIndex, event = {}) {
  if (selectedTableId !== tableId) {
    selectedTableRowIndexes.clear();
    selectionAnchorIndex = -1;
  }
  selectedTableId = tableId;
  const toggle = Boolean(event.ctrlKey || event.metaKey);
  if (event.shiftKey && selectionAnchorIndex >= 0) {
    const visibleRows = [...referenceTable.querySelectorAll("tbody tr")];
    const anchorPosition = visibleRows.findIndex((row) => Number(row.dataset.sourceIndex) === selectionAnchorIndex);
    const targetPosition = visibleRows.indexOf(tableRow);
    if (anchorPosition >= 0 && targetPosition >= 0) {
      selectedTableRowIndexes = new Set(visibleRows
        .slice(Math.min(anchorPosition, targetPosition), Math.max(anchorPosition, targetPosition) + 1)
        .map((row) => Number(row.dataset.sourceIndex)));
    }
  } else if (toggle) {
    if (selectedTableRowIndexes.has(sourceIndex)) selectedTableRowIndexes.delete(sourceIndex);
    else selectedTableRowIndexes.add(sourceIndex);
    selectionAnchorIndex = sourceIndex;
  } else {
    selectedTableRowIndexes = new Set([sourceIndex]);
    selectionAnchorIndex = sourceIndex;
  }
  referenceTable.querySelectorAll("tbody tr").forEach((row) => {
    const selected = selectedTableRowIndexes.has(Number(row.dataset.sourceIndex));
    row.classList.toggle("selected-row", selected);
    row.setAttribute("aria-selected", String(selected));
  });
  removeTableRowButton.disabled = selectedTableRowIndexes.size === 0;
}

function addTableRow() {
  const table = independentTables.find((candidate) => candidate.id === activeTableId);
  if (!table) return;
  const rows = projectTableRows(table);
  const row = Array(table.columns.length).fill("");
  rows.push(row);
  recalculateTable(table, rows);
  recalculateDependentTables(table);
  selectedTableId = table.id;
  selectedTableRowIndexes = new Set([rows.length - 1]);
  selectionAnchorIndex = rows.length - 1;
  saveProjects();
  tableSearch.value = "";
  tableSort = { tableId: table.id, column: -1, direction: "asc" };
  renderReferenceTable(table.id);
  requestAnimationFrame(() => {
    const scroll = document.querySelector(".table-scroll");
    scroll.scrollTop = scroll.scrollHeight;
    referenceTable.querySelector("tbody tr:last-child .editable-cell")?.focus();
  });
}

function removeTableRow() {
  if (!activeTableId || selectedTableId !== activeTableId || selectedTableRowIndexes.size === 0) return;
  const table = independentTables.find((candidate) => candidate.id === activeTableId);
  if (!table) return;
  const rows = projectTableRows(table);
  [...selectedTableRowIndexes].sort((left, right) => right - left).forEach((index) => {
    rows.splice(index, 1);
  });
  recalculateTable(table, rows);
  recalculateDependentTables(table);
  saveProjects();
  selectedTableId = "";
  selectedTableRowIndexes.clear();
  selectionAnchorIndex = -1;
  removeTableRowButton.disabled = true;
  renderReferenceTable(table.id);
}

function renderSummaryLinks(groupName) {
  summaryLinks.innerHTML = "";
  summaryLinks.hidden = !groupName;
  if (!groupName) return;

  const section = modules.find((candidate) => candidate.group === groupName);
  if (!section || !section.items.length) {
    const note = document.createElement("span");
    note.className = "summary-note";
    note.textContent = "Reference tables will be added as their calculation dependencies are migrated.";
    summaryLinks.appendChild(note);
    return;
  }

  section.items.forEach((item) => {
    const button = document.createElement("button");
    button.type = "button";
    button.textContent = item[0];
    button.addEventListener("click", () => {
      search.value = "";
      renderTree();
      const target = document.querySelector(`[data-id="${CSS.escape(slugify(item[0]))}"]`);
      if (target) selectModule(target);
    });
    summaryLinks.appendChild(button);
  });
}

function syncActiveState() {
  const id = location.hash.slice(1) || "space-condition-setpoints";
  document.querySelectorAll("[data-id]").forEach((button) => button.classList.toggle("active", button.dataset.id === id));
  const active = document.querySelector(`[data-id="${CSS.escape(id)}"]`);
  if (active) updateWorkspace(active.dataset);
}

function openBrowser() {
  browser.classList.add("open");
  scrim.classList.add("open");
  document.body.style.overflow = "hidden";
}

function closeBrowser() {
  browser.classList.remove("open");
  scrim.classList.remove("open");
  document.body.style.overflow = "";
}

function createProjectId() {
  return globalThis.crypto?.randomUUID?.() || `project-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function defaultProject() {
  const project = { id: createProjectId() };
  projectFields.forEach((input) => {
    const field = input.dataset.projectField;
    project[field] = localStorage.getItem(`hvac-project-${field}`) ?? input.value ?? "";
  });
  project.number ||= "185021";
  project.name ||= "IESVE 2025 Energy Model";
  return project;
}

function saveProjects() {
  const next = JSON.stringify(projects);
  const previous = localStorage.getItem(PROJECTS_KEY);
  if (!applyingHistory && previous && previous !== next) {
    undoStack.push(previous);
    if (undoStack.length > 100) undoStack.shift();
    redoStack.length = 0;
  }
  localStorage.setItem(PROJECTS_KEY, next);
  localStorage.setItem(ACTIVE_PROJECT_KEY, activeProjectId);
}

function restoreProjectHistory(snapshot) {
  applyingHistory = true;
  try {
    projects = JSON.parse(snapshot);
    if (!projects.some((project) => project.id === activeProjectId)) activeProjectId = projects[0]?.id || "";
    localStorage.setItem(PROJECTS_KEY, JSON.stringify(projects));
    localStorage.setItem(ACTIVE_PROJECT_KEY, activeProjectId);
    selectedTableCells.clear();
    cellSelectionAnchor = null;
    fillProjectFields();
    renderProjectList();
    syncActiveState();
  } finally {
    applyingHistory = false;
  }
}

function undoProjectChange() {
  const snapshot = undoStack.pop();
  if (!snapshot) return;
  redoStack.push(JSON.stringify(projects));
  restoreProjectHistory(snapshot);
}

function redoProjectChange() {
  const snapshot = redoStack.pop();
  if (!snapshot) return;
  undoStack.push(JSON.stringify(projects));
  restoreProjectHistory(snapshot);
}

function loadProjects() {
  try {
    const saved = JSON.parse(localStorage.getItem(PROJECTS_KEY) || "null");
    projects = Array.isArray(saved) && saved.length ? saved : [defaultProject()];
  } catch {
    projects = [defaultProject()];
  }

  const savedActiveId = localStorage.getItem(ACTIVE_PROJECT_KEY);
  activeProjectId = projects.some((project) => project.id === savedActiveId) ? savedActiveId : projects[0].id;
  saveProjects();
}

function activeProject() {
  return projects.find((project) => project.id === activeProjectId) || projects[0];
}

function fillProjectFields() {
  const project = activeProject();
  if (!project) return;
  projectFields.forEach((input) => {
    input.value = project[input.dataset.projectField] || "";
  });
}

function renderProjectList(query = projectSearch.value) {
  const normalized = query.trim().toLowerCase();
  const matches = projects.filter((project) =>
    [project.number, project.name, project.client].some((value) => String(value || "").toLowerCase().includes(normalized)),
  );
  projectList.innerHTML = "";

  if (!matches.length) {
    const empty = document.createElement("p");
    empty.className = "project-list-empty";
    empty.textContent = "No projects match this search.";
    projectList.appendChild(empty);
    return;
  }

  matches.forEach((project) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "project-list-item";
    button.classList.toggle("active", project.id === activeProjectId);
    if (project.id === activeProjectId) button.setAttribute("aria-current", "true");

    const number = document.createElement("strong");
    number.textContent = project.number;
    const name = document.createElement("span");
    name.textContent = project.name || "Untitled project";
    button.append(number, name);
    button.addEventListener("click", () => selectProject(project.id));
    projectList.appendChild(button);
  });
}

function selectProject(projectId) {
  if (!projects.some((project) => project.id === projectId)) return;
  activeProjectId = projectId;
  selectedTableId = "";
  selectedTableRowIndexes.clear();
  selectionAnchorIndex = -1;
  saveProjects();
  fillProjectFields();
  renderProjectList();
  syncActiveState();
}

function setProjectSwitcher(open) {
  shell.classList.toggle("projects-open", open);
  projectSwitcherToggle.setAttribute("aria-expanded", String(open));
  projectSwitcherToggle.setAttribute("aria-label", `${open ? "Close" : "Open"} project list`);
  projectSwitcherToggle.title = `${open ? "Close" : "Open"} project list`;
  if (open) {
    renderProjectList();
    projectSearch.focus();
  }
}

function openProjectDialog() {
  projectForm.reset();
  projectDialogError.textContent = "";
  projectDialog.showModal();
  requestAnimationFrame(() => newProjectNumber.focus());
}

function addProject(event) {
  event.preventDefault();
  const number = newProjectNumber.value.trim();
  if (!number) {
    projectDialogError.textContent = "Enter a project number.";
    newProjectNumber.focus();
    return;
  }
  if (projects.some((project) => String(project.number).toLowerCase() === number.toLowerCase())) {
    projectDialogError.textContent = "That project number already exists.";
    newProjectNumber.focus();
    return;
  }

  const project = {
    id: createProjectId(),
    number,
    client: "",
    name: "",
    date: "",
    made_by: "",
    checked_by: "",
    submittal: "",
  };
  projects.push(project);
  projectSearch.value = "";
  projectDialog.close();
  selectProject(project.id);
}

function initializeProjects() {
  loadProjects();
  fillProjectFields();
  renderProjectList();

  projectFields.forEach((input) => {
    if (input.readOnly) return;
    input.addEventListener("input", () => {
      const project = activeProject();
      if (!project) return;
      project[input.dataset.projectField] = input.value;
      saveProjects();
      renderProjectList();
    });
  });
}

search.addEventListener("input", (event) => renderTree(event.target.value));
projectSearch.addEventListener("input", (event) => renderProjectList(event.target.value));
tableSearch.addEventListener("input", (event) => {
  if (activeTableId) renderReferenceTable(activeTableId, event.target.value);
});
twoValueSchedule.addEventListener("change", () => {
  const project = activeProject();
  if (!project || activeTableId !== "calc-space-condition-setpoints") return;
  project.calcSettings ||= {};
  project.calcSettings.twoValueSchedule = twoValueSchedule.value.trim();
  saveProjects();
});
document.addEventListener("keydown", (event) => {
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "z") {
    event.preventDefault();
    if (event.shiftKey) redoProjectChange(); else undoProjectChange();
    return;
  }
  if (event.key === "Delete" && selectedTableCells.size) {
    const selection = window.getSelection();
    if (document.activeElement?.isContentEditable && selection && !selection.isCollapsed) return;
    if (clearSelectedTableCellValues()) event.preventDefault();
    return;
  }
  if (!["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(event.key)) return;
  const cell = event.composedPath().find((node) => node instanceof HTMLTableCellElement && referenceTable.contains(node));
  if (!cell || event.altKey || event.ctrlKey || event.metaKey) return;
  if (event.shiftKey && cell.isContentEditable && ["ArrowLeft", "ArrowRight"].includes(event.key)) return;
  event.preventDefault();
  event.stopImmediatePropagation();
  moveToAdjacentCell(cell, event.key, event.shiftKey);
}, true);

addTableRowButton.addEventListener("click", addTableRow);
removeTableRowButton.addEventListener("click", removeTableRow);
pasteDataButton.addEventListener("click", pasteDataFromClipboard);
copyDataButton.addEventListener("click", copyTabularData);
importExcelButton.addEventListener("click", () => importExcelInput.click());
importExcelInput.addEventListener("change", () => {
  importRoomZoneLoads(importExcelInput.files?.[0]);
});
editEquationButton.addEventListener("click", beginEquationEdit);
saveEquationButton.addEventListener("click", saveEquationEdit);
cancelEquationButton.addEventListener("click", cancelEquationEdit);
selectedEquation.addEventListener("keydown", (event) => {
  if (selectedEquation.readOnly) return;
  if (event.key === "Enter") {
    event.preventDefault();
    saveEquationEdit();
  } else if (event.key === "Escape") {
    event.preventDefault();
    event.stopPropagation();
    cancelEquationEdit();
  }
});
projectSwitcherToggle.addEventListener("click", () => setProjectSwitcher(!shell.classList.contains("projects-open")));
document.querySelector("#add-project").addEventListener("click", openProjectDialog);
document.querySelector("#cancel-project").addEventListener("click", () => projectDialog.close());
projectForm.addEventListener("submit", addProject);
document.querySelector("#open-browser").addEventListener("click", openBrowser);
document.querySelector("#close-browser").addEventListener("click", closeBrowser);
scrim.addEventListener("click", closeBrowser);
window.addEventListener("hashchange", syncActiveState);
document.addEventListener("pointermove", (event) => updateFillPreview(event.clientX, event.clientY));
document.addEventListener("pointerup", finishFillDrag);
document.addEventListener("pointercancel", finishFillDrag);
document.addEventListener("pointerdown", (event) => {
  if (event.target.closest?.(".fill-handle") || event.target.closest?.("td.editable-cell")) return;
  clearFillHandle();
});
tableScroll.addEventListener("scroll", clearFillHandle);
modelInputsView.addEventListener("pointerdown", (event) => {
  if (!event.target.closest("input.calculated-value")) hideModelInputEquation();
});
window.addEventListener("paste", (event) => {
  if (activeTableId !== "iesve-tabular-space-data") return;
  if (event.target instanceof HTMLInputElement || event.target instanceof HTMLTextAreaElement || event.target.isContentEditable) return;
  const text = event.clipboardData?.getData("text/plain") || "";
  if (!text.trim()) return;
  event.preventDefault();
  try {
    pasteTabularData(text);
  } catch (error) {
    setCsvFileStatus(error.message || "The pasted clipboard data could not be used.", true);
  }
});
window.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && !projectDialog.open) {
    closeBrowser();
    setProjectSwitcher(false);
  }
});

initializeProjects();
renderTree();

let loadedVersion = null;
async function checkForUpdates() {
  if (document.visibilityState !== "visible") return;
  try {
    const isLocal = location.hostname === "127.0.0.1" || location.hostname === "localhost";
    const versionUrl = isLocal ? `/version?t=${Date.now()}` : `./version.json?t=${Date.now()}`;
    const response = await fetch(versionUrl, { cache: "no-store" });
    if (!response.ok) return;
    const { version } = await response.json();
    if (loadedVersion !== null && version !== loadedVersion) location.reload();
    loadedVersion = version;
  } catch {
    // The local server may be restarting; the next poll will reconnect.
  }
}

checkForUpdates();
setInterval(checkForUpdates, 1200);
