const modules = [
  {
    group: "IESVE 2025",
    source: "IES Data → IES Loads",
    summary: "Import, normalize, export, and review the IESVE 2025 space and room-load datasets used by the design workbook.",
    items: [
      ["Thermal Template", "Thermal · B3:O115", "Map thermal space types to ventilation, occupant heat-gain, and lighting criteria.", "iesve-thermal-template"],
      ["Tabular Space Data", "IES Data · D3:AL201", "Review and edit the IESVE tabular space dataset used by downstream calculations.", "iesve-tabular-space-data"],
      ["Room/Zone Loads Report", "Room/Zone Loads · A10:U149", "Review imported room and zone sensible cooling, latent cooling, and heating loads.", "room-zone-loads-report"],
    ],
  },
  {
    group: "Space Calculations",
    source: "Inputs → IES Loads → Calc",
    summary: "Review space conditions, loads, zoning, ventilation, air balance, latent performance, baseline systems, and monitoring criteria.",
    items: [
      ["General", "Calc · B:E", "Review the space list, type, volume, and area fields that anchor the calculation row.", "calc-general"],
      ["Space Condition Setpoints", "Calc · F:N", "Define heating, cooling, humidity, setback, and ventilated temperature-rise criteria.", "calc-space-condition-setpoints"],
      ["DHW", "Calc · O:V", "Calculate occupancy-driven domestic hot-water demand and schedule values.", "calc-dhw"],
      ["Internal Gains Calculations", "Calc · W:AP", "Calculate lighting, people, miscellaneous, and total internal gains by space.", "calc-internal-gains"],
      ["Room Loads", "Calc · AQ:BC", "Consolidate sensible cooling, latent cooling, and heating room loads used for sizing.", "calc-room-loads"],
      ["Equipment Zoning", "Calc · BD:BQ", "Assign spaces to equipment zones and evaluate shared operating criteria.", "calc-equipment-zoning"],
      ["Heating Load Calculations", "Calc · BR:BZ", "Calculate design heating requirements while preserving workbook sizing and rounding logic.", "calc-heating-loads"],
      ["Cooling Load Calculations", "Calc · CA:CO", "Calculate design sensible, latent, and total cooling requirements.", "calc-cooling-loads"],
      ["Required Ventilation and Exhaust Rate Calculations", "Calc · CP:DH", "Determine required outdoor-air and exhaust quantities for each applicable space.", "calc-ventilation-exhaust"],
      ["Pressurization Calculations", "Calc · DI:DY", "Evaluate supply, return, exhaust, and transfer relationships for space pressure intent.", "calc-pressurization"],
      ["Non-Peak Air Balance", "Calc · DZ:EG", "Review airflow balance away from coincident peak-load conditions.", "calc-non-peak-air-balance"],
      ["Air Balance", "Calc · EH:EU", "Review the space supply, return, exhaust, transfer, and balance relationships.", "calc-air-balance"],
      ["Latent Load Calculations", "Calc · EV:FE", "Trace latent gains and moisture loads through the space calculation path.", "calc-latent-loads"],
      ["Space Condition Type and Baseline System", "Calc · FF:FQ", "Map space condition types to the workbook baseline-system logic.", "calc-condition-baseline"],
      ["CO₂ Monitoring Calculation", "Calc · FR:FY", "Identify spaces subject to carbon-dioxide monitoring criteria.", "calc-co2-monitoring"],
    ],
  },
  {
    group: "Selected Space Requirements",
    source: "Lighting → Misc → Exhaust → Transfer",
    summary: "Manage supplemental fixture, equipment, exhaust, and transfer-air requirements for the selected spaces that need added detail.",
    items: [
      ["Lighting Loads", "Lighting", "Add detailed lighting loads for selected spaces where fixture-level inputs are required."],
      ["Miscellaneous Sensible Loads", "Misc", "Add detailed plug, process, and equipment sensible loads for selected spaces."],
      ["General Exhaust Requirements", "Exhaust", "Apply general exhaust criteria to selected spaces."],
      ["Exhaust Equipment Requirements", "Exhaust", "Define equipment-specific exhaust demands and operating relationships."],
      ["Transfer Air", "Transfer", "Define transfer-air paths and quantities for selected spaces."],
    ],
  },
  {
    group: "Airside Equipment",
    source: "Airside → Psych",
    summary: "Review airside design settings, coil duties, and psychrometric processes for the project systems.",
    items: [
      ["Settings", "Airside", "Configure shared airside design conditions and equipment assumptions."],
      ["Preheat Coils", "Airside", "Size and review preheat coil performance at workbook design conditions."],
      ["Cooling Coils", "Airside", "Size and review cooling coil sensible, latent, and total performance."],
      ["Reheat / Heating Coils", "Airside", "Size and review reheat and heating coil performance."],
      ["Psychrometric Charts", "Psych", "Visualize air-state processes used in the airside calculations."],
    ],
  },
  {
    group: "Plantside Equipment",
    source: "Plantside",
    summary: "Review the calculated cooling and heating plant design duties and equipment selections.",
    items: [
      ["Cooling Plant Equipment", "Plantside", "Review cooling plant equipment selections and calculated design duties."],
      ["Heating Plant Equipment", "Plantside", "Review heating plant equipment selections and calculated design duties."],
    ],
  },
  {
    group: "Energy",
    source: "Energy",
    summary: "Compare proposed energy performance with the four baseline building rotations used by the workbook.",
    items: [
      ["Proposed", "Energy", "Review the proposed building energy-model results."],
      ["Baseline 000deg", "Energy", "Review the baseline energy-model results at the 000-degree rotation."],
      ["Baseline 090deg", "Energy", "Review the baseline energy-model results at the 090-degree rotation."],
      ["Baseline 180deg", "Energy", "Review the baseline energy-model results at the 180-degree rotation."],
      ["Baseline 270deg", "Energy", "Review the baseline energy-model results at the 270-degree rotation."],
    ],
  },
  {
    group: "Independent Tables",
    source: "Lighting → Misc → Exhaust → ASHRAE → Water",
    summary: "Browse project schedules and the independent ASHRAE and water-property reference tables used by the workbook calculations.",
    items: [
      ["Lighting Schedule", "Lighting · O13:Q62", "Lighting fixture types, wattages, and calculated project quantities.", "schedule-lighting"],
      ["Equipment Sensible Gain Schedule", "Misc · T9:Z56", "Equipment load inputs in Btu/h and kW with efficiency, space allocation, calculated heat gain, and project quantities.", "schedule-equipment-sensible-gain"],
      ["Grouped Equipment Sensible Gain Schedule", "Misc · AA9:AE11", "Reusable equipment groups with calculated row heat gain and group heat-gain totals.", "schedule-grouped-equipment-sensible-gain"],
      ["General Exhaust Schedule", "Exhaust · AV9:BE40", "General exhaust criteria by fixture, area, and occupied or unoccupied air-change basis.", "schedule-general-exhaust"],
      ["Exhaust Equipment Schedule", "Exhaust · AV9:BE40", "Equipment-specific exhaust airflow for on and off operating conditions.", "schedule-exhaust-equipment"],
      ["Ventilation Rates", "ASHRAE · B4:E83", "Outdoor-air rates and default occupant density by occupancy category.", "ashrae-62-1-ventilation"],
      ["Baseline Lighting Power Density", "ASHRAE · G4:H108", "Baseline lighting power density by common space type.", "ashrae-90-1-baseline-lighting"],
      ["Proposed Lighting Power Density", "ASHRAE · J4:K103", "Lighting power allowances by common space type.", "ashrae-90-1-proposed-lighting"],
      ["Occupant Heat Gain", "ASHRAE · M4:O17", "Sensible and latent heat gain per person by activity level.", "ashrae-fundamentals-people-heat"],
      ["Climate Zones and Baseline Systems", "ASHRAE · T4:AD23", "Climate-zone descriptions and baseline system assignments by building type and size.", "ashrae-climate-zones"],
      ["Baseline System Descriptions", "ASHRAE · AL4:AR18", "Baseline HVAC system types, fan control, cooling source, and heating source.", "ashrae-90-1-baseline-systems"],
      ["Ethylene Glycol Density", "Water · B9:L38", "Density of aqueous ethylene glycol solutions by temperature and volume concentration.", "water-ethylene-density"],
      ["Propylene Glycol Density", "Water · O9:Y38", "Density of inhibited aqueous propylene glycol solutions by temperature and volume concentration.", "water-propylene-density"],
      ["Ethylene Glycol Specific Heat", "Water · B44:L73", "Specific heat of aqueous ethylene glycol solutions by temperature and volume concentration.", "water-ethylene-specific-heat"],
      ["Propylene Glycol Specific Heat", "Water · O44:Y73", "Specific heat of aqueous propylene glycol solutions by temperature and volume concentration.", "water-propylene-specific-heat"],
      ["Water Properties at 14.700 psia", "Water · B89:O113", "Thermophysical properties of water at atmospheric pressure.", "water-nist-properties"],
    ],
  },
];

const independentTables = [
  ...(globalThis.INDEPENDENT_TABLES || []),
  ...(globalThis.CALC_SECTION_TABLES || []),
];

const tabularSpaceHeaders = [
  { label: "Space ID" },
  { label: "Space Name" },
  { label: "Heating Design Supply Air Temperature", unit: "°F" },
  { label: "Cooling Design Supply Air Temperature", unit: "°F" },
  { label: "DHW Consumption Room-level Setting" },
  { label: "DHW Consumption", unit: "US gal/h" },
  { label: "DHW Consumption Pattern" },
  { label: "DHW Pattern Of Use Profile" },
  { label: "Heating Setpoint", unit: "°F" },
  { label: "Cooling Setpoint", unit: "°F" },
  { label: "Saturation Upper Limit", unit: "%" },
  { label: "Gain 1 Input Mode" },
  { label: "Gain 1 Occupancy", unit: "people" },
  { label: "Gain 1 Max. Sensible Gain", unit: "Btu/h" },
  { label: "Gain 1 Max. Sensible Gain", unit: "Btu/h·person" },
  { label: "Gain 1 Max. Latent Gain", unit: "Btu/h·person" },
  { label: "Gain 1 Max. Power Consumption", unit: "Btu/h" },
  { label: "Gain 2 Input Mode" },
  { label: "Gain 2 Occupancy", unit: "people" },
  { label: "Gain 2 Max. Sensible Gain", unit: "Btu/h" },
  { label: "Gain 2 Max. Sensible Gain", unit: "Btu/h·person" },
  { label: "Gain 2 Max. Latent Gain", unit: "Btu/h·person" },
  { label: "Gain 2 Max. Power Consumption", unit: "Btu/h" },
  { label: "Gain 3 Input Mode" },
  { label: "Gain 3 Occupancy", unit: "people" },
  { label: "Gain 3 Max. Sensible Gain", unit: "Btu/h" },
  { label: "Gain 3 Max. Sensible Gain", unit: "Btu/h·person" },
  { label: "Gain 3 Max. Latent Gain", unit: "Btu/h·person" },
  { label: "Gain 3 Max. Power Consumption", unit: "Btu/h" },
  { label: "Basis for OA Requirement" },
  { label: "Outdoor Air Req. Type" },
  { label: "Outdoor Air Req.", unit: "cfm" },
  { label: "Use Exhaust Air Change Req?" },
  { label: "Exhaust Air Change Req." },
  { label: "Exhaust Air Change Req. Unit" },
];

const tabularSpaceCsvHeaders = [
  "Space ID",
  "Space Name (Real)",
  "Heating Design Supply Air Temperature (°F) (Real)",
  "Cooling Design Supply Air Temperature (°F) (Real)",
  "DHW Consumption Room-level Setting (Real)",
  "DHW Consumption (Real)",
  "DHW Consumption Pattern (Real)",
  "DHW Pattern Of Use Profile (Real)",
  "Heating Setpoint (°F) (Real)",
  "Cooling Setpoint (°F) (Real)",
  "% Saturation Upper Limit (Real)",
  "Gain 1 Input Mode (Real)",
  "Gain 1 Occupancy (People) (Real)",
  "Gain 1 Max. Sensible Gain (Btu/h) (Real)",
  "Gain 1 Max. Sensible Gain (Btu/h·person) (Real)",
  "Gain 1 Max. Latent Gain (Btu/h·person) (Real)",
  "Gain 1 Max. Power Consumption (Btu/h) (Real)",
  "Gain 2 Input Mode (Real)",
  "Gain 2 Occupancy (People) (Real)",
  "Gain 2 Max. Sensible Gain (Btu/h) (Real)",
  "Gain 2 Max. Sensible Gain (Btu/h·person) (Real)",
  "Gain 2 Max. Latent Gain (Btu/h·person) (Real)",
  "Gain 2 Max. Power Consumption (Btu/h) (Real)",
  "Gain 3 Input Mode (Real)",
  "Gain 3 Occupancy (People) (Real)",
  "Gain 3 Max. Sensible Gain (Btu/h) (Real)",
  "Gain 3 Max. Sensible Gain (Btu/h·person) (Real)",
  "Gain 3 Max. Latent Gain (Btu/h·person) (Real)",
  "Gain 3 Max. Power Consumption (Btu/h) (Real)",
  "Basis for OA Requirement (Real)",
  "Outdoor Air Req. Type (Real)",
  "Outdoor Air Req. (cfm) (Real)",
  "Use Exhaust Air Change Req? (Real)",
  "Exhaust Air Change Req. (Real)",
  "Exhaust Air Change Req. Unit (Real)",
];

if (!independentTables.some((table) => table.id === "iesve-tabular-space-data")) {
  const numericColumns = new Set([2, 3, 5, 10, 12, 13, 14, 15, 16, 18, 19, 20, 21, 22, 24, 25, 26, 27, 28, 31, 33]);
  independentTables.unshift({
    id: "iesve-tabular-space-data",
    name: "Tabular Space Data",
    standard: "Tabular Space Data",
    description: "IESVE tabular space data structure populated from pasted source data.",
    sheet: "IES Data",
    range: "D3:AL201",
    headers: tabularSpaceHeaders,
    columns: tabularSpaceHeaders.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`),
    columnTypes: tabularSpaceHeaders.map((_, index) => numericColumns.has(index) ? "number" : "text"),
    percentageColumns: [10],
    csvHeaders: tabularSpaceCsvHeaders,
    lockedColumns: tabularSpaceHeaders.map((_, index) => index),
    frozenColumns: 2,
    rows: [],
  });
}

if (!independentTables.some((table) => table.id === "room-zone-loads-report")) {
  const headers = [
    { label: "Zone Group" },
    { label: "Zone" },
    { label: "Room" },
    { label: "Sensible Cooling (without oversizing)", unit: "MBH" },
    { label: "Latent Cooling (without oversizing)", unit: "MBH" },
    { label: "Heating (without oversizing)", unit: "MBH" },
  ];
  independentTables.unshift({
    id: "room-zone-loads-report",
    name: "Room/Zone Loads Report",
    standard: "Room/Zone Loads Report",
    description: "Room and zone loads imported from the workbook report beginning at row 10.",
    sheet: "IES Loads",
    range: "A10:U149",
    headers,
    columns: [
      "Zone Group",
      "Zone",
      "Room",
      "Sensible Cooling Load without Oversizing (MBH)",
      "Latent Cooling Load without Oversizing (MBH)",
      "Heating Load without Oversizing (MBH)",
    ],
    columnTypes: ["text", "text", "text", "number", "number", "number"],
    lockedColumns: headers.map((_, index) => index),
    decimalColumns: [3, 4, 5],
    excelImport: true,
    frozenColumns: 3,
    identityColumns: [0, 1, 2],
    headerClasses: {
      3: "sensible-cooling-header",
      4: "latent-cooling-header",
      5: "heating-load-header",
    },
    rows: [],
  });
}

const tree = document.querySelector("#project-tree");
const search = document.querySelector("#browser-search");
const browser = document.querySelector("#project-browser");
const scrim = document.querySelector("#drawer-scrim");
const moduleContent = document.querySelector("#module-content");
const summaryLinks = document.querySelector("#summary-links");
const shell = document.querySelector(".app-shell");
const projectList = document.querySelector("#project-list");
const projectSearch = document.querySelector("#project-search");
const projectDialog = document.querySelector("#project-dialog");
const projectForm = document.querySelector("#project-form");
const newProjectNumber = document.querySelector("#new-project-number");
const projectDialogError = document.querySelector("#project-dialog-error");
const projectSwitcherToggle = document.querySelector("#project-switcher-toggle");
const tableView = document.querySelector("#table-view");
const referenceTable = document.querySelector("#reference-table");
const tableSearch = document.querySelector("#table-search");
const tableCount = document.querySelector("#table-count");
const tableStandard = document.querySelector("#table-standard");
const addTableRowButton = document.querySelector("#add-table-row");
const removeTableRowButton = document.querySelector("#remove-table-row");
const editableKey = document.querySelector(".editable-key");
const calculatedKey = document.querySelector(".calculated-key");
const matchKey = document.querySelector(".match-key");
const differentKey = document.querySelector(".different-key");
const formulaBar = document.querySelector("#formula-bar");
const selectedEquation = document.querySelector("#selected-equation");
const editEquationButton = document.querySelector("#edit-equation");
const saveEquationButton = document.querySelector("#save-equation");
const cancelEquationButton = document.querySelector("#cancel-equation");
const formulaError = document.querySelector("#formula-error");
const clipboardActions = document.querySelector("#clipboard-actions");
const excelActions = document.querySelector("#excel-actions");
const importExcelButton = document.querySelector("#import-excel");
const importExcelInput = document.querySelector("#import-excel-input");
const pasteDataButton = document.querySelector("#paste-table-data");
const copyDataButton = document.querySelector("#copy-table-data");
const csvFileStatus = document.querySelector("#csv-file-status");
const templateStatus = document.querySelector("#template-status");
const rowActions = document.querySelector("#row-actions");
const csvComparisonBar = document.querySelector("#csv-comparison-bar");
const csvComparisonColumn = document.querySelector("#csv-comparison-column");
const csvComparisonValue = document.querySelector("#csv-comparison-value");
const csvComparisonStatus = document.querySelector("#csv-comparison-status");
let activeTableId = "";
let tableSort = { tableId: "", column: -1, direction: "asc" };
let selectedTableId = "";
let selectedTableRowIndexes = new Set();
let selectionAnchorIndex = -1;

const PROJECTS_KEY = "hvac-projects-v1";
const ACTIVE_PROJECT_KEY = "hvac-active-project-v1";
const EQUATION_OVERRIDES_KEY = "hvac-equation-overrides-v1";
const EQUIPMENT_EQUATION_SCHEMA_KEY = "hvac-equipment-equation-schema-v1";
const tableNumberFormatter = new Intl.NumberFormat("en-US", { maximumFractionDigits: 20 });
const twoDecimalFormatter = new Intl.NumberFormat("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const calculatedBtuNumberFormatter = new Intl.NumberFormat("en-US", { maximumFractionDigits: 0 });
const projectFields = [...document.querySelectorAll("[data-project-field]")];
let projects = [];
let activeProjectId = "";
let selectedEquationContext = null;
let equationOverrides = {};
const csvImportsByProject = new Map();
const excelImportsByProject = new Map();
let selectedCsvComparisonContext = null;
try {
  equationOverrides = JSON.parse(localStorage.getItem(EQUATION_OVERRIDES_KEY) || "{}");
  if (localStorage.getItem(EQUIPMENT_EQUATION_SCHEMA_KEY) !== "4") {
    if (equationOverrides["schedule-equipment-sensible-gain"]) delete equationOverrides["schedule-equipment-sensible-gain"][5];
    if (equationOverrides["schedule-grouped-equipment-sensible-gain"]) delete equationOverrides["schedule-grouped-equipment-sensible-gain"][4];
    localStorage.setItem(EQUATION_OVERRIDES_KEY, JSON.stringify(equationOverrides));
    localStorage.setItem(EQUIPMENT_EQUATION_SCHEMA_KEY, "4");
  }
} catch {
  equationOverrides = {};
}

const slugify = (text) => text.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");

function renderTree(query = "") {
  const normalized = query.trim().toLowerCase();
  tree.innerHTML = "";
  let resultCount = 0;

  modules.forEach((section) => {
    const groupMatch = section.group.toLowerCase().includes(normalized);
    const visibleItems = section.items.filter((item) => !normalized || groupMatch || item[0].toLowerCase().includes(normalized));
    if (normalized && !groupMatch && !visibleItems.length) return;
    resultCount += visibleItems.length + 1;

    const wrapper = document.createElement("section");
    wrapper.className = "tree-group";

    const row = document.createElement("div");
    row.className = "group-row";

    if (section.items.length) {
      const expander = document.createElement("button");
      expander.className = "group-expander";
      expander.type = "button";
      expander.setAttribute("aria-label", `Collapse ${section.group}`);
      expander.setAttribute("aria-expanded", "true");
      expander.innerHTML = '<span class="chevron" aria-hidden="true">›</span>';
      expander.addEventListener("click", () => {
        wrapper.classList.toggle("collapsed");
        const expanded = !wrapper.classList.contains("collapsed");
        expander.setAttribute("aria-expanded", String(expanded));
        expander.setAttribute("aria-label", `${expanded ? "Collapse" : "Expand"} ${section.group}`);
      });
      row.appendChild(expander);
    } else {
      const spacer = document.createElement("span");
      spacer.className = "group-spacer";
      row.appendChild(spacer);
    }

    const groupLink = document.createElement("button");
    groupLink.className = "group-link";
    groupLink.type = "button";
    groupLink.dataset.id = `section-${slugify(section.group)}`;
    groupLink.dataset.title = section.group;
    groupLink.dataset.group = "Project Browser";
    groupLink.dataset.source = section.source;
    groupLink.dataset.description = section.summary;
    groupLink.dataset.summary = "true";
    groupLink.textContent = section.group;
    groupLink.addEventListener("click", () => selectModule(groupLink));
    row.appendChild(groupLink);

    if (section.items.length) {
      const count = document.createElement("span");
      count.className = "item-count";
      count.textContent = String(section.items.length);
      row.appendChild(count);
    }

    wrapper.appendChild(row);

    if (visibleItems.length) {
      const children = document.createElement("div");
      children.className = "tree-children";
      visibleItems.forEach((item) => children.appendChild(createLeaf(item, section.group)));
      wrapper.appendChild(children);
    }
    tree.appendChild(wrapper);
  });

  if (!resultCount) {
    const empty = document.createElement("p");
    empty.className = "no-results";
    empty.textContent = "No calculations match this search.";
    tree.appendChild(empty);
  }

  syncActiveState();
}

function createLeaf(item, group) {
  const button = document.createElement("button");
  button.type = "button";
  button.className = "tree-leaf";
  button.dataset.id = slugify(item[0]);
  button.dataset.title = item[0];
  button.dataset.group = group;
  button.dataset.source = item[1];
  button.dataset.description = item[2];
  if (item[3]) button.dataset.table = item[3];
  button.textContent = item[0];
  button.addEventListener("click", () => selectModule(button));
  return button;
}

function selectModule(button) {
  history.replaceState(null, "", `#${button.dataset.id}`);
  updateWorkspace(button.dataset);
  syncActiveState();
  closeBrowser();
}

function updateWorkspace(data) {
  const isSummary = data.summary === "true";
  const isTable = Boolean(data.table);
  document.querySelector("#crumb-group").textContent = data.group;
  document.querySelector("#crumb-page").textContent = data.title;
  document.querySelector("#page-kicker").textContent = isSummary ? "SECTION SUMMARY" : data.group.toUpperCase();
  document.querySelector("#page-title").textContent = data.title;
  document.querySelector("#page-description").textContent = data.description;
  document.querySelector("#source-sheet").textContent = data.source;
  document.querySelector(".section-label").textContent = isSummary ? "TABLE CONTENTS" : "CURRENT MODULE";
  document.querySelector("#module-heading").textContent = data.title;
  document.querySelector("#module-status").textContent = isTable ? "Table migrated" : "Structure ready";
  document.querySelector("#parity-status").textContent = isTable ? "Workbook data matched" : "Not tested";
  document.querySelector("#revision-status").textContent = isTable ? "Workbook source preserved" : "Source preserved";
  document.querySelector("#module-action").textContent = isTable ? "Editable table" : "Calculation pending";
  document.querySelector("#empty-title").textContent = isSummary ? `${data.title} summary` : "Ready for workbook logic";
  document.querySelector("#empty-copy").textContent = isSummary
    ? data.description
    : "The navigation and source mapping are in place. Inputs, equations, units, validation, and Excel parity tests will be added in the next migration increment.";
  moduleContent.classList.toggle("is-summary", isSummary);
  shell.classList.toggle("summary-mode", isSummary);
  shell.classList.toggle("table-mode", isTable);
  moduleContent.hidden = isTable || !isSummary;
  tableView.hidden = !isTable;
  if (isTable) {
    tableSearch.value = "";
    renderReferenceTable(data.table);
  } else {
    activeTableId = "";
    renderSummaryLinks(isSummary ? data.title : null);
  }
  document.title = `${data.title} · HVAC Design Workbook`;
}

function renderReferenceTable(tableId, query = tableSearch.value) {
  const table = independentTables.find((candidate) => candidate.id === tableId);
  if (!table) return;
  activeTableId = tableId;
  tableStandard.textContent = table.standard;
  referenceTable.classList.toggle("two-frozen-columns", table.frozenColumns === 2);
  referenceTable.classList.toggle("three-frozen-columns", table.frozenColumns === 3);
  calculatedKey.hidden = ![...(table.calculatedColumns || []), ...(table.lockedColumns || [])].length;
  updateCsvToolbar(table);
  clearCsvComparison();
  clearSelectedEquation();
  const normalized = query.trim().toLowerCase();
  const sourceRows = projectTableRows(table);
  recalculateTable(table, sourceRows);
  const headers = displayedTableHeaders(table);
  if (selectedTableId !== tableId) {
    selectedTableId = "";
    selectedTableRowIndexes.clear();
    selectionAnchorIndex = -1;
  } else {
    selectedTableRowIndexes = new Set([...selectedTableRowIndexes].filter((index) => index < sourceRows.length));
  }
  removeTableRowButton.disabled = selectedTableRowIndexes.size === 0;
  const rows = sourceRows
    .map((row, sourceIndex) => ({ row, sourceIndex }))
    .filter(({ row }) => !normalized || row.some((value) => String(value ?? "").toLowerCase().includes(normalized)));

  if (tableSort.tableId === tableId && tableSort.column >= 0) {
    const { column, direction } = tableSort;
    rows.sort((left, right) => compareTableValues(left.row[column], right.row[column]) * (direction === "asc" ? 1 : -1));
  }

  referenceTable.innerHTML = "";
  referenceTable.setAttribute("aria-multiselectable", "true");
  const head = document.createElement("thead");
  const headerRow = document.createElement("tr");
  headers.forEach((header, columnIndex) => {
    const cell = document.createElement("th");
    cell.scope = "col";
    if ((table.calculatedColumns || []).includes(columnIndex)) cell.classList.add("calculated-header");
    if (table.headerClasses?.[columnIndex]) cell.classList.add(table.headerClasses[columnIndex]);
    const content = document.createElement("div");
    content.className = "table-header-content";

    const label = document.createElement("span");
    label.className = "column-label";
    appendFormattedText(label, header.label);
    if (header.subscript) {
      const subscript = document.createElement("sub");
      subscript.textContent = header.subscript;
      label.appendChild(subscript);
    }
    content.appendChild(label);

    if (header.unit) {
      const unit = document.createElement("span");
      unit.className = "column-unit";
      appendFormattedText(unit, header.unit);
      content.appendChild(unit);
    }

    const sortButton = document.createElement("button");
    sortButton.type = "button";
    sortButton.className = "column-sort-control";
    sortButton.title = `Sort by ${header.label}`;
    sortButton.setAttribute("aria-label", `Sort by ${header.label}`);
    if (tableSort.tableId === tableId && tableSort.column === columnIndex) {
      sortButton.textContent = tableSort.direction === "asc" ? "↑" : "↓";
      cell.setAttribute("aria-sort", tableSort.direction === "asc" ? "ascending" : "descending");
    } else {
      sortButton.textContent = "↕";
    }
    sortButton.addEventListener("click", () => sortReferenceTable(tableId, columnIndex));
    content.appendChild(sortButton);
    cell.appendChild(content);
    headerRow.appendChild(cell);
  });
  head.appendChild(headerRow);

  const dropdownOptionsByColumn = new Map(
    Object.keys(table.dropdownColumns || {}).map((columnIndex) => {
      const index = Number(columnIndex);
      return [index, tableDropdownOptions(table, index)];
    }),
  );

  const body = document.createElement("tbody");
  rows.forEach(({ row, sourceIndex }) => {
    const tableRow = document.createElement("tr");
    tableRow.dataset.sourceIndex = String(sourceIndex);
    tableRow.classList.toggle("selected-row", selectedTableId === tableId && selectedTableRowIndexes.has(sourceIndex));
    tableRow.setAttribute("aria-selected", String(selectedTableId === tableId && selectedTableRowIndexes.has(sourceIndex)));
    tableRow.addEventListener("click", (event) => selectTableRow(tableId, tableRow, sourceIndex, event));
    row.forEach((value, index) => {
      const cell = document.createElement("td");
      if (typeof value === "number") cell.classList.add("numeric-cell");
      if ((table.id === "iesve-tabular-space-data" && index < 2) || (table.identityColumns || []).includes(index)) {
        cell.classList.add("identity-cell");
      }
      const calculated = (table.calculatedColumns || []).includes(index);
      const locked = (table.lockedColumns || []).includes(index);
      if (calculated || locked) {
        cell.textContent = formatTableValue(value, table, index);
        cell.classList.add("calculated-cell");
        if (locked) cell.classList.add("locked-cell");
        cell.tabIndex = 0;
        cell.title = calculated ? "Calculated value; select to view the equation" : "Calculated value";
        cell.setAttribute("aria-label", `Calculated ${table.headers[index].label}, row ${sourceIndex + 1}`);
        if (calculated) {
          cell.addEventListener("click", () => showSelectedEquation(table, cell, index));
          cell.addEventListener("focus", () => showSelectedEquation(table, cell, index));
        } else {
          cell.addEventListener("focus", clearSelectedEquation);
        }
        cell.addEventListener("keydown", (event) => {
          if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(event.key)) {
            event.preventDefault();
            moveToAdjacentCell(cell, event.key, event.shiftKey);
          }
        });
      } else if (table.dropdownColumns?.[index]) {
        cell.classList.add("editable-cell", "dropdown-cell");
        const select = document.createElement("select");
        select.className = "table-cell-select";
        select.setAttribute("aria-label", `Select ${table.headers[index].label}, row ${sourceIndex + 1}`);
        const options = dropdownOptionsByColumn.get(index) || [];
        const currentValue = String(value ?? "");
        const addOption = (optionValue) => {
          const option = document.createElement("option");
          option.value = optionValue;
          option.textContent = optionValue;
          select.appendChild(option);
        };
        addOption("");
        if (currentValue !== "") addOption(currentValue);
        select.value = currentValue;
        select.title = select.value;
        const populateDropdownOptions = () => {
          if (select.dataset.optionsLoaded === "true") return;
          const selectedValue = select.value;
          const optionValues = selectedValue !== "" && !options.includes(selectedValue)
            ? [selectedValue, ...options]
            : options;
          select.replaceChildren();
          addOption("");
          optionValues.forEach(addOption);
          select.value = selectedValue;
          select.dataset.optionsLoaded = "true";
        };
        select.addEventListener("pointerdown", populateDropdownOptions);
        select.addEventListener("focus", () => {
          populateDropdownOptions();
          clearSelectedEquation();
        });
        select.addEventListener("change", () => {
          select.title = select.value;
          updateTableCell(table, sourceRows, sourceIndex, index, select.value);
        });
        select.addEventListener("keydown", (event) => {
          if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(event.key)) {
            event.preventDefault();
            moveToAdjacentCell(cell, event.key, event.shiftKey);
          }
        });
        cell.appendChild(select);
      } else {
        cell.textContent = formatTableValue(value, table, index);
        cell.classList.add("editable-cell");
        cell.contentEditable = "true";
        cell.spellcheck = false;
        cell.setAttribute("aria-label", `Edit ${table.headers[index].label}, row ${sourceIndex + 1}`);
        cell.addEventListener("focus", () => {
          clearSelectedEquation();
        });
        cell.addEventListener("keydown", (event) => {
          if (event.key === "Enter") {
            event.preventDefault();
            cell.blur();
          } else if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(event.key)) {
            event.preventDefault();
            moveToAdjacentCell(cell, event.key, event.shiftKey);
          }
        });
        cell.addEventListener("blur", () => updateTableCell(table, sourceRows, sourceIndex, index, cell.textContent));
      }
      decorateCsvComparisonCell(table, cell, row, sourceIndex, index);
      decorateRoomValidationCell(table, cell, value, index);
      cell.addEventListener("pointerdown", (event) => {
        if (event.button !== 0 || !(table.lockedColumns || []).includes(index)) return;
        cell.focus({ preventScroll: true });
        markSelectedTableCell(cell);
      });
      cell.addEventListener("focusin", () => {
        if ((table.lockedColumns || []).includes(index)) markSelectedTableCell(cell);
        showCsvComparison(table, sourceRows, sourceIndex, index);
      });
      cell.addEventListener("click", () => {
        if ((table.lockedColumns || []).includes(index)) {
          cell.focus({ preventScroll: true });
          markSelectedTableCell(cell);
        }
        showCsvComparison(table, sourceRows, sourceIndex, index);
      });
      tableRow.appendChild(cell);
    });
    body.appendChild(tableRow);
  });

  const widths = calculateColumnWidths(table, headers, sourceRows);
  const columnGroup = document.createElement("colgroup");
  widths.forEach((width) => {
    const column = document.createElement("col");
    column.style.width = `${width}px`;
    columnGroup.appendChild(column);
  });
  referenceTable.append(columnGroup, head, body);
  referenceTable.style.width = `${widths.reduce((total, width) => total + width, 0)}px`;
  referenceTable.style.setProperty("--first-column-width", `${widths[0]}px`);
  referenceTable.style.setProperty("--second-column-width", `${widths[1] || 0}px`);
  tableCount.textContent = rows.length === sourceRows.length
    ? `${sourceRows.length} rows`
    : `${rows.length} of ${sourceRows.length} rows`;
}

function appendFormattedText(element, text) {
  String(text).split(/(ft[23])/gi).forEach((part) => {
    if (/^ft[23]$/i.test(part)) {
      element.append("ft");
      const superscript = document.createElement("sup");
      superscript.textContent = part.slice(-1);
      element.appendChild(superscript);
    } else {
      element.append(part);
    }
  });
}

function ensureProjectTableRows(project, table) {
  if (!project) return table.rows;
  project.independentTables ||= {};
  project.independentTableSchemaVersions ||= {};
  let savedRows = project.independentTables[table.id];
  if (!Array.isArray(savedRows) && table.sourceTableId && Array.isArray(project.independentTables[table.sourceTableId])) {
    const sourceRows = project.independentTables[table.sourceTableId];
    if (sourceRows.every((row) => row.length >= Math.max(...table.sourceColumnIndexes) + 1)) {
      savedRows = sourceRows.map((row) => table.sourceColumnIndexes.map((index) => row[index]));
      project.independentTables[table.id] = savedRows;
      saveProjects();
    }
  }
  if (table.id === "schedule-equipment-sensible-gain" && project.independentTableSchemaVersions[table.id] !== 3) {
    if (Array.isArray(savedRows)) {
      project.independentTables[table.id] = savedRows.map((row) => {
        if (row.length === 6) return [row[0], row[1], row[2] ?? "", row[3] ?? "", "", row[4], row[5]];
        const kilowatts = row[2] !== "" && row[2] !== null && row[2] !== undefined
          ? numberFromTableValue(row[2]) / 1000
          : row[3] ?? "";
        return [row[0], row[1], kilowatts, row[4] ?? "", "", row[5], row[6]];
      });
    } else {
      project.independentTables[table.id] = table.rows.map((row) => [...row]);
    }
    project.independentTableSchemaVersions[table.id] = 3;
    savedRows = project.independentTables[table.id];
    saveProjects();
  }
  if (table.id === "iesve-tabular-space-data" && project.independentTableSchemaVersions[table.id] !== 2) {
    project.independentTables[table.id] = [];
    project.clipboardImports ||= {};
    delete project.clipboardImports[table.id];
    project.independentTableSchemaVersions[table.id] = 2;
    savedRows = project.independentTables[table.id];
    saveProjects();
  }
  if (table.id === "room-zone-loads-report" && project.independentTableSchemaVersions[table.id] !== 1) {
    project.independentTables[table.id] = [];
    project.excelImports ||= {};
    delete project.excelImports[table.id];
    project.independentTableSchemaVersions[table.id] = 1;
    savedRows = project.independentTables[table.id];
    saveProjects();
  }
  if (table.id === "ashrae-90-1-baseline-systems" && Array.isArray(savedRows) && savedRows.some((row) => row.length === 7)) {
    project.independentTables[table.id] = savedRows.map((row) => row.length === 7 ? row.filter((_, index) => index !== 2) : row);
    saveProjects();
  } else if (!Array.isArray(savedRows) || savedRows.some((row) => row.length !== table.columns.length)) {
    project.independentTables[table.id] = table.rows.map((row) => [...row]);
    saveProjects();
  }
  return project.independentTables[table.id];
}

function projectTableRows(table) {
  return ensureProjectTableRows(activeProject(), table);
}

function ensureProjectTableHeaders(project, table) {
  if (!project) return table.headers;
  project.independentTableHeaders ||= {};
  let savedHeaders = project.independentTableHeaders[table.id];
  if (!Array.isArray(savedHeaders) && table.sourceTableId && Array.isArray(project.independentTableHeaders[table.sourceTableId])) {
    const sourceHeaders = project.independentTableHeaders[table.sourceTableId];
    if (sourceHeaders.length >= Math.max(...table.sourceColumnIndexes) + 1) {
      savedHeaders = table.sourceColumnIndexes.map((index) => ({ ...sourceHeaders[index] }));
      project.independentTableHeaders[table.id] = savedHeaders;
      saveProjects();
    }
  }
  if (table.id === "ashrae-90-1-baseline-systems" && Array.isArray(savedHeaders) && savedHeaders.length === 7) {
    project.independentTableHeaders[table.id] = savedHeaders.filter((_, index) => index !== 2);
    saveProjects();
  } else if (!Array.isArray(savedHeaders) || savedHeaders.length !== table.headers.length) {
    project.independentTableHeaders[table.id] = table.headers.map((header) => ({ ...header }));
    saveProjects();
  }
  return project.independentTableHeaders[table.id];
}

function projectTableHeaders(table) {
  return table.headers;
}

function displayedTableHeaders(table) {
  return projectTableHeaders(table);
}

function isPercentageColumn(table, columnIndex) {
  return table.headers[columnIndex]?.unit === "%";
}

function formatTableValue(value, table, columnIndex) {
  if (typeof value === "number" && Number.isFinite(value) && table && Number.isInteger(columnIndex)) {
    if ((table.decimalColumns || []).includes(columnIndex)) return twoDecimalFormatter.format(value);
    if (isPercentageColumn(table, columnIndex)) return `${tableNumberFormatter.format(value * 100)}%`;
    if ([...(table.calculatedColumns || []), ...(table.lockedColumns || [])].includes(columnIndex)
      && String(table.headers[columnIndex]?.unit || "").startsWith("Btu/h")) {
      return calculatedBtuNumberFormatter.format(value);
    }
  }
  return typeof value === "number" && Number.isFinite(value) ? tableNumberFormatter.format(value) : value ?? "";
}

function updateTableCell(table, rows, rowIndex, columnIndex, rawValue) {
  const value = rawValue.trim();
  const percentage = isPercentageColumn(table, columnIndex);
  const normalizedNumber = value.replace(/,/g, "").replace(/\s*%$/, "");
  rows[rowIndex][columnIndex] = table.columnTypes[columnIndex] === "number" && normalizedNumber !== "" && Number.isFinite(Number(normalizedNumber))
    ? Number(normalizedNumber) / (percentage ? 100 : 1)
    : value;
  recalculateTable(table, rows);
  recalculateDependentTables(table);
  saveProjects();
  refreshRenderedTableValues(table, rows);
  updateCsvComparisonDecorations(table, rows);
  if (selectedCsvComparisonContext?.tableId === table.id) {
    const { rowIndex: selectedRow, columnIndex: selectedColumn } = selectedCsvComparisonContext;
    showCsvComparison(table, rows, selectedRow, selectedColumn);
  }
}

function refreshRenderedTableValues(table, rows) {
  referenceTable.querySelectorAll("tbody tr").forEach((tableRow) => {
    const row = rows[Number(tableRow.dataset.sourceIndex)];
    if (!row) return;
    table.headers.forEach((_, columnIndex) => {
      if (!(table.calculatedColumns || []).includes(columnIndex) && !isPercentageColumn(table, columnIndex)) return;
      const cell = tableRow.cells[columnIndex];
      if (!cell) return;
      cell.textContent = formatTableValue(row[columnIndex], table, columnIndex);
      cell.classList.toggle("numeric-cell", typeof row[columnIndex] === "number");
    });
  });
  autoFitRenderedTable(table, displayedTableHeaders(table), rows);
}

function csvImportKey(table) {
  return `${activeProject()?.id || "default"}::${table.id}`;
}

function csvImportState(table) {
  if (!table?.csvHeaders) return null;
  const key = csvImportKey(table);
  if (csvImportsByProject.has(key)) return csvImportsByProject.get(key);
  const saved = activeProject()?.clipboardImports?.[table.id];
  if (!saved || !Array.isArray(saved.sourceRows) || !Array.isArray(saved.mappedColumns) || !saved.importedAt || !saved.templateType) return null;
  const state = {
    importedAt: saved.importedAt,
    mappedColumns: saved.mappedColumns,
    sourceRows: saved.sourceRows,
    templateType: saved.templateType,
  };
  csvImportsByProject.set(key, state);
  return state;
}

function excelImportState(table) {
  if (!table?.excelImport) return null;
  const key = csvImportKey(table);
  if (excelImportsByProject.has(key)) return excelImportsByProject.get(key);
  const saved = activeProject()?.excelImports?.[table.id];
  if (!saved?.importedAt || !saved?.fileName) return null;
  const state = {
    importedAt: saved.importedAt,
    fileName: saved.fileName,
    simulationRunAt: saved.simulationRunAt || "",
    simulationRunPrecision: saved.simulationRunPrecision || "time",
  };
  excelImportsByProject.set(key, state);
  return state;
}

function setCsvFileStatus(message, isError = false) {
  csvFileStatus.textContent = message;
  csvFileStatus.title = message;
  csvFileStatus.classList.toggle("is-error", isError);
}

function updateCsvToolbar(table) {
  const supportsCsv = Array.isArray(table.csvHeaders);
  const supportsExcel = Boolean(table.excelImport);
  templateStatus.classList.toggle("simulation-status", supportsExcel);
  clipboardActions.hidden = !supportsCsv;
  excelActions.hidden = !supportsExcel;
  rowActions.hidden = supportsCsv || supportsExcel;
  csvFileStatus.hidden = !supportsCsv && !supportsExcel;
  templateStatus.hidden = !supportsCsv && !supportsExcel;
  editableKey.hidden = supportsCsv || supportsExcel;
  matchKey.hidden = !supportsCsv;
  differentKey.hidden = !supportsCsv;
  calculatedKey.lastChild.textContent = supportsCsv ? "Not in source" : supportsExcel ? "Imported" : "Calculated";
  if (!supportsCsv && !supportsExcel) {
    copyDataButton.disabled = true;
    setCsvFileStatus("");
    templateStatus.textContent = "";
    return;
  }
  if (supportsExcel) {
    copyDataButton.disabled = true;
    const state = excelImportState(table);
    const importedAt = state ? new Date(state.importedAt) : null;
    const dateText = importedAt && Number.isFinite(importedAt.getTime())
      ? new Intl.DateTimeFormat(undefined, { dateStyle: "medium", timeStyle: "short" }).format(importedAt)
      : "";
    setCsvFileStatus(state ? `Last upload: ${dateText}` : "No Excel imported");
    const simulationRunAt = state?.simulationRunAt ? new Date(state.simulationRunAt) : null;
    const simulationText = simulationRunAt && Number.isFinite(simulationRunAt.getTime())
      ? new Intl.DateTimeFormat(undefined, state.simulationRunPrecision === "date"
        ? { dateStyle: "medium" }
        : { dateStyle: "medium", timeStyle: "medium" }).format(simulationRunAt)
      : "";
    templateStatus.textContent = state ? `Simulation run: ${simulationText || "Not available"}` : "";
    templateStatus.title = state?.fileName || "";
    templateStatus.hidden = !state;
    return;
  }
  const state = csvImportState(table);
  copyDataButton.disabled = !state || !projectTableRows(table).length;
  const importedAt = state ? new Date(state.importedAt) : null;
  const dateText = importedAt && Number.isFinite(importedAt.getTime())
    ? new Intl.DateTimeFormat(undefined, { dateStyle: "medium", timeStyle: "short" }).format(importedAt)
    : "";
  setCsvFileStatus(state ? `Last upload: ${dateText}` : "No data pasted");
  templateStatus.textContent = state ? `${state.templateType} Template` : "";
  templateStatus.hidden = !state;
}

function clearCsvComparison() {
  selectedCsvComparisonContext = null;
  csvComparisonBar.hidden = true;
  csvComparisonBar.classList.remove("is-different", "is-unmapped");
  csvComparisonColumn.textContent = "";
  csvComparisonValue.textContent = "";
  csvComparisonStatus.textContent = "";
}

function tableValueForCsv(table, value, columnIndex) {
  if (isPercentageColumn(table, columnIndex) && typeof value === "number") return value * 100;
  return value ?? "";
}

function csvValuesMatch(table, tableValue, csvValue, columnIndex) {
  const current = tableValueForCsv(table, tableValue, columnIndex);
  const left = String(current ?? "").trim();
  const right = String(csvValue ?? "").trim();
  const leftNumber = Number(left.replace(/,/g, ""));
  const rightNumber = Number(right.replace(/,/g, ""));
  if (left !== "" && right !== "" && Number.isFinite(leftNumber) && Number.isFinite(rightNumber)) {
    return Math.abs(leftNumber - rightNumber) <= 0.001;
  }
  return left.localeCompare(right, undefined, { sensitivity: "base" }) === 0;
}

function csvComparisonForCell(table, row, sourceIndex, columnIndex) {
  const state = csvImportState(table);
  if (!state) return null;
  if (!state.mappedColumns[columnIndex]) {
    return { mapped: false, matches: false, csvValue: "" };
  }
  const csvRow = state.sourceRows[sourceIndex];
  const csvValue = csvRow?.[columnIndex] ?? "";
  return {
    mapped: true,
    linked: Boolean(csvRow),
    matches: Boolean(csvRow) && csvValuesMatch(table, row[columnIndex], csvValue, columnIndex),
    csvValue,
  };
}

function decorateCsvComparisonCell(table, cell, row, sourceIndex, columnIndex) {
  cell.classList.remove("csv-match", "csv-different");
  if (table.id === "iesve-tabular-space-data" && columnIndex < 2) return;
  const comparison = csvComparisonForCell(table, row, sourceIndex, columnIndex);
  if (!comparison?.mapped) return;
  cell.classList.add(comparison.matches ? "csv-match" : "csv-different");
}

function markSelectedTableCell(cell) {
  referenceTable.querySelectorAll(".table-cell-selected").forEach((candidate) => {
    candidate.classList.remove("table-cell-selected");
    candidate.removeAttribute("aria-current");
  });
  cell.classList.add("table-cell-selected");
  cell.setAttribute("aria-current", "true");
}

function decorateRoomValidationCell(table, cell, value, columnIndex) {
  if (table.id !== "room-zone-loads-report" || columnIndex !== 2) return;
  const tabularTable = independentTables.find((candidate) => candidate.id === "iesve-tabular-space-data");
  const tabularRows = tabularTable ? projectTableRows(tabularTable) : [];
  const room = String(value ?? "").trim();
  const exists = tabularRows.some((row) => String(row[1] ?? "").trim().localeCompare(room, undefined, { sensitivity: "base" }) === 0);
  if (exists) return;
  cell.classList.add("room-not-in-tabular");
  cell.title = "Room not in Tabular Space Data";
  cell.setAttribute("aria-label", `${cell.getAttribute("aria-label")}. Room not in Tabular Space Data`);
}

function updateCsvComparisonDecorations(table, rows) {
  if (!table.csvHeaders) return;
  referenceTable.querySelectorAll("tbody tr").forEach((tableRow) => {
    const sourceIndex = Number(tableRow.dataset.sourceIndex);
    const row = rows[sourceIndex];
    if (!row) return;
    [...tableRow.cells].forEach((cell, columnIndex) => {
      decorateCsvComparisonCell(table, cell, row, sourceIndex, columnIndex);
    });
  });
}

function showCsvComparison(table, rows, sourceIndex, columnIndex) {
  const state = csvImportState(table);
  if (!state) {
    clearCsvComparison();
    return;
  }
  const row = rows[sourceIndex];
  if (!row) return;
  selectedCsvComparisonContext = { tableId: table.id, rowIndex: sourceIndex, columnIndex };
  const header = table.headers[columnIndex];
  csvComparisonColumn.textContent = `${header.label}${header.unit ? ` (${header.unit})` : ""}`;
  const comparison = csvComparisonForCell(table, row, sourceIndex, columnIndex);
  csvComparisonBar.hidden = false;
  csvComparisonBar.classList.toggle("is-unmapped", !comparison?.mapped);
  csvComparisonBar.classList.toggle("is-different", Boolean(comparison?.mapped && !comparison.matches));
  if (!comparison?.mapped) {
    csvComparisonValue.textContent = "Not included in the pasted source data";
    csvComparisonStatus.textContent = "Not in source";
  } else {
    csvComparisonValue.textContent = comparison.linked
      ? (String(comparison.csvValue) || "(blank)")
      : "No source row";
    csvComparisonStatus.textContent = comparison.matches ? "Matches source" : "Differs from source";
  }
}

function csvHeaderForTemplate(header, templateType) {
  if (!header || header === "Space ID") return header;
  return header.replace(/ \(Real\)$/, ` (${templateType})`);
}

function detectTemplateType(headers) {
  if (CsvTools.normalizeHeader(headers[0]) !== "space id") {
    throw new Error("The first pasted column must be Space ID.");
  }
  const spaceName = String(headers[1] ?? "").trim();
  const match = spaceName.match(/^Space Name \((Real|Proposed|Baseline)\)$/i);
  if (!match) throw new Error("The second pasted column must be Space Name (Real), Space Name (Proposed), or Space Name (Baseline).");
  const templateType = match[1][0].toUpperCase() + match[1].slice(1).toLowerCase();
  const suffix = ` (${templateType})`.toLowerCase();
  const invalidHeader = headers.slice(1).find((header) => {
    const value = String(header ?? "").trim();
    return value !== "" && !value.toLowerCase().endsWith(suffix);
  });
  if (invalidHeader !== undefined) {
    throw new Error(`Every pasted header after Space ID must end with (${templateType}). Check: ${invalidHeader}`);
  }
  return templateType;
}

function csvColumnMap(table, headers, templateType) {
  const headerIndexes = new Map();
  headers.forEach((header, index) => {
    const normalized = CsvTools.normalizeHeader(header);
    if (normalized && !headerIndexes.has(normalized)) headerIndexes.set(normalized, index);
  });
  return table.csvHeaders.map((header) => header === null
    ? -1
    : (headerIndexes.get(CsvTools.normalizeHeader(csvHeaderForTemplate(header, templateType))) ?? -1));
}

function saveClipboardImport(table, state) {
  const project = activeProject();
  if (!project) return;
  project.clipboardImports ||= {};
  project.clipboardImports[table.id] = {
    importedAt: state.importedAt,
    mappedColumns: state.mappedColumns,
    sourceRows: state.sourceRows,
    templateType: state.templateType,
  };
  saveProjects();
}

function pasteTabularData(text) {
  const table = independentTables.find((candidate) => candidate.id === activeTableId);
  if (!table?.csvHeaders) return;
  const grid = CsvTools.parseClipboard(text);
  const headerRowIndex = grid.findIndex((row) => CsvTools.normalizeHeader(row[0]) === "space id");
  if (headerRowIndex < 0) throw new Error("The pasted header row must begin with Space ID and Space Name.");
  const headers = grid[headerRowIndex];
  const templateType = detectTemplateType(headers);
  const columnMap = csvColumnMap(table, headers, templateType);
  if (columnMap[0] < 0 || columnMap[1] < 0) throw new Error("Space ID or Space Name is missing from the pasted data.");

  const pastedRows = grid.slice(headerRowIndex + 1)
    .filter((row) => row.some((value) => String(value ?? "").trim() !== ""))
    .map((row) => Array.from({ length: headers.length }, (_, index) => row[index] ?? ""))
    .filter((row) => row[columnMap[0]].trim() !== "" || row[columnMap[1]].trim() !== "");
  if (!pastedRows.length) throw new Error("The pasted data does not contain any space rows.");

  const rows = projectTableRows(table);
  const existingBySpaceId = new Map(rows.map((row) => [String(row[0] ?? "").trim().toLowerCase(), row]));
  const sourceRows = pastedRows.map((pastedRow) => table.csvHeaders.map((header, columnIndex) => {
    const pastedColumnIndex = columnMap[columnIndex];
    return header && pastedColumnIndex >= 0 ? pastedRow[pastedColumnIndex] : null;
  }));
  const importedRows = sourceRows.map((sourceRow) => {
    const spaceId = String(sourceRow[0] ?? "").trim();
    const existing = existingBySpaceId.get(spaceId.toLowerCase());
    const row = existing ? [...existing] : Array(table.columns.length).fill("");
    row[0] = spaceId;
    row[1] = String(sourceRow[1] ?? "").trim();
    return row;
  });
  rows.splice(0, rows.length, ...importedRows);
  const state = {
    importedAt: new Date().toISOString(),
    mappedColumns: columnMap.map((columnIndex) => columnIndex >= 0),
    sourceRows,
    templateType,
  };
  csvImportsByProject.set(csvImportKey(table), state);
  saveClipboardImport(table, state);
  selectedTableId = "";
  selectedTableRowIndexes.clear();
  selectionAnchorIndex = -1;
  tableSearch.value = "";
  tableSort = { tableId: table.id, column: -1, direction: "asc" };
  renderReferenceTable(table.id);
}

async function pasteDataFromClipboard() {
  pasteDataButton.disabled = true;
  try {
    if (!navigator.clipboard?.readText || !window.isSecureContext) {
      throw new Error("Direct clipboard access is unavailable. Press Ctrl+V while this table is open.");
    }
    const text = await navigator.clipboard.readText();
    if (!text.trim()) throw new Error("The clipboard does not contain text data.");
    pasteTabularData(text);
  } catch (error) {
    setCsvFileStatus(error.message || "The clipboard data could not be used.", true);
  } finally {
    pasteDataButton.disabled = false;
  }
}

async function writeClipboardText(text) {
  if (navigator.clipboard?.writeText && window.isSecureContext) {
    await navigator.clipboard.writeText(text);
    return;
  }
  const helper = document.createElement("textarea");
  helper.value = text;
  helper.setAttribute("readonly", "");
  helper.style.position = "fixed";
  helper.style.opacity = "0";
  document.body.appendChild(helper);
  helper.select();
  const copied = document.execCommand("copy");
  helper.remove();
  if (!copied) throw new Error("Clipboard access was blocked by the browser.");
}

async function copyTabularData() {
  const table = independentTables.find((candidate) => candidate.id === activeTableId);
  const state = csvImportState(table);
  if (!table?.csvHeaders || !state) return;
  const rows = projectTableRows(table);
  const headers = table.csvHeaders.map((header) => csvHeaderForTemplate(header, state.templateType));
  const values = rows.map((row) => table.headers.map((_, columnIndex) => formatTableValue(row[columnIndex], table, columnIndex)));
  copyDataButton.disabled = true;
  try {
    await writeClipboardText(CsvTools.stringifyClipboard([headers, ...values]));
    copyDataButton.textContent = "Copied to clipboard";
    setTimeout(() => {
      copyDataButton.textContent = "Copy data to clipboard...";
      copyDataButton.disabled = false;
    }, 1200);
  } catch (error) {
    setCsvFileStatus(error.message || "The table could not be copied.", true);
    copyDataButton.disabled = false;
    setTimeout(() => updateCsvToolbar(table), 2500);
  }
}

function normalizedLoadHeader(value) {
  return String(value ?? "").replace(/\s+/g, " ").trim().toLowerCase();
}

function findRoomZoneLoadSheet(workbook) {
  for (const sheet of workbook.sheets) {
    let columns = null;
    const headerRowIndex = sheet.rows.findIndex((row, index) => {
      if (index > 30 || !row) return false;
      const zoneGroup = row.findIndex((value) => normalizedLoadHeader(value) === "zone group");
      const sensibleHeader = row.findIndex((value) => normalizedLoadHeader(value).includes("sensible cooling load"));
      const latent = row.findIndex((value) => normalizedLoadHeader(value).includes("latent cooling load"));
      const heating = row.findIndex((value) => normalizedLoadHeader(value).includes("heating load"));
      if (zoneGroup < 0 || sensibleHeader < 0 || latent < 0 || heating < 0) return false;
      if (normalizedLoadHeader(row[zoneGroup + 1]) !== "zone" || normalizedLoadHeader(row[zoneGroup + 2]) !== "room") return false;
      columns = {
        zoneGroup,
        zone: zoneGroup + 1,
        room: zoneGroup + 2,
        sensible: sensibleHeader + 1,
        latent,
        heating,
      };
      return true;
    });
    if (headerRowIndex >= 0) return { sheet, headerRowIndex, columns };
  }
  throw new Error("The workbook does not contain the expected Room/Zone Loads Report headers.");
}

function loadNumber(value, rowNumber, label) {
  if (value === "" || value === null || value === undefined) return "";
  if (typeof value === "number" && Number.isFinite(value)) return value;
  const number = Number(String(value).replace(/,/g, "").trim());
  if (!Number.isFinite(number)) throw new Error(`${label} is not numeric on Excel row ${rowNumber}.`);
  return number;
}

function roomZoneRowsFromWorkbook(workbook) {
  const { sheet, headerRowIndex, columns } = findRoomZoneLoadSheet(workbook);
  let zoneGroup = "";
  let zone = "";
  const rows = [];
  sheet.rows.slice(headerRowIndex + 2).forEach((sourceRow, offset) => {
    if (!sourceRow) return;
    const sourceGroup = String(sourceRow[columns.zoneGroup] ?? "").trim();
    const sourceZone = String(sourceRow[columns.zone] ?? "").trim();
    const room = String(sourceRow[columns.room] ?? "").trim();
    if (sourceGroup) zoneGroup = sourceGroup;
    if (sourceZone) zone = sourceZone;
    if (!room) return;
    const excelRow = headerRowIndex + 3 + offset;
    rows.push([
      zoneGroup,
      zone,
      room,
      loadNumber(sourceRow[columns.sensible], excelRow, "Sensible cooling load"),
      loadNumber(sourceRow[columns.latent], excelRow, "Latent cooling load"),
      loadNumber(sourceRow[columns.heating], excelRow, "Heating load"),
    ]);
  });
  if (!rows.length) throw new Error("The Room/Zone Loads Report does not contain any room rows beginning at row 10.");
  return rows;
}

async function importRoomZoneLoads(file) {
  const table = independentTables.find((candidate) => candidate.id === activeTableId);
  if (!table?.excelImport || !file) return;
  if (!/\.(xlsx|xlsm)$/i.test(file.name)) {
    setCsvFileStatus("Select an .xlsx or .xlsm Excel workbook.", true);
    importExcelInput.value = "";
    return;
  }
  importExcelButton.disabled = true;
  setCsvFileStatus("Importing Excel workbook...");
  try {
    const workbook = await XlsxReader.read(await file.arrayBuffer(), {
      sheetNamePattern: /ies loads|room.*zone.*loads|loads report/i,
    });
    const { simulationRunAt, simulationRunPrecision } = simulationRunTimeFromWorkbook(workbook, file);
    const importedRows = roomZoneRowsFromWorkbook(workbook);
    const rows = projectTableRows(table);
    rows.splice(0, rows.length, ...importedRows);
    const state = { importedAt: new Date().toISOString(), fileName: file.name, simulationRunAt, simulationRunPrecision };
    excelImportsByProject.set(csvImportKey(table), state);
    const project = activeProject();
    project.excelImports ||= {};
    project.excelImports[table.id] = state;
    selectedTableId = "";
    selectedTableRowIndexes.clear();
    selectionAnchorIndex = -1;
    tableSearch.value = "";
    tableSort = { tableId: table.id, column: -1, direction: "asc" };
    saveProjects();
    renderReferenceTable(table.id);
  } catch (error) {
    setCsvFileStatus(error.message || "The Excel workbook could not be imported.", true);
  } finally {
    importExcelButton.disabled = false;
    importExcelInput.value = "";
  }
}

function simulationRunTimeFromFile(file) {
  const relativePath = String(file.webkitRelativePath || "");
  const nativePath = String(file.path || "").replace(/\\/g, "/");
  const parentFolders = [relativePath, nativePath]
    .map((path) => path.split("/").filter(Boolean).slice(-2, -1)[0] || "")
    .filter(Boolean);
  const fileStem = String(file.name || "").replace(/\.(xlsx|xlsm)$/i, "");
  const match = [...parentFolders, fileStem]
    .map((value) => value.match(/(\d{8})[ _-](\d{6})$/))
    .find(Boolean);
  if (!match) return "";
  const [, date, time] = match;
  const year = Number(date.slice(0, 4));
  const month = Number(date.slice(4, 6));
  const day = Number(date.slice(6, 8));
  const hour = Number(time.slice(0, 2));
  const minute = Number(time.slice(2, 4));
  const second = Number(time.slice(4, 6));
  const value = new Date(year, month - 1, day, hour, minute, second);
  if (value.getFullYear() !== year || value.getMonth() !== month - 1 || value.getDate() !== day
    || value.getHours() !== hour || value.getMinutes() !== minute || value.getSeconds() !== second) {
    throw new Error("The simulation timestamp in the report folder name is not a valid date and time.");
  }
  return value.toISOString();
}

function simulationRunTimeFromWorkbook(workbook, file) {
  const createdAt = new Date(workbook.createdAt || "");
  if (Number.isFinite(createdAt.getTime())) {
    return { simulationRunAt: createdAt.toISOString(), simulationRunPrecision: "time" };
  }
  const reportDate = workbook.sheets?.[0]?.rows?.[3]?.[1];
  const dateMatch = String(reportDate || "").match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (dateMatch) {
    const value = new Date(Number(dateMatch[1]), Number(dateMatch[2]) - 1, Number(dateMatch[3]));
    return { simulationRunAt: value.toISOString(), simulationRunPrecision: "date" };
  }
  const fromPath = simulationRunTimeFromFile(file);
  return { simulationRunAt: fromPath, simulationRunPrecision: fromPath ? "time" : "date" };
}

function tableDropdownOptions(table, columnIndex) {
  const config = table.dropdownColumns?.[columnIndex];
  if (!config) return [];
  const sources = config.sources || [config];
  return [...new Set(sources.flatMap((source) => {
    const sourceTable = independentTables.find((candidate) => candidate.id === source.sourceTableId);
    return sourceTable ? projectTableRows(sourceTable).map((row) => row[source.sourceColumn]) : [];
  })
    .filter((value) => value !== null && value !== undefined && value !== "")
    .map(String))];
}

function tableEquations(table) {
  return { ...(table.equations || {}), ...(equationOverrides[table.id] || {}) };
}

function equationColumnIndex(table, name) {
  const normalize = (value) => String(value || "").replace(/^@/, "").replace(/[^A-Za-z0-9]+/g, "").toLowerCase();
  const normalized = normalize(name);
  let index = table.headers.findIndex((header) => normalize(`${header.label || ""}${header.unit || ""}`) === normalized);
  if (index < 0) index = table.headers.findIndex((header) => normalize(header.label) === normalized);
  if (index < 0) index = (table.columns || []).findIndex((column) => normalize(column) === normalized);
  return index;
}

function tokenizeEquation(expression) {
  const source = String(expression || "").trim().replace(/^=/, "");
  const tokens = [];
  let index = 0;
  while (index < source.length) {
    const character = source[index];
    if (/\s/.test(character)) { index += 1; continue; }
    if (character === "@") {
      const reference = source.slice(index + 1).match(/^[A-Za-z_][A-Za-z0-9_]*/);
      if (!reference) throw new Error("Enter a column reference after @");
      tokens.push({ type: "reference", value: reference[0] });
      index += reference[0].length + 1;
      continue;
    }
    if (character === '"') {
      let value = "";
      index += 1;
      while (index < source.length && source[index] !== '"') value += source[index++];
      if (source[index] !== '"') throw new Error("Missing closing quote");
      tokens.push({ type: "string", value });
      index += 1;
      continue;
    }
    const number = source.slice(index).match(/^(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?/i);
    if (number) {
      tokens.push({ type: "number", value: Number(number[0]) });
      index += number[0].length;
      continue;
    }
    const identifier = source.slice(index).match(/^[A-Za-z_][A-Za-z0-9_]*/);
    if (identifier) {
      tokens.push({ type: "identifier", value: identifier[0].toUpperCase() });
      index += identifier[0].length;
      continue;
    }
    const pair = source.slice(index, index + 2);
    if ([">=", "<=", "<>", "!=", "=="].includes(pair)) {
      tokens.push({ type: "operator", value: pair });
      index += 2;
      continue;
    }
    if ("+-*/&=><(),".includes(character)) {
      tokens.push({ type: ["(", ")", ","].includes(character) ? character : "operator", value: character });
      index += 1;
      continue;
    }
    throw new Error(`Unsupported character: ${character}`);
  }
  tokens.push({ type: "end", value: "" });
  return tokens;
}

function evaluateEquation(expression, table, row) {
  const tokens = tokenizeEquation(expression);
  let position = 0;
  const current = () => tokens[position];
  const take = (type) => {
    if (current().type !== type) throw new Error(`Expected ${type}`);
    return tokens[position++];
  };
  const numeric = (value) => numberFromTableValue(value);
  const functions = {
    IF: (condition, yes, no) => condition ? yes : no,
    N: numeric,
    ROUND: (value, digits = 0) => {
      const factor = 10 ** numeric(digits);
      return Math.round(numeric(value) * factor) / factor;
    },
    MIN: (...values) => Math.min(...values.map(numeric)),
    MAX: (...values) => Math.max(...values.map(numeric)),
    ABS: (value) => Math.abs(numeric(value)),
    LOOKUP: (value) => value === "" || value === null || value === undefined ? "" : table.lookup?.[String(value)] ?? 0,
  };

  function primary() {
    const token = current();
    if (token.type === "number" || token.type === "string") { position += 1; return token.value; }
    if (token.type === "reference") {
      position += 1;
      const column = equationColumnIndex(table, token.value);
      if (column < 0) throw new Error(`Unknown column @${token.value}`);
      return row[column];
    }
    if (token.type === "identifier") {
      position += 1;
      if (token.value === "TRUE") return true;
      if (token.value === "FALSE") return false;
      const fn = functions[token.value];
      if (!fn) throw new Error(`Unsupported function ${token.value}`);
      take("(");
      const args = [];
      if (current().type !== ")") {
        args.push(comparison());
        while (current().type === ",") { position += 1; args.push(comparison()); }
      }
      take(")");
      return fn(...args);
    }
    if (token.type === "(") {
      position += 1;
      const value = comparison();
      take(")");
      return value;
    }
    throw new Error("Expected a value");
  }

  function unary() {
    if (current().type === "operator" && ["+", "-"].includes(current().value)) {
      const operator = tokens[position++].value;
      const value = numeric(unary());
      return operator === "-" ? -value : value;
    }
    return primary();
  }
  function multiply() {
    let value = unary();
    while (current().type === "operator" && ["*", "/"].includes(current().value)) {
      const operator = tokens[position++].value;
      const right = numeric(unary());
      value = operator === "*" ? numeric(value) * right : numeric(value) / right;
    }
    return value;
  }
  function add() {
    let value = multiply();
    while (current().type === "operator" && ["+", "-"].includes(current().value)) {
      const operator = tokens[position++].value;
      const right = numeric(multiply());
      value = operator === "+" ? numeric(value) + right : numeric(value) - right;
    }
    return value;
  }
  function concatenate() {
    let value = add();
    while (current().type === "operator" && current().value === "&") {
      position += 1;
      value = String(value ?? "") + String(add() ?? "");
    }
    return value;
  }
  function comparison() {
    let value = concatenate();
    if (current().type === "operator" && ["=", "==", "!=", "<>", ">", "<", ">=", "<="].includes(current().value)) {
      const operator = tokens[position++].value;
      const right = concatenate();
      if (["=", "=="].includes(operator)) return value == right;
      if (["!=", "<>"].includes(operator)) return value != right;
      if (operator === ">") return value > right;
      if (operator === "<") return value < right;
      if (operator === ">=") return value >= right;
      return value <= right;
    }
    return value;
  }

  const result = comparison();
  if (current().type !== "end") throw new Error("Unexpected text after formula");
  return result;
}

function clearSelectedEquation() {
  formulaBar.hidden = true;
  selectedEquation.value = "";
  selectedEquation.readOnly = true;
  selectedEquationContext = null;
  editEquationButton.hidden = false;
  saveEquationButton.hidden = true;
  cancelEquationButton.hidden = true;
  formulaError.hidden = true;
  formulaError.textContent = "";
  referenceTable.querySelectorAll(".equation-cell-selected").forEach((cell) => cell.classList.remove("equation-cell-selected"));
}

function showSelectedEquation(table, cell, column) {
  referenceTable.querySelectorAll(".equation-cell-selected").forEach((candidate) => candidate.classList.remove("equation-cell-selected"));
  cell.classList.add("equation-cell-selected");
  selectedEquationContext = { table, column };
  selectedEquation.value = equationOverrides[table.id]?.[column]
    || table.displayEquations?.[column]
    || table.equations?.[column]
    || "";
  selectedEquation.readOnly = true;
  editEquationButton.hidden = Boolean(table.readonlyEquations);
  saveEquationButton.hidden = true;
  cancelEquationButton.hidden = true;
  formulaError.hidden = true;
  formulaBar.hidden = false;
}

function beginEquationEdit() {
  if (!selectedEquationContext) return;
  const { table, column } = selectedEquationContext;
  if (table.readonlyEquations) return;
  selectedEquation.value = tableEquations(table)[column] || "=0";
  selectedEquation.readOnly = false;
  editEquationButton.hidden = true;
  saveEquationButton.hidden = false;
  cancelEquationButton.hidden = false;
  formulaError.hidden = true;
  selectedEquation.focus();
  selectedEquation.select();
}

function cancelEquationEdit() {
  if (!selectedEquationContext) return;
  const { table, column } = selectedEquationContext;
  selectedEquation.value = equationOverrides[table.id]?.[column]
    || table.displayEquations?.[column]
    || table.equations?.[column]
    || "";
  selectedEquation.readOnly = true;
  editEquationButton.hidden = false;
  saveEquationButton.hidden = true;
  cancelEquationButton.hidden = true;
  formulaError.hidden = true;
}

function sourceTableForEquation(name) {
  const normalized = String(name).replace(/[^A-Za-z0-9]+/g, "").toLowerCase();
  return independentTables.find((table) => [table.id, table.name, table.standard]
    .some((value) => String(value || "").replace(/[^A-Za-z0-9]+/g, "").toLowerCase() === normalized));
}

function evaluateProjectEquation(expression, table, row, rows, project) {
  const qualifiedSumif = String(expression || "").trim().match(/^=SUMIF\(\s*\[([^\]]+)\]@([A-Za-z_][A-Za-z0-9_]*)\s*,\s*@([A-Za-z_][A-Za-z0-9_]*)\s*,\s*\[([^\]]+)\]@([A-Za-z_][A-Za-z0-9_]*)\s*\)$/i);
  if (qualifiedSumif) {
    const rangeTable = sourceTableForEquation(qualifiedSumif[1]);
    const sumTable = sourceTableForEquation(qualifiedSumif[4]);
    if (!rangeTable || rangeTable !== sumTable) throw new Error("SUMIF range and sum columns must use the same table");
    const rangeColumn = equationColumnIndex(rangeTable, qualifiedSumif[2]);
    const criteriaColumn = equationColumnIndex(table, qualifiedSumif[3]);
    const sumColumn = equationColumnIndex(sumTable, qualifiedSumif[5]);
    if ([rangeColumn, criteriaColumn, sumColumn].some((index) => index < 0)) throw new Error("Unknown SUMIF column reference");
    const sourceRows = rangeTable.id === table.id ? rows : ensureProjectTableRows(project, rangeTable);
    const criteria = row[criteriaColumn];
    return sourceRows.reduce((total, candidate) => candidate[rangeColumn] == criteria ? total + numberFromTableValue(candidate[sumColumn]) : total, 0);
  }
  const sumif = String(expression || "").trim().match(/^=SUMIF\(\s*@([A-Za-z_][A-Za-z0-9_]*)\s*,\s*@([A-Za-z_][A-Za-z0-9_]*)\s*,\s*@([A-Za-z_][A-Za-z0-9_]*)\s*\)$/i);
  if (sumif) {
    const rangeColumn = equationColumnIndex(table, sumif[1]);
    const criteriaColumn = equationColumnIndex(table, sumif[2]);
    const sumColumn = equationColumnIndex(table, sumif[3]);
    if ([rangeColumn, criteriaColumn, sumColumn].some((index) => index < 0)) throw new Error("Unknown SUMIF column reference");
    const criteria = row[criteriaColumn];
    return rows.reduce((total, candidate) => candidate[rangeColumn] == criteria ? total + numberFromTableValue(candidate[sumColumn]) : total, 0);
  }

  const withLookups = String(expression || "").replace(/XLOOKUP\(\s*@([A-Za-z_][A-Za-z0-9_]*)\s*,\s*\[([^\]]+)\]@([A-Za-z_][A-Za-z0-9_]*)\s*,\s*\[([^\]]+)\]@([A-Za-z_][A-Za-z0-9_]*)\s*\)/gi, (reference, currentColumnName, lookupTableName, lookupColumnName, resultTableName, resultColumnName) => {
    const lookupTable = sourceTableForEquation(lookupTableName);
    const resultTable = sourceTableForEquation(resultTableName);
    if (!lookupTable || lookupTable !== resultTable) throw new Error(`Unknown XLOOKUP table in ${reference}`);
    const currentColumn = equationColumnIndex(table, currentColumnName);
    const lookupColumn = equationColumnIndex(lookupTable, lookupColumnName);
    const resultColumn = equationColumnIndex(resultTable, resultColumnName);
    if ([currentColumn, lookupColumn, resultColumn].some((index) => index < 0)) throw new Error(`Unknown XLOOKUP column in ${reference}`);
    const sourceRows = ensureProjectTableRows(project, lookupTable);
    const lookupValue = String(row[currentColumn] ?? "");
    const sourceRow = sourceRows.find((candidate) => String(candidate[lookupColumn] ?? "").localeCompare(lookupValue, undefined, { sensitivity: "base" }) === 0);
    const value = sourceRow?.[resultColumn] ?? 0;
    return typeof value === "number" ? String(value) : JSON.stringify(String(value));
  });

  const resolved = withLookups.replace(/\[([^\]]+)\]@([A-Za-z_][A-Za-z0-9_]*)/g, (reference, tableName, columnName) => {
    const sourceTable = sourceTableForEquation(tableName);
    if (!sourceTable) throw new Error(`Unknown table [${tableName}]`);
    const sourceColumn = equationColumnIndex(sourceTable, columnName);
    const lookupColumn = equationColumnIndex(table, sourceTable.headers[0].label);
    if (sourceColumn < 0 || lookupColumn < 0) throw new Error(`Unknown reference ${reference}`);
    const sourceRows = ensureProjectTableRows(project, sourceTable);
    const lookupValue = String(row[lookupColumn] ?? "");
    const sourceRow = sourceRows.find((candidate) => String(candidate[0] ?? "").localeCompare(lookupValue, undefined, { sensitivity: "base" }) === 0);
    const value = sourceRow?.[sourceColumn] ?? 0;
    return typeof value === "number" ? String(value) : JSON.stringify(String(value));
  });
  return evaluateEquation(resolved, table, row);
}

function recalculateTable(table, rows, project = activeProject()) {
  if (table.preserveImportedValues) return;
  if (table.calculation === "grouped-equipment-schedule") {
    const equipmentTable = independentTables.find((candidate) => candidate.id === "schedule-equipment-sensible-gain");
    if (equipmentTable) recalculateTable(equipmentTable, ensureProjectTableRows(project, equipmentTable), project);
  }

  const equations = tableEquations(table);
  (table.calculatedColumns || []).slice().sort((left, right) => left - right).forEach((column) => {
    rows.forEach((row) => {
      if (row[0] === "" || row[0] === null || row[0] === undefined) {
        row[column] = "";
      } else {
        row[column] = evaluateProjectEquation(equations[column] || "=0", table, row, rows, project);
      }
    });
  });
}

function recalculateDependentTables(table, project = activeProject()) {
  if (table.id !== "schedule-equipment-sensible-gain") return;
  const groupedTable = independentTables.find((candidate) => candidate.id === "schedule-grouped-equipment-sensible-gain");
  if (groupedTable) recalculateTable(groupedTable, ensureProjectTableRows(project, groupedTable), project);
}

function saveEquationEdit() {
  if (!selectedEquationContext) return;
  const { table, column } = selectedEquationContext;
  const equation = selectedEquation.value.trim();
  if (!equation.startsWith("=")) {
    formulaError.textContent = "Equations must begin with =";
    formulaError.hidden = false;
    return;
  }

  const previous = equationOverrides[table.id]?.[column];
  equationOverrides[table.id] ||= {};
  equationOverrides[table.id][column] = equation;
  try {
    if (projects.length) {
      projects.forEach((project) => {
        recalculateTable(table, ensureProjectTableRows(project, table), project);
        recalculateDependentTables(table, project);
      });
    } else {
      recalculateTable(table, table.rows, null);
      recalculateDependentTables(table, null);
    }
  } catch (error) {
    if (previous === undefined) delete equationOverrides[table.id][column];
    else equationOverrides[table.id][column] = previous;
    formulaError.textContent = error.message || "This equation could not be calculated.";
    formulaError.hidden = false;
    return;
  }

  localStorage.setItem(EQUATION_OVERRIDES_KEY, JSON.stringify(equationOverrides));
  saveProjects();
  selectedEquation.readOnly = true;
  editEquationButton.hidden = false;
  saveEquationButton.hidden = true;
  cancelEquationButton.hidden = true;
  formulaError.hidden = true;
  refreshRenderedTableValues(table, projectTableRows(table));
}

function numberFromTableValue(value) {
  const number = Number(String(value ?? "").replace(/,/g, ""));
  return Number.isFinite(number) ? number : 0;
}

function compareTableValues(left, right) {
  const leftBlank = left === null || left === undefined || left === "";
  const rightBlank = right === null || right === undefined || right === "";
  if (leftBlank !== rightBlank) return leftBlank ? 1 : -1;
  if (typeof left === "number" && typeof right === "number") return left - right;
  return String(left ?? "").localeCompare(String(right ?? ""), undefined, { numeric: true, sensitivity: "base" });
}

function calculateColumnWidths(table, headers, rows) {
  const context = document.createElement("canvas").getContext("2d");
  return headers.map((header, index) => {
    context.font = '11px Aptos, "Segoe UI", Arial, sans-serif';
    const contentWidth = rows.reduce((maximum, row) => Math.max(maximum, context.measureText(String(formatTableValue(row[index], table, index))).width), 0);
    const dropdownWidth = table.dropdownColumns?.[index]
      ? tableDropdownOptions(table, index).reduce((maximum, option) => Math.max(maximum, context.measureText(option).width), 0)
      : 0;
    context.font = '700 12px Aptos, "Segoe UI", Arial, sans-serif';
    const labelWidth = String(`${header.label || ""}${header.subscript || ""}`)
      .split(/[\s-]+/)
      .reduce((maximum, part) => Math.max(maximum, context.measureText(part).width), 0) + 54;
    context.font = '650 10px Aptos, "Segoe UI", Arial, sans-serif';
    const unitWidth = context.measureText(header.unit || "").width + 52;
    const numericColumn = table.columnTypes[index] === "number";
    const maximumWidth = table.dropdownColumns?.[index] ? 360 : numericColumn ? 160 : 360;
    const minimumWidth = table.dropdownColumns?.[index] ? 220 : numericColumn ? 96 : 110;
    const desiredContentWidth = Math.max(contentWidth + 24, dropdownWidth + 48);
    return Math.ceil(Math.max(minimumWidth, Math.min(maximumWidth, desiredContentWidth), Math.min(maximumWidth, labelWidth), Math.min(maximumWidth, unitWidth)));
  });
}

function autoFitRenderedTable(table, headers, rows) {
  const widths = calculateColumnWidths(table, headers, rows);
  referenceTable.querySelectorAll("col").forEach((column, index) => {
    column.style.width = `${widths[index]}px`;
  });
  referenceTable.style.width = `${widths.reduce((total, width) => total + width, 0)}px`;
}

function moveToAdjacentCell(cell, key, extendSelection = false) {
  const row = cell.closest("tr");
  const body = row.parentElement;
  const rows = [...body.rows];
  let rowIndex = rows.indexOf(row);
  let columnIndex = cell.cellIndex;
  const rowStep = key === "ArrowUp" ? -1 : key === "ArrowDown" ? 1 : 0;
  const columnStep = key === "ArrowLeft" ? -1 : key === "ArrowRight" ? 1 : 0;

  while (true) {
    rowIndex += rowStep;
    columnIndex += columnStep;
    const targetRow = rows[rowIndex];
    if (!targetRow || columnIndex < 0 || columnIndex >= targetRow.cells.length) return;
    const target = targetRow.cells[columnIndex];
    if (target.classList.contains("editable-cell") || target.classList.contains("calculated-cell")) {
      const focusTarget = target.querySelector("select") || target;
      focusTarget.focus();
      if (target.isContentEditable) {
        const selection = window.getSelection();
        const range = document.createRange();
        range.selectNodeContents(target);
        range.collapse(false);
        selection.removeAllRanges();
        selection.addRange(range);
      }
      const sourceIndex = Number(targetRow.dataset.sourceIndex);
      selectTableRow(activeTableId, targetRow, sourceIndex, {
        shiftKey: extendSelection && rowStep !== 0,
        ctrlKey: false,
        metaKey: false,
      });
      alignCellInTableViewport(target);
      return;
    }
  }
}

function alignCellInTableViewport(cell) {
  const scroll = cell.closest(".table-scroll");
  const row = cell.closest("tr");
  if (!scroll || !row) return;
  const viewport = scroll.getBoundingClientRect();
  const cellRect = cell.getBoundingClientRect();
  const activeTable = independentTables.find((table) => table.id === activeTableId);
  const frozenColumnCount = activeTable?.frozenColumns || 1;
  const frozenRect = row.cells[frozenColumnCount - 1]?.getBoundingClientRect();
  const visibleLeft = cell.cellIndex >= frozenColumnCount && frozenRect ? Math.max(viewport.left, frozenRect.right) : viewport.left;
  const visibleRight = viewport.left + scroll.clientWidth;
  if (cellRect.left < visibleLeft) {
    scroll.scrollLeft = Math.max(0, scroll.scrollLeft - (visibleLeft - cellRect.left));
  } else if (cellRect.right > visibleRight) {
    scroll.scrollLeft += cellRect.right - visibleRight;
  }
}

function sortReferenceTable(tableId, column) {
  tableSort = tableSort.tableId === tableId && tableSort.column === column
    ? { tableId, column, direction: tableSort.direction === "asc" ? "desc" : "asc" }
    : { tableId, column, direction: "asc" };
  renderReferenceTable(tableId);
}

function selectTableRow(tableId, tableRow, sourceIndex, event = {}) {
  if (selectedTableId !== tableId) {
    selectedTableRowIndexes.clear();
    selectionAnchorIndex = -1;
  }
  selectedTableId = tableId;
  const toggle = Boolean(event.ctrlKey || event.metaKey);
  if (event.shiftKey && selectionAnchorIndex >= 0) {
    const visibleRows = [...referenceTable.querySelectorAll("tbody tr")];
    const anchorPosition = visibleRows.findIndex((row) => Number(row.dataset.sourceIndex) === selectionAnchorIndex);
    const targetPosition = visibleRows.indexOf(tableRow);
    if (anchorPosition >= 0 && targetPosition >= 0) {
      selectedTableRowIndexes = new Set(visibleRows
        .slice(Math.min(anchorPosition, targetPosition), Math.max(anchorPosition, targetPosition) + 1)
        .map((row) => Number(row.dataset.sourceIndex)));
    }
  } else if (toggle) {
    if (selectedTableRowIndexes.has(sourceIndex)) selectedTableRowIndexes.delete(sourceIndex);
    else selectedTableRowIndexes.add(sourceIndex);
    selectionAnchorIndex = sourceIndex;
  } else {
    selectedTableRowIndexes = new Set([sourceIndex]);
    selectionAnchorIndex = sourceIndex;
  }
  referenceTable.querySelectorAll("tbody tr").forEach((row) => {
    const selected = selectedTableRowIndexes.has(Number(row.dataset.sourceIndex));
    row.classList.toggle("selected-row", selected);
    row.setAttribute("aria-selected", String(selected));
  });
  removeTableRowButton.disabled = selectedTableRowIndexes.size === 0;
}

function addTableRow() {
  const table = independentTables.find((candidate) => candidate.id === activeTableId);
  if (!table) return;
  const rows = projectTableRows(table);
  const row = Array(table.columns.length).fill("");
  rows.push(row);
  recalculateTable(table, rows);
  recalculateDependentTables(table);
  selectedTableId = table.id;
  selectedTableRowIndexes = new Set([rows.length - 1]);
  selectionAnchorIndex = rows.length - 1;
  saveProjects();
  tableSearch.value = "";
  tableSort = { tableId: table.id, column: -1, direction: "asc" };
  renderReferenceTable(table.id);
  requestAnimationFrame(() => {
    const scroll = document.querySelector(".table-scroll");
    scroll.scrollTop = scroll.scrollHeight;
    referenceTable.querySelector("tbody tr:last-child .editable-cell")?.focus();
  });
}

function removeTableRow() {
  if (!activeTableId || selectedTableId !== activeTableId || selectedTableRowIndexes.size === 0) return;
  const table = independentTables.find((candidate) => candidate.id === activeTableId);
  if (!table) return;
  const rows = projectTableRows(table);
  [...selectedTableRowIndexes].sort((left, right) => right - left).forEach((index) => {
    rows.splice(index, 1);
  });
  recalculateTable(table, rows);
  recalculateDependentTables(table);
  saveProjects();
  selectedTableId = "";
  selectedTableRowIndexes.clear();
  selectionAnchorIndex = -1;
  removeTableRowButton.disabled = true;
  renderReferenceTable(table.id);
}

function renderSummaryLinks(groupName) {
  summaryLinks.innerHTML = "";
  summaryLinks.hidden = !groupName;
  if (!groupName) return;

  const section = modules.find((candidate) => candidate.group === groupName);
  if (!section || !section.items.length) {
    const note = document.createElement("span");
    note.className = "summary-note";
    note.textContent = "Reference tables will be added as their calculation dependencies are migrated.";
    summaryLinks.appendChild(note);
    return;
  }

  section.items.forEach((item) => {
    const button = document.createElement("button");
    button.type = "button";
    button.textContent = item[0];
    button.addEventListener("click", () => {
      search.value = "";
      renderTree();
      const target = document.querySelector(`[data-id="${CSS.escape(slugify(item[0]))}"]`);
      if (target) selectModule(target);
    });
    summaryLinks.appendChild(button);
  });
}

function syncActiveState() {
  const id = location.hash.slice(1) || "space-condition-setpoints";
  document.querySelectorAll("[data-id]").forEach((button) => button.classList.toggle("active", button.dataset.id === id));
  const active = document.querySelector(`[data-id="${CSS.escape(id)}"]`);
  if (active) updateWorkspace(active.dataset);
}

function openBrowser() {
  browser.classList.add("open");
  scrim.classList.add("open");
  document.body.style.overflow = "hidden";
}

function closeBrowser() {
  browser.classList.remove("open");
  scrim.classList.remove("open");
  document.body.style.overflow = "";
}

function createProjectId() {
  return globalThis.crypto?.randomUUID?.() || `project-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function defaultProject() {
  const project = { id: createProjectId() };
  projectFields.forEach((input) => {
    const field = input.dataset.projectField;
    project[field] = localStorage.getItem(`hvac-project-${field}`) ?? input.value ?? "";
  });
  project.number ||= "185021";
  project.name ||= "IESVE 2025 Energy Model";
  return project;
}

function saveProjects() {
  localStorage.setItem(PROJECTS_KEY, JSON.stringify(projects));
  localStorage.setItem(ACTIVE_PROJECT_KEY, activeProjectId);
}

function loadProjects() {
  try {
    const saved = JSON.parse(localStorage.getItem(PROJECTS_KEY) || "null");
    projects = Array.isArray(saved) && saved.length ? saved : [defaultProject()];
  } catch {
    projects = [defaultProject()];
  }

  const savedActiveId = localStorage.getItem(ACTIVE_PROJECT_KEY);
  activeProjectId = projects.some((project) => project.id === savedActiveId) ? savedActiveId : projects[0].id;
  saveProjects();
}

function activeProject() {
  return projects.find((project) => project.id === activeProjectId) || projects[0];
}

function fillProjectFields() {
  const project = activeProject();
  if (!project) return;
  projectFields.forEach((input) => {
    input.value = project[input.dataset.projectField] || "";
  });
}

function renderProjectList(query = projectSearch.value) {
  const normalized = query.trim().toLowerCase();
  const matches = projects.filter((project) =>
    [project.number, project.name, project.client].some((value) => String(value || "").toLowerCase().includes(normalized)),
  );
  projectList.innerHTML = "";

  if (!matches.length) {
    const empty = document.createElement("p");
    empty.className = "project-list-empty";
    empty.textContent = "No projects match this search.";
    projectList.appendChild(empty);
    return;
  }

  matches.forEach((project) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "project-list-item";
    button.classList.toggle("active", project.id === activeProjectId);
    if (project.id === activeProjectId) button.setAttribute("aria-current", "true");

    const number = document.createElement("strong");
    number.textContent = project.number;
    const name = document.createElement("span");
    name.textContent = project.name || "Untitled project";
    button.append(number, name);
    button.addEventListener("click", () => selectProject(project.id));
    projectList.appendChild(button);
  });
}

function selectProject(projectId) {
  if (!projects.some((project) => project.id === projectId)) return;
  activeProjectId = projectId;
  selectedTableId = "";
  selectedTableRowIndexes.clear();
  selectionAnchorIndex = -1;
  saveProjects();
  fillProjectFields();
  renderProjectList();
  syncActiveState();
}

function setProjectSwitcher(open) {
  shell.classList.toggle("projects-open", open);
  projectSwitcherToggle.setAttribute("aria-expanded", String(open));
  projectSwitcherToggle.setAttribute("aria-label", `${open ? "Close" : "Open"} project list`);
  projectSwitcherToggle.title = `${open ? "Close" : "Open"} project list`;
  if (open) {
    renderProjectList();
    projectSearch.focus();
  }
}

function openProjectDialog() {
  projectForm.reset();
  projectDialogError.textContent = "";
  projectDialog.showModal();
  requestAnimationFrame(() => newProjectNumber.focus());
}

function addProject(event) {
  event.preventDefault();
  const number = newProjectNumber.value.trim();
  if (!number) {
    projectDialogError.textContent = "Enter a project number.";
    newProjectNumber.focus();
    return;
  }
  if (projects.some((project) => String(project.number).toLowerCase() === number.toLowerCase())) {
    projectDialogError.textContent = "That project number already exists.";
    newProjectNumber.focus();
    return;
  }

  const project = {
    id: createProjectId(),
    number,
    client: "",
    name: "",
    date: "",
    made_by: "",
    checked_by: "",
    submittal: "",
  };
  projects.push(project);
  projectSearch.value = "";
  projectDialog.close();
  selectProject(project.id);
}

function initializeProjects() {
  loadProjects();
  fillProjectFields();
  renderProjectList();

  projectFields.forEach((input) => {
    if (input.readOnly) return;
    input.addEventListener("input", () => {
      const project = activeProject();
      if (!project) return;
      project[input.dataset.projectField] = input.value;
      saveProjects();
      renderProjectList();
    });
  });
}

search.addEventListener("input", (event) => renderTree(event.target.value));
projectSearch.addEventListener("input", (event) => renderProjectList(event.target.value));
tableSearch.addEventListener("input", (event) => {
  if (activeTableId) renderReferenceTable(activeTableId, event.target.value);
});
addTableRowButton.addEventListener("click", addTableRow);
removeTableRowButton.addEventListener("click", removeTableRow);
pasteDataButton.addEventListener("click", pasteDataFromClipboard);
copyDataButton.addEventListener("click", copyTabularData);
importExcelButton.addEventListener("click", () => importExcelInput.click());
importExcelInput.addEventListener("change", () => {
  importRoomZoneLoads(importExcelInput.files?.[0]);
});
editEquationButton.addEventListener("click", beginEquationEdit);
saveEquationButton.addEventListener("click", saveEquationEdit);
cancelEquationButton.addEventListener("click", cancelEquationEdit);
selectedEquation.addEventListener("keydown", (event) => {
  if (selectedEquation.readOnly) return;
  if (event.key === "Enter") {
    event.preventDefault();
    saveEquationEdit();
  } else if (event.key === "Escape") {
    event.preventDefault();
    event.stopPropagation();
    cancelEquationEdit();
  }
});
projectSwitcherToggle.addEventListener("click", () => setProjectSwitcher(!shell.classList.contains("projects-open")));
document.querySelector("#add-project").addEventListener("click", openProjectDialog);
document.querySelector("#cancel-project").addEventListener("click", () => projectDialog.close());
projectForm.addEventListener("submit", addProject);
document.querySelector("#open-browser").addEventListener("click", openBrowser);
document.querySelector("#close-browser").addEventListener("click", closeBrowser);
scrim.addEventListener("click", closeBrowser);
window.addEventListener("hashchange", syncActiveState);
window.addEventListener("paste", (event) => {
  if (activeTableId !== "iesve-tabular-space-data") return;
  if (event.target instanceof HTMLInputElement || event.target instanceof HTMLTextAreaElement || event.target.isContentEditable) return;
  const text = event.clipboardData?.getData("text/plain") || "";
  if (!text.trim()) return;
  event.preventDefault();
  try {
    pasteTabularData(text);
  } catch (error) {
    setCsvFileStatus(error.message || "The pasted clipboard data could not be used.", true);
  }
});
window.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && !projectDialog.open) {
    closeBrowser();
    setProjectSwitcher(false);
  }
});

initializeProjects();
renderTree();

let loadedVersion = null;
async function checkForUpdates() {
  if (document.visibilityState !== "visible") return;
  try {
    const isLocal = location.hostname === "127.0.0.1" || location.hostname === "localhost";
    const versionUrl = isLocal ? `/version?t=${Date.now()}` : `./version.json?t=${Date.now()}`;
    const response = await fetch(versionUrl, { cache: "no-store" });
    if (!response.ok) return;
    const { version } = await response.json();
    if (loadedVersion !== null && version !== loadedVersion) location.reload();
    loadedVersion = version;
  } catch {
    // The local server may be restarting; the next poll will reconnect.
  }
}

checkForUpdates();
setInterval(checkForUpdates, 1200);
