function thermalTypeKey(value) {
  return String(value ?? "").normalize("NFKC").replace(/&lt;/gi, "<").replace(/&gt;/gi, ">").replace(/[\u200b-\u200d\ufeff]/g, "")
    .replace(/[–—−]/g, "-").replace(/≤|=<|<\s*=/g, "<=").replace(/≥|=>|>\s*=/g, ">=")
    .replace(/\s+/g, " ").trim().toLowerCase().replace(/\s*([:<>=])\s*/g, "$1");
}

const modules = [
  {
    group: "Model Inputs",
    source: "Inputs",
    summary: "Project, site, climate, weather, and building inputs used throughout the workbook.",
    directView: "model-inputs",
    items: [],
  },
  {
    group: "IESVE 2025",
    source: "IES Data → IES Loads",
    summary: "Import, normalize, export, and review the IESVE 2025 space and room-load datasets used by the design workbook.",
    items: [
      ["Thermal Templates", "Thermal · B3:O115", "Map thermal space types to ventilation, occupant heat-gain, and lighting criteria.", "iesve-thermal-template"],
      ["Tabular Space Data", "IES Data · D3:AL201", "Review and edit the IESVE tabular space dataset used by downstream calculations.", "iesve-tabular-space-data"],
      ["Room/Zone Loads Report", "Room/Zone Loads · A10:U149", "Review imported room and zone sensible cooling, latent cooling, and heating loads.", "room-zone-loads-report"],
    ],
  },
  {
    group: "Space Calculations",
    source: "Inputs → IES Loads → Calc",
    summary: "Review space conditions, loads, zoning, ventilation, air balance, latent performance, baseline systems, and monitoring criteria.",
    items: [
      ["Space Condition Setpoints", "Calc · F:N", "Define heating, cooling, humidity, setback, and ventilated temperature-rise criteria.", "calc-space-condition-setpoints"],
      ["Domestic Water Heating", "Calc · O:V", "Calculate occupancy-driven domestic hot-water demand and schedule values.", "calc-dhw"],
      ["Lighting Gains", "Calc · W:AC", "Calculate recommended, manual, proposed, and baseline lighting gains by space.", "calc-lighting-gains"],
      ["People Gains", "Calc · AD:AK", "Calculate recommended occupancy and sensible and latent people gains by space.", "calc-people-gains"],
      ["Equipment Gains", "Calc · AL:AP", "Calculate recommended, manual, and summarized miscellaneous sensible gains by space.", "calc-misc-gains"],
      ["Space Loads", "Calc · AQ:BC", "Consolidate sensible cooling, latent cooling, and heating space loads used for sizing.", "calc-room-loads"],
      ["Equipment Zoning", "Calc · BD:BQ", "Assign ventilation, air-handling, valve, coil, exhaust, cooling, and heating equipment by space.", "calc-equipment-zoning"],
      ["ASHRAE 62.1 Ventilation Requirements", "Calc · CP:DC", "Calculate space ventilation from the linked source tables.", "calc-ventilation-exhaust"],
      ["Exhaust Airflow Requirements", "Calc · Exhaust", "Summarize occupied and unoccupied exhaust requirements by space.", "calc-exhaust-requirements"],
      ["Cooling & Heating Airflow Requirements", "Calc · BR:CO", "Size cooling and heating airflow from equipment leaving air.", "calc-airflow-requirements"],
      ["Pressurization Requirements", "Calc · DI:DY", "Calculate ventilation and exhaust air requirements for pressurization.", "calc-pressurization"],
      ["Air Balancing Requirements", "Calc · Balance", "Calculate transfer air, requested balance, and additional ventilation or relief.", "calc-air-balancing-requirements"],
      ["Peak Airflows", "Calc · Peak", "Size primary cooling, primary heating, and secondary heating airflow.", "calc-peak-airflows"],
      ["Latent Load Calculations", "Calc · EV:FE", "Trace latent gains and moisture loads through the space calculation path.", "calc-latent-loads"],
      ["Space Condition Type and Baseline System", "Calc · FF:FQ", "Map space condition types to the workbook baseline-system logic.", "calc-condition-baseline"],
      ["CO₂ Monitoring Calculation", "Calc · FR:FY", "Identify spaces subject to carbon-dioxide monitoring criteria.", "calc-co2-monitoring"],
    ],
  },
  {
    group: "Air Balances",
    source: "Equipment Zoning → Air Balancing Requirements → Peak Airflows",
    summary: "Review supply, ventilation, exhaust, return, and pressurization balances by system type.",
    items: [
      ["DOAS & Zone Recirculation Air Balance", "Calc · DOAS / Zone", "Balance dedicated outdoor air and room recirculation equipment.", "calc-doas-zone-air-balance"],
      ["AHU with 100% OA Air Balance", "Calc · 100% OA", "Review maximum, occupied minimum, and unoccupied minimum outdoor-air supply and exhaust.", "calc-ahu-oa-air-balance"],
      ["AHU with Economizing Air Balance", "Calc · Economizing", "Review supply, ventilation, return, and exhaust for economizing systems.", "calc-ahu-economizing-air-balance"],
      ["DOAS & AHU Air Balance", "Calc · DOAS / AHU", "Balance dedicated outdoor air and central recirculating air handlers.", "calc-doas-ahu-air-balance"],
    ],
  },
  {
    group: "Selected Space Requirements",
    source: "Lighting → Misc → Exhaust → Transfer",
    summary: "Manage supplemental fixture, equipment, exhaust, and transfer-air requirements for the selected spaces that need added detail.",
    items: [
      ["Detailed Lighting Gains", "Lighting · E13:M235", "Add detailed lighting gains for selected spaces where fixture-level inputs are required.", "selected-lighting-loads"],
      ["Detailed Equipment Gains", "Misc · E9:R72", "Add detailed plug, process, and equipment sensible gains for selected spaces.", "selected-misc-loads"],
      ["General Exhaust Requirements", "Exhaust · T9:AI89", "Apply general exhaust criteria to selected spaces.", "selected-general-exhaust"],
      ["Exhaust Equipment Requirements", "Exhaust · AK9:AT84", "Define equipment-specific exhaust demands and operating relationships.", "selected-exhaust-equipment"],
      ["Transfer Air", "Transfer · L9:V110", "Define transfer-air paths and quantities for selected spaces.", "selected-transfer-air"],
    ],
  },
  {
    group: "Airside Equipment",
    source: "Airside → Psych",
    summary: "Review airside design settings, coil duties, and psychrometric processes for the project systems.",
    items: [
      ["Settings", "Airside · B:AG", "Review equipment quantities, ventilation features, effectiveness values, and associated equipment.", "airside-settings"],
      ["Preheat Coils", "Airside · AH:AT", "Size and review preheat coil performance at workbook design conditions.", "airside-preheat"],
      ["Ventilation Cooling Coils", "Airside · AU:CM", "Size and review ventilation cooling coils.", "airside-ventilation-cooling"],
      ["Room Air Cooling Coils", "Airside · AU:CM", "Size and review room air cooling coils.", "airside-room-cooling"],
      ["In Unit Reheat Coils", "Airside · CN:DG", "Size and review reheat within ventilation units.", "airside-in-unit-reheat"],
      ["Downstream Reheat Coils", "Airside · CN:DG", "Size and review downstream reheat coils.", "airside-downstream-reheat"],
      ["Room Air Heating Coils", "Airside · CN:DG", "Size and review room air heating coils.", "airside-room-heating"],
      ["Psychrometric Chart", "Psych", "Visualize air-state processes used in the airside calculations."],
    ],
  },
  {
    group: "Plantside Equipment",
    source: "Plantside",
    summary: "Review the calculated cooling and heating plant design duties and equipment selections.",
    items: [
      ["Cooling Plants", "Plantside · B9:U12", "Review cooling plant equipment selections and calculated design duties.", "cooling-plant"],
      ["Heating Plants", "Plantside · B9:U12", "Review heating plant equipment selections and calculated design duties.", "heating-plant"],
    ],
  },
  {
    group: "Energy",
    source: "Energy",
    summary: "Compare proposed energy performance with the four baseline building rotations used by the workbook.",
    items: [
      ["Proposed", "Energy", "Review the proposed building energy-model results."],
      ["Baseline 000deg", "Energy", "Review the baseline energy-model results at the 000-degree rotation."],
      ["Baseline 090deg", "Energy", "Review the baseline energy-model results at the 090-degree rotation."],
      ["Baseline 180deg", "Energy", "Review the baseline energy-model results at the 180-degree rotation."],
      ["Baseline 270deg", "Energy", "Review the baseline energy-model results at the 270-degree rotation."],
    ],
  },
  {
    group: "Independent Tables",
    source: "Lighting → Misc → Exhaust → ASHRAE → Water",
    summary: "Browse project schedules and the independent ASHRAE and water-property reference tables used by the workbook calculations.",
    items: [
      ["Lighting Schedule", "Lighting · O13:Q62", "Lighting fixture types, wattages, and calculated project quantities.", "schedule-lighting"],
      ["Equipment Sensible Gain Schedule", "Misc · T9:Z56", "Equipment load inputs in Btu/h and kW with efficiency, space allocation, calculated heat gain, and project quantities.", "schedule-equipment-sensible-gain"],
      ["Grouped Equipment Sensible Gain Schedule", "Misc · AA9:AE11", "Reusable equipment groups with calculated row heat gain and group heat-gain totals.", "schedule-grouped-equipment-sensible-gain"],
      ["General Exhaust Schedule", "Exhaust · AV9:BE40", "General exhaust criteria by fixture, area, and occupied or unoccupied air-change basis.", "schedule-general-exhaust"],
      ["Exhaust Equipment Schedule", "Exhaust · AV9:BE40", "Equipment-specific exhaust airflow for on and off operating conditions.", "schedule-exhaust-equipment"],
      ["Ventilation Rates", "ASHRAE · B4:E83", "Outdoor-air rates and default occupant density by occupancy category.", "ashrae-62-1-ventilation"],
      ["Pressurization Types", "Calc · PR", "Map pressurization type to relief-to-ventilation percentage.", "schedule-pressurization-types"],
      ["Baseline Lighting Power Density", "ASHRAE · G4:H108", "Baseline lighting power density by common space type.", "ashrae-90-1-baseline-lighting"],
      ["Proposed Lighting Power Density", "ASHRAE · J4:K103", "Lighting power allowances by common space type.", "ashrae-90-1-proposed-lighting"],
      ["Occupant Heat Gain", "ASHRAE · M4:O17", "Sensible and latent heat gain per person by activity level.", "ashrae-fundamentals-people-heat"],
      ["Climate Zones and Baseline Systems", "ASHRAE · T4:AD23", "Climate-zone descriptions and baseline system assignments by building type and size.", "ashrae-climate-zones"],
      ["Baseline System Descriptions", "ASHRAE · AL4:AR18", "Baseline HVAC system types, fan control, cooling source, and heating source.", "ashrae-90-1-baseline-systems"],
      ["FEMP SHW Calculator Table", "ASHRAE · AT4:AU11", "Estimated service hot-water use by building type for domestic hot-water calculations.", "femp-shw-calculator"],
      ["Ethylene Glycol Density", "Water · B9:L38", "Density of aqueous ethylene glycol solutions by temperature and volume concentration.", "water-ethylene-density"],
      ["Propylene Glycol Density", "Water · O9:Y38", "Density of inhibited aqueous propylene glycol solutions by temperature and volume concentration.", "water-propylene-density"],
      ["Ethylene Glycol Specific Heat", "Water · B44:L73", "Specific heat of aqueous ethylene glycol solutions by temperature and volume concentration.", "water-ethylene-specific-heat"],
      ["Propylene Glycol Specific Heat", "Water · O44:Y73", "Specific heat of aqueous propylene glycol solutions by temperature and volume concentration.", "water-propylene-specific-heat"],
      ["Water Properties at 14.700 psia", "Water · B89:O113", "Thermophysical properties of water at atmospheric pressure.", "water-nist-properties"],
    ],
  },
];

const independentTables = [
  ...(globalThis.INDEPENDENT_TABLES || []),
  ...(globalThis.CALC_SECTION_TABLES || []),
  ...(globalThis.SELECTED_REQUIREMENT_TABLES || []),
  ...(globalThis.AIRSIDE_PLANTSIDE_TABLES || []),
].filter((table) => table.id !== "calc-general");

if (!independentTables.some((table) => table.id === "femp-shw-calculator")) {
  independentTables.push({
    id: "femp-shw-calculator",
    name: "FEMP SHW Calculator Table",
    standard: "FEMP SHW Calculator Table",
    description: "Estimated hot-water use from the workbook FEMP SHW Calculator table.",
    sheet: "ASHRAE",
    range: "AT4:AU11",
    headers: [
      { label: "Building Type" },
      { label: "Estimated Hot Water Use", unit: "gal/person-day" },
    ],
    columns: ["Building Type", "Estimated Hot Water Use (gal/person-day)"],
    columnTypes: ["text", "number"],
    lockedColumns: [0, 1],
    identityColumns: [0],
    rows: [
      ["House", 15.8],
      ["Hotel/Motel", 20],
      ["Hospital", 52],
      ["Office", 1.1],
      ["Restaurant", 2.4],
      ["School", 0.5],
      ["School with Showers", 1.9],
    ],
  });
}

const fempConsumptionSchedules = {
  "House": "BLDG: Health - DHW", "Hotel/Motel": "BLDG: Health - DHW", "Hospital": "BLDG: Health - DHW",
  "Office": "BLDG: Office - DHW", "Restaurant": "BLDG: Restaurant - DHW",
  "School": "BLDG: School - DHW", "School with Showers": "BLDG: School - DHW",
};
{
  const femp = independentTables.find((table) => table.id === "femp-shw-calculator");
  femp.headers.push({ label: "Consumption Schedule" }); femp.columns.push("Consumption Schedule");
  femp.columnTypes.push("text"); femp.rows = femp.rows.map((row) => [...row.slice(0, 2), ""]);
  femp.scheduleCalculation = true; femp.autoColumns = [2]; femp.scheduleColumn = 2;
}

if (!independentTables.some((table) => table.id === "project-inputs")) {
  independentTables.unshift({
    id: "project-inputs",
    name: "Model Inputs",
    standard: "Model Inputs",
    description: "Project site, climate, weather, and building inputs from the workbook Inputs sheet.",
    sheet: "Inputs",
    range: "B19:I54",
    headers: [
      { label: "Category" }, { label: "Input" }, { label: "Value" }, { label: "Unit" },
    ],
    columns: ["Category", "Input", "Value", "Unit"],
    columnTypes: ["text", "text", "text", "text"],
    lockedColumns: [0, 1, 3],
    cellDropdownRows: { 16: { 2: ["TRUE"] } },
    frozenColumns: 2,
    identityColumns: [0, 1],
    schemaVersion: 2,
    rows: [
      ["Site", "Location", "Forest Park, Georgia", ""],
      ["Site", "Country / State", "Curry County, NM", ""],
      ["Site", "Latitude", "33.63 N", "degrees"],
      ["Site", "Longitude", "84.442 W", "degrees"],
      ["Site", "Climate Zone", "3A", ""],
      ["Site", "Elevation", 1011, "ft"],
      ["Site", "Simulation Weather Data", "USA_GA_Atlanta-Hartsfield-Jackson_Intl.AP_722190_TMY3.epw", ""],
      ["Cooling Design", "Percentile", 0.01, "%"],
      ["Cooling Design", "Dry Bulb", 91.6, "°F"],
      ["Cooling Design", "Wet Bulb", 73.6, "°F"],
      ["Dehumidification", "Dry Bulb", 80.4, "°F"],
      ["Dehumidification", "Humidity Ratio", 128.5, "gr/lb"],
      ["Heating Design", "Percentile", 0.99, "%"],
      ["Heating Design", "Dry Bulb", 27.1, "°F"],
      ["Humidification", "Dry Bulb", 32.1, "°F"],
      ["Humidification", "Humidity Ratio", 9.2, "gr/lb"],
      ["Building", "UFC", "TRUE", ""],
      ["Building", "Infiltration at 0.3 in. pressure differential", 0.25, "CFM/ft2"],
    ],
  });
}

configureCalcSectionTables();
configureWorkbookPressurizationTables();
configureSystemAirBalanceTables();
configureSelectedRequirementTables();
configureThermalTemplate();
configureAirsideTables();
configureCoilViews();
configurePlantTables();
independentTables.filter((table) => table.id.startsWith("calc-")).forEach((table) => {
  table.fixedRows = true;
  table.spaceColumn = ["calc-equipment-zoning", "calc-exhaust-requirements"].includes(table.id) ? 2
    : ["calc-ventilation-exhaust", "calc-pressurization", "calc-air-balancing-requirements"].includes(table.id) ? 1 : 0;
});

independentTables.filter((table) => table.id.startsWith("selected-")).forEach((table) => {
  table.spaceColumn = table.id === "selected-transfer-air" ? 4 : 0;
});

function configurePlantTables() {
  const source = independentTables.find((table) => table.id === "plantside-equipment");
  if (!source || independentTables.some((table) => table.id === "cooling-plant")) return;
  const add = (id, name, cooling) => {
    const headers = [
      { label: "Plant" }, { label: "# of Equipment Served" },
      { label: "Sum of Peaks", unit: "MBH" }, { label: "Diversity Factor", unit: "%" },
      { label: "Block Load", unit: "MBH" }, { label: "Safety Factor", unit: "%" },
      { label: "Load", unit: "MBH" },
      ...(cooling ? [{ label: "Load", unit: "ton" }] : []),
      { label: "Quantity" }, { label: "% of Plant Load", unit: "%" },
      { label: "Capacity", unit: "MBH" },
      ...(cooling ? [{ label: "Capacity", unit: "ton" }] : []),
      { label: "Water" }, { label: "EWT", unit: "°F" }, { label: "LWT", unit: "°F" },
      { label: "Glycol", unit: "%" }, { label: "Cp", unit: "Btu/lb-°F" },
      { label: "Density", unit: "lb/gal" }, { label: "Block Flow", unit: "GPM" },
      { label: "Equipment Flow", unit: "GPM" },
    ];
    const equipmentStart = cooling ? 8 : 7;
    const waterStart = cooling ? 12 : 10;
    const rows = source.rows.filter((row) => cooling ? Boolean(row[19]) : !row[19]).map((row) => [
      row[0], "", "", row[2] ?? "", row[3] ?? "", row[4] ?? "", row[5] ?? "",
      ...(cooling ? [row[6] ?? ""] : []), "", "", row[9] ?? "",
      ...(cooling ? [row[10] ?? ""] : []), "TRUE", row[11] ?? "", row[12] ?? "",
      row[14] ?? 0, row[15] ?? "", row[16] ?? "", row[17] ?? "", row[18] ?? "",
    ]);
    const calculatedColumns = [1, 2, 6, ...(cooling ? [7] : []), equipmentStart + 2,
      ...(cooling ? [equipmentStart + 3] : []), waterStart + 4, waterStart + 5, waterStart + 6, waterStart + 7];
    const displayEquations = {
      1: '=SUM([Coils]@Quantity serving @Plant)',
      2: '=SUM([Coils]@Capacity * [Settings]@Quantity for @Plant)',
      3: '=100%', 5: '=10%',
      6: '=IF(@Block Load="",MIN(@Sum of Peaks,@Sum of Peaks*@Diversity Factor),MIN(@Sum of Peaks,@Sum of Peaks*@Diversity Factor,@Block Load*(1+@Safety Factor)))',
      8: '=1', 9: '=100%',
      [equipmentStart + 2]: '=IFERROR(@Load * @% of Plant Load / @Quantity, 0)',
      [waterStart]: '=TRUE', [waterStart + 1]: cooling ? '=57°F' : '=110°F',
      [waterStart + 2]: cooling ? '=42°F' : '=140°F', [waterStart + 3]: '=0%',
      [waterStart + 4]: '=INTERPOLATE([Water or Propylene Glycol Properties]@Cp, AVERAGE(@EWT, @LWT), @Glycol)',
      [waterStart + 5]: '=INTERPOLATE([Water or Propylene Glycol Properties]@Density, AVERAGE(@EWT, @LWT), @Glycol)',
      [waterStart + 6]: '=@Load * 1000 / (60 * @Cp * @Density * ABS(@LWT - @EWT))',
      [waterStart + 7]: '=@Capacity * 1000 / (60 * @Cp * @Density * ABS(@LWT - @EWT))',
    };
    if (cooling) {
      displayEquations[7] = '=@Load [MBH] / 12';
      displayEquations[equipmentStart + 3] = '=@Capacity [MBH] / 12';
    } else {
      displayEquations[equipmentStart] = '=1';
      displayEquations[equipmentStart + 1] = '=100%';
    }
    const table = {
      id, name, standard: name, description: `${name} design duties and water flow.`, sheet: "Plantside", range: source.range,
      headers, columns: headers.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`),
      columnTypes: headers.map((_, index) => index === 0 || index === waterStart ? "text" : "number"),
      rows, calculatedColumns, lockedColumns: [], identityColumns: [], frozenColumns: 2,
      headerGroups: [
        { label: "General", start: 0, span: 2, className: "space-group-header" },
        { label: "Load", start: 2, span: cooling ? 6 : 5, className: cooling ? "sensible-cooling-header" : "heating-load-header" },
        { label: "Equipment", start: equipmentStart, span: cooling ? 4 : 3, className: cooling ? "sensible-cooling-header" : "heating-load-header" },
        { label: "Water", start: waterStart, span: 8, className: cooling ? "sensible-cooling-header" : "heating-load-header" },
      ],
      headerClasses: Object.fromEntries(headers.map((_, index) => [index, index < 2 ? "space-group-header" : cooling ? "sensible-cooling-header" : "heating-load-header"])),
      sectionStartColumns: [2, equipmentStart, waterStart],
      dropdownColumns: { [waterStart]: { options: ["TRUE", "FALSE"] } },
      autoColumns: [3, 5, equipmentStart, equipmentStart + 1, waterStart, waterStart + 1, waterStart + 2, waterStart + 3],
      decimalColumns: [2, 6, equipmentStart + 2, ...(cooling ? [7, equipmentStart + 3] : []), waterStart + 5],
      fourDecimalColumns: [waterStart + 4],
      zeroDecimalColumns: [1, 3, 5, equipmentStart, equipmentStart + 1, waterStart + 3, waterStart + 1, waterStart + 2, waterStart + 6, waterStart + 7],
      displayEquations, preserveImportedValues: false, readonlyEquations: true,
      plantCalculation: cooling ? "cooling" : "heating", schemaVersion: 5,
    };
    independentTables.push(table);
  };
  add("cooling-plant", "Cooling Plants", true);
  add("heating-plant", "Heating Plants", false);
}

function configureCoilViews() {
  const clone = (sourceId, id, name, calculation, description) => {
    const source = independentTables.find((table) => table.id === sourceId);
    if (!source || independentTables.some((table) => table.id === id)) return;
    independentTables.push({ ...source, id, name, standard: name, description, rows: [], sourceRows: { ...(source.sourceRows || {}) }, displayEquations: { ...source.displayEquations }, coilCalculation: calculation, schemaVersion: 1 });
  };
  clone("airside-cooling", "airside-ventilation-cooling", "Ventilation Cooling Coils", "ventilation-cooling", "Cooling coils serving ventilation equipment with active ventilation cooling.");
  clone("airside-cooling", "airside-room-cooling", "Room Air Cooling Coils", "room-air-cooling", "Cooling coils serving room-air equipment.");
  clone("airside-heating", "airside-in-unit-reheat", "In Unit Reheat Coils", "in-unit-reheat", "Reheat coils located within ventilation equipment.");
  clone("airside-heating", "airside-downstream-reheat", "Downstream Reheat Coils", "downstream-reheat", "Reheat coils serving equipment downstream of central ventilation.");
  clone("airside-heating", "airside-room-heating", "Room Air Heating Coils", "room-air-heating", "Room-air heating equipment coils.");
  const hide = (id, hidden) => {
    const table = independentTables.find((candidate) => candidate.id === id);
    if (!table) return;
    table.hiddenColumns = hidden;
    table.headerGroups = table.headerGroups.filter((group) => group.label === "Capacity and Plant" || !hidden.includes(group.start));
  };
  const sequence = (start, end) => Array.from({ length: end - start + 1 }, (_, index) => start + index);
  hide("airside-ventilation-cooling", sequence(33, 41));
  hide("airside-room-cooling", [...sequence(1, 8), ...sequence(15, 32), ...sequence(42, 44)]);
  hide("airside-in-unit-reheat", [...sequence(11, 16), 17]);
  hide("airside-downstream-reheat", [...sequence(11, 16), 17]);
  hide("airside-room-heating", [...sequence(5, 10), 17]);
  for (const id of ["airside-ventilation-cooling", "airside-room-cooling", "airside-in-unit-reheat", "airside-downstream-reheat", "airside-room-heating"]) {
    const table = independentTables.find((candidate) => candidate.id === id);
    if (!table) continue;
    table.headerGroups = table.headerGroups.map((group) => ({ ...group, label: group.label.replaceAll("Conditions", "Condition") }));
    const plantGroup = table.headerGroups.find((group) => group.label === "Capacity and Plant");
    if (plantGroup) {
      plantGroup.label = "Plant";
      plantGroup.start = table.coilCalculation === "room-air-cooling" ? 45 : table.coilCalculation === "ventilation-cooling" ? 42 : 18;
      plantGroup.span = table.coilCalculation === "room-air-cooling" ? 2 : table.coilCalculation === "ventilation-cooling" ? 5 : 2;
    }
    if (table.coilCalculation === "room-air-cooling") {
      const leaving = table.headerGroups.find((group) => group.start === 9);
      if (leaving) leaving.label = "Leaving Condition";
    }
    if (["in-unit-reheat", "downstream-reheat"].includes(table.coilCalculation)) {
      const entering = table.headerGroups.find((group) => group.start === 5);
      if (entering) entering.label = "Entering Condition - Upstream Coil Leaving";
    }
    table.sectionStartColumns = table.headerGroups.slice(2).map((group) => group.start);
    const cooling = table.coilCalculation.endsWith("cooling");
    const flow = cooling ? 46 : 19;
    const capacity = cooling ? "@Total Capacity" : table.coilCalculation === "room-air-heating" ? "@[Entering Air Condition - Room Air]@Capacity" : "@[Entering Condition - Upstream Coil Leaving]@Capacity";
    table.displayEquations[flow] = `=COILFLOW(${capacity}, @Plant Serving Coil)`;
    if (cooling) {
      for (const [sensible, latent] of [[21, 22], [30, 31], [39, 40]]) {
        table.displayEquations[sensible] = '=@Leaving Sensible Constant * @Airflow * (@Entering DB - @Leaving DB) / 1000';
        table.displayEquations[latent] = '=@Leaving Latent Constant * @Airflow * (@Entering HR - @Leaving HR) / 1000';
      }
      const sensible = table.coilCalculation === "ventilation-cooling"
        ? '=IF([Cooling Design Day]@Capacity >= [Dehumidification Design Day]@Capacity, [Cooling Design Day]@Sensible, [Dehumidification Design Day]@Sensible)'
        : '=[Cooling Room Air]@Sensible';
      const latent = table.coilCalculation === "ventilation-cooling"
        ? '=IF([Cooling Design Day]@Capacity >= [Dehumidification Design Day]@Capacity, [Cooling Design Day]@Latent, [Dehumidification Design Day]@Latent)'
        : '=[Cooling Room Air]@Latent';
      table.displayEquations[42] = sensible;
      table.displayEquations[43] = latent;
      table.displayEquations[44] = table.coilCalculation === "ventilation-cooling"
        ? '=MAX([Cooling Design Day]@Capacity, [Dehumidification Design Day]@Capacity)'
        : '=[Cooling Room Air]@Capacity';
    } else {
      const roomAir = table.coilCalculation === "room-air-heating";
      table.displayEquations[2] = roomAir ? '=[Entering Air Condition - Room Air]@Hum-Ratio' : '=IF(@Ventilation,[Model Inputs]@Heating Design Hum-Ratio,[Room Air Cooling Coil]@Leaving Hum-Ratio)';
      table.displayEquations[5] = '=MIN(IF(@Preheat,[Preheat Coil]@Leaving Dry-Bulb,IF(@Ventilation,[Model Inputs]@Heating Design Dry-Bulb,"")),IF(@Ventilation,[Ventilation Cooling Coil]@Dehumidification Dry-Bulb,[Room Air Cooling Coil]@Leaving Dry-Bulb))';
      table.displayEquations[6] = roomAir ? '=[Entering Air Condition - Room Air]@Hum-Ratio' : '=IF(@Ventilation,[Model Inputs]@Heating Design Hum-Ratio,[Room Air Cooling Coil]@Leaving Hum-Ratio)';
      table.displayEquations[7] = '=WETBULB(@Entering Dry-Bulb, @Entering Hum-Ratio)';
      table.displayEquations[8] = '=SENSIBLECONSTANT(@Entering Dry-Bulb, @Entering Hum-Ratio)';
      table.displayEquations[9] = '=[Upstream Cooling or Preheat Coil]@Airflow';
      table.displayEquations[10] = '=@Leaving Sensible Constant * @Airflow * (@Leaving DB - @Entering DB) / 1000';
      table.displayEquations[16] = '=@Leaving Sensible Constant * @Airflow * (@Leaving DB - @Entering DB) / 1000';
      table.displayEquations[17] = roomAir ? '=[Entering Air Condition - Room Air]@Capacity' : '=[Entering Condition - Upstream Coil Leaving]@Capacity';
    }
  }
}

function configureNetworkZoningTable() {
  if (independentTables.some((table) => table.id === "calc-equipment-zoning-table")) return;
  const source = independentTables.find((table) => table.id === "calc-equipment-zoning");
  if (!source) return;
  const headers = [
    { label: "Zone Group" }, { label: "Zone" }, { label: "Space" },
    { label: "Ventilation System" }, { label: "SA System" }, { label: "EA System" }, { label: "RA System" },
    { label: "Supply Air Valve" }, { label: "Reheat Coil" }, { label: "Cooling Equipment" },
    { label: "Heating Equipment" }, { label: "General Exhaust Valve" },
  ];
  independentTables.push({
    id: "calc-equipment-zoning-table", name: "Equipment Zoning Table", standard: "Equipment Zoning Table",
    description: "Space-level equipment assignments derived from building-system connections and zone-group nodes.", sheet: "Calc", range: "BD:BQ",
    headers, columns: headers.map((header) => header.label), columnTypes: Array(headers.length).fill("text"),
    rows: source.rows.map((row) => [row[0] ?? "", row[1] ?? "", row[2] ?? "", ...Array(9).fill("")]),
    calculatedColumns: [3, 4, 5, 6], lockedColumns: [0, 1, 2], identityColumns: [0, 1, 2], frozenColumns: 3,
    autoColumns: [7, 8, 9, 10, 11], fixedRows: true, readonlyEquations: true, preserveImportedValues: false,
    headerClasses: { 3: "ventilation-header", 4: "supply-air-header", 5: "exhaust-header", 6: "return-air-header" },
    sectionStartColumns: [3, 7], columnWidthOverrides: { 3: 125, 4: 115, 5: 115, 6: 115, 7: 115, 8: 105, 9: 120, 10: 120, 11: 130 },
    displayEquations: {
      3: '=[Equipment Zoning]@Ventilation System', 4: '=[Equipment Zoning]@SA / OA System',
      5: '=[Equipment Zoning]@Exhaust System', 6: '=[Equipment Zoning]@RA / EA System',
    },
    zoningNetworkTableCalculation: true, schemaVersion: 1,
  });
}

function configureAirsideTables() {
  const settings = independentTables.find((table) => table.id === "airside-settings");
  if (!settings) return;
  const sourceIndexes = [0, 1, 2, 3, 4, 6, 8, 9, 29, 31, 10, 12, 17, 18, 19, 20, 21, 22, 23, 24, 26, 27];
  settings.sourceRows = Object.fromEntries(Object.entries(settings.sourceRows || {}).map(([equipment, row]) => {
    const migrated = sourceIndexes.map((index) => row[index] ?? "");
    [4, 5, 6, 7, 8, 9, 10].forEach((index) => { migrated[index] = ""; });
    return [equipment, migrated];
  }));
  settings.headers = [
    { label: "Equipment" },
    { label: "Rooms Served" },
    { label: "Design Airflow", unit: "CFM" },
    { label: "Unit Type" },
    { label: "Quantity" },
    { label: "Load Percentage", unit: "%" },
    { label: "Preheat Coil" },
    { label: "Ventilation Cooling Coil" },
    { label: "Ez Cool", subscripts: [1] },
    { label: "Ez Heat", subscripts: [1] },
    { label: "Energy" },
    { label: "Associated Equipment" },
    { label: "Ventilation Unocc Minimum", unit: "CFM" },
    { label: "Ventilation Occ Minimum", unit: "CFM" },
    { label: "Cooling Peak", unit: "CFM" },
    { label: "IESVE Cooling Block", unit: "CFM" },
    { label: "Cooling Design", unit: "CFM" },
    { label: "Heating Peak", unit: "CFM" },
    { label: "IESVE Heating Block", unit: "CFM" },
    { label: "Heating Design", unit: "CFM" },
    { label: "Exhaust Minimum", unit: "CFM" },
    { label: "Exhaust Airflow", unit: "CFM" },
  ];
  settings.columns = settings.headers.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`);
  settings.hiddenColumns = Array.from({ length: settings.headers.length - 12 }, (_, index) => index + 12);
  settings.columnTypes = ["text", "number", "number", "text", "number", "number", "text", "text", "number", "number", "text", "text", ...Array(10).fill("number")];
  settings.calculatedColumns = [1, 2, 11, 12, 13, 14, 16, 17, 19, 20, 21];
  settings.lockedColumns = [0, 1, 2];
  settings.identityColumns = [0, 1, 2];
  settings.frozenColumns = 3;
  settings.dropdownColumns = {
    6: { options: ["", "TRUE"] },
    7: { options: ["", "TRUE"] },
    10: { options: ["ER", "Econ"] },
  };
  settings.autoColumns = [4, 5, 6, 7, 8, 9];
  settings.zeroDecimalColumns = [1, 2, 4, 5, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21];
  settings.oneDecimalColumns = [8, 9];
  settings.columnWidthOverrides = { 6: 96, 7: 112, 8: 76, 9: 76, 10: 96 };
  settings.headerClasses = { 6: "heating-load-header", 7: "sensible-cooling-header" };
  settings.displayEquations = {
    1: '=LET(spaces,VSTACK(FILTER([Equipment Zoning]@Space,EQUIPMENTMATCH(@Equipment),""),FILTER([Exhaust Equipment Requirements]@Space,[Exhaust Equipment Requirements]@Exhaust Equipment=@Equipment,""),FILTER([Exhaust Equipment Requirements]@Space,[Exhaust Equipment Requirements]@Exhaust Valve=@Equipment,"")),COUNTA(UNIQUE(FILTER(spaces,spaces<>""))))',
    2: '=IF(@Cooling Design<>0, @Cooling Design, @Exhaust Airflow)',
    5: '=1 / @Quantity',
    8: '=IF(@Ventilation Cooling Coil="TRUE", 1.0, "")',
    9: '=IF(@Ventilation Cooling Coil="TRUE", 1.0, "")',
    11: '=EQUIPMENTASSOCIATION(@Equipment, [Equipment Zoning])',
    12: '=SUMIF([Equipment Zoning]@Equipment, @Equipment, [Space Calculations]@Ventilation Unocc Minimum)',
    13: '=SUMIF([Equipment Zoning]@Equipment, @Equipment, [Space Calculations]@Ventilation Occ Minimum)',
    14: '=SUMIF([Equipment Zoning]@Cooling Equipment, @Equipment, [Space Calculations]@Cooling Airflow)',
    15: '=[IESVE Room Loads]@Cooling Block Airflow',
    16: '=IF(@IESVE Cooling Block="", @Cooling Peak * @Load Percentage, @IESVE Cooling Block * @Load Percentage)',
    17: '=SUMIF([Equipment Zoning]@Heating Equipment, @Equipment, [Space Calculations]@Heating Airflow)',
    18: '=[IESVE Room Loads]@Heating Block Airflow',
    19: '=IF(@IESVE Heating Block="", @Heating Peak * @Load Percentage, @IESVE Heating Block * @Load Percentage)',
    20: '=XLOOKUP(@Equipment, [Exhaust Requirements]@Equipment, [Exhaust Requirements]@Minimum Airflow) * @Load Percentage',
    21: '=XLOOKUP(@Equipment, [Exhaust Requirements]@Equipment, [Exhaust Requirements]@Airflow) * @Load Percentage',
  };
  settings.airsideSettingsCalculation = true;
  settings.preserveImportedValues = true;
  settings.readonlyEquations = true;

  const configureCoil = (id, colorClass, groups, renamedHeaders = {}) => {
    const table = independentTables.find((candidate) => candidate.id === id);
    if (!table) return;
    Object.entries(renamedHeaders).forEach(([column, label]) => { table.headers[Number(column)].label = label; });
    table.headers.forEach((header) => {
      header.label = header.label
        .replace(/^Outside Air Heating - /, "")
        .replace(/^Outside Air Cooling - /, "")
        .replace(/^Outside Air Dehumidification - /, "")
        .replace(/^Room Air Cooling - /, "")
        .replace(/^Preheat Coil Air Leaving - /, "")
        .replace(/^Room Air Heating - /, "");
    });
    table.columns = table.headers.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`);
    table.headerGroups = [{ label: "General", start: 0, span: 1, className: "space-group-header" }, ...groups.map((group) => ({ ...group, className: colorClass }))];
    table.headerClasses = Object.fromEntries(table.headers.map((_, index) => [index, index === 0 ? "space-group-header" : colorClass]));
    table.sectionStartColumns = groups.slice(1).map((group) => group.start);
    table.zeroDecimalColumns = table.headers.map((header, index) => header.unit === "CFM" || /Latent Constant/i.test(header.label) ? index : -1).filter((index) => index >= 0);
    table.oneDecimalColumns = table.headers.map((header, index) => header.unit === "°F" ? index : -1).filter((index) => index >= 0);
    table.threeDecimalColumns = table.headers.map((header, index) => /Sensible Constant/i.test(header.label) ? index : -1).filter((index) => index >= 0);
    table.fiveDecimalColumns = table.headers.map((header, index) => header.unit === "lb/lb" ? index : -1).filter((index) => index >= 0);
    table.decimalColumns = table.headers.map((header, index) => ["MBH", "GPM"].includes(header.unit) ? index : -1).filter((index) => index >= 0);
  };
  configureCoil("airside-preheat", "heating-load-header", [
    { label: "Leaving Conditions", start: 1, span: 5 },
    { label: "Outside Air Heating", start: 6, span: 6 },
    { label: "Plant", start: 12, span: 2 },
  ], { 6: "Sensible Constant" });
  configureCoil("airside-cooling", "sensible-cooling-header", [
    { label: "Leaving Conditions", start: 1, span: 13 },
    { label: "Outside Air Cooling", start: 14, span: 9 },
    { label: "Outside Air Dehumidification", start: 23, span: 9 },
    { label: "Room Air Cooling", start: 32, span: 9 },
    { label: "Capacity and Plant", start: 41, span: 5 },
  ], { 14: "Sensible Constant", 15: "Latent Constant", 23: "Sensible Constant", 24: "Latent Constant", 32: "Sensible Constant", 33: "Latent Constant" });
  configureCoil("airside-heating", "heating-load-header", [
    { label: "Leaving Conditions", start: 1, span: 5 },
    { label: "Preheat Coil Air Leaving", start: 6, span: 6 },
    { label: "Room Air Heating", start: 12, span: 6 },
    { label: "Capacity and Plant", start: 18, span: 3 },
  ], { 6: "Sensible Constant", 12: "Sensible Constant" });
  configureDetailedCoilTables();
}

function configureDetailedCoilTables() {
  const configure = ({ id, headers, transform, calculatedColumns, groups, colorClass, autoColumns = [], editableColumns = [] }) => {
    const table = independentTables.find((candidate) => candidate.id === id);
    if (!table) return;
    table.sourceRows = Object.fromEntries(Object.entries(table.sourceRows || {}).map(([equipment, row]) => [equipment, transform(row)]));
    table.headers = headers;
    table.columns = headers.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`);
    table.columnTypes = headers.map((header, index) => index === 0 || ["Equipment", "Plant Serving Coil"].includes(header.label) ? "text" : "number");
    table.calculatedColumns = calculatedColumns;
    table.lockedColumns = [0];
    table.identityColumns = [0];
    table.frozenColumns = 1;
    table.headerGroups = [{ label: "General", start: 0, span: 1, className: "space-group-header" }, ...groups.map((group) => ({ ...group, className: colorClass }))];
    table.headerClasses = Object.fromEntries(headers.map((_, index) => [index, index ? colorClass : "space-group-header"]));
    table.sectionStartColumns = groups.slice(1).map((group) => group.start);
    table.autoColumns = autoColumns;
    table.zeroDecimalColumns = headers.map((header, index) => header.unit === "CFM" || /Latent Constant/i.test(header.label) ? index : -1).filter((index) => index >= 0);
    table.oneDecimalColumns = headers.map((header, index) => header.unit === "°F" ? index : -1).filter((index) => index >= 0);
    table.threeDecimalColumns = headers.map((header, index) => /Sensible Constant/i.test(header.label) ? index : -1).filter((index) => index >= 0);
    table.fiveDecimalColumns = headers.map((header, index) => header.unit === "lb/lb" ? index : -1).filter((index) => index >= 0);
    table.decimalColumns = headers.map((header, index) => ["MBH", "GPM"].includes(header.unit) ? index : -1).filter((index) => index >= 0);
    table.preserveImportedValues = false;
    table.readonlyEquations = true;
    table.coilCalculation = id.replace("airside-", "");
    table.schemaVersion = undefined;
  };

  configure({
    id: "airside-preheat",
    headers: [
      { label: "Equipment" },
      { label: "Dry-Bulb", unit: "°F" }, { label: "Hum-Ratio", unit: "lb/lb" }, { label: "Wet-Bulb", unit: "°F" }, { label: "Sensible Constant" },
      { label: "Dry-Bulb", unit: "°F" }, { label: "Hum-Ratio", unit: "lb/lb" }, { label: "Wet-Bulb", unit: "°F" }, { label: "Sensible Constant" },
      { label: "Airflow", unit: "CFM" }, { label: "Capacity", unit: "MBH" }, { label: "Plant Serving Coil" }, { label: "Flow Rate", unit: "GPM" },
    ],
    transform: (row) => [row[0], "", row[3], row[4], row[5], row[7], row[8], row[9], row[6], row[10], row[11], row[12], row[13]],
    calculatedColumns: [2, 3, 4, 5, 6, 7, 8, 10, 12],
    autoColumns: [1],
    editableColumns: [1, 9, 11, 12],
    colorClass: "heating-load-header",
    groups: [
      { label: "Leaving Condition", start: 1, span: 4 },
      { label: "Entering Condition - Heating Design Day", start: 5, span: 6 },
      { label: "Plant", start: 11, span: 2 },
    ],
  });

  configure({
    id: "airside-cooling",
    headers: [
      { label: "Equipment" },
      { label: "Unaccounted Latent", unit: "MBH" }, { label: "Required Dry-Bulb", unit: "°F" }, { label: "Min Dry-Bulb", unit: "°F" }, { label: "Rel-Hum", unit: "%" }, { label: "Hum-Ratio", unit: "lb/lb" }, { label: "Wet-Bulb", unit: "°F" }, { label: "Sensible Constant" }, { label: "Latent Constant" },
      { label: "Max Dry-Bulb", unit: "°F" }, { label: "Rel-Hum", unit: "%" }, { label: "Hum-Ratio", unit: "lb/lb" }, { label: "Wet-Bulb", unit: "°F" }, { label: "Sensible Constant" }, { label: "Latent Constant" },
      { label: "Dry-Bulb", unit: "°F" }, { label: "Hum-Ratio", unit: "lb/lb" }, { label: "Wet-Bulb", unit: "°F" }, { label: "Sensible Constant" }, { label: "Latent Constant" }, { label: "Airflow", unit: "CFM" }, { label: "Sensible", unit: "MBH" }, { label: "Latent", unit: "MBH" }, { label: "Capacity", unit: "MBH" },
      { label: "Dry-Bulb", unit: "°F" }, { label: "Hum-Ratio", unit: "lb/lb" }, { label: "Wet-Bulb", unit: "°F" }, { label: "Sensible Constant" }, { label: "Latent Constant" }, { label: "Airflow", unit: "CFM" }, { label: "Sensible", unit: "MBH" }, { label: "Latent", unit: "MBH" }, { label: "Capacity", unit: "MBH" },
      { label: "Dry-Bulb", unit: "°F" }, { label: "Hum-Ratio", unit: "lb/lb" }, { label: "Wet-Bulb", unit: "°F" }, { label: "Sensible Constant" }, { label: "Latent Constant" }, { label: "Airflow", unit: "CFM" }, { label: "Sensible", unit: "MBH" }, { label: "Latent", unit: "MBH" }, { label: "Capacity", unit: "MBH" },
      { label: "Sensible Capacity", unit: "MBH" }, { label: "Latent Capacity", unit: "MBH" }, { label: "Total Capacity", unit: "MBH" }, { label: "Plant Serving Coil" }, { label: "Flow Rate", unit: "GPM" },
    ],
    transform: (row) => [
      row[0], row[3], row[4], "", "", "", "", "", "", "", "", "", "", "", "",
      row[16], row[17], row[18], row[14], row[15], row[19], row[20], row[21], row[22],
      row[25], row[26], row[27], row[23], row[24], row[28], row[29], row[30], row[31],
      row[34], row[35], row[36], row[32], row[33], row[37], row[38], row[39], row[40],
      row[41], row[42], row[43], row[44], row[45],
    ],
    calculatedColumns: [5, 6, 7, 8, 11, 12, 13, 14, ...Array.from({ length: 30 }, (_, index) => index + 15).filter((index) => ![20, 29, 38, 45].includes(index)), 46],
    autoColumns: [3, 4, 9, 10],
    editableColumns: [1, 2, 3, 4, 9, 10, 20, 29, 38, 45],
    colorClass: "sensible-cooling-header",
    groups: [
      { label: "Leaving Conditions - Dehumidification Mode", start: 1, span: 8 },
      { label: "Leaving Conditions - Normal Operation", start: 9, span: 6 },
      { label: "Entering Conditions - Cooling Design Day", start: 15, span: 9 },
      { label: "Entering Conditions - Dehumidification Design Day", start: 24, span: 9 },
      { label: "Entering Conditions - Cooling Room Air", start: 33, span: 9 },
      { label: "Capacity and Plant", start: 42, span: 5 },
    ],
  });

  configure({
    id: "airside-heating",
    headers: [
      { label: "Equipment" },
      { label: "Dry-Bulb", unit: "°F" }, { label: "Hum-Ratio", unit: "lb/lb" }, { label: "Wet-Bulb", unit: "°F" }, { label: "Sensible Constant" },
      { label: "Dry-Bulb", unit: "°F" }, { label: "Hum-Ratio", unit: "lb/lb" }, { label: "Wet-Bulb", unit: "°F" }, { label: "Sensible Constant" }, { label: "Airflow", unit: "CFM" }, { label: "Capacity", unit: "MBH" },
      { label: "Dry-Bulb", unit: "°F" }, { label: "Hum-Ratio", unit: "lb/lb" }, { label: "Wet-Bulb", unit: "°F" }, { label: "Sensible Constant" }, { label: "Airflow", unit: "CFM" }, { label: "Capacity", unit: "MBH" },
      { label: "Total Capacity", unit: "MBH" }, { label: "Plant Serving Coil" }, { label: "Flow Rate", unit: "GPM" },
    ],
    transform: (row) => [row[0], "", row[3], row[4], row[5], row[7], row[8], row[9], row[6], row[10], row[11], row[13], row[14], row[15], row[12], row[16], row[17], row[18], row[19], row[20]],
    calculatedColumns: [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 19],
    autoColumns: [1],
    editableColumns: [1, 18],
    colorClass: "heating-load-header",
    groups: [
      { label: "Leaving Conditions", start: 1, span: 4 },
      { label: "Entering Air Condition - Preheat Coil Air Leaving", start: 5, span: 6 },
      { label: "Entering Air Condition - Room Air", start: 11, span: 6 },
      { label: "Capacity and Plant", start: 17, span: 3 },
    ],
  });

  const preheat = independentTables.find((table) => table.id === "airside-preheat");
  if (preheat) {
    preheat.headerLinks = { 11: "heating-plant" };
    preheat.dropdownColumns = { 11: { sourceTableId: "heating-plant", sourceColumn: 0 } };
    preheat.displayEquations = {
    2: '=[Entering Conditions - Heating Design Day]@Hum-Ratio',
    3: '=WETBULB(@Dry-Bulb, @Hum-Ratio, [Model Inputs]@Barometric Pressure)',
    4: '=SENSIBLECONSTANT(@Dry-Bulb, @Hum-Ratio, [Model Inputs]@Barometric Pressure)',
    5: '=[Model Inputs]@Heating Design Dry-Bulb', 6: '=[Model Inputs]@Heating Design Hum-Ratio',
    7: '=WETBULB(@Dry-Bulb, @Hum-Ratio, [Model Inputs]@Barometric Pressure)',
    8: '=SENSIBLECONSTANT(@Dry-Bulb, @Hum-Ratio, [Model Inputs]@Barometric Pressure)',
    10: '=@Leaving Sensible Constant * @Airflow * (@Leaving DB - @Entering DB) / 1000',
    12: '=COILFLOW(@Capacity, @Plant Serving Coil)',
    };
  }
  const cooling = independentTables.find((table) => table.id === "airside-cooling");
  if (cooling) {
    cooling.headerLinks = { 45: "cooling-plant" };
    cooling.dropdownColumns = { 45: { sourceTableId: "cooling-plant", sourceColumn: 0 } };
    cooling.displayEquations = {
    5: '=HUMIDITYRATIO(@Dry-Bulb, @Rel-Hum, [Model Inputs]@Barometric Pressure)', 6: '=WETBULB(@Dry-Bulb, @Hum-Ratio)',
    7: '=SENSIBLECONSTANT(@Dry-Bulb, @Hum-Ratio)', 8: '=LATENTCONSTANT(@Dry-Bulb, @Hum-Ratio)',
    11: '=HUMIDITYRATIO(@Dry-Bulb, @Rel-Hum, [Model Inputs]@Barometric Pressure)', 12: '=WETBULB(@Dry-Bulb, @Hum-Ratio)',
    13: '=SENSIBLECONSTANT(@Dry-Bulb, @Hum-Ratio)', 14: '=LATENTCONSTANT(@Dry-Bulb, @Hum-Ratio)',
    15: '=[Model Inputs]@Cooling Design Dry-Bulb', 16: '=[Model Inputs]@Cooling Design Hum-Ratio',
    24: '=[Model Inputs]@Dehumidification Design Dry-Bulb', 25: '=[Model Inputs]@Dehumidification Design Hum-Ratio',
    33: '=AVERAGE([Space Condition Setpoints]@Cooling Setpoint for rooms served)',
    34: '=AVERAGE([Space Condition Setpoints]@Cooling Hum-Ratio for rooms served)',
    42: '=SUM(@Sensible across entering conditions)', 43: '=SUM(@Latent across entering conditions)', 44: '=@Sensible Capacity + @Latent Capacity',
    46: '=COILFLOW(@Total Capacity, @Plant Serving Coil)',
    };
  }
  [17, 26, 35].forEach((column) => { if (cooling) cooling.displayEquations[column] = '=WETBULB(@Dry-Bulb, @Hum-Ratio)'; });
  [18, 27, 36].forEach((column) => { if (cooling) cooling.displayEquations[column] = '=SENSIBLECONSTANT(@Dry-Bulb, @Hum-Ratio)'; });
  [19, 28, 37].forEach((column) => { if (cooling) cooling.displayEquations[column] = '=LATENTCONSTANT(@Dry-Bulb, @Hum-Ratio)'; });
  [[21, "Sensible"], [22, "Latent"], [23, "Capacity"], [30, "Sensible"], [31, "Latent"], [32, "Capacity"], [39, "Sensible"], [40, "Latent"], [41, "Capacity"]].forEach(([column, name]) => {
    if (cooling) cooling.displayEquations[column] = name === "Capacity" ? '=@Sensible + @Latent' : name === "Sensible"
      ? '=@Leaving Sensible Constant * @Airflow * (@Entering DB - @Leaving DB) / 1000'
      : '=@Leaving Latent Constant * @Airflow * (@Entering HR - @Leaving HR) / 1000';
  });
  const heating = independentTables.find((table) => table.id === "airside-heating");
  if (heating) {
    heating.headerLinks = { 18: "heating-plant" };
    heating.dropdownColumns = { 18: { sourceTableId: "heating-plant", sourceColumn: 0 } };
    heating.displayEquations = {
    2: '=AVERAGE([Space Condition Setpoints]@Heating Hum-Ratio for rooms served)', 3: '=WETBULB(@Dry-Bulb, @Hum-Ratio)',
    4: '=SENSIBLECONSTANT(@Dry-Bulb, @Hum-Ratio)',
    5: '=XLOOKUP(@Upstream Ventilation Equipment, [Preheat Coils]@Equipment, [Preheat Coils]@Leaving Dry-Bulb)',
    6: '=[Preheat Coils]@Leaving Hum-Ratio', 7: '=[Preheat Coils]@Leaving Wet-Bulb', 8: '=[Preheat Coils]@Leaving Sensible Constant',
    11: '=AVERAGE([Space Condition Setpoints]@Heating Setpoint for rooms served)',
    12: '=AVERAGE([Space Condition Setpoints]@Heating Hum-Ratio for rooms served)', 13: '=WETBULB(@Dry-Bulb, @Hum-Ratio)',
    14: '=SENSIBLECONSTANT(@Dry-Bulb, @Hum-Ratio)', 16: '=@Leaving Sensible Constant * @Airflow * (@Leaving DB - @Entering DB) / 1000',
    17: '=SUM(@Capacity)', 19: '=COILFLOW(@Total Capacity, @Plant Serving Coil)',
    };
  }
}

function configureThermalTemplate() {
  const thermal = independentTables.find((table) => table.id === "iesve-thermal-template");
  if (!thermal) return;
  thermal.name = "Thermal Templates";
  thermal.standard = "Thermal Templates";
  thermal.headers[10] = { ...thermal.headers[10], label: "Baseline LPD" };
  thermal.headers[12] = { ...thermal.headers[12], label: "Proposed LPD" };
  thermal.headers[1] = { ...thermal.headers[1], label: "# of Spaces" };
  thermal.columns[10] = "Baseline LPD (W/ft2)";
  thermal.columns[12] = "Proposed LPD (W/ft2)";
  thermal.headerLinks = {
    2: "ashrae-62-1-ventilation",
    6: "ashrae-fundamentals-people-heat",
    9: "ashrae-90-1-baseline-lighting",
    11: "ashrae-90-1-proposed-lighting",
  };
  thermal.equations ||= {};
  thermal.displayEquations ||= {};
  thermal.equations[1] = "=COUNTIF([Space Condition Setpoints]@Type,@Type)";
  thermal.displayEquations[1] = "=COUNTIF([Space Condition Setpoints]@Type, @Type)";
  thermal.lockedColumns = (thermal.lockedColumns || []).filter((column) => column !== 0 && column !== 1);
  thermal.calculatedColumns = [...new Set([...(thermal.calculatedColumns || []), 1])];
  thermal.identityColumns = (thermal.identityColumns || []).filter((column) => column !== 0 && column !== 1);
  thermal.frozenColumns = 2;
  thermal.thermalTemplateCalculation = true; thermal.spaceColumn = 0;
  thermal.thermalDefaultRows = thermal.rows.map((row) => [...row]);
  thermal.thermalLookupColumns = [3, 4, 5, 7, 8, 10, 12];
  thermal.calculatedColumns = [1, ...thermal.thermalLookupColumns];
  thermal.displayZeroAsDash = true; thermal.zeroDashStartColumn = 0;
  thermal.readonlyEquations = true;
  thermal.autoColumns = Array.from({ length: thermal.columns.length - 2 }, (_, index) => index + 2);
  thermal.headers.forEach((header, index) => { header.calculated = thermal.calculatedColumns.includes(index); });
}

function configureSelectedRequirementTables() {
  const lighting = independentTables.find((table) => table.id === "selected-lighting-loads");
  if (lighting) {
    lighting.name = "Detailed Lighting Gains";
    lighting.standard = "Detailed Lighting Gains";
    const retained = [0, 1, 2, 3, 6];
    lighting.headers = [
      { label: "Space Name" }, { label: "Light" }, { label: "Quantity" },
      { label: "Wattage", unit: "W" }, { label: "Gain", unit: "W" },
    ];
    lighting.columns = lighting.headers.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`);
    lighting.columnTypes = ["text", "text", "number", "number", "number"];
    lighting.rows = lighting.rows.map((row) => retained.map((index) => row[index]));
    lighting.calculatedColumns = [3, 4];
    lighting.displayEquations = {
      3: "=XLOOKUP(@Light, [Lighting Schedule]@Light, [Lighting Schedule]@Wattage)",
      4: "=@Quantity * @Wattage",
    };
    lighting.equations = {
      3: "=XLOOKUP(@Light, [Lighting Schedule]@Light, [Lighting Schedule]@Wattage)",
      4: "=@Quantity*@Wattage",
    };
    lighting.preserveImportedValues = false;
    lighting.readonlyEquations = false;
    lighting.dropdownColumns = {
      0: { sourceTableId: "calc-space-condition-setpoints", sourceColumn: 0 },
      1: { sourceTableId: "schedule-lighting", sourceColumn: 0 },
    };
    lighting.headerLinks = { 1: "schedule-lighting" };
    lighting.schemaVersion = 4;
  }
  const misc = independentTables.find((table) => table.id === "selected-misc-loads");
  if (misc) {
    misc.name = "Detailed Equipment Gains";
    misc.standard = "Detailed Equipment Gains";
    const retained = [0, 1, 2, 3, 4, 5, 6, 9, 10, 11];
    misc.headers = [
      { label: "Space Name" }, { label: "Equipment" }, { label: ">1 Items" },
      { label: "Per Person" }, { label: "People" }, { label: "Quantity" },
      { label: "Sens Heat Gain", unit: "Btu/h" }, { label: "Misc", unit: "kW" },
      { label: "Misc", unit: "Btu/h" }, { label: "Gain", unit: "Btu/h" },
    ];
    misc.columns = misc.headers.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`);
    misc.columnTypes = ["text", "text", "number", "text", "text", "number", "number", "number", "number", "number"];
    misc.rows = misc.rows.map((row) => retained.map((index) => row[index])).map((row) => {
      row[3] = row[3] === true || String(row[3]).toUpperCase() === "TRUE" ? "TRUE" : "";
      return row;
    });
    misc.calculatedColumns = [4, 5, 6, 9];
    misc.displayEquations = {
      4: '=IF(@Per Person="TRUE", XLOOKUP(@Space Name, [People Gains]@Space, [People Gains]@Actual People), "-")',
      5: '=IF(@>1 Items="", 1, @>1 Items)',
      6: '=XLOOKUP(@Equipment, [Equipment Sensible Gain Schedule + Grouped Equipment Sensible Gain Schedule]@Equipment, @Heat Gain)',
      9: '=IF(@People="-", 1, @People) * @Quantity * @Sens Heat Gain + 3412.142 * @Misc kW + @Misc Btu/h',
    };
    misc.dropdownColumns = {
      0: { sourceTableId: "calc-space-condition-setpoints", sourceColumn: 0 },
      1: { sources: [
        { sourceTableId: "schedule-equipment-sensible-gain", sourceColumn: 0 },
        { sourceTableId: "schedule-grouped-equipment-sensible-gain", sourceColumn: 0 },
      ] },
      3: { options: ["TRUE"] },
    };
    misc.headerLinks = { 1: "schedule-equipment-sensible-gain" };
    misc.columnWidthOverrides = { 3: 94, 4: 96, 5: 96 };
    misc.miscLoadCalculation = true;
    misc.preserveImportedValues = false;
    misc.readonlyEquations = true;
    misc.schemaVersion = 4;
  }

  const generalExhaust = independentTables.find((table) => table.id === "selected-general-exhaust");
  if (generalExhaust) {
    generalExhaust.rows = generalExhaust.rows.map((row) => [row[0], row[12], row[9], row[2], row[3], row[4], row[5], row[7], row[10], row[13], row[6], row[8], row[11], row[14]]);
    generalExhaust.headers = [
      { label: "Space" }, { label: "Vz", subscripts: [1], unit: "ft3" }, { label: "Az", subscripts: [1], unit: "ft2" },
      { label: "Exhaust Equipment" }, { label: "Requirement" }, { label: "Fixture Quantity" },
      { label: "Fixture", unit: "CFM" }, { label: "Rate", unit: "CFM/ft2" },
      { label: "ACH", unit: "1/Vz" }, { label: "Exhaust", unit: "CFM" },
      { label: "Fixture", unit: "CFM" }, { label: "Rate", unit: "CFM/ft2" },
      { label: "ACH", unit: "1/Vz" }, { label: "Exhaust", unit: "CFM" },
    ];
    generalExhaust.columns = generalExhaust.headers.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`);
    generalExhaust.columnTypes = generalExhaust.headers.map((_, index) => [0, 3, 4].includes(index) ? "text" : "number");
    generalExhaust.calculatedColumns = [1, 2, 3, 6, 7, 8, 9, 10, 11, 12, 13];
    generalExhaust.dropdownColumns = { 0: { sourceTableId: "calc-space-condition-setpoints", sourceColumn: 0 }, 4: { sourceTableId: "schedule-general-exhaust", sourceColumn: 0 } };
    generalExhaust.headerLinks = { 3: "calc-equipment-zoning", 4: "schedule-general-exhaust" };
    generalExhaust.frozenColumns = 6;
    generalExhaust.headerGroups = [
      { label: "General", start: 0, span: 6, className: "space-group-header" },
      { label: "Occupied Requirements", start: 6, span: 4, className: "exhaust-header" },
      { label: "Unoccupied Requirements", start: 10, span: 4, className: "exhaust-header" },
    ];
    generalExhaust.headerClasses = Object.fromEntries([...Array.from({ length: 6 }, (_, i) => [i, "space-group-header"]), ...Array.from({ length: 8 }, (_, i) => [i + 6, "exhaust-header"])]);
    generalExhaust.sectionStartColumns = [6, 10];
    generalExhaust.columnWidthOverrides = { 0: 195, 1: 95, 2: 95, 3: 155, 4: 290, 5: 125 };
    generalExhaust.zeroDecimalColumns = [1, 2, 5, 6, 9, 10, 13];
    generalExhaust.decimalColumns = [7, 8, 11, 12];
    generalExhaust.summaryColumns = [9, 13];
    generalExhaust.generalRequirementsLayout = true;
    generalExhaust.displayEquations = {
      1: "=XLOOKUP(@Space,[Tabular Space Data]@Space Name,[Tabular Space Data]@Volume)", 2: "=XLOOKUP(@Space,[Tabular Space Data]@Space Name,[Tabular Space Data]@Floor Area)",
      3: "=XLOOKUP(@Space, [Equipment Zoning]@Space, [Equipment Zoning]@Exhaust Equipment)",
      6: "=XLOOKUP(@Requirement, [General Exhaust Schedule]@Requirement, @Fixture Occupied)",
      7: "=XLOOKUP(@Requirement, [General Exhaust Schedule]@Requirement, @Rate Occupied)",
      8: "=XLOOKUP(@Requirement, [General Exhaust Schedule]@Requirement, @ACH Occupied)",
      9: "=MAX(@Fixture * @Fixture Quantity, @Rate * @Az, @ACH * @Vz / 60)",
      10: "=XLOOKUP(@Requirement, [General Exhaust Schedule]@Requirement, @Fixture Unoccupied)",
      11: "=XLOOKUP(@Requirement, [General Exhaust Schedule]@Requirement, @Rate Unoccupied)",
      12: "=XLOOKUP(@Requirement, [General Exhaust Schedule]@Requirement, @ACH Unoccupied)",
      13: "=MAX(@Fixture * @Fixture Quantity, @Rate * @Az, @ACH * @Vz / 60)",
    };
    generalExhaust.preserveImportedValues = false;
    generalExhaust.generalExhaustCalculation = true;
    generalExhaust.readonlyEquations = true;
    generalExhaust.schemaVersion = 1;
  }
  const equipmentExhaust = independentTables.find((table) => table.id === "selected-exhaust-equipment");
  if (equipmentExhaust) {
    equipmentExhaust.rows = equipmentExhaust.rows.map((row) => [row[0], row[4] || "", row[3], row[2], row[1], row[7], row[8]]);
    equipmentExhaust.headers = [
      { label: "Space" }, { label: "Exhaust Equipment" }, { label: "Task/Hood Exhaust Valve" },
      { label: "Equipment" }, { label: "Equipment Quantity" },
      { label: "On", unit: "CFM" }, { label: "Off", unit: "CFM" },
    ];
    equipmentExhaust.columns = equipmentExhaust.headers.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`);
    equipmentExhaust.columnTypes = ["text", "text", "text", "text", "number", "number", "number"];
    equipmentExhaust.calculatedColumns = [5, 6];
    equipmentExhaust.dropdownColumns = { 0: { sourceTableId: "calc-space-condition-setpoints", sourceColumn: 0 }, 3: { sourceTableId: "schedule-exhaust-equipment", sourceColumn: 0 } };
    equipmentExhaust.headerLinks = { 1: "calc-equipment-zoning", 3: "schedule-exhaust-equipment" };
    equipmentExhaust.frozenColumns = 1;
    equipmentExhaust.headerGroups = [];
    equipmentExhaust.headerClasses = { 0: "space-group-header", 1: "space-group-header", 2: "space-group-header", 3: "space-group-header", 4: "space-group-header", 5: "exhaust-header", 6: "exhaust-header" };
    equipmentExhaust.sectionStartColumns = [5];
    equipmentExhaust.columnWidthOverrides = { 0: 195, 1: 155, 2: 175, 3: 210, 4: 125 };
    equipmentExhaust.zeroDecimalColumns = [4, 5, 6];
    equipmentExhaust.summaryColumns = [5, 6];
    equipmentExhaust.displayEquations = { 1: "=XLOOKUP(@Space, [Equipment Zoning]@Space, [Equipment Zoning]@Exhaust Equipment)", 5: "=XLOOKUP(@Equipment, [Exhaust Equipment Schedule]@Equipment, [Exhaust Equipment Schedule]@On) * @Equipment Quantity", 6: "=XLOOKUP(@Equipment, [Exhaust Equipment Schedule]@Equipment, [Exhaust Equipment Schedule]@Off) * @Equipment Quantity" };
    equipmentExhaust.preserveImportedValues = false;
    equipmentExhaust.equipmentExhaustCalculation = true;
    equipmentExhaust.readonlyEquations = true;
    equipmentExhaust.schemaVersion = 1;
  }
  const transfer = independentTables.find((table) => table.id === "selected-transfer-air");
  if (transfer) {
    transfer.headers = ["Pressurized Air", "Transfer Amount", "Balanced Air", "Forced Extra", "Space", "Transfer Air", "Space", "Forced Extra", "Balanced Air", "Transfer Amount", "Pressurized Air", "Means of Transfer"].map((label, i) => ({ label, ...(![4,6,11].includes(i) ? { unit: "CFM" } : {}) }));
    transfer.columns = ["From Pressurized Air", "From Transfer Amount", "From Balanced Air", "From Forced Extra", "From Space", "Transfer Air", "To Space", "To Forced Extra", "To Balanced Air", "To Transfer Amount", "To Pressurized Air", "Means of Transfer"];
    transfer.rows = transfer.rows.map((r) => ["", "", "", "", r[3], r[4], r[5], "", "", "", "", r[9]]);
    transfer.columnTypes = transfer.headers.map((_, i) => [4,6,11].includes(i) ? "text" : "number");
    transfer.calculatedColumns = [0,1,2,3,7,8,9,10]; transfer.lockedColumns = []; transfer.identityColumns = [];
    transfer.frozenColumns = 0; transfer.transferAirCalculation = true; transfer.displayZeroAsDash = true; transfer.zeroDashStartColumn = 0;
    transfer.headerGroups = [{ label: "Transfer From", start: 0, span: 5 }, { label: "Amount", start: 5, span: 1 }, { label: "Transfer To", start: 6, span: 5 }, { label: "Type", start: 11, span: 1 }];
    transfer.sectionStartColumns = [5,6,11]; transfer.zeroDecimalColumns = [0,1,2,3,5,7,8,9,10];
    transfer.dropdownColumns = { 4: { sourceTableId: "calc-space-condition-setpoints", sourceColumn: 0 }, 6: { sourceTableId: "calc-space-condition-setpoints", sourceColumn: 0 }, 11: { options: ["Ducted", "Door Undercut", "Door Louver", "Open Air"] } };
    delete transfer.suggestColumns;
    transfer.headerLinks = { 0: "calc-air-balancing-requirements", 3: "calc-air-balancing-requirements", 7: "calc-air-balancing-requirements", 10: "calc-air-balancing-requirements" };
    transfer.displayEquations = {};
    for (const [space, pa, ta, ba, extra] of [["From Space",0,1,2,3], ["To Space",10,9,8,7]]) {
      const lookup = (name) => `XLOOKUP(@${space},[Air Balancing Requirements]@Space,[Air Balancing Requirements]@${name},0)`;
      transfer.displayEquations[pa] = `=${lookup("Required Ventilation")} - ${lookup("Required Relief")}`;
      transfer.displayEquations[ta] = `=${lookup("Transfer Air Out")} - ${lookup("Transfer Air In")}`;
      transfer.displayEquations[ba] = `=@${space === "From Space" ? "From" : "To"} Pressurized Air + @${space === "From Space" ? "From" : "To"} Transfer Amount`;
      transfer.displayEquations[extra] = `=${lookup("Additional Ventilation")} - ${lookup("Additional Relief")}`;
    }
    transfer.schemaVersion = 4;
  }
}

function configureCalcSectionTables() {
  const general = globalThis.CALC_SECTION_TABLES?.find((table) => table.id === "calc-general");
  const generalRows = general?.rows || [];
  const bySpace = new Map(generalRows.map((row) => [String(row[0]), row]));

  const setpoints = independentTables.find((table) => table.id === "calc-space-condition-setpoints");
  if (setpoints) {
    setpoints.headers = [
      { label: "Space" }, { label: "Type" }, { label: "Relative Humidity", unit: "%" },
      { label: "Main Setpoint", unit: "°F" }, { label: "Temperature Setback", unit: "°F" },
      { label: "Humidity Ratio", unit: "lb/lb" }, { label: "Schedule" },
      { label: "Ventilated Temperature Rise", unit: "°F" }, { label: "Main Setpoint", unit: "°F" },
      { label: "Temperature Setback", unit: "°F" }, { label: "Humidity Ratio", unit: "lb/lb" }, { label: "Schedule" },
    ];
    setpoints.columns = ["Space", "Type", "Relative Humidity", "Heating Main Setpoint", "Heating Temperature Setback", "Heating Humidity Ratio", "Heating Schedule", "Ventilated Temperature Rise", "Cooling Main Setpoint", "Cooling Temperature Setback", "Cooling Humidity Ratio", "Cooling Schedule"];
    setpoints.columnTypes = setpoints.headers.map((_, i) => [0, 1, 6, 11].includes(i) ? "text" : "number");
    setpoints.rows = setpoints.rows.map((row) => [row[0], bySpace.get(String(row[0]))?.[1] ?? "", row[1], row[2], row[3], row[4], "", row[5], row[7], row[8], row[9], ""]);
    setpoints.calculatedColumns = [5, 10]; setpoints.lockedColumns = [0, 1];
    setpoints.identityColumns = [0, 1]; setpoints.frozenColumns = 3;
    setpoints.fiveDecimalColumns = [5, 10]; setpoints.oneDecimalColumns = [3, 4, 7, 8, 9];
    setpoints.autoColumns = [6, 11]; setpoints.conditionScheduleCalculation = true;
    setpoints.headerGroups = [{ label: "General", start: 0, span: 3 }, { label: "Heating", start: 3, span: 4, className: "heating-load-header" }, { label: "Cooling", start: 7, span: 5, className: "sensible-cooling-header" }];
    setpoints.headerClasses = Object.fromEntries(setpoints.headers.map((_, i) => [i, i < 3 ? "space-group-header" : i < 7 ? "heating-load-header" : "sensible-cooling-header"]));
    setpoints.sectionStartColumns = [3, 7];
    setpoints.conditionalCalculatedColumns = { 8: { whenColumn: 7, baseValue: 91.6 } };
    setpoints.displayEquations = {
      5: "=HUMIDITY_RATIO(@Heating Main Setpoint, @Relative Humidity, [Inputs]@Barometric Pressure)",
      6: '=IF(@Heating Temperature Setback="","",[Two-value Schedule])',
      8: "=[Inputs]@Cooling Design Dry Bulb + @Ventilated Temperature Rise",
      10: "=HUMIDITY_RATIO(@Cooling Main Setpoint, @Relative Humidity, [Inputs]@Barometric Pressure)",
      11: '=IF(@Cooling Temperature Setback="","",[Two-value Schedule])',
    };
    setpoints.twoValueScheduleDefault = "System extended hours";
    setpoints.schemaVersion = 3;
  }

  const dhw = independentTables.find((table) => table.id === "calc-dhw");
  if (dhw) {
    dhw.name = dhw.standard = "Domestic Water Heating";
    dhw.headers = [
      { label: "Space" },
      { label: "Building Type" },
      { label: "Total People" },
      { label: "DHW Consumption", unit: "GPH" },
      { label: "DHW Consumption Schedule" },
    ];
    dhw.columns = ["Space", "Building Type", "Total People", "DHW Consumption (GPH)", "DHW Consumption Schedule"];
    dhw.columnTypes = ["text", "text", "number", "number", "text"];
    dhw.rows = dhw.rows.map((row) => [...row.slice(0, 4), ""]);
    dhw.scheduleCalculation = true; dhw.autoColumns = [4]; dhw.scheduleColumn = 4;
    dhw.displayZeroAsDash = true; dhw.zeroDashStartColumn = 3;
    dhw.calculatedColumns = [3];
    dhw.lockedColumns = [0];
    dhw.identityColumns = [0];
    dhw.fiveDecimalColumns = [3];
    dhw.summaryColumns = [1, 2, 3];
    dhw.summaryAggregations = { 1: "count", 2: "sum", 3: "sum" };
    dhw.preserveImportedValues = false;
    dhw.readonlyEquations = false;
    dhw.dropdownColumns = { 1: { sourceTableId: "femp-shw-calculator", sourceColumn: 0 } };
    dhw.headerLinks = { 1: "femp-shw-calculator" };
    dhw.equations = { 3: "=@TotalPeople*XLOOKUP(@BuildingType, [FEMP SHW Calculator Table]@BuildingType, [FEMP SHW Calculator Table]@EstimatedHotWaterUse)/24" };
    dhw.displayEquations = { 3: "=@Total People * XLOOKUP(@Building Type, [FEMP SHW Calculator Table]@Building Type, [FEMP SHW Calculator Table]@Estimated Hot Water Use) / 24" };
    dhw.displayEquations[4] = '=IF(@Building Type="","",XLOOKUP(@Building Type,[FEMP SHW Calculator Table]@Building Type,[FEMP SHW Calculator Table]@Consumption Schedule))';
    dhw.schemaVersion = 2;
  }

  const roomLoads = independentTables.find((table) => table.id === "calc-room-loads");
  if (roomLoads) {
    roomLoads.name = "Space Loads";
    roomLoads.standard = "Space Loads";
    roomLoads.headers = [
      { label: "Space" }, { label: "Type" },
      { label: "IESVE", unit: "MBH" }, { label: "Internal Gains", unit: "MBH" }, { label: "Size per IGs" },
      { label: "Add/Subtract", unit: "MBH" }, { label: "Oversizing Factor", unit: "%" }, { label: "Load", unit: "MBH" },
      { label: "IESVE", unit: "MBH" }, { label: "People", unit: "MBH" }, { label: "Size per IESVE" },
      { label: "Add/Subtract", unit: "MBH" }, { label: "Oversizing Factor", unit: "%" }, { label: "Load", unit: "MBH" },
      { label: "IESVE", unit: "MBH" }, { label: "Add/Subtract", unit: "MBH" }, { label: "Oversizing Factor", unit: "%" }, { label: "Load", unit: "MBH" },
    ];
    roomLoads.columns = roomLoads.headers.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`);
    roomLoads.rows = roomLoads.rows.map((row) => {
      const migrated = [row[0], bySpace.get(String(row[0]))?.[1] ?? "", ...row.slice(1)];
      return [...migrated.slice(0, 6), 0.1, migrated[6], ...migrated.slice(7, 11), 0.1, migrated[11], ...migrated.slice(12, 14), 0.1, migrated[14]];
    });
    roomLoads.rows.forEach((row) => { row[4] = String(row[4]).toUpperCase() === "TRUE" ? "TRUE" : ""; row[10] = String(row[10]).toUpperCase() === "TRUE" ? "TRUE" : ""; });
    roomLoads.columnTypes = ["text", "text", "number", "number", "text", "number", "number", "number", "number", "number", "text", "number", "number", "number", "number", "number", "number", "number"];
    roomLoads.calculatedColumns = [2, 3, 7, 8, 9, 13, 14, 17];
    roomLoads.lockedColumns = [0, 1]; roomLoads.identityColumns = [0, 1]; roomLoads.frozenColumns = 2;
    roomLoads.dropdownColumns = { 4: { options: ["TRUE"] }, 10: { options: ["TRUE"] } };
    roomLoads.autoColumns = [6, 12, 16];
    roomLoads.columnWidthOverrides = { 4: 94, 6: 170, 10: 94, 12: 170, 16: 170 };
    roomLoads.decimalColumns = [2, 3, 5, 7, 8, 9, 11, 13, 14, 15, 17];
    roomLoads.summaryColumns = [2, 3, 5, 7, 8, 9, 11, 13, 14, 15, 17];
    roomLoads.headerGroups = [
      { label: "General", start: 0, span: 2, className: "space-group-header" },
      { label: "Cooling Sensible", start: 2, span: 6, className: "sensible-cooling-header" },
      { label: "Cooling Latent", start: 8, span: 6, className: "latent-cooling-header" },
      { label: "Heating", start: 14, span: 4, className: "heating-load-header" },
    ];
    roomLoads.headerClasses = Object.fromEntries([
      ...[2, 3, 4, 5, 6, 7].map((index) => [index, "sensible-cooling-header"]),
      ...[8, 9, 10, 11, 12, 13].map((index) => [index, "latent-cooling-header"]),
      ...[14, 15, 16, 17].map((index) => [index, "heating-load-header"]),
    ]);
    roomLoads.sectionStartColumns = [8, 14];
    roomLoads.headerLinks = { 2: "room-zone-loads-report", 8: "room-zone-loads-report", 14: "room-zone-loads-report" };
    roomLoads.displayEquations = {
      2: '=XLOOKUP(@Space, [Room/Zone Loads Report]@Room, [Room/Zone Loads Report]@Sensible Cooling)',
      3: '=([Lighting Gains]@Proposed Lighting Gain + [People Gains]@Sensible Load + [Miscellaneous Sensible Gains]@Miscellaneous Sensible Load) / 1000',
      7: '=MAX((1 + [Cooling Sensible]@Oversizing Factor) * (IF([Cooling Sensible]@Size per IGs="TRUE", [Cooling Sensible]@Internal Gains, N([Cooling Sensible]@IESVE)) + [Cooling Sensible]@Add/Subtract), 0)',
      8: '=XLOOKUP(@Space, [Room/Zone Loads Report]@Room, [Room/Zone Loads Report]@Latent Cooling)',
      9: '=[People Gains]@Latent Load / 1000',
      13: '=MAX((1 + [Cooling Latent]@Oversizing Factor) * (IF([Cooling Latent]@Size per IESVE="TRUE", N([Cooling Latent]@IESVE), [Cooling Latent]@People) + [Cooling Latent]@Add/Subtract), 0)',
      14: '=XLOOKUP(@Space, [Room/Zone Loads Report]@Room, [Room/Zone Loads Report]@Heating)',
      17: '=MAX((1 + [Heating]@Oversizing Factor) * (N([Heating]@IESVE) + [Heating]@Add/Subtract), 0)',
    };
    roomLoads.roomLoadCalculation = true;
    roomLoads.displayZeroAsDash = true; roomLoads.zeroDashStartColumn = 0;
    roomLoads.preserveImportedValues = false;
    roomLoads.readonlyEquations = true;
  }

  for (const cooling of [true, false]) {
    const table = independentTables.find((candidate) => candidate.id === (cooling ? "calc-cooling-loads" : "calc-heating-loads"));
    if (!table) continue;
    const color = cooling ? "sensible-cooling-header" : "heating-load-header";
    const equipment = cooling ? "Cooling Equipment" : "Heating Equipment";
    table.name = cooling ? "Cooling Airflow Requirements" : "Heating Airflow Requirements";
    table.standard = table.name;
    table.description = `Space ${cooling ? "cooling" : "heating"} airflow based on the assigned equipment leaving air and space sensible load.`;
    table.headers = [
      { label: "Space" }, { label: "Load", unit: "MBH" }, { label: "DB", unit: "°F" },
      { label: equipment }, { label: "Sensible Constant" }, { label: "DB", unit: "°F" }, { label: "Airflow", unit: "CFM" },
    ];
    table.columns = table.headers.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`);
    table.columnTypes = ["text", "number", "number", "text", "number", "number", "number"];
    table.rows = table.rows.map((row) => [row[0], "", "", "", "", "", ""]);
    table.calculatedColumns = [1, 2, 3, 4, 5, 6];
    table.lockedColumns = [0];
    table.identityColumns = [0];
    table.frozenColumns = 3;
    table.headerGroups = [
      { label: "Space Condition", start: 0, span: 3, className: "space-group-header" },
      { label: "Equipment Leaving Air", start: 3, span: 4, className: color },
    ];
    table.headerClasses = Object.fromEntries(table.headers.map((_, index) => [index, index < 3 ? "space-group-header" : color]));
    table.sectionStartColumns = [3];
    table.headerLinks = { 1: "calc-room-loads", 2: "calc-space-condition-setpoints", 3: "calc-equipment-zoning" };
    table.decimalColumns = [1];
    table.oneDecimalColumns = [2, 5];
    table.threeDecimalColumns = [4];
    table.zeroDecimalColumns = [6];
    table.displayEquations = {
      1: `=[Space Loads]@${cooling ? "Cooling Sensible Load" : "Heating Load"}`,
      2: `=[Space Condition Setpoints]@${cooling ? "Cooling" : "Heating"} Setpoint`,
      3: `=IF([Equipment Zoning]@${equipment}<>"", [Equipment Zoning]@${equipment}, [Equipment Zoning]@${cooling ? "Central Equipment" : "Reheat Coil"})`,
      4: '=[Assigned Coil]@Leaving Sensible Constant',
      5: '=[Assigned Coil]@Leaving Dry-Bulb',
      6: `=IF(@Equipment="","",CEILING(MAX(IFERROR(@Load * 1000 / (@Sensible Constant * ${cooling ? "(@Space DB - @Leaving DB)" : "(@Leaving DB - @Space DB)"}),0),[Supply Min]),5))`,
    };
    table.coolingLoadCalculation = cooling;
    table.heatingLoadCalculation = !cooling;
    table.preserveImportedValues = false;
    table.readonlyEquations = true;
    table.schemaVersion = 2;
  }

  if (!independentTables.some((table) => table.id === "calc-airflow-requirements")) {
    const headers = [
      { label: "Space" },
      ...["Cooling", "Heating"].flatMap(() => [
        { label: "Space Load", unit: "MBH" }, { label: "Space Dry-Bulb", unit: "°F" },
        { label: "Equipment" }, { label: "Equipment Sensible Constant" },
        { label: "Equipment Dry-Bulb", unit: "°F" }, { label: "Airflow", unit: "CFM" },
      ]),
    ];
    independentTables.push({
      id: "calc-airflow-requirements", name: "Cooling & Heating Airflow Requirements",
      standard: "Cooling & Heating Airflow Requirements", description: "Cooling and heating space airflow at assigned equipment leaving conditions.",
      sheet: "Calc", range: "BR:CO", headers,
      columns: headers.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`),
      columnTypes: headers.map((_, index) => [0, 3, 9].includes(index) ? "text" : "number"),
      rows: generalRows.map((row) => [row[0], ...Array(12).fill("")]),
      calculatedColumns: Array.from({ length: 12 }, (_, index) => index + 1),
      lockedColumns: [0], identityColumns: [0], fixedRows: true, frozenColumns: 1,
      headerGroups: [
        { label: "General", start: 0, span: 1, className: "space-group-header" },
        { label: "Cooling", start: 1, span: 6, className: "sensible-cooling-header" },
        { label: "Heating", start: 7, span: 6, className: "heating-load-header" },
      ],
      headerClasses: Object.fromEntries(headers.map((_, index) => [index, !index ? "space-group-header" : index <= 6 ? "sensible-cooling-header" : "heating-load-header"])),
      sectionStartColumns: [1, 7], headerLinks: { 1: "calc-room-loads", 2: "calc-space-condition-setpoints", 3: "calc-equipment-zoning", 7: "calc-room-loads", 8: "calc-space-condition-setpoints", 9: "calc-equipment-zoning" },
      decimalColumns: [1, 7], oneDecimalColumns: [2, 5, 8, 11], threeDecimalColumns: [4, 10], zeroDecimalColumns: [6, 12],
      summaryColumns: [1, 3, 6, 7, 9, 12], summaryAggregations: { 3: "unique-count", 9: "unique-count" }, supplyMinimumDefault: 50,
      displayEquations: Object.fromEntries([0, 1].flatMap((part) => {
        const offset = part * 6;
        const cooling = !part;
        return [
          [offset + 1, `=[Space Loads]@${cooling ? "Cooling Sensible" : "Heating"} Load`],
          [offset + 2, `=[Space Condition Setpoints]@${cooling ? "Cooling" : "Heating"} Setpoint`],
          [offset + 3, `=IF([Equipment Zoning]@${cooling ? "Cooling" : "Heating"} Equipment<>"", [Equipment Zoning]@${cooling ? "Cooling" : "Heating"} Equipment, [Equipment Zoning]@${cooling ? "Central Equipment" : "Reheat Coil"})`],
          [offset + 4, "=[Assigned Coil]@Leaving Sensible Constant"],
          [offset + 5, "=[Assigned Coil]@Leaving Dry-Bulb"],
          [offset + 6, `=IF(@Primary Equipment="","",CEILING(MAX(IFERROR(@Space Load * 1000 / (@Equipment Sensible Constant * ${cooling ? "(@Space Dry-Bulb - @Equipment Dry-Bulb)" : "(@Equipment Dry-Bulb - @Space Dry-Bulb)"}),0),[Supply Min]),5))`],
        ];
      })),
      combinedAirflowCalculation: true, preserveImportedValues: false, readonlyEquations: true, schemaVersion: 1,
    });
  }
  const combinedAirflow = independentTables.find((table) => table.id === "calc-airflow-requirements");
  if (combinedAirflow) {
    for (const column of [3, 9]) combinedAirflow.headers[column].label = "Primary Equipment";
    combinedAirflow.headers.splice(6, 0, { label: "Minimum Airflow", unit: "CFM" });
    combinedAirflow.headers.splice(13, 0, { label: "Minimum Airflow", unit: "CFM" });
    combinedAirflow.columns = combinedAirflow.headers.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`);
    combinedAirflow.columnTypes.splice(6, 0, "number"); combinedAirflow.columnTypes.splice(13, 0, "number");
    combinedAirflow.rows = combinedAirflow.rows.map((row) => [...row.slice(0, 6), "", row[6], ...row.slice(7, 12), "", row[12]]);
    combinedAirflow.calculatedColumns = Array.from({ length: 14 }, (_, index) => index + 1).filter(c=>![6,13].includes(c));
    combinedAirflow.autoColumns = [6,13];
    combinedAirflow.headerGroups[1].span = 7; combinedAirflow.headerGroups[2].start = 8; combinedAirflow.headerGroups[2].span = 7;
    combinedAirflow.headerClasses = Object.fromEntries(combinedAirflow.headers.map((_, index) => [index, !index ? "space-group-header" : index <= 7 ? "sensible-cooling-header" : "heating-load-header"]));
    combinedAirflow.sectionStartColumns = [1, 8];
    combinedAirflow.headerLinks = { 1: "calc-room-loads", 2: "calc-space-condition-setpoints", 3: "calc-equipment-zoning", 8: "calc-room-loads", 9: "calc-space-condition-setpoints", 10: "calc-equipment-zoning" };
    combinedAirflow.decimalColumns = [1, 8]; combinedAirflow.oneDecimalColumns = [2, 5, 9, 12];
    combinedAirflow.threeDecimalColumns = [4, 11]; combinedAirflow.zeroDecimalColumns = [6, 7, 13, 14];
    combinedAirflow.summaryColumns = [1, 3, 6, 7, 8, 10, 13, 14]; combinedAirflow.summaryAggregations = { 3: "unique-count", 10: "unique-count" };
    const oldEquations = combinedAirflow.displayEquations;
    combinedAirflow.displayEquations = Object.fromEntries(Object.entries(oldEquations).map(([index, equation]) => [Number(index) >= 7 ? Number(index) + 1 : Number(index), equation]));
    combinedAirflow.displayEquations[6] = '=IF(@Primary Equipment="","",[Supply Min])';
    combinedAirflow.displayEquations[13] = '=IF(@Primary Equipment="","",[Supply Min])';
    combinedAirflow.displayEquations[7] = oldEquations[6].replace("[Supply Min]", "@Minimum Airflow");
    combinedAirflow.displayEquations[14] = oldEquations[12].replace("[Supply Min]", "@Minimum Airflow");
    combinedAirflow.schemaVersion = 2;
  }

  const equipmentZoning = independentTables.find((table) => table.id === "calc-equipment-zoning");
  if (equipmentZoning) {
    equipmentZoning.name = "Equipment Zoning";
    equipmentZoning.standard = "Equipment Zoning";
    equipmentZoning.description = "Assign and override ventilation, supply-air, exhaust, cooling, and heating equipment by space.";
    equipmentZoning.headers = [
      { label: "Zone Group" }, { label: "Zone" }, { label: "Space" },
      { label: "Ventilation Equipment" }, { label: "Central Equipment" }, { label: "Supply Air Valve" },
      { label: "Reheat Coil" }, { label: "Exhaust Equipment" }, { label: "General Exhaust Valve" },
      { label: "Cooling Equipment" }, { label: "Heating Equipment" },
    ];
    equipmentZoning.columns = equipmentZoning.headers.map((header) => header.label);
    equipmentZoning.columnTypes = Array(equipmentZoning.headers.length).fill("text");
    equipmentZoning.rows = equipmentZoning.rows.map((row) => [
      row[1] ?? "", "", row[0] ?? "", row[2] ?? "", "", "", row[14] === "-" ? "" : row[14] ?? "",
      row[5] === "-" ? "" : row[5] ?? "", row[4] ?? "", row[9] === "-" ? "" : row[9] ?? "", "",
    ]);
    equipmentZoning.calculatedColumns = [];
    equipmentZoning.lockedColumns = [0, 1, 2];
    equipmentZoning.identityColumns = [0, 1, 2];
    equipmentZoning.frozenColumns = 3;
    equipmentZoning.headerGroups = [
      { label: "General", start: 0, span: 3, className: "space-group-header", linkTableId: "room-zone-loads-report" },
      { label: "Ventilation", start: 3, span: 1, className: "ventilation-header" },
      { label: "Supply", start: 4, span: 3, className: "building-circulation-header" },
      { label: "Exhaust", start: 7, span: 2, className: "exhaust-header" },
      { label: "Zone Recirculation", start: 9, span: 2, className: "zone-circulation-header" },
    ];
    equipmentZoning.headerClasses = {
      3: "ventilation-header", 4: "sensible-cooling-header", 5: "valve-header", 6: "heating-load-header",
      7: "exhaust-header", 8: "exhaust-header", 9: "sensible-cooling-header", 10: "heating-load-header",
    };
    equipmentZoning.sectionStartColumns = [4, 7, 9];
    equipmentZoning.autoColumns = [4, 6, 8, 10];
    equipmentZoning.displayEquations = {
      4: '=IF(@Cooling Equipment<>"", "", @Ventilation Equipment)',
      6: '=IF(OR(@Central Equipment="", @Heating Equipment<>""), "", @Supply Air Valve)',
      7: '=@Ventilation Equipment',
      10: '=@Cooling Equipment',
    };
    equipmentZoning.columnWidthOverrides = { 0: 120, 1: 105, 2: 185, 3: 125, 4: 105, 5: 125, 6: 110, 7: 125, 8: 125, 9: 125, 10: 125 };
    equipmentZoning.summaryColumns = equipmentZoning.headers.map((_, index) => index).filter((index) => index >= 3);
    equipmentZoning.summaryAggregations = Object.fromEntries(equipmentZoning.summaryColumns.map((index) => [index, "unique-count"]));
    equipmentZoning.equipmentZoningCalculation = true;
    equipmentZoning.preserveImportedValues = false;
    equipmentZoning.readonlyEquations = true;
    equipmentZoning.schemaVersion = 3;
  }

  const ventilation = independentTables.find((table) => table.id === "calc-ventilation-exhaust");
  if (ventilation) {
    ventilation.name = "ASHRAE 62.1 Ventilation Requirements";
    ventilation.standard = ventilation.name;
    ventilation.description = "Space ventilation calculated from equipment zoning, occupancy, thermal templates, and airside settings.";
    ventilation.headers = [
      { label: "Ventilation Equipment" }, { label: "Space" }, { label: "Space Type" },
      { label: "Rp", subscripts: [1], unit: "cfm/person" },
      { label: "Ra", subscripts: [1], unit: "cfm/ft2" },
      { label: "Pz", subscripts: [1], unit: "people" },
      { label: "Az", subscripts: [1], unit: "ft2" },
      { label: "RpRz", subscripts: [1, 3], unit: "CFM" },
      { label: "RaAz", subscripts: [1, 3], unit: "CFM" },
      { label: "Vbz", subscripts: [1, 2], unit: "CFM" },
      { label: "Ez Cool", subscripts: [1] },
      { label: "Voz Cool", subscripts: [1, 2], unit: "CFM" },
      { label: "Ez Heat", subscripts: [1] },
      { label: "Voz Heat", subscripts: [1, 2], unit: "CFM" },
      { label: "Vot", subscripts: [1, 2], unit: "CFM" },
    ];
    ventilation.columns = ventilation.headers.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`);
    ventilation.rows = ventilation.rows.map((row) => [row[1], row[0], ...row.slice(3, 7), "", ...row.slice(7, 15)]);
    ventilation.columnTypes = ventilation.headers.map((_, index) => index < 3 ? "text" : "number");
    ventilation.calculatedColumns = [0, ...Array.from({ length: 12 }, (_, index) => index + 3).filter((index) => ![10, 12].includes(index))];
    ventilation.lockedColumns = [0, 1];
    ventilation.identityColumns = [0, 1];
    ventilation.frozenColumns = 3;
    ventilation.autoColumns = [2, 10, 12];
    ventilation.dropdownColumns = { 2: { sourceTableId: "ashrae-62-1-ventilation", sourceColumn: 0 } };
    ventilation.headerGroups = [];
    ventilation.headerClasses = Object.fromEntries([
      ...[0, 1, 2].map((index) => [index, "space-group-header"]),
      ...Array.from({ length: 12 }, (_, index) => [index + 3, "ventilation-header"]),
    ]);
    ventilation.sectionStartColumns = [3,7,10,14];
    ventilation.headerLinks = { 0: "calc-equipment-zoning", 2: "iesve-thermal-template", 3: "ashrae-62-1-ventilation", 4: "ashrae-62-1-ventilation", 5: "calc-people-gains", 10: "airside-settings", 12: "airside-settings" };
    ventilation.displayEquations = {
      0: "=[Equipment Zoning]@Ventilation Equipment",
      2: "=XLOOKUP([Space Condition Setpoints]@Type, [Thermal Templates]@Space Type, [Thermal Templates]@Occupancy Category)",
      3: "=XLOOKUP(@Space Type, [Ventilation Rates]@Occupancy Category, [Ventilation Rates]@Rp)",
      4: "=XLOOKUP(@Space Type, [Ventilation Rates]@Occupancy Category, [Ventilation Rates]@Ra)",
      5: "=[People Gains]@Actual People", 6: "=[People Gains]@Area", 7: "=@Rp * @Pz", 8: "=@Ra * @Az",
      9: "=@RpRz + @RaAz", 10: "=XLOOKUP(@Ventilation Equipment, [Settings]@Equipment, [Settings]@Ez Cool)",
      11: "=[Vbz] / [Ez Cool]",
      12: "=XLOOKUP(@Ventilation Equipment, [Settings]@Equipment, [Settings]@Ez Heat)",
      13: "=[Vbz] / [Ez Heat]",
      14: "=IF(MAX([Voz Heat], [Voz Cool])=0,0,CEILING(MAX([Voz Heat], [Voz Cool], [Ventilation Min]),5))",
    };
    ventilation.zeroDecimalColumns = Array.from({ length: 12 }, (_, index) => index + 3).filter((index) => ![3, 4, 10, 12].includes(index));
    ventilation.oneDecimalColumns = [3, 10, 12];
    ventilation.decimalColumns = [4];
    ventilation.summaryColumns = [5, 6, 7, 8, 9, 11, 13, 14];
    ventilation.displayZeroAsDash = true;
    ventilation.columnWidthOverrides = { 0: 165, 1: 195, 2: 215 };
    ventilation.preserveImportedValues = false;
    ventilation.readonlyEquations = true;
    ventilation.ventilationRequirementsCalculation = true;
    ventilation.ventilationMinimumDefault = 25;
    ventilation.schemaVersion = 4;
  }

  if (!independentTables.some((table) => table.id === "calc-exhaust-requirements")) {
    const headers = [
      { label: "Exhaust Equipment" }, { label: "General Exhaust Valve" }, { label: "Space" },
      { label: "Separate Equipment Max", unit: "CFM" }, { label: "Separate Equipment Min", unit: "CFM" },
      { label: "Task/Hood Valves Max", unit: "CFM" }, { label: "Task/Hood Valves Min", unit: "CFM" },
      { label: "General Occupied", unit: "CFM" }, { label: "General Unoccupied", unit: "CFM" },
      { label: "Occupied Max", unit: "CFM" }, { label: "Occupied Min", unit: "CFM" },
      { label: "Unoccupied Min", unit: "CFM" },
    ];
    independentTables.push({
      id: "calc-exhaust-requirements", name: "Exhaust Airflow Requirements", standard: "Exhaust Airflow Requirements",
      description: "Summarize general and equipment exhaust demands by space.", sheet: "Calc", range: "Exhaust",
      headers, columns: headers.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`),
      columnTypes: headers.map((_, index) => index < 3 ? "text" : "number"),
      rows: generalRows.map((row) => ["", "", row[0], ...Array(9).fill("")]),
      calculatedColumns: [0, 1, ...Array.from({ length: 9 }, (_, index) => index + 3)], lockedColumns: [0, 1, 2],
      identityColumns: [0, 1, 2], frozenColumns: 3,
      headerClasses: Object.fromEntries(headers.map((_, index) => [index, index < 3 ? "space-group-header" : "exhaust-header"])),
      sectionStartColumns: [3, 7, 9],
      headerLinks: { 0: "calc-equipment-zoning", 1: "calc-equipment-zoning", 3: "selected-exhaust-equipment", 4: "selected-exhaust-equipment", 5: "selected-exhaust-equipment", 6: "selected-exhaust-equipment", 7: "selected-general-exhaust", 8: "selected-general-exhaust" },
      columnWidthOverrides: { 0: 155, 1: 170, 2: 195 },
      zeroDecimalColumns: Array.from({ length: 9 }, (_, index) => index + 3),
      summaryColumns: Array.from({ length: 9 }, (_, index) => index + 3), displayZeroAsDash: true,
      displayEquations: {
        0: "=[Equipment Zoning]@Exhaust Equipment", 1: "=[Equipment Zoning]@General Exhaust Valve",
        3: "=SUMIFS([Exhaust Equipment Requirements]@On, @Space, @Space, @Exhaust Equipment, <>[Equipment Zoning]@Exhaust Equipment)",
        4: "=SUMIFS([Exhaust Equipment Requirements]@Off, @Space, @Space, @Exhaust Equipment, <>[Equipment Zoning]@Exhaust Equipment)",
        5: "=SUMIFS([Exhaust Equipment Requirements]@On, @Space, @Space, @Task/Hood Exhaust Valve, <>@General Exhaust Valve, @Exhaust Equipment, =@Exhaust Equipment)",
        6: "=SUMIFS([Exhaust Equipment Requirements]@Off, @Space, @Space, @Task/Hood Exhaust Valve, <>@General Exhaust Valve, @Exhaust Equipment, =@Exhaust Equipment)",
        7: "=LET(total,SUMIF([General Exhaust Requirements]@Space,@Space,[General Exhaust Requirements]@Occupied Exhaust),IF(total=0,0,CEILING(MAX(total,[Exhaust Min]),5)))",
        8: "=LET(total,SUMIF([General Exhaust Requirements]@Space,@Space,[General Exhaust Requirements]@Unoccupied Exhaust),IF(total=0,0,CEILING(total,5)))",
        9: "=MAX(@Separate Equipment Max + @Task/Hood Valves Max, @General Occupied)",
        10: "=MAX(@Separate Equipment Min + @Task/Hood Valves Min, @General Occupied)",
        11: "=MAX(@Separate Equipment Min + @Task/Hood Valves Min, @General Unoccupied)",
      },
      preserveImportedValues: false, readonlyEquations: true,
      exhaustRequirementsCalculation: true, exhaustMinimumDefault: 25, schemaVersion: 3,
    });
  }

  const pressurization = independentTables.find((table) => table.id === "calc-pressurization");
  if (pressurization) {
    pressurization.name = "Pressurization Requirements";
    pressurization.standard = pressurization.name;
    pressurization.description = "Calculate required airflow, pressurization offsets, transfer air, and the final air balance by space.";
    pressurization.headers = [
      { label: "Space" }, { label: "Ventilation Equipment" }, { label: "Supply Valve" }, { label: "Air Path" },
      { label: "Vent ≥ Clg/Htg Req" }, { label: "Ventilation Occupied", unit: "CFM" },
      { label: "Exhaust Occupied", unit: "CFM" }, { label: "Exhaust Unoccupied", unit: "CFM" },
      { label: "Pressurization Type" }, { label: "Exhaust % of Ventilation" },
      { label: "Max Vent", unit: "CFM" }, { label: "Max Exh", unit: "CFM" },
      { label: "Manual Balance", unit: "CFM" }, { label: "Extra Vent", unit: "CFM" },
      { label: "Extra Exh", unit: "CFM" }, { label: "Add Vent", unit: "CFM" },
      { label: "Add Exh", unit: "CFM" },
      { label: "OA", unit: "CFM" }, { label: "EA", unit: "CFM" },
      { label: "PA", unit: "CFM" }, { label: "TAI", unit: "CFM" },
      { label: "TAO", unit: "CFM" }, { label: "Balance", unit: "CFM" },
    ];
    pressurization.columns = pressurization.headers.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`);
    pressurization.columnTypes = pressurization.headers.map((_, index) => [0, 1, 2, 3, 4, 8].includes(index) ? "text" : "number");
    pressurization.rows = pressurization.rows.map((row) => [row[0], "", "", "", "", "", "", "", row[3] || "", "", "", "", row[7] ?? "", "", "", row[10] ?? "", row[11] ?? "", ...Array(6).fill("")]);
    pressurization.calculatedColumns = [1, 2, 3, 5, 6, 7, 9, 10, 11, 13, 14, 17, 18, 19, 20, 21, 22];
    pressurization.lockedColumns = [0];
    pressurization.identityColumns = [0];
    pressurization.frozenColumns = 4;
    pressurization.autoColumns = [4];
    pressurization.dropdownColumns = { 4: { options: ["TRUE", "FALSE"] }, 8: { options: ["1 - Negative", "3 - Neutral", "5 - Positive"] } };
    pressurization.headerGroups = [
      { label: "General", start: 0, span: 4, className: "space-group-header" },
      { label: "Requirements", start: 4, span: 4, className: "space-group-header" },
      { label: "Pressurization", start: 8, span: 9, className: "space-group-header" },
      { label: "Balance", start: 17, span: 6, className: "space-group-header" },
    ];
    pressurization.headerClasses = Object.fromEntries(pressurization.headers.map((_, index) => [index, [1, 5].includes(index) ? "ventilation-header" : [6, 7].includes(index) ? "exhaust-header" : "space-group-header"]));
    pressurization.sectionStartColumns = [4, 8, 17];
    pressurization.headerLinks = { 1: "calc-equipment-zoning", 2: "calc-equipment-zoning", 5: "calc-ventilation-exhaust", 6: "calc-exhaust-requirements", 7: "calc-exhaust-requirements", 20: "selected-transfer-air", 21: "selected-transfer-air" };
    pressurization.zeroDecimalColumns = Array.from({ length: 18 }, (_, index) => index + 5).filter((index) => index !== 8 && index !== 9);
    pressurization.decimalColumns = [9];
    pressurization.summaryColumns = [5, 6, 7, 10, 11, 13, 14, 17, 18, 19, 20, 21, 22];
    pressurization.displayEquations = {
      1: '=[Equipment Zoning]@Ventilation Equipment',
      2: '=[Equipment Zoning]@Supply Air Valve',
      3: '=IF(@Ventilation Equipment="", "", IF(@Ventilation Equipment<>[Equipment Zoning]@Central Equipment, "100% OA", IF([Settings]@Energy="Econ", "Econ RA", "")))',
      4: '=FALSE',
      5: '=MAX([ASHRAE 62.1 Ventilation Requirements]@Vot * IF(@Air Path="100% OA", 1, IF(@Air Path="Econ RA", 1.5, "")), IF(@Vent ≥ Clg/Htg Req="TRUE", MAX([Cooling & Heating Airflow Requirements]@Cooling Airflow, [Cooling & Heating Airflow Requirements]@Heating Airflow), 0))',
      6: '=[Exhaust Airflow Requirements]@Occupied Max',
      7: '=[Exhaust Airflow Requirements]@Unoccupied Min',
      9: '=XLOOKUP(@Pressurization Type, {"1 - Negative","3 - Neutral","5 - Positive"}, {1.08,1,0.95}, "")',
      10: '=IF(@Exhaust % of Ventilation="", @Ventilation Occupied, IF(@Exhaust Occupied>=@Exhaust % of Ventilation*@Ventilation Occupied, CEILING(@Exhaust Occupied/@Exhaust % of Ventilation,5), @Ventilation Occupied))',
      11: '=IF(@Exhaust % of Ventilation="", @Exhaust Occupied, IF(@Exhaust Occupied>=@Exhaust % of Ventilation*@Ventilation Occupied, @Exhaust Occupied, CEILING(@Exhaust % of Ventilation*@Ventilation Occupied,5)))',
      13: '=IF(@Manual Balance="",0,MAX(0,@Manual Balance-(@Max Vent-@Max Exh+@TAI-@TAO)))',
      14: '=IF(@Manual Balance="",0,MAX(0,-(@Manual Balance-(@Max Vent-@Max Exh+@TAI-@TAO))))',
      17: '=@Max Vent+@Extra Vent+@Add Vent',
      18: '=@Max Exh+@Extra Exh+@Add Exh',
      19: '=@OA-@EA',
      20: '=SUMIF([Transfer Air]@To Room, @Space, [Transfer Air]@Transfer Amount)',
      21: '=SUMIF([Transfer Air]@From Room, @Space, [Transfer Air]@Transfer Amount)',
      22: '=@PA+@TAI-@TAO',
    };
    pressurization.pressurizationCalculation = true;
    pressurization.preserveImportedValues = false;
    pressurization.readonlyEquations = true;
    pressurization.schemaVersion = 3;
  }

  const gains = independentTables.find((table) => table.id === "calc-internal-gains");
  if (gains) {
    const oldCalculated = new Set(gains.calculatedColumns || []);
    const oldDisplayEquations = { ...(gains.displayEquations || {}) };
    const buildGainTable = ({ id, name, range, activeSourceIndex, sourceIndexes, headers, summarySourceIndexes = [], oneDecimalSourceIndexes = [] }) => {
      const tableHeaders = [{ label: "Space" }, { label: "Type" }, { label: "Area", unit: "ft2" }, ...headers, { label: "Active" }];
      const table = {
        id, name, standard: name, description: `${name} split from the workbook Calc table.`, sheet: "Calc", range,
        headers: tableHeaders,
        columns: tableHeaders.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`),
        columnTypes: tableHeaders.map((_, index) => index < 2 || index === tableHeaders.length - 1 ? "text" : "number"),
        rows: gains.rows.map((row) => {
          const source = bySpace.get(String(row[0])) || [];
          const active = row[activeSourceIndex] === true || String(row[activeSourceIndex]).toLowerCase() === "true";
          return [row[0], source[1] ?? "", source[3] ?? "", ...sourceIndexes.map((index) => row[index]), active ? "Yes" : "No"];
        }),
        calculatedColumns: [...sourceIndexes.map((sourceIndex, index) => oldCalculated.has(sourceIndex) ? index + 3 : -1).filter((index) => index >= 0), tableHeaders.length - 1],
        lockedColumns: [0, 1, 2], identityColumns: [0, 1, 2], frozenColumns: 3,
        summaryColumns: summarySourceIndexes.map((sourceIndex) => sourceIndexes.indexOf(sourceIndex) + 3).filter((index) => index >= 3),
        oneDecimalColumns: oneDecimalSourceIndexes.map((sourceIndex) => sourceIndexes.indexOf(sourceIndex) + 3).filter((index) => index >= 3),
        displayEquations: {}, preserveImportedValues: true, readonlyEquations: true, schemaVersion: 1,
      };
      sourceIndexes.forEach((sourceIndex, index) => {
        if (oldDisplayEquations[sourceIndex]) table.displayEquations[index + 3] = oldDisplayEquations[sourceIndex];
      });
      if (oldDisplayEquations[activeSourceIndex]) table.displayEquations[tableHeaders.length - 1] = oldDisplayEquations[activeSourceIndex];
      independentTables.push(table);
    };

    buildGainTable({
      id: "calc-lighting-gains", name: "Lighting Gains", range: "W:AC", activeSourceIndex: 1,
      sourceIndexes: [2, 3, 4, 5, 6, 7], summarySourceIndexes: [6, 7], oneDecimalSourceIndexes: [2, 3, 5],
      headers: [
        { label: "Thermal Template Lighting Power Density", unit: "W/ft2" },
        { label: "Recommended Lighting Power Density", unit: "W/ft2" },
        { label: "Detailed Lighting Gain", unit: "W" },
        { label: "Manual Lighting Power Density", unit: "W/ft2" },
        { label: "Proposed Lighting Gain", unit: "Btu/h" },
        { label: "Baseline Lighting Gain", unit: "Btu/h" },
      ],
    });
    buildGainTable({
      id: "calc-people-gains", name: "People Gains", range: "AD:AK", activeSourceIndex: 8,
      sourceIndexes: [9, 10, 11, 12, 13, 14, 15], summarySourceIndexes: [12, 13, 14, 15],
      headers: [
        { label: "Thermal Template Sensible Heat", unit: "Btu/h-person" },
        { label: "Thermal Template Latent Heat", unit: "Btu/h-person" },
        { label: "Recommended Area per Person", unit: "ft2/person" },
        { label: "Manual People" }, { label: "People Count", unit: "people" },
        { label: "Sensible People Gain", unit: "Btu/h" }, { label: "Latent People Gain", unit: "Btu/h" },
      ],
    });
    buildGainTable({
      id: "calc-misc-gains", name: "Miscellaneous Sensible Gains", range: "AL:AP", activeSourceIndex: 16,
      sourceIndexes: [17, 18, 19, 20], summarySourceIndexes: [20], oneDecimalSourceIndexes: [17, 19],
      headers: [
        { label: "Thermal Template Sensible Gain Density", unit: "W/ft2" },
        { label: "Detailed Equipment Load", unit: "Btu/h" },
        { label: "Manual Sensible Gain Density", unit: "W/ft2" },
        { label: "Calculated Miscellaneous Load", unit: "Btu/h" },
      ],
    });

    const thermal = independentTables.find((table) => table.id === "iesve-thermal-template");
    const thermalByType = new Map((thermal?.rows || []).map((row) => [thermalTypeKey(row[0]), row]));
    const activityMap = (sourceIndex) => Object.fromEntries(gains.rows.map((row) => [String(row[0]), row[sourceIndex] === true || String(row[sourceIndex]).toLowerCase() === "true"]));

    const lighting = independentTables.find((table) => table.id === "calc-lighting-gains");
    if (lighting) {
      lighting.headers = [
        { label: "Space" }, { label: "Type" }, { label: "Area", unit: "ft2" },
        { label: "Proposed LPD", unit: "W/ft2" }, { label: "Baseline LPD", unit: "W/ft2" },
        { label: "Manual Lighting Gain", unit: "W" }, { label: "Detailed Lighting Gain", unit: "W" },
        { label: "Proposed Lighting Gain", unit: "Btu/h" }, { label: "Baseline Lighting Gain", unit: "Btu/h" },
      ];
      lighting.columns = lighting.headers.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`);
      lighting.columnTypes = ["text", "text", "number", "number", "number", "number", "number", "number", "number"];
      lighting.rows = gains.rows.map((row) => {
        const source = bySpace.get(String(row[0])) || [];
        return [row[0], source[1] ?? "", source[3] ?? "", "", "", "", "", row[6], row[7]];
      });
      lighting.calculatedColumns = [3, 4, 6, 7, 8];
      lighting.lockedColumns = [0, 1, 2]; lighting.identityColumns = [0, 1, 2]; lighting.frozenColumns = 3;
      lighting.sectionStartColumns = [...new Set([...(lighting.sectionStartColumns || []), 7])];
      lighting.summaryColumns = [2, 7, 8]; lighting.oneDecimalColumns = [3, 4]; lighting.zeroDecimalColumns = [2];
      lighting.activityBySpace = activityMap(1);
      lighting.volumeBySpace = Object.fromEntries(generalRows.map((row) => [String(row[0]), row[2]]));
      lighting.gainCalculation = "lighting";
      lighting.headerLinks = { 3: "iesve-thermal-template", 4: "iesve-thermal-template", 6: "selected-lighting-loads" };
      lighting.headerClasses = { 7: "sensible-cooling-header", 8: "sensible-cooling-header" };
      lighting.preserveImportedValues = true; lighting.readonlyEquations = true; lighting.schemaVersion = 3;
      lighting.displayEquations = {
        3: '=IFGAINACTIVE("Lighting", XLOOKUP(@Type, [Thermal Templates]@Space Type, [Thermal Templates]@Proposed LPD))',
        4: '=IFGAINACTIVE("Lighting", XLOOKUP(@Type, [Thermal Templates]@Space Type, [Thermal Templates]@Baseline LPD))',
        6: '=IFGAINACTIVE("Lighting", SUMIF([Lighting Loads]@Space Name, @Space, [Lighting Loads]@Gain))',
        7: '=IFGAINACTIVE("Lighting", 3.412 * COALESCE(@Detailed Lighting Gain, @Manual Lighting Gain, @Proposed LPD * @Area))',
        8: '=IFGAINACTIVE("Lighting", 3.412 * @Baseline LPD * @Area)',
      };
    }

    const people = independentTables.find((table) => table.id === "calc-people-gains");
    if (people) {
      people.headers = [
        { label: "Space" }, { label: "Type" }, { label: "Area", unit: "ft2" },
        { label: "Occupant Density", unit: "people/ft2" }, { label: "Manual People", unit: "people" },
        { label: "Actual People", unit: "people" }, { label: "Sensible Heat", unit: "Btu/h-person" },
        { label: "Latent Heat", unit: "Btu/h-person" }, { label: "Sensible Gain", unit: "Btu/h" },
        { label: "Latent Gain", unit: "Btu/h" },
      ];
      people.columns = people.headers.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`);
      people.columnTypes = ["text", "text", "number", "number", "number", "number", "number", "number", "number", "number"];
      people.rows = gains.rows.map((row) => {
        const source = bySpace.get(String(row[0])) || [];
        return [row[0], source[1] ?? "", source[3] ?? "", "", row[12], row[13], "", "", row[14], row[15]];
      });
      people.calculatedColumns = [3, 5, 6, 7, 8, 9];
      people.lockedColumns = [0, 1, 2]; people.identityColumns = [0, 1, 2]; people.frozenColumns = 3;
      people.sectionStartColumns = [...new Set([...(people.sectionStartColumns || []), 5])];
      people.summaryColumns = [2, 4, 5, 8, 9]; people.zeroDecimalColumns = [2, 5];
      people.activityBySpace = activityMap(8); people.gainCalculation = "people";
      people.headerLinks = { 3: "iesve-thermal-template", 6: "iesve-thermal-template", 7: "iesve-thermal-template" };
      people.headerClasses = { 8: "sensible-cooling-header", 9: "latent-cooling-header" };
      people.preserveImportedValues = true; people.readonlyEquations = true; people.schemaVersion = 3;
      people.displayEquations = {
        3: '=IFGAINACTIVE("People", XLOOKUP(@Type, [Thermal Templates]@Space Type, [Thermal Templates]@Occupant Density) / 1000)',
        5: '=IFGAINACTIVE("People", IF(@Manual People="", ROUND(@Occupant Density * @Area, 0), @Manual People))',
        6: '=IFGAINACTIVE("People", XLOOKUP(@Type, [Thermal Templates]@Space Type, [Thermal Templates]@Sensible Heat))',
        7: '=IFGAINACTIVE("People", XLOOKUP(@Type, [Thermal Templates]@Space Type, [Thermal Templates]@Latent Heat))',
        8: '=IFGAINACTIVE("People", @Actual People * @Sensible Heat)',
        9: '=IFGAINACTIVE("People", @Actual People * @Latent Heat)',
      };
    }

    const misc = independentTables.find((table) => table.id === "calc-misc-gains");
    if (misc) {
      misc.headers = [
        { label: "Space" }, { label: "Type" }, { label: "Area", unit: "ft2" },
        { label: "Sensible Heat Gain Density", unit: "W/ft2" },
        { label: "Detailed Equipment Gain", unit: "Btu/h" }, { label: "Miscellaneous Sensible Gain", unit: "Btu/h" },
      ];
      misc.columns = misc.headers.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`);
      misc.columnTypes = ["text", "text", "number", "number", "number", "number"];
      misc.rows = gains.rows.map((row) => {
        const source = bySpace.get(String(row[0])) || [];
        return [row[0], source[1] ?? "", source[3] ?? "", "", row[18], row[20]];
      });
      misc.calculatedColumns = [3, 4, 5];
      misc.lockedColumns = [0, 1, 2]; misc.identityColumns = [0, 1, 2]; misc.frozenColumns = 3;
      misc.sectionStartColumns = [...new Set([...(misc.sectionStartColumns || []), 5])];
      misc.summaryColumns = [2, 5]; misc.oneDecimalColumns = [3]; misc.zeroDecimalColumns = [2];
      misc.activityBySpace = activityMap(16); misc.gainCalculation = "misc";
      misc.headerLinks = { 3: "iesve-thermal-template", 4: "selected-misc-loads" };
      misc.headerClasses = { 5: "sensible-cooling-header" };
      misc.preserveImportedValues = true; misc.readonlyEquations = true; misc.schemaVersion = 3;
      misc.displayEquations = {
        3: '=IFGAINACTIVE("Computers", XLOOKUP(@Type, [Thermal Templates]@Space Type, [Thermal Templates]@Sensible Heat Gain Density))',
        4: '=IFGAINACTIVE("Computers", SUMIF([Miscellaneous Sensible Loads]@Space Name, @Space, [Miscellaneous Sensible Loads]@Gain))',
        5: '=IFGAINACTIVE("Computers", COALESCE(@Detailed Equipment Load, 3.412 * @Sensible Heat Gain Density * @Area))',
      };
    }
  }
}

const tabularSpaceHeaders = [
  { label: "Space ID" },
  { label: "Space Name" },
  { label: "Heating Design Supply Air Temperature", unit: "°F" },
  { label: "Cooling Design Supply Air Temperature", unit: "°F" },
  { label: "DHW Consumption Room-level Setting" },
  { label: "DHW Consumption", unit: "US gal/h" },
  { label: "DHW Consumption Pattern" },
  { label: "DHW Pattern Of Use Profile" },
  { label: "Heating Setpoint", unit: "°F" },
  { label: "Cooling Setpoint", unit: "°F" },
  { label: "Saturation Upper Limit", unit: "%" },
  { label: "Gain 1 Input Mode" },
  { label: "Gain 1 Occupancy", unit: "people" },
  { label: "Gain 1 Max. Sensible Gain", unit: "Btu/h" },
  { label: "Gain 1 Max. Sensible Gain", unit: "Btu/h·person" },
  { label: "Gain 1 Max. Latent Gain", unit: "Btu/h·person" },
  { label: "Gain 1 Max. Power Consumption", unit: "Btu/h" },
  { label: "Gain 2 Input Mode" },
  { label: "Gain 2 Occupancy", unit: "people" },
  { label: "Gain 2 Max. Sensible Gain", unit: "Btu/h" },
  { label: "Gain 2 Max. Sensible Gain", unit: "Btu/h·person" },
  { label: "Gain 2 Max. Latent Gain", unit: "Btu/h·person" },
  { label: "Gain 2 Max. Power Consumption", unit: "Btu/h" },
  { label: "Gain 3 Input Mode" },
  { label: "Gain 3 Occupancy", unit: "people" },
  { label: "Gain 3 Max. Sensible Gain", unit: "Btu/h" },
  { label: "Gain 3 Max. Sensible Gain", unit: "Btu/h·person" },
  { label: "Gain 3 Max. Latent Gain", unit: "Btu/h·person" },
  { label: "Gain 3 Max. Power Consumption", unit: "Btu/h" },
  { label: "Basis for OA Requirement" },
  { label: "Outdoor Air Req. Type" },
  { label: "Outdoor Air Req.", unit: "cfm" },
  { label: "Use Exhaust Air Change Req?" },
  { label: "Exhaust Air Change Req." },
  { label: "Exhaust Air Change Req. Unit" },
];

const tabularSpaceCsvHeaders = [
  "Space ID",
  "Space Name (Real)",
  "Heating Design Supply Air Temperature (°F) (Real)",
  "Cooling Design Supply Air Temperature (°F) (Real)",
  "DHW Consumption Room-level Setting (Real)",
  "DHW Consumption (Real)",
  "DHW Consumption Pattern (Real)",
  "DHW Pattern Of Use Profile (Real)",
  "Heating Setpoint (°F) (Real)",
  "Cooling Setpoint (°F) (Real)",
  "% Saturation Upper Limit (Real)",
  "Gain 1 Input Mode (Real)",
  "Gain 1 Occupancy (People) (Real)",
  "Gain 1 Max. Sensible Gain (Btu/h) (Real)",
  "Gain 1 Max. Sensible Gain (Btu/h·person) (Real)",
  "Gain 1 Max. Latent Gain (Btu/h·person) (Real)",
  "Gain 1 Max. Power Consumption (Btu/h) (Real)",
  "Gain 2 Input Mode (Real)",
  "Gain 2 Occupancy (People) (Real)",
  "Gain 2 Max. Sensible Gain (Btu/h) (Real)",
  "Gain 2 Max. Sensible Gain (Btu/h·person) (Real)",
  "Gain 2 Max. Latent Gain (Btu/h·person) (Real)",
  "Gain 2 Max. Power Consumption (Btu/h) (Real)",
  "Gain 3 Input Mode (Real)",
  "Gain 3 Occupancy (People) (Real)",
  "Gain 3 Max. Sensible Gain (Btu/h) (Real)",
  "Gain 3 Max. Sensible Gain (Btu/h·person) (Real)",
  "Gain 3 Max. Latent Gain (Btu/h·person) (Real)",
  "Gain 3 Max. Power Consumption (Btu/h) (Real)",
  "Basis for OA Requirement (Real)",
  "Outdoor Air Req. Type (Real)",
  "Outdoor Air Req. (cfm) (Real)",
  "Use Exhaust Air Change Req? (Real)",
  "Exhaust Air Change Req. (Real)",
  "Exhaust Air Change Req. Unit (Real)",
];

if (!independentTables.some((table) => table.id === "iesve-tabular-space-data")) {
  const numericColumns = new Set([2, 3, 5, 10, 12, 13, 14, 15, 16, 18, 19, 20, 21, 22, 24, 25, 26, 27, 28, 31, 33]);
  independentTables.unshift({
    id: "iesve-tabular-space-data",
    name: "Tabular Space Data",
    standard: "Tabular Space Data",
    description: "IESVE tabular space data structure populated from pasted source data.",
    sheet: "IES Data",
    range: "D3:AL201",
    headers: tabularSpaceHeaders,
    columns: tabularSpaceHeaders.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`),
    columnTypes: tabularSpaceHeaders.map((_, index) => numericColumns.has(index) ? "number" : "text"),
    percentageColumns: [10],
    csvHeaders: tabularSpaceCsvHeaders,
    lockedColumns: tabularSpaceHeaders.map((_, index) => index),
    frozenColumns: 2,
    rows: [],
  });
}

const tabularFields = [
  { key: "differences", label: "# of Differing Values", csv: null, export: false },
  { key: "id", legacy: 0 }, { key: "space", legacy: 1 },
  { key: "thermal", label: "Thermal Template", csv: "Thermal Template (Real)" },
  { key: "volume", label: "Volume", unit: "ft³", csv: "Volume (ft³) (Real)" },
  { key: "area", label: "Floor Area", unit: "ft²", csv: "Floor Area (ft²) (Real)" },
  ...["oaBasis", "oaType", "ventilation", "useExhaust", "relief", "exhaustUnit"].map((key, index) => ({ key, legacy: 29 + index })),
  ...["heatingSupply", "coolingSupply", "dhwEnabled", "dhw", "dhwPattern", "dhwSchedule", "heatingSetpoint", "coolingSetpoint", "rh"].map((key, index) => ({ key, legacy: 2 + index })),
  ...[1, 2, 3].flatMap((slot) => [
    { key: `gain${slot}Type`, label: `Gain ${slot} Type`, csv: `Gain ${slot} Type (Real)` },
    ...["Mode", "Occupancy", "Sensible", "PersonSensible", "PersonLatent", "Power"].map((suffix, index) => ({ key: `gain${slot}${suffix}`, legacy: 11 + (slot - 1) * 6 + index })),
  ]),
];
const tabularV3Keys = tabularFields.filter((field) => field.key !== "differences").flatMap((field) => /^gain[123]Type$/.test(field.key) ? [field.key, field.key.replace("Type", "SourceMode")] : [field.key]);
const tabularColumn = Object.fromEntries(tabularFields.map((field, index) => [field.key, index]));
{
  const tabular = independentTables.find((table) => table.id === "iesve-tabular-space-data");
  tabular.tabularCalculation = true; tabular.spaceColumn = tabularColumn.space; tabular.idColumn = tabularColumn.id;
  tabular.headers = tabularFields.map((field) => field.legacy !== undefined ? { ...tabularSpaceHeaders[field.legacy] } : { label: field.label, unit: field.unit });
  tabular.headers[tabularColumn.rh] = { label: "% Saturation Upper Limit", unit: "" };
  tabular.csvHeaders = tabularFields.map((field) => field.legacy !== undefined ? tabularSpaceCsvHeaders[field.legacy] : field.csv);
  tabular.csvHeaders[tabularColumn.rh] = "% Saturation Upper Limit (Real)";
  tabular.columns = tabular.headers.map((h) => `${h.label}${h.unit ? ` (${h.unit})` : ""}`);
  tabular.columnTypes = tabularFields.map(() => "text");
  tabular.calculatedColumns = tabularFields.map((_, index) => index).filter((index) => ![tabularColumn.id, tabularColumn.space].includes(index));
  tabular.zeroDecimalColumns = [tabularColumn.differences];
  tabular.threeDecimalColumns = tabularFields.map((f, i) => /^gain[123](Sensible|PersonSensible|PersonLatent|Power)$/.test(f.key) ? i : -1).filter((i) => i >= 0);
  tabular.lockedColumns = tabularFields.map((_, index) => index); tabular.identityColumns = [tabularColumn.id, tabularColumn.space];
  tabular.frozenColumns = 3; tabular.readonlyEquations = true; tabular.displayEquations = {};
  tabular.headerGroups = [
    { label: "Identifier", start: 0, span: 3 }, { label: "General", start: 3, span: 3 },
    { label: "System", start: 6, span: 6 }, { label: "Space Conditions", start: 12, span: 9 },
    { label: "Internal Gains", start: 21, span: 21 },
  ];
  tabular.sectionStartColumns = [3, 6, 12, 21];
}

if (!independentTables.some((table) => table.id === "room-zone-loads-report")) {
  const headers = [
    { label: "Zone Group" },
    { label: "Zone" },
    { label: "Room" },
    { label: "Sensible Cooling (without oversizing)", unit: "MBH" },
    { label: "Latent Cooling (without oversizing)", unit: "MBH" },
    { label: "Heating (without oversizing)", unit: "MBH" },
  ];
  independentTables.unshift({
    id: "room-zone-loads-report", spaceColumn: 2,
    name: "Room/Zone Loads Report",
    standard: "Room/Zone Loads Report",
    description: "Room and zone loads imported from the workbook report beginning at row 10.",
    sheet: "IES Loads",
    range: "A10:U149",
    headers,
    columns: [
      "Zone Group",
      "Zone",
      "Room",
      "Sensible Cooling Load without Oversizing (MBH)",
      "Latent Cooling Load without Oversizing (MBH)",
      "Heating Load without Oversizing (MBH)",
    ],
    columnTypes: ["text", "text", "text", "number", "number", "number"],
    lockedColumns: headers.map((_, index) => index),
    decimalColumns: [3, 4, 5],
    excelImport: true,
    frozenColumns: 3,
    identityColumns: [0, 1, 2],
    headerClasses: {
      3: "sensible-cooling-header",
      4: "latent-cooling-header",
      5: "heating-load-header",
    },
    rows: [],
  });
}

function configureWorkbookPressurizationTables() {
  const spaces = independentTables.find((table) => table.id === "calc-pressurization")?.rows.map((row) => row[0]) || [];
  const definitions = [
    ["1 - Negative", 1.08], ["2 - Slightly Negative", 1.06], ["3 - Neutral", 1], ["4 - Slightly Positive", 0.97], ["5 - Positive", 0.95],
  ];
  independentTables.push({
    id: "schedule-pressurization-types", name: "Pressurization Types", standard: "Pressurization Types",
    description: "Pressurization category and exhaust as a percentage of ventilation.", sheet: "Calc", range: "PR_TABLE",
    headers: [{ label: "Pressurization Type" }, { label: "Exhaust % of Ventilation", unit: "%" }],
    columns: ["Pressurization Type", "Exhaust % of Ventilation (%)"], columnTypes: ["text", "number"],
    rows: definitions, frozenColumns: 1, lockedColumns: [0], identityColumns: [0], zeroDecimalColumns: [1],
    summaryColumns: [], schemaVersion: 1,
  });
  const press = independentTables.find((table) => table.id === "calc-pressurization");
  if (!press) return;
  const oldRows = press.rows;
  press.headers = [
    { label: "Space" }, { label: "Ventilation Equipment" }, { label: "Central Equipment" },
    { label: "Supply Air Valve" }, { label: "Heating Coil" }, { label: "Air Path" },
    { label: "Minimum ≥ Cooling & Heating" }, { label: "Ventilation Requirement", unit: "CFM" },
    { label: "Cooling Requirement", unit: "CFM" }, { label: "Heating Requirement", unit: "CFM" },
    { label: "Ventilation Minimum", unit: "CFM" }, { label: "Exhaust Required", unit: "CFM" },
    { label: "Pressurization Type" }, { label: "Pressurization Percentage", unit: "%" },
    { label: "Pressurization Ventilation", unit: "CFM" }, { label: "Pressurization Relief", unit: "CFM" },
    { label: "Add Vent", unit: "CFM" }, { label: "Add Relief", unit: "CFM" },
    { label: "Ventilation", unit: "CFM" }, { label: "Relief", unit: "CFM" },
    { label: "Pressurization", unit: "CFM" },
  ];
  press.columns = press.headers.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`);
  press.columnTypes = press.headers.map((_, index) => [0, 1, 2, 3, 4, 5, 6, 12].includes(index) ? "text" : "number");
  press.rows = oldRows.map((row) => {
    const values = Array(21).fill(""); values[0] = row[0];
    values[12] = row[8] || ""; values[16] = row[15] ?? ""; values[17] = row[16] ?? "";
    return values;
  });
  press.calculatedColumns = [1, 2, 3, 4, 5, 7, 8, 9, 10, 11, 13, 14, 15, 18, 19, 20];
  press.lockedColumns = [0]; press.identityColumns = [0]; press.frozenColumns = 1;
  press.autoColumns = [6]; press.dropdownColumns = {
    6: { options: ["TRUE", "FALSE"] },
    12: { sourceTableId: "schedule-pressurization-types", sourceColumn: 0 },
  };
  press.headerGroups = [
    { label: "General", start: 0, span: 6, className: "space-group-header" },
    { label: "Requirements", start: 6, span: 6, className: "space-group-header" },
    { label: "Pressurization", start: 12, span: 6, className: "space-group-header" },
    { label: "Balance", start: 18, span: 3, className: "space-group-header" },
  ];
  press.headerClasses = Object.fromEntries(press.headers.map((_, index) => [index,
    [1, 7, 10, 14, 18].includes(index) ? "ventilation-header" : [11, 15, 19].includes(index) ? "exhaust-header" : "space-group-header"]));
  press.sectionStartColumns = [6, 12, 18];
  press.headerLinks = { 1: "calc-equipment-zoning", 2: "calc-equipment-zoning", 3: "calc-equipment-zoning", 4: "calc-equipment-zoning",
    7: "calc-ventilation-exhaust", 8: "calc-airflow-requirements", 9: "calc-airflow-requirements",
    11: "calc-exhaust-requirements", 12: "schedule-pressurization-types", 13: "schedule-pressurization-types" };
  press.summaryColumns = [1, 2, 3, 4, 7, 8, 9, 10, 11, 14, 15, 16, 17, 18, 19, 20];
  press.summaryAggregations = { 1: "unique-count", 2: "unique-count", 3: "unique-count", 4: "unique-count" };
  press.zeroDecimalColumns = [7, 8, 9, 10, 11, 13, 14, 15, 16, 17, 18, 19, 20];
  press.topMetric = { label: "Occupied Building Pressurization", numerator: 20, denominator: 18 };
  press.displayEquations = {
    1: "=[Equipment Zoning]@Ventilation Equipment", 2: "=[Equipment Zoning]@Central Equipment",
    3: "=[Equipment Zoning]@Supply Air Valve", 4: "=[Equipment Zoning]@Reheat Coil",
    5: '=IF(@Ventilation Equipment="","",IF(@Ventilation Equipment<>@Central Equipment,"100% OA",IF([Settings]@Energy="Econ","Econ RA","100% OSA")))',
    6: '=""',
    7: "=[ASHRAE 62.1 Ventilation Requirements]@Vot",
    8: '=IF(@Minimum ≥ Cooling & Heating="TRUE",[Cooling & Heating Airflow Requirements]@Cooling Airflow,"")',
    9: '=IF(AND(@Minimum ≥ Cooling & Heating="TRUE",@Heating Coil<>""),[Cooling & Heating Airflow Requirements]@Heating Airflow,"")',
    10: '=IF(@Air Path="Econ RA",1.5*@Ventilation Requirement,IF(@Air Path="100% OSA",IF(@Minimum ≥ Cooling & Heating="TRUE",MAX(@Ventilation Requirement,@Cooling Requirement,@Heating Requirement),@Ventilation Requirement),@Ventilation Requirement))',
    11: "=[Exhaust Airflow Requirements]@Occupied Max",
    13: '=XLOOKUP(@Pressurization Type,[Pressurization Types]@Pressurization Type,[Pressurization Types]@Exhaust % of Ventilation,"")',
    14: '=IF(@Pressurization Percentage="",@Ventilation Minimum,IF(@Exhaust Required>=@Pressurization Percentage*@Ventilation Minimum,CEILING(@Exhaust Required/@Pressurization Percentage,5),@Ventilation Minimum))',
    15: '=IF(@Pressurization Percentage="",@Exhaust Required,IF(@Exhaust Required>=@Pressurization Percentage*@Ventilation Minimum,@Exhaust Required,CEILING(@Pressurization Percentage*@Ventilation Minimum,5)))',
    18: "=@Pressurization Ventilation+@Add Vent", 19: "=@Pressurization Relief+@Add Relief", 20: "=@Ventilation-@Relief",
  };
  press.schemaVersion = 4;
  press.headers[16].label = "Ventilation";
  press.headers[17].label = "Relief";
  press.headers[18].label = "Adjusted Ventilation";
  press.headers[19].label = "Adjusted Relief";
  press.headerGroups = [];
  press.headerClasses = Object.fromEntries(press.headers.map((_, index) => [index,
    [1, 7, 10, 14, 16, 18].includes(index) ? "ventilation-header"
      : [11, 15, 17, 19].includes(index) ? "exhaust-header"
      : index === 8 ? "sensible-cooling-header" : [4, 9].includes(index) ? "heating-load-header" : "space-group-header"]));
  press.headers.unshift({ label: "Zone Group" });
  press.columns = press.headers.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`);
  press.columnTypes.unshift("text");
  press.rows = press.rows.map((row) => ["", ...row]);
  press.calculatedColumns = press.calculatedColumns.map((index) => index + 1);
  press.lockedColumns = [0, 1]; press.identityColumns = [0, 1]; press.frozenColumns = 2;
  press.autoColumns = [7]; press.dropdownColumns = { 7: { options: ["TRUE", "FALSE"] }, 13: { sourceTableId: "schedule-pressurization-types", sourceColumn: 0 } };
  press.headerClasses = Object.fromEntries(Object.entries(press.headerClasses).map(([index, className]) => [Number(index) + 1, className]));
  press.headerClasses[0] = "space-group-header";
  press.sectionStartColumns = [7, 13, 19];
  press.headerLinks = Object.fromEntries(Object.entries(press.headerLinks).map(([index, id]) => [Number(index) + 1, id]));
  press.summaryColumns = press.summaryColumns.map((index) => index + 1);
  press.summaryAggregations = Object.fromEntries(Object.entries(press.summaryAggregations).map(([index, kind]) => [Number(index) + 1, kind]));
  press.zeroDecimalColumns = press.zeroDecimalColumns.map((index) => index + 1);
  press.topMetric = { label: "Occupied Building Pressurization", numerator: 21, denominator: 19, calculated: true,
    equation: '=IF(SUM([Adjusted Ventilation])=0,"",SUM([Pressurization])/SUM([Adjusted Ventilation]))' };
  press.displayEquations = Object.fromEntries(Object.entries(press.displayEquations).map(([index, equation]) => [Number(index) + 1, equation]));
  press.displayEquations[0] = "=[Equipment Zoning]@Zone Group";
  press.displayEquations[19] = "=@Pressurization Ventilation+@Ventilation";
  press.displayEquations[20] = "=@Pressurization Relief+@Relief";
  press.displayEquations[21] = "=@Adjusted Ventilation-@Adjusted Relief";
  press.schemaVersion = 5;

  const balancingHeaders = ["Space", "Required Ventilation", "Required Relief", "Transfer Air In", "Transfer Air Out", "Balance", "Manual Balance", "Extra Ventilation", "Extra Relief", "Ventilation", "Relief"]
    .map((label, index) => ({ label, ...(index && index !== 6 ? { unit: "CFM" } : {}) }));
  independentTables.push({
    id: "calc-air-balancing-requirements", name: "Air Balancing Requirements", standard: "Air Balancing Requirements",
    description: "Required airflow, transfer air, manual balance, and additional ventilation or relief by space.",
    sheet: "Calc", range: "Balance", headers: balancingHeaders,
    columns: balancingHeaders.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`),
    columnTypes: balancingHeaders.map((_, index) => index ? "number" : "text"),
    rows: spaces.map((space) => [space, ...Array(10).fill("")]),
    calculatedColumns: [1, 2, 3, 4, 5, 7, 8, 9, 10], lockedColumns: [0], identityColumns: [0], frozenColumns: 1,
    headerClasses: Object.fromEntries(balancingHeaders.map((_, index) => [index, "space-group-header"])),
    sectionStartColumns: [1, 6, 7, 9],
    headerLinks: { 1: "calc-pressurization", 2: "calc-pressurization", 3: "selected-transfer-air", 4: "selected-transfer-air" },
    summaryColumns: [1, 2, 3, 4, 5, 7, 8, 9, 10],
    zeroDecimalColumns: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
    topMetric: { label: "Occupied Building Pressurization", numeratorDifference: [9, 10], denominator: 9 },
    displayEquations: { 1: "=[Pressurization Requirements]@Ventilation", 2: "=[Pressurization Requirements]@Relief",
      3: "=SUMIF([Transfer Air]@Transfer Air To Room,@Space,[Transfer Air]@Transfer Amount)",
      4: "=SUMIF([Transfer Air]@Transfer Air From Room,@Space,[Transfer Air]@Transfer Amount)",
      5: "=@Required Ventilation-@Required Relief+@Transfer Air In-@Transfer Air Out",
      7: '=IF(@Manual Balance="","",MAX(0,@Manual Balance-@Balance))',
      8: '=IF(@Manual Balance="","",MAX(0,@Balance-@Manual Balance))',
      9: "=@Required Ventilation+@Extra Ventilation", 10: "=@Required Relief+@Extra Relief" },
    airBalancingCalculation: true, preserveImportedValues: false, readonlyEquations: true, schemaVersion: 1, fixedRows: true,
  });
  const balancing = independentTables.at(-1);
  balancing.headers.unshift({ label: "Zone Group" });
  balancing.columns = balancing.headers.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`);
  balancing.columnTypes.unshift("text"); balancing.rows = balancing.rows.map((row) => ["", ...row]);
  balancing.calculatedColumns = balancing.calculatedColumns.map((index) => index + 1);
  balancing.lockedColumns = [0, 1]; balancing.identityColumns = [0, 1]; balancing.frozenColumns = 2;
  balancing.headerClasses = Object.fromEntries(balancing.headers.map((_, index) => [index,
    [2, 8, 10].includes(index) ? "ventilation-header" : [3, 9, 11].includes(index) ? "exhaust-header" : "space-group-header"]));
  balancing.sectionStartColumns = [2, 7, 8, 10];
  balancing.headerLinks = Object.fromEntries(Object.entries(balancing.headerLinks).map(([index, id]) => [Number(index) + 1, id]));
  balancing.summaryColumns = balancing.summaryColumns.map((index) => index + 1);
  balancing.zeroDecimalColumns = balancing.zeroDecimalColumns.map((index) => index + 1);
  balancing.topMetric = { label: "Occupied Building Pressurization", numeratorDifference: [10, 11], denominator: 10, calculated: true,
    equation: '=IF(SUM([Ventilation])=0,"",(SUM([Ventilation])-SUM([Relief]))/SUM([Ventilation]))' };
  balancing.displayEquations = Object.fromEntries(Object.entries(balancing.displayEquations).map(([index, equation]) => [Number(index) + 1, equation]));
  balancing.displayEquations[0] = "=[Equipment Zoning]@Zone Group";
  balancing.displayEquations[2] = "=[Pressurization Requirements]@Adjusted Ventilation";
  balancing.displayEquations[3] = "=[Pressurization Requirements]@Adjusted Relief";
  balancing.headers.push({ label: "Pressurization", unit: "CFM" });
  balancing.columns.push("Pressurization (CFM)");
  balancing.columnTypes.push("number");
  balancing.rows.forEach((row) => row.push(""));
  balancing.calculatedColumns.push(12); balancing.summaryColumns.push(12); balancing.zeroDecimalColumns.push(12);
  balancing.headerClasses[12] = "space-group-header";
  balancing.displayEquations[12] = "=@Ventilation-@Relief";
  balancing.displayZeroAsDash = true;
  balancing.zeroDashStartColumn = 0;
  balancing.topMetric = { label: "Occupied Building Pressurization", numerator: 12, denominator: 10, calculated: true,
    equation: '=IF(SUBTOTAL(109,[Ventilation])=0,"",SUBTOTAL(109,[Pressurization])/SUBTOTAL(109,[Ventilation]))' };
  balancing.schemaVersion = 3;

  const peakLabels = ["Space", "Primary Equipment", "Cooling Required", "Required Ventilation", "Peak", "Sensible Contribution",
    "Primary Equipment", "Heating Required", "Required Ventilation", "50% of Cooling Limit", "Reheat Peak", "Sensible Contribution",
    "Remaining Sensible", "Space Dry-Bulb", "Secondary Equipment", "Eq Sens Constant", "Eq Dry Bulb", "Airflow", "Sensible Contribution"];
  const peakHeaders = peakLabels.map((label, index) => ({ label, ...([2, 3, 4, 7, 8, 9, 10, 17].includes(index) ? { unit: "CFM" }
    : [5, 11, 12, 18].includes(index) ? { unit: "MBH" } : [13, 16].includes(index) ? { unit: "°F" } : {}) }));
  independentTables.push({
    id: "calc-peak-airflows", name: "Peak Airflows", standard: "Peak Airflows",
    description: "Size primary cooling, primary heating, and secondary heating airflow from space loads and equipment leaving air.",
    sheet: "Calc", range: "Peak", headers: peakHeaders,
    columns: peakHeaders.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`),
    columnTypes: peakHeaders.map((_, index) => [0, 1, 6, 14].includes(index) ? "text" : "number"),
    rows: spaces.map((space) => [space, ...Array(18).fill("")]),
    calculatedColumns: Array.from({ length: 18 }, (_, index) => index + 1), lockedColumns: [0], identityColumns: [0], frozenColumns: 1,
    headerGroups: [
      { label: "General", start: 0, span: 1, className: "space-group-header" },
      { label: "Primary Cooling", start: 1, span: 5, className: "sensible-cooling-header" },
      { label: "Primary Heating", start: 6, span: 6, className: "heating-load-header" },
      { label: "Secondary Heating", start: 12, span: 7, className: "heating-load-header" },
    ],
    headerClasses: Object.fromEntries(peakHeaders.map((_, index) => [index, index === 0 ? "space-group-header" : index < 6 ? "sensible-cooling-header" : "heating-load-header"])),
    sectionStartColumns: [1, 6, 12],
    headerLinks: { 1: "calc-equipment-zoning", 2: "calc-airflow-requirements", 3: "calc-air-balancing-requirements",
      6: "calc-equipment-zoning", 7: "calc-airflow-requirements", 8: "calc-air-balancing-requirements", 14: "calc-equipment-zoning" },
    summaryColumns: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 14, 17, 18],
    summaryAggregations: { 1: "unique-count", 6: "unique-count", 14: "count" },
    zeroDecimalColumns: [2, 3, 4, 7, 8, 9, 10, 17], decimalColumns: [5, 11, 12, 18], oneDecimalColumns: [13, 16], threeDecimalColumns: [15],
    displayEquations: {
      1: '=[Equipment Zoning]@Cooling Equipment or Supply Air Valve or Central Equipment',
      2: '=[Cooling & Heating Airflow Requirements]@Cooling Airflow',
      3: '=IF(@Primary Equipment=[Equipment Zoning]@Central Equipment,[Air Balancing Requirements]@Ventilation,"")',
      4: '=MAX(@Cooling Required,@Required Ventilation)',
      5: '=@Eq Sens Constant*@Peak*(@Space Dry-Bulb-@Eq Dry Bulb)/1000',
      6: '=[Equipment Zoning]@Reheat Coil or Heating Equipment',
      7: '=[Cooling & Heating Airflow Requirements]@Heating Airflow',
      8: '=IF(AND(@Ventilation Equipment=@Central Equipment,@Primary Equipment=@Reheat Coil),[Air Balancing Requirements]@Ventilation,"")',
      9: '=IF(AND(@Primary Equipment=@Reheat Coil,[Settings]@Energy="Econ"),FLOOR(@Cooling Peak/2,5),"")',
      10: '=MIN(MAX(@Required Ventilation,@Heating Required),MAX(@Required Ventilation,@50% of Cooling Limit))',
      11: '=@Eq Sens Constant*@Reheat Peak*(@Eq Dry Bulb-@Space Dry-Bulb)/1000',
      12: '=MAX(0,[Space Loads]@Heating Load-@Sensible Contribution)',
      14: '=IF(@Primary Equipment=@Reheat Coil,IF([Equipment Zoning]@Heating Equipment<>"",[Equipment Zoning]@Heating Equipment,"PFP Box"),"")',
      15: '=IF(@Secondary Equipment="PFP Box",SENSIBLECONSTANT(@Eq Dry Bulb,[Space Condition Setpoints]@Heating Humidity Ratio),[Heating Coil]@Leaving Sensible Constant)',
      16: '=IF(@Secondary Equipment="PFP Box",[Reheat Coil]@Leaving Dry-Bulb,[Heating Coil]@Leaving Dry-Bulb)',
      17: '=IF(@Secondary Equipment="","",CEILING(MAX([Supply Min],@Remaining Sensible*1000/(@Eq Sens Constant*(@Eq Dry Bulb-@Space Dry-Bulb))),5))',
      18: '=@Eq Sens Constant*@Airflow*(@Eq Dry Bulb-@Space Dry-Bulb)/1000',
    },
    peakAirflowCalculation: true, preserveImportedValues: false, readonlyEquations: true, schemaVersion: 1, fixedRows: true,
  });
  const peak = independentTables.at(-1);
  peak.headers[15].label = "Equipment Sensible Constant";
  peak.headers[16].label = "Equipment Dry-Bulb";
  peak.headers[10].label = "Peak";
  peak.headers[17].label = "Peak";
  peak.columns = peak.headers.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`);
  peak.headerClasses = Object.fromEntries(peak.headers.map((_, index) => [index,
    index === 0 ? "space-group-header" : [3, 8].includes(index) ? "ventilation-header"
      : index < 6 ? "sensible-cooling-header" : "heating-load-header"]));
  peak.displayEquations = Object.fromEntries(Object.entries(peak.displayEquations).map(([index, equation]) =>
    [index, equation.replaceAll("Eq Sens Constant", "Equipment Sensible Constant").replaceAll("Eq Dry Bulb", "Equipment Dry-Bulb").replaceAll("@Reheat Peak", "@Peak")]));
  peak.displayEquations[17] = '=@Remaining Sensible*1000/(@Equipment Sensible Constant*(@Equipment Dry-Bulb-@Space Dry-Bulb))';
  peak.displayEquations[18] = '=@Equipment Sensible Constant*@Peak*(@Equipment Dry-Bulb-@Space Dry-Bulb)/1000';
  peak.schemaVersion = 3;
}

function configureSystemAirBalanceTables() {
  for (const id of ["calc-air-balance", "calc-non-peak-air-balance"]) {
    const index = independentTables.findIndex((table) => table.id === id);
    if (index >= 0) independentTables.splice(index, 1);
  }
  const normal = "space-group-header", vent = "ventilation-header", exhaust = "exhaust-header", heat = "heating-load-header";
  const zoning = "calc-equipment-zoning", balancing = "calc-air-balancing-requirements", peak = "calc-peak-airflows";
  // Field name, column label, header color, source table, display equation, text/number.
  const fields = {
    space: ["Space", normal, "calc-space-condition-setpoints", "=[Equipment Zoning]@Space", "text"],
    ventilationEquipment: ["Ventilation Equipment", vent, zoning, "=[Equipment Zoning]@Ventilation Equipment", "text"],
    occupiedVentilation: ["Occupied Ventilation Airflow", vent, balancing, "=[Air Balancing Requirements]@Ventilation"],
    exhaustEquipment: ["Exhaust Equipment", exhaust, zoning, "=[Equipment Zoning]@Exhaust Equipment", "text"],
    occupiedExhaust: ["Occupied Exhaust Airflow", exhaust, balancing, "=[Air Balancing Requirements]@Relief"],
    occupiedPressure: ["Occupied Pressurized Air", normal, balancing, "=@Occupied Ventilation Airflow-@Occupied Exhaust Airflow"],
    occupiedTransferIn: ["Occupied Transfer Air In", normal, "selected-transfer-air", "=[Air Balancing Requirements]@Transfer Air In"],
    occupiedTransferOut: ["Occupied Transfer Air Out", normal, "selected-transfer-air", "=[Air Balancing Requirements]@Transfer Air Out"],
    occupiedBalanced: ["Occupied Balanced Air", normal, "", "=@Occupied Pressurized Air+@Occupied Transfer Air In-@Occupied Transfer Air Out"],
    coolingEquipment: ["Zone Recirculation Equipment", normal, zoning, "=[Equipment Zoning]@Cooling Equipment", "text"],
    coolingSupply: ["Maximum Supply Airflow", normal, peak, "=MAX(SUMIFS([Peak Airflows]@Primary Cooling Peak,[Peak Airflows]@Primary Cooling Equipment,@Zone Recirculation Equipment),SUMIFS([Peak Airflows]@Primary Heating Peak,[Peak Airflows]@Primary Heating Equipment,@Zone Recirculation Equipment),SUMIFS([Peak Airflows]@Secondary Heating Peak,[Peak Airflows]@Secondary Equipment,@Zone Recirculation Equipment))"],
    coolingReturn: ["Maximum Return Airflow", normal, "", "=@Maximum Supply Airflow"],
    heatingEquipment: ["Zone Recirculation Equipment", heat, zoning, '=IF([Equipment Zoning]@Heating Equipment<>[Equipment Zoning]@Cooling Equipment,[Equipment Zoning]@Heating Equipment,"")', "text"],
    heatingSupply: ["Maximum Supply Airflow", heat, peak, "=MAX(SUMIFS([Peak Airflows]@Primary Heating Peak,[Peak Airflows]@Primary Heating Equipment,@Zone Recirculation Equipment),SUMIFS([Peak Airflows]@Secondary Heating Peak,[Peak Airflows]@Secondary Equipment,@Zone Recirculation Equipment))"],
    heatingReturn: ["Maximum Return Airflow", heat, "", "=@Maximum Supply Airflow"],
    centralEquipment: ["Central Equipment", normal, zoning, "=[Equipment Zoning]@Central Equipment", "text"],
    supplyValve: ["Supply Air Valve", vent, zoning, "=[Equipment Zoning]@Supply Air Valve", "text"],
    maximumSupply: ["Maximum Supply Airflow", vent, peak, "=MAX([Peak Airflows]@Primary Cooling Peak,IF(OR([Peak Airflows]@Primary Heating Equipment=@Central Equipment,[Peak Airflows]@Primary Heating Equipment=[Equipment Zoning]@Reheat Coil),[Peak Airflows]@Primary Heating Peak,0),[Air Balancing Requirements]@Ventilation)"],
    minimumOccupiedSupply: ["Minimum Occupied Supply Airflow", vent, balancing, "=[Air Balancing Requirements]@Ventilation"],
    minimumUnoccupiedSupply: ["Minimum Unoccupied Supply Airflow", vent, "calc-exhaust-requirements", '=IF(@Minimum Unoccupied Exhaust Airflow=0,0,CEILING(MAX(0,@Minimum Unoccupied Exhaust Airflow+[Air Balancing Requirements]@Pressurization),5))'],
    exhaustValves: ["Exhaust Air Valves", exhaust, "selected-exhaust-equipment", '=TEXTJOIN(", ",TRUE,UNIQUE([Equipment Zoning]@General Exhaust Valve,[Exhaust Equipment Requirements]@Task/Hood Exhaust Valve))', "text"],
    maximumExhaust: ["Maximum Exhaust Airflow", exhaust, balancing, "=[Air Balancing Requirements]@Relief"],
    minimumOccupiedExhaust: ["Minimum Occupied Exhaust Airflow", exhaust, "calc-exhaust-requirements", "=MIN(@Maximum Exhaust Airflow,[Exhaust Airflow Requirements]@Occupied Min)"],
    minimumUnoccupiedExhaust: ["Minimum Unoccupied Exhaust Airflow", exhaust, "calc-exhaust-requirements", "=[Exhaust Airflow Requirements]@Unoccupied Min"],
    pressure: ["Pressurized Air", normal, balancing, "=[Air Balancing Requirements]@Ventilation-[Air Balancing Requirements]@Relief"],
    transferIn: ["Transfer Air In", normal, "selected-transfer-air", "=[Air Balancing Requirements]@Transfer Air In"],
    transferOut: ["Transfer Air Out", normal, "selected-transfer-air", "=[Air Balancing Requirements]@Transfer Air Out"],
    balanced: ["Balanced Air", normal, "", "=@Pressurized Air+@Transfer Air In-@Transfer Air Out"],
    requiredVentilation: ["Required Ventilation Airflow", vent, balancing, "=[Air Balancing Requirements]@Ventilation"],
    returnToCentral: ["Maximum Return to Central Airflow", normal, "", "=MAX(0,@Maximum Supply Airflow-@Occupied Exhaust Airflow)"],
    returnToValve: ["Maximum Return to Valve Airflow", normal, "", "=MAX(0,@Maximum Supply Airflow-@Required Ventilation Airflow)"],
    centralSupply: ["Maximum Supply Airflow", normal, peak, "=MAX([Peak Airflows]@Primary Cooling Peak,IF(OR([Peak Airflows]@Primary Heating Equipment=@Central Equipment,[Peak Airflows]@Primary Heating Equipment=[Equipment Zoning]@Reheat Coil),[Peak Airflows]@Primary Heating Peak,0))"],
    centralReturn: ["Maximum Return Airflow", normal, "", "=@Maximum Supply Airflow"],
  };
  const definitions = [
    ["doas-zone", "DOAS & Zone Recirculation Air Balance", ["space", "ventilationEquipment", "occupiedVentilation", "exhaustEquipment", "occupiedExhaust", "occupiedPressure", "occupiedTransferIn", "occupiedTransferOut", "occupiedBalanced", "coolingEquipment", "coolingSupply", "coolingReturn", "heatingEquipment", "heatingSupply", "heatingReturn"], [1, 3, 5, 9, 12]],
    ["ahu-oa", "AHU with 100% OA Air Balance", ["space", "centralEquipment", "supplyValve", "maximumSupply", "minimumOccupiedSupply", "minimumUnoccupiedSupply", "exhaustEquipment", "exhaustValves", "maximumExhaust", "minimumOccupiedExhaust", "minimumUnoccupiedExhaust", "pressure", "transferIn", "transferOut", "balanced"], [2, 6, 11]],
    ["ahu-economizing", "AHU with Economizing Air Balance", ["space", "exhaustEquipment", "occupiedExhaust", "centralEquipment", "supplyValve", "maximumSupply", "minimumOccupiedSupply", "requiredVentilation", "returnToCentral", "returnToValve", "pressure", "transferIn", "transferOut", "balanced", "heatingEquipment", "heatingSupply", "heatingReturn"], [1, 3, 4, 8, 10, 14]],
    ["doas-ahu", "DOAS & AHU Air Balance", ["space", "ventilationEquipment", "occupiedVentilation", "exhaustEquipment", "occupiedExhaust", "occupiedPressure", "occupiedTransferIn", "occupiedTransferOut", "occupiedBalanced", "centralEquipment", "supplyValve", "centralSupply", "centralReturn", "heatingEquipment", "heatingSupply", "heatingReturn"], [1, 3, 5, 9, 13]],
  ];
  definitions.forEach(([mode, name, names, dividers]) => {
    const definitions = names.map((field) => fields[field]);
    const headers = definitions.map(([label, , , , type]) => ({ label, ...(type === "text" ? {} : { unit: "CFM" }) }));
    const numbers = definitions.flatMap((definition, index) => definition[4] === "text" ? [] : [index]);
    const equipment = names.flatMap((field, index) => /Equipment$/.test(field) ? [index] : []);
    const table = {
      id: `calc-${mode}-air-balance`, name, standard: name, sheet: "Calc", range: name,
      description: "Space airflow balance using equipment zoning, air balancing requirements, and peak airflows.",
      headers, columns: headers.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`),
      columnTypes: definitions.map((definition) => definition[4] === "text" ? "text" : "number"),
      rows: [], calculatedColumns: names.map((_, index) => index).filter((index) => index > 0),
      lockedColumns: [0], identityColumns: [0], frozenColumns: 1, fixedRows: true,
      headerGroups: [], headerClasses: Object.fromEntries(definitions.map((definition, index) => [index, definition[1]])),
      headerLinks: Object.fromEntries(definitions.flatMap((definition, index) => definition[2] ? [[index, definition[2]]] : [])),
      displayEquations: Object.fromEntries(definitions.map((definition, index) => [index,
        definition[3].replaceAll(",@Zone Recirculation Equipment)", ",@Zone Recirculation Equipment,[Peak Airflows]@Space,@Space)")])),
      sectionStartColumns: dividers, summaryColumns: [...numbers.filter((index) => index > 0), ...equipment],
      summaryAggregations: Object.fromEntries(equipment.map((index) => [index, "unique-count"])),
      zeroDecimalColumns: numbers, preserveImportedValues: false, readonlyEquations: true,
      systemAirBalanceMode: mode, balanceFields: names, schemaVersion: 1,
    };
    table.displayZeroAsDash = true;
    table.zeroDashStartColumn = 0;
    const pressureField = names.includes("occupiedPressure") ? "occupiedPressure" : "pressure";
    const ventilationField = names.includes("occupiedVentilation") ? "occupiedVentilation" : "minimumOccupiedSupply";
    const pressureColumn = names.indexOf(pressureField), ventilationColumn = names.indexOf(ventilationField);
    table.topMetric = { label: "Occupied Building Pressurization", numerator: pressureColumn, denominator: ventilationColumn, calculated: true,
      equation: `=IFERROR(SUBTOTAL(109,[@${headers[pressureColumn].label}])/SUBTOTAL(109,[@${headers[ventilationColumn].label}]),0)` };
    if (mode === "doas-zone") {
      delete table.headerLinks[names.indexOf("occupiedPressure")];
      table.displayEquations[names.indexOf("heatingEquipment")] = '=IF(AND([Equipment Zoning]@Reheat Coil="",[Equipment Zoning]@Heating Equipment<>[Equipment Zoning]@Cooling Equipment),[Equipment Zoning]@Heating Equipment,"")';
      for (const field of ["coolingSupply"]) {
        table.displayEquations[names.indexOf(field)] = '=IF(@Zone Recirculation Equipment="","",MAX(IF([Peak Airflows]@Primary Cooling Equipment=@Zone Recirculation Equipment,[Peak Airflows]@Primary Cooling Peak,0),IF([Peak Airflows]@Primary Heating Equipment=@Zone Recirculation Equipment,[Peak Airflows]@Primary Heating Peak,0)))';
      }
    }
    if (mode === "doas-zone") table.displayEquations[names.indexOf("heatingSupply")] = '=IF(@Zone Recirculation Equipment="","",[Peak Airflows]@Primary Heating Peak)';
    if (mode === "ahu-oa") {
      for (const [field, aggregation] of [["supplyValve", "unique-count"], ["exhaustValves", "unique-list-count"]]) {
        const column = names.indexOf(field); table.summaryColumns.push(column); table.summaryAggregations[column] = aggregation;
      }
      delete table.headerLinks[names.indexOf("pressure")];
      table.displayEquations[names.indexOf("pressure")] = '=@Maximum Supply Airflow-@Maximum Exhaust Airflow';
      const metric = (label, denominator, difference) => ({ label, denominator: names.indexOf(denominator), calculated: true,
        ...(difference ? { numeratorDifference: difference.map((field) => names.indexOf(field)) } : { numerator: names.indexOf("pressure") }),
        equation: `=IFERROR((${difference ? difference.map((field) => `SUBTOTAL(109,[@${headers[names.indexOf(field)].label}])`).join("-") : "SUBTOTAL(109,[@Pressurized Air])"})/SUBTOTAL(109,[@${headers[names.indexOf(denominator)].label}]),0)` });
      table.topMetrics = [
        metric("Maximum Occupied Building Pressurization", "maximumSupply"),
        metric("Minimum Occupied Building Pressurization", "minimumOccupiedSupply"),
        metric("Minimum Unoccupied Building Pressurization", "minimumUnoccupiedSupply", ["minimumUnoccupiedSupply", "minimumUnoccupiedExhaust"]),
      ];
      table.topMetric = table.topMetrics[0];
      table.displayEquations[names.indexOf("maximumSupply")] = '=MAX([Peak Airflows]@Primary Cooling Peak,[Peak Airflows]@Primary Heating Peak)';
      table.displayEquations[names.indexOf("minimumOccupiedSupply")] = '=MAX([Pressurization Requirements]@Ventilation Min,@Pressurized Air+[Exhaust Airflow Requirements]@Occupied Min,0)';
      table.displayEquations[names.indexOf("minimumOccupiedExhaust")] = '=@Minimum Occupied Supply Airflow-@Pressurized Air';
      table.displayEquations[names.indexOf("minimumUnoccupiedSupply")] = '=MAX(0,@Pressurized Air+[Exhaust Airflow Requirements]@Unoccupied Min)';
      table.displayEquations[names.indexOf("minimumUnoccupiedExhaust")] = '=@Minimum Unoccupied Supply Airflow-@Pressurized Air';
      table.headerLinks[names.indexOf("minimumOccupiedSupply")] = "calc-pressurization";
    }
    if (mode === "doas-ahu") table.headerClasses[names.indexOf("supplyValve")] = normal;
    if (mode !== "doas-zone" && names.includes("heatingEquipment")) {
      table.displayEquations[names.indexOf("heatingEquipment")] = '=IF(AND([Equipment Zoning]@Heating Equipment<>@Central Equipment,[Equipment Zoning]@Heating Equipment<>[Equipment Zoning]@Reheat Coil),[Equipment Zoning]@Heating Equipment,"")';
    }
    independentTables.push(table);
  });
}

independentTables.forEach((table) => {
  if (table.thermalTemplateCalculation || table.id.startsWith("calc-")) {
    table.headers.forEach((header, column) => {
      if (header.label === "Type" || (table.thermalTemplateCalculation && column === 0)) {
        header.label = "Thermal Template";
        if (!table.thermalTemplateCalculation) { table.headerLinks ||= {}; table.headerLinks[column] = "iesve-thermal-template"; }
      }
    });
    Object.entries(table.displayEquations || {}).forEach(([column, equation]) => {
      table.displayEquations[column] = equation.replace(/@Type\b/g, "@Thermal Template");
    });
  }
});


function configureEquipmentAirflows() {
  const headers = [
    {label:"Tag"}, {label:"Maximum Airflow",unit:"CFM"}, {label:"Minimum Occupied Airflow",unit:"CFM"},
    {label:"Minimum Unoccupied Airflow",unit:"CFM"}, {label:"Design Airflow",unit:"CFM"}, {label:"Design Airflow",unit:"CFM"},
    {label:"Maximum Airflow",unit:"CFM"}, {label:"Minimum Occupied Airflow",unit:"CFM"}, {label:"Minimum Unoccupied Airflow",unit:"CFM"}
  ];
  const groups = [{label:"Equipment",start:0,span:1},{label:"Supply",start:1,span:3},
    {label:"Cooling",start:4,span:1,className:"sensible-cooling-header"}, {label:"Heating",start:5,span:1,className:"heating-load-header"},
    {label:"Return/Exhaust",start:6,span:3}];
  const table = {id:"airside-airflows",name:"Airflows",standard:"Airflows",sheet:"Airside",range:"Airflows",
    description:"Equipment airflows aggregated from space air balances and peak cooling and heating demands.",
    headers,columns:headers.map((h,i)=>`${groups.find(g=>i>=g.start&&i<g.start+g.span).label} ${h.label}`),
    rows:[],columnTypes:["text",...Array(8).fill("number")],lockedColumns:[0],identityColumns:[0],calculatedColumns:[2,3,4,5,7,8],autoColumns:[1,6],
    frozenColumns:1,fixedRows:true,readonlyEquations:true,airsideSection:true,equipmentAirflowsCalculation:true,
    zeroDecimalColumns:[1,2,3,4,5,6,7,8],displayZeroAsDash:true,summaryColumns:[1,2,3,4,5,6,7,8],
    sectionStartColumns:[1,4,5,6],headerGroups:groups,headerClasses:{4:"sensible-cooling-header",5:"heating-load-header"},
    headerLinks:{0:"airside-settings"},displayEquations:{},schemaVersion:1};
  for (let c=1;c<9;c++) table.displayEquations[c] = equipmentAirflowEquation(c);
  independentTables.push(table);
  const section=modules.find(m=>m.items.some(i=>i[3]==="airside-settings"));
  section.items.splice(section.items.findIndex(i=>i[3]==="airside-settings")+1,0,["Airflows","Airside · Airflows",table.description,table.id]);
}
configureEquipmentAirflows();

function expandedAirflowWords(text) {
  return String(text).replace(/\bmin\b(?!\s*\()/gi,"Minimum").replace(/\bmax\b(?!\s*\()/gi,"Maximum");
}
for(const table of independentTables) {
  table.headers.forEach(h=>h.label=expandedAirflowWords(h.label));
  table.headerGroups?.forEach(g=>g.label=expandedAirflowWords(g.label));
  if(table.displayEquations)for(const [c,eq] of Object.entries(table.displayEquations))table.displayEquations[c]=expandedAirflowWords(eq);
  if(table.coilCalculation) {
    const kind=table.coilCalculation;
    const columns=kind==="preheat"?[9]:kind==="ventilation-cooling"?[20,29,38]:kind==="room-air-cooling"?[38]:kind==="room-air-heating"?[15]:[9];
    const field=["preheat","ventilation-cooling"].includes(kind)?"Maximum Supply Airflow":kind==="room-air-cooling"?"Design Cooling Airflow":"Design Heating Airflow";
    columns.forEach(c=>{
      if(!table.calculatedColumns.includes(c))table.calculatedColumns.push(c);
      table.autoColumns=(table.autoColumns||[]).filter(a=>a!==c);
      table.displayEquations[c]=kind==="in-unit-reheat" ? '=IF([Airflows]@Design Heating Airflow="",[Airflows]@Maximum Supply Airflow,[Airflows]@Design Heating Airflow)' : `=[Airflows]@${field}`;
      table.headerLinks ||= {};table.headerLinks[c]="airside-airflows";
    });
  }
}

function configureLatestTables() {
  const settings=independentTables.find(t=>t.id==="airside-settings");
  settings.hiddenColumns=[...new Set([...(settings.hiddenColumns||[]),2])];settings.frozenColumns=2;settings.identityColumns=[0,1];
  const cooling=independentTables.find(t=>t.id==="cooling-plant");cooling.hiddenColumns=[...new Set([...(cooling.hiddenColumns||[]),7])];
  const af=independentTables.find(t=>t.equipmentAirflowsCalculation);af.headerLinks[4]="calc-peak-airflows";af.headerLinks[5]="calc-peak-airflows";
  const ex=independentTables.find(t=>t.exhaustRequirementsCalculation);
  ex.headers[5].label="Different Valve Maximum";ex.headers[6].label="Different Valve Minimum";
  ex.headers.splice(7,0,{label:"Same Valve/Equipment Maximum",unit:"CFM"},{label:"Same Valve/Equipment Minimum",unit:"CFM"});
  ex.columns=ex.headers.map(h=>`${h.label}${h.unit?` (${h.unit})`:""}`);ex.columnTypes=ex.headers.map((_,i)=>i<3?"text":"number");
  ex.rows=ex.rows.map(r=>[...r.slice(0,7),0,0,...r.slice(7)]);ex.schemaVersion=4;
  ex.calculatedColumns=[0,1,...Array.from({length:11},(_,i)=>i+3)];ex.zeroDecimalColumns=ex.summaryColumns=Array.from({length:11},(_,i)=>i+3);
  ex.sectionStartColumns=[3,9,11];
  ex.headerClasses=Object.fromEntries(ex.headers.map((_,i)=>[i,i<3?"space-group-header":"exhaust-header"]));
  ex.headerLinks={0:"calc-equipment-zoning",1:"calc-equipment-zoning",...Object.fromEntries([3,4,5,6,7,8].map(i=>[i,"selected-exhaust-equipment"])),9:"selected-general-exhaust",10:"selected-general-exhaust"};
  ex.displayEquations=Object.fromEntries(Object.entries(ex.displayEquations).map(([c,e])=>[Number(c)>=7?Number(c)+2:c,e.replaceAll("Task/Hood Valves","Different Valve").replaceAll("Task/Hood Exhaust Valve","Same Exhaust Valve").replaceAll("@On","@Maximum").replaceAll("@Off","@Minimum")]));
  for(const [c,flow] of [[7,"Maximum"],[8,"Minimum"]])ex.displayEquations[c]=`=SUMIFS([Exhaust Equipment Requirements]@${flow},[Exhaust Equipment Requirements]@Space,@Space,[Exhaust Equipment Requirements]@Same Exhaust Valve,@General Exhaust Valve,[Exhaust Equipment Requirements]@Exhaust Equipment,@Exhaust Equipment)`;
  ex.displayEquations[11]="=MAX(@Separate Equipment Maximum+@Different Valve Maximum+@Same Valve/Equipment Maximum,@General Occupied)";
  ex.displayEquations[12]="=MAX(@Separate Equipment Minimum+@Different Valve Minimum+@Same Valve/Equipment Minimum,@General Occupied)";
  ex.displayEquations[13]="=MAX(@Separate Equipment Minimum+@Different Valve Minimum+@Same Valve/Equipment Minimum,@General Unoccupied)";
  const req=independentTables.find(t=>t.equipmentExhaustCalculation);req.headers[2].label="Same Exhaust Valve";req.headers[5].label="Maximum";req.headers[6].label="Minimum";
  const schedule=independentTables.find(t=>t.id==="schedule-exhaust-equipment");
  schedule.headers[0].label="Equipment";schedule.headers[1]={label:"Maximum",unit:"CFM"};schedule.headers[2]={label:"Minimum",unit:"CFM"};
  for(const t of independentTables) {
    for(const d of Object.values(t.dropdownColumns||{}))if(d.options?.some(v=>String(v).toUpperCase()==="TRUE") && d.options.every(v=>["TRUE","FALSE",""].includes(String(v).toUpperCase())))d.options=["","TRUE"];
    for(const [c,e] of Object.entries(t.displayEquations||{}))t.displayEquations[c]=e.replaceAll("Task/Hood Exhaust Valve","Same Exhaust Valve").replaceAll("[Exhaust Equipment Requirements]@On","[Exhaust Equipment Requirements]@Maximum").replaceAll("[Exhaust Equipment Requirements]@Off","[Exhaust Equipment Requirements]@Minimum").replaceAll("[Exhaust Equipment Schedule]@On","[Exhaust Equipment Schedule]@Maximum").replaceAll("[Exhaust Equipment Schedule]@Off","[Exhaust Equipment Schedule]@Minimum");
  }
  [6,7,8].forEach(c=>af.displayEquations[c]=equipmentReturnEquation(c));
}
configureLatestTables();

function configureRevision24() {
  const af=independentTables.find(t=>t.equipmentAirflowsCalculation);
  af.headerGroups[0].label="General";af.headers[0].label="Equipment";af.columns[0]="Equipment";af.summaryColumns=[];
  for(const [c,e] of Object.entries(af.displayEquations))af.displayEquations[c]=e.replaceAll("@Tag","@Equipment");
  const req=independentTables.find(t=>t.equipmentExhaustCalculation);req.headers[2].label="Exhaust Valve";req.columns[2]="Exhaust Valve";
  for(const t of independentTables)for(const [c,e] of Object.entries(t.displayEquations||{}))t.displayEquations[c]=e.replaceAll("Same Exhaust Valve","Exhaust Valve");
  for(const t of independentTables.filter(t=>t.coilCalculation))for(const [c,e] of Object.entries(t.displayEquations||{}))t.displayEquations[c]=e.replaceAll("@Leaving Sensible Constant *","@Entering Sensible Constant *").replaceAll("@Leaving Latent Constant *","@Entering Latent Constant *");
  for(const t of independentTables.filter(t=>t.coilCalculation))t.calculatedColumns=t.calculatedColumns.filter(c=>!t.autoColumns?.includes(c));
  const latent=independentTables.find(t=>t.id==="calc-latent-loads");
  const headers=[['Space'],['Space Load','MBH'],['Space Hum-Ratio','lb/lb'],['Ventilation Equipment'],['Equipment Dry-Bulb','°F'],['Equipment Hum-Ratio','lb/lb'],['Equipment Latent Constant'],['Airflow','CFM'],['Latent Contribution','MBH'],['Primary Cooling Equipment'],['Equipment Dry-Bulb','°F'],['Equipment Hum-Ratio','lb/lb'],['Equipment Latent Constant'],['Airflow','CFM'],['Latent Contribution','MBH'],['Remaining Latent Load','MBH'],['Required Dehumidification Dry-Bulb','°F']].map(([label,unit])=>({label,unit}));
  Object.assign(latent,{name:'Latent Loads',standard:'Latent Loads',description:'Space latent load, equipment contributions and required ventilation dehumidification.',headers,columns:headers.map(h=>h.label),columnTypes:headers.map((_,c)=>[0,3,9].includes(c)?'text':'number'),rows:latent.rows.map(r=>[r[0],...Array(16).fill('')]),schemaVersion:2,spaceColumn:0,frozenColumns:1,identityColumns:[0],lockedColumns:[0],calculatedColumns:Array.from({length:16},(_,c)=>c+1),readonlyEquations:true,preserveImportedValues:false,latentLoadCalculation:true,displayZeroAsDash:true,headerGroups:[],headerClasses:Object.fromEntries(headers.map((_,c)=>[c,c?'latent-cooling-header':'space-group-header'])),sectionStartColumns:[1,3,9,15],summaryColumns:[1,7,8,13,14,15],zeroDecimalColumns:[7,13],oneDecimalColumns:[4,10,16],threeDecimalColumns:[1,8,14,15],fiveDecimalColumns:[2,5,11],decimalColumns:[6,12],headerLinks:{1:'calc-room-loads',2:'calc-space-condition-setpoints',3:'airside-ventilation-cooling',9:'airside-room-cooling'},formulaScopes:{Ventilation:[3,9], 'Primary Cooling':[9,15]}});
  latent.displayEquations={
    1:'=[Space Loads]@[Cooling Latent Load]',2:'=[Space Condition Setpoints]@[Cooling Hum-Ratio]',
    3:'=IF(COUNTIF([Ventilation Cooling Coils]@Equipment,[Equipment Zoning]@Ventilation Equipment)>0,[Equipment Zoning]@Ventilation Equipment,"-")',
    4:'=XLOOKUP(@Ventilation Equipment,[Ventilation Cooling Coils]@Equipment,[Ventilation Cooling Coils]@[Minimum Dry-Bulb],"")',
    5:'=XLOOKUP(@Ventilation Equipment,[Ventilation Cooling Coils]@Equipment,[Ventilation Cooling Coils]@[Dehumidification Hum-Ratio],"")',
    6:'=XLOOKUP(@Ventilation Equipment,[Ventilation Cooling Coils]@Equipment,[Ventilation Cooling Coils]@[Dehumidification Latent Constant],"")',
    7:'=IF(@Ventilation Equipment="-","",IF(@Ventilation Equipment=[Equipment Zoning]@Central Equipment,[Peak Airflows]@[Primary Cooling Peak],[Air Balancing Requirements]@Ventilation))',
    8:'=[Ventilation]@Equipment Latent Constant * [Ventilation]@Airflow * (@Space Hum-Ratio - [Ventilation]@Equipment Hum-Ratio) / 1000',
    9:'=IF(@Ventilation Equipment=[Equipment Zoning]@Central Equipment,"-",IF([Equipment Zoning]@Cooling Equipment<>"",[Equipment Zoning]@Cooling Equipment,IF([Equipment Zoning]@Supply Air Valve<>"",[Equipment Zoning]@Supply Air Valve,IF([Equipment Zoning]@Central Equipment<>"",[Equipment Zoning]@Central Equipment,"-"))))',
    10:'=XLOOKUP(@Primary Cooling Equipment,[Room Air Cooling Coils]@Equipment,[Room Air Cooling Coils]@[Leaving Dry-Bulb],"")',
    11:'=XLOOKUP(@Primary Cooling Equipment,[Room Air Cooling Coils]@Equipment,[Room Air Cooling Coils]@[Leaving Hum-Ratio],"")',
    12:'=XLOOKUP(@Primary Cooling Equipment,[Room Air Cooling Coils]@Equipment,[Room Air Cooling Coils]@[Leaving Latent Constant],"")',
    13:'=IF(@Primary Cooling Equipment="-","",[Peak Airflows]@[Primary Cooling Peak])',
    14:'=[Primary Cooling]@Equipment Latent Constant * [Primary Cooling]@Airflow * (@Space Hum-Ratio - [Primary Cooling]@Equipment Hum-Ratio) / 1000',
    15:'=MAX(0,@Space Load - [Ventilation]@Latent Contribution - [Primary Cooling]@Latent Contribution)',
    16:'=IF(AND(@Remaining Latent Load>0,[Ventilation]@Airflow>0,[Ventilation]@Equipment Latent Constant>0),IFERROR(LET(HR,@Space Hum-Ratio-([Ventilation]@Latent Contribution+@Remaining Latent Load)*1000/([Ventilation]@Equipment Latent Constant*[Ventilation]@Airflow),VP,HR*[Model Inputs]@Barometric Pressure/(0.621945+HR),satVP,VP/XLOOKUP(@Ventilation Equipment,[Ventilation Cooling Coils]@Equipment,[Ventilation Cooling Coils]@[Dehumidification Rel-Hum]),alpha,LN(satVP/(0.145038*0.61094)),DBC,243.04*alpha/(17.625-alpha),ROUNDDOWN(DBC*9/5+32,1)),""),"")'
  };
  for(const m of modules)for(const item of m.items)if(item[3]===latent.id)item[0]='Latent Loads';
  const vent=independentTables.find(t=>t.id==='airside-ventilation-cooling');
  vent.calculatedColumns=[...new Set([...vent.calculatedColumns,1,2])];vent.headerLinks[1]=vent.headerLinks[2]=latent.id;
  vent.displayEquations[1]='=SUMIF([Latent Loads]@Ventilation Equipment,@Equipment,[Latent Loads]@Remaining Latent Load)';
  vent.displayEquations[2]='=IFERROR(MIN(FILTER([Latent Loads]@Required Dehumidification Dry-Bulb,([Latent Loads]@Ventilation Equipment=@Equipment)*ISNUMBER([Latent Loads]@Required Dehumidification Dry-Bulb))),"")';
}
configureRevision24();


function configureRevision25() {
  const latent=independentTables.find(t=>t.latentLoadCalculation);
  latent.name=latent.standard='Latent Cooling Requirements';latent.threeDecimalColumns=[];latent.decimalColumns=[1,8,14,15];latent.zeroDecimalColumns=[6,7,12,13];latent.summaryColumns=[1,3,7,8,9,13,14,15];latent.summaryAggregations={3:'unique-count',9:'unique-count'};
  Object.assign(latent.headerLinks,{3:'calc-equipment-zoning',4:'airside-ventilation-cooling',5:'airside-ventilation-cooling',6:'airside-ventilation-cooling',7:'calc-peak-airflows',9:'calc-equipment-zoning',10:'airside-room-cooling',11:'airside-room-cooling',12:'airside-room-cooling',13:'calc-peak-airflows'});
  for(const m of modules)for(const item of m.items)if(item[3]===latent.id)item[0]=latent.name;
  for(const t of independentTables)for(const [c,e] of Object.entries(t.displayEquations||{}))t.displayEquations[c]=e.replaceAll('[Latent Loads]','[Latent Cooling Requirements]');
  const af=independentTables.find(t=>t.equipmentAirflowsCalculation);
  for(let c=1;c<=8;c++)af.displayEquations[c]=`=(${af.displayEquations[c].replace(/^=/,'')}) * XLOOKUP(@Equipment,[Settings]@Equipment,[Settings]@Load Percentage,1)`;
  const t=independentTables.find(t=>t.id==='calc-condition-baseline');
  const headers=[['Zone Group'],['Space'],['Thermal Template'],['Area','ft2'],['Sensible Cooling','MBH'],['Latent Cooling','MBH'],['Sensible Heating','MBH'],['Cooling Relative','Btu/h-ft2'],['Heating Relative','Btu/h-ft2'],['Indirectly Conditioned Space'],['Condition Type'],['System Type']].map(([label,unit])=>({label,unit}));
  Object.assign(t,{name:'Condition Type & Baseline System',standard:'Condition Type & Baseline System',description:'Classify space conditions and assign baseline systems.',headers,columns:headers.map(h=>h.label),columnTypes:headers.map((_,i)=>i>=3&&i<=8?'number':'text'),rows:t.rows.map(r=>['',r[0],'','',0,0,0,0,0,r[8]===true||String(r[8]).toUpperCase()==='TRUE'?'TRUE':'',r[10],r[11]||'']),schemaVersion:25,conditionBaselineCalculation:true,preserveImportedValues:false,spaceColumn:1,frozenColumns:4,identityColumns:[0,1,2],lockedColumns:[0,1,2],calculatedColumns:[3,4,5,6,7,8,10],autoColumns:[11],decimalColumns:[4,5,6,7,8],zeroDecimalColumns:[3],summaryColumns:[3,4,5,6],displayZeroAsDash:true,headerGroups:[{label:'General',start:0,span:4},{label:'Space Condition Type',start:4,span:7},{label:'Baseline',start:11,span:1}],sectionStartColumns:[4,11],headerClasses:{4:'sensible-cooling-header',5:'latent-cooling-header',6:'heating-load-header',7:'sensible-cooling-header',8:'heating-load-header'},headerLinks:{2:'iesve-thermal-template',4:'calc-peak-airflows',5:latent.id,6:'calc-peak-airflows',11:'model-inputs'},dropdownColumns:{9:{options:['','TRUE']},11:{options:[]}}});
  t.equations={};t.displayEquations={0:'=[Equipment Zoning]@Zone Group',2:'=[Tabular Space Data]@Thermal Template',3:'=[Tabular Space Data]@Floor Area',4:'=[Peak Airflows]@Primary Cooling Sensible Contribution',5:'=[Latent Cooling Requirements]@[Ventilation Latent Contribution]+[Latent Cooling Requirements]@[Primary Cooling Latent Contribution]',6:'=[Peak Airflows]@Primary Heating Sensible Contribution+[Peak Airflows]@Secondary Heating Sensible Contribution',7:'=IFERROR(1000*(@Sensible Cooling+@Latent Cooling)/@Area,0)',8:'=IFERROR(1000*@Sensible Heating/@Area,0)',10:'=IF(OR(@Cooling Relative>=[Cooled Space Relative Bound],@Heating Relative>[Heated Space Relative Bound],@Indirectly Conditioned Space=TRUE),"Conditioned",IF(@Heating Relative>=[Semi-Heated Space Relative Bound],"Semi-Heated","Unconditioned"))',11:'=[Model Inputs]@Number & " - " & [Model Inputs]@System'};
  for(const m of modules)for(const item of m.items)if(item[3]===t.id)item[0]=t.name;
  const energy=modules.find(m=>m.group==='Energy');energy.group='Energy Analysis';
  energy.items=[['Energy Simulations Summary','Energy Analysis','Compare annual proposed and baseline energy totals.','energy-summary']];
  const summaryHeaders=[['Simulation'],['Electricity','MMBtu'],['Natural Gas','MMBtu'],['Total Energy','MMBtu'],['Electricity','kWh'],['Natural Gas','therms']].map(([label,unit])=>({label,unit}));
  independentTables.push({id:'energy-summary',name:'Energy Simulations Summary',standard:'Energy Analysis',headers:summaryHeaders,columns:summaryHeaders.map(h=>h.label),columnTypes:['text',...Array(5).fill('number')],rows:['Proposed','Baseline 000deg','Baseline 090deg','Baseline 180deg','Baseline 270deg','Average Baseline'].map(x=>[x,...Array(5).fill('')]),energySummary:true,calculatedColumns:[1,2,3,4,5],lockedColumns:[0],identityColumns:[0],frozenColumns:1,fixedRows:true,summaryColumns:[],decimalColumns:[1,2,3,4,5],readonlyEquations:true,displayZeroAsDash:true,displayEquations:{3:'=@[Electricity [MMBtu]] + @[Natural Gas [MMBtu]]',4:'=@[Electricity [MMBtu]] * 1000000 / 3412.141633',5:'=@[Natural Gas [MMBtu]] * 10'}});
  for(const [suffix,name] of [['proposed','Proposed'],['baseline-000','Baseline 000deg'],['baseline-090','Baseline 090deg'],['baseline-180','Baseline 180deg'],['baseline-270','Baseline 270deg']]) {
    const id='energy-'+suffix;independentTables.push({id,name:name+' Simulation',standard:name+' Simulation',headers:[{label:'Date'}],columns:['Date'],columnTypes:['text'],rows:[],energySimulation:true,fixedRows:true,lockedColumns:[0],calculatedColumns:[],identityColumns:[0],frozenColumns:1,summaryColumns:[],forceSummary:true,summaryLabel:'Summed Totals',readonlyEquations:true});
    energy.items.push([name+' Simulation','Energy Analysis','Paste simulation energy results.',id]);
  }
}
configureRevision25();

function conditionBaselineDefaults(project) {
  const model={...modelInputDefaults,...project.modelInputs},climate=independentTables.find(t=>t.id==='ashrae-climate-zones'),systems=independentTables.find(t=>t.id==='ashrae-90-1-baseline-systems');
  const climates=ensureProjectTableRows(project,climate),systemRows=ensureProjectTableRows(project,systems),r=climates.find(r=>String(r[0])===String(model.climateZone));
  let c=climate.headers.findIndex(h=>h.label===model.baselineBuildingType);if(c<2||c>9)c=8;
  const number=r?.[c]??'',system=systemRows.find(s=>String(s[0])===String(number));
  return {cooling:3.4,heating:r?.[10]??'',semiheated:3.4,number,system:system?.[1]||'',baseline:system?`${number} - ${system[1]}`:'',options:systemRows.map(s=>`${s[0]} - ${s[1]}`)};
}
function recalculateConditionBaseline(table,rows,project) {
  refreshLatentLoads(project);
  const get=id=>ensureProjectTableRows(project,independentTables.find(t=>t.id===id));
  const peaks=new Map(get('calc-peak-airflows').map(r=>[requirementKey(r[0]),r])),latents=new Map(get('calc-latent-loads').map(r=>[requirementKey(r[0]),r])),zones=new Map(get('calc-equipment-zoning').map(r=>[requirementKey(r[2]),r]));
  const d=conditionBaselineDefaults(project);project.baselineSystemAutos ||= {};project.baselineSystemOverrides ||= {};table.autoCellStates=new Map();
  rows.forEach((r,i)=>{const key=requirementKey(r[1]),p=peaks.get(key)||[],l=latents.get(key)||[],z=zones.get(key)||[],meta=tabularMetadata(project,r[1])||{};
    r[0]=z[0]||'';r[2]=meta.type||'';r[3]=requirementNumber(meta.area);r[4]=requirementNumber(p[5]);r[5]=requirementNumber(l[8])+requirementNumber(l[14]);r[6]=requirementNumber(p[11])+requirementNumber(p[18]);r[7]=r[3]>0?1000*(r[4]+r[5])/r[3]:0;r[8]=r[3]>0?1000*r[6]/r[3]:0;
    r[9]=String(r[9]).toUpperCase()==='TRUE'?'TRUE':'';
    r[10]=r[7]>=d.cooling||(d.heating!==''&&r[8]>Number(d.heating))||r[9]==='TRUE'?'Conditioned':r[8]>=d.semiheated?'Semi-Heated':'Unconditioned';
    if(!Object.hasOwn(project.baselineSystemAutos,key)&&r[11]&&r[11]!==d.baseline)project.baselineSystemOverrides[key]=r[11];
    project.baselineSystemAutos[key]=d.baseline;
    if(Object.hasOwn(project.baselineSystemOverrides,key))r[11]=project.baselineSystemOverrides[key];else {r[11]=d.baseline;table.autoCellStates.set(i,new Set([11]));}
  });
}
function wetBulbGrid(dryBulb,hr,pressure) {
  if(!Number.isFinite(dryBulb)||!Number.isFinite(hr)||!Number.isFinite(pressure)||pressure<=0||dryBulb< -50)return '';
  const n=Math.round((dryBulb+50)*10)+1;if(n>100000)return '';
  let result=-50,error=Infinity;
  for(let i=0;i<n;i++){const wb=-50+i*0.1,tr=wb+459.67,pws=Math.exp(wb>=32?-10440.397/tr-11.29465-.027022355*tr+.00001289036*tr**2-.0000000024780681*tr**3+6.5459673*Math.log(tr):-10214.165/tr-4.8932428-.0053765794*tr+.00000019202377*tr**2+.00000000035575832*tr**3-9.0344688e-14*tr**4+4.1635019*Math.log(tr));
    const ws=.621945*pws/(pressure-pws),w=wb>=32?((1093-.556*wb)*ws-.24*(dryBulb-wb))/(1093+.444*dryBulb-wb):((1220-.04*wb)*ws-.24*(dryBulb-wb))/(1220+.444*dryBulb-.48*wb),e=Math.abs(w-hr);if(e<error){error=e;result=wb;}
  }return Math.round(result*10)/10;
}
function tableOrderKey(table,row,index,project) {
  if(table.spaceColumn!==undefined&&!table.id.startsWith('selected-'))return 'space:'+requirementKey(row[table.spaceColumn]);
  if(table.airsideSection||table.energySummary)return 'name:'+requirementKey(row[0]);
  project.tableRowIds ||= {};const ids=project.tableRowIds[table.id] ||= [];return ids[index] ||= `row:${crypto.randomUUID()}`;
}
function orderTableRows(table,sourceRows,rows,project) {
  if(table.psychCalculation||table.equipmentScheduleCalculation)return;
  if(table.energySimulation||table.energySummary)return rows;
  if(!project)return rows;project.tableViewOrders ||= {};
  const state=project.tableViewOrders[table.id] ||= {column:table.energySummary?-1:0,direction:'asc',order:[]};
  const all=sourceRows.map((row,sourceIndex)=>({row,sourceIndex,key:tableOrderKey(table,row,sourceIndex,project)}));
  if(state.column>=0)all.sort((a,b)=>compareTableValues(a.row[state.column],b.row[state.column])*(state.direction==='desc'?-1:1));
  else {const rank=new Map(state.order.map((k,i)=>[k,i]));all.sort((a,b)=>(rank.get(a.key)??Infinity)-(rank.get(b.key)??Infinity));}
  state.order=all.map(x=>x.key);const rank=new Map(all.map((x,i)=>[x.sourceIndex,i]));rows.sort((a,b)=>rank.get(a.sourceIndex)-rank.get(b.sourceIndex));tableSort={tableId:table.id,column:state.column,direction:state.direction};
  return rows;
}
function releaseTableSort(table,project) {
  if(!project?.tableViewOrders)return;
  // Retain every table's established order when a source changes its calculated values.
  for(const state of Object.values(project.tableViewOrders))state.column=-1;
  if(tableSort.tableId===table.id)tableSort.column=-1;
}

function configureEnergyColumns(table,project) {
  const saved=project?.energyImports?.[table.id];const headers=saved?.headers||[{label:'Date'}];
  const imported=project?.independentTables?.[table.id];if(imported?.length&&/^(?:summed\s+)?totals?$|^sum$/i.test(String(imported.at(-1)[0]).trim()))imported.pop();
  table.headers=headers.map(h=>({...h}));table.columns=headers.map(h=>h.label);table.columnTypes=headers.map((_,i)=>i?'number':'text');table.calculatedColumns=headers.map((_,i)=>i).slice(1);table.summaryColumns=[...table.calculatedColumns];table.decimalColumns=[...table.calculatedColumns];table.headerGroups=[];
}
function parseEnergyClipboard(text) {
  const grid=CsvTools.parseClipboard(String(text));while(grid.length&&grid.at(-1).every(v=>!String(v).trim()))grid.pop();
  if(grid.length<5)throw Error('Paste the complete simulation table, including its header, blank line, Date/file row, data and totals row.');
  if(grid[1].some(v=>String(v).trim()))throw Error('The second row must be empty.');
  const titles=grid[0].slice(1).map(x=>String(x).trim());if(!titles.length||titles.some(x=>!x))throw Error('Each simulation data column needs a header.');
  const headers=[{label:'Date'},...titles.map(title=>{const m=title.match(/^(.*?)\s*\(([^)]+)\)\s*$/);return {label:m?m[1].trim():title,unit:m?(m[2].toLowerCase()==='mbtu'?'MMBtu':m[2]):undefined};})];
  if(new Set(headers.map(h=>h.label.toLowerCase())).size!==headers.length)throw Error('The pasted simulation has duplicate column names.');
  if(String(grid[2]?.[0]).trim().toLowerCase()!=='date')throw Error('The third row must start with Date and contain the simulation filename.');
  if(grid[2].length!==headers.length||grid[2].slice(1).some(v=>!String(v).trim()))throw Error('Missing simulation file values.');
  if(grid.at(-1).length!==headers.length)throw Error('The totals row has the wrong number of columns.');
  const files=[...new Set(grid[2].slice(1).map(x=>String(x).trim()).filter(Boolean))];
  const rows=[];
  for(let i=3;i<grid.length-1;i++){const r=grid[i];if(r.every(x=>!String(x).trim()))continue;
    if(r.length!==headers.length)throw Error(`Row ${i+1} has ${r.length} columns; expected ${headers.length}.`);
    if(!String(r[0]).trim())throw Error(`Row ${i+1} is missing a date.`);
    rows.push(r.map((v,c)=>{if(!c)return String(v).trim();const text=String(v).trim();if(!text)return '';if(text==='-')return 0;const n=Number(text.replace(/,/g,'').replace(/^\((.*)\)$/,'-$1'));if(!Number.isFinite(n))throw Error(`Row ${i+1}, ${headers[c].label} is not a number.`);return n;}));
  }
  if(!rows.length)throw Error('The simulation contains no data rows.');
  return {headers,rows,simulationFile:files.join(', ')};
}
function importEnergyClipboard(table,text,project=activeProject()) {
  const parsed=parseEnergyClipboard(text);project.energyImports ||= {};project.independentTables ||= {};
  project.energyImports[table.id]={headers:parsed.headers,simulationFile:parsed.simulationFile,uploadedAt:new Date().toISOString()};
  project.independentTables[table.id]=parsed.rows;
  if(project.tableViewOrders)delete project.tableViewOrders[table.id];if(project.tableRowIds)delete project.tableRowIds[table.id];
  configureEnergyColumns(table,project);saveProjects();renderReferenceTable(table.id,'');
}
function energySimulationTotals(project,id) {
  const meta=project.energyImports?.[id],rows=project.independentTables?.[id]||[];
  const total=name=>{const c=meta?.headers.findIndex(h=>h.label.trim().toLowerCase()===name.toLowerCase()&&String(h.unit).toLowerCase()==='mmbtu')??-1;return c<0?'':rows.reduce((n,r)=>n+requirementNumber(r[c]),0);};
  return [total('Electricity'),total('Natural Gas')];
}
function recalculateEnergySummary(table,rows,project) {
  const ids=['energy-proposed','energy-baseline-000','energy-baseline-090','energy-baseline-180','energy-baseline-270'];for(const id of ids)configureEnergyColumns(independentTables.find(t=>t.id===id),project);
  const totals=ids.map(id=>energySimulationTotals(project,id));
  const average=[0,1].map(c=>totals.slice(1).every(r=>r[c]!=='')?totals.slice(1).reduce((n,r)=>n+r[c],0)/4:'');
  const ordered=[['Proposed',totals[0],ids[0]],['Average Baseline',average,null],...ids.slice(1).map((id,i)=>[`Baseline ${['000','090','180','270'][i]}deg`,totals[i+1],id])];
  table.cellDisplayEquations=new Map();table.mutedCellStates=new Map();rows.splice(0,rows.length,...ordered.map(([label,v])=>[label,v[0],v[1],v.every(x=>x!=='')?v[0]+v[1]:'',v[0]===''?'':v[0]*1000000/3412.141633,v[1]===''?'':v[1]*10]));
  ordered.forEach(([label,values,id],i)=>{const equations=new Map();for(const c of [1,2]){const fuel=table.headers[c].label;equations.set(c,id?`=XLOOKUP("${fuel}",[${independentTables.find(t=>t.id===id).name}]@Headers,[${independentTables.find(t=>t.id===id).name}]@Summed Totals)`:`=AVERAGE(SUM([Baseline 000deg Simulation]@${fuel}),SUM([Baseline 090deg Simulation]@${fuel}),SUM([Baseline 180deg Simulation]@${fuel}),SUM([Baseline 270deg Simulation]@${fuel}))`);}table.cellDisplayEquations.set(i,equations);});
}

function addIesveConstructionNote(section) {
  const heading=section.querySelector('h2,h3,legend');if(!heading)return;
  const note=document.createElement('small');note.className='iesve-set-marker';note.textContent=' [set values in IESVE]';heading.appendChild(note);
}
function showRevisionMetric(node,equation,values={}) {
  selectStandaloneControl(node);clearCsvComparison();selectedAutoRestore=null;
  selectedEquationContext={equation,values,model:true};selectedEquation.value=equation;displayFormulaFunctions(equation);editEquationButton.hidden=true;formulaBar.hidden=false;
}
function renderRevision25Controls(table,rows) {
  document.querySelectorAll('.revision25-controls').forEach(n=>n.remove());
  if(!table.conditionBaselineCalculation&&!table.energySummary&&!table.energySimulation)return;
  const project=activeProject(),bar=document.createElement('div');bar.className='revision25-controls';
  if(table.conditionBaselineCalculation)document.querySelector('.table-toolbar').before(bar);else if(table.energySimulation){bar.classList.add('energy-import-controls');document.querySelector('.table-toolbar').appendChild(bar);}else {bar.classList.add('energy-summary-controls');tableScroll.parentElement.insertBefore(bar,tableScroll);}
  const metric=(label,value,equation,values={},state='')=>{const node=document.createElement('button');node.type='button';node.className='revision-metric '+state;const caption=document.createElement('span'),output=document.createElement('output');caption.textContent=label;output.textContent=value;if(label)node.appendChild(caption);node.appendChild(output);node.addEventListener('click',()=>showRevisionMetric(node,equation,values));bar.appendChild(node);return node;};
  if(table.conditionBaselineCalculation){const d=conditionBaselineDefaults(project);
    metric('Cooled Space Relative Bound',d.cooling,'=3.4');
    metric('Heated Space Relative Bound',d.heating,'=XLOOKUP([Model Inputs]@Climate Zone,[Climate Zones and Baseline Systems]@Climate Zone,[Climate Zones and Baseline Systems]@Heated Space Criteria)');
    metric('Semi-Heated Space Relative Bound',d.semiheated,'=3.4');
  }
  if(table.conditionBaselineCalculation)bar.querySelectorAll('output').forEach(output=>{output.append(' Btu/h-ft');const sup=document.createElement('sup');sup.textContent='2';output.appendChild(sup);});
  if(table.energySimulation){
    const button=document.createElement('button');button.type='button';button.className='energy-paste-button import-excel-button';button.textContent='Paste values from clipboard…';
    const status=document.createElement('span');status.className='energy-import-status';const upload=project.energyImports?.[table.id];const date=document.createElement('span'),file=document.createElement('span');date.textContent=`Last upload: ${upload?new Date(upload.uploadedAt).toLocaleString():'—'}`;file.textContent=`Simulation file: ${upload?.simulationFile||'—'}`;status.append(date,file);
    const error=document.createElement('span');error.className='energy-import-error';error.setAttribute('role','status');
    button.addEventListener('click',async()=>{try{if(!navigator.clipboard?.readText)throw Error('Press Ctrl+V with this simulation tab open to paste the table.');importEnergyClipboard(table,await navigator.clipboard.readText());}catch(e){showPasteFormatError();}});
    bar.append(status,button,error);
  }
  if(table.energySummary){project.energyAnalysis ||= {};
    const fields=document.createElement('div');fields.className='energy-pci-fields';bar.appendChild(fields);
    for(const [key,label] of [['pci','PCI'],['pciTarget','PCI']]){const field=document.createElement('label');field.className='energy-index-input';const caption=document.createElement('span');caption.textContent=label;if(key==='pciTarget'){const sub=document.createElement('sub');sub.textContent='t';caption.appendChild(sub);}const input=document.createElement('input');input.type='text';input.inputMode='decimal';input.value=project.energyAnalysis[key]??'';input.addEventListener('change',()=>{const value=input.value.trim();if(value!==''&&!Number.isFinite(Number(value))){input.setCustomValidity('Enter a number.');input.reportValidity();return;}input.setCustomValidity('');project.energyAnalysis[key]=value===''?'':Number(value);saveProjects();renderReferenceTable(table.id,'',{skipRecalculation:true});});field.append(caption,input);fields.appendChild(field);}
    const pci=project.energyAnalysis.pci,target=project.energyAnalysis.pciTarget,ready=pci!==undefined&&pci!==''&&target!==undefined&&target!=='',pass=ready&&pci<=target;
    metric('',ready?`The performance cost index\n${pass?'is less than or equal to':'exceeds'}\nthe performance cost index target`:'Enter both index values','=IF(@Performance Cost Index<=@Performance Cost Index Target,TRUE,FALSE)',{'Performance Cost Index':pci??'','Performance Cost Index Target':target??''},ready?(pass?'metric-pass':'metric-fail'):'');
    const proposed=rows[0]?.[3],baseline=rows.find(r=>r[0]==='Average Baseline')?.[3],energyReady=typeof proposed==='number'&&typeof baseline==='number',less=energyReady&&proposed<=baseline;
    metric('',energyReady?`The proposed building's energy consumption\n${less?'is less than or equal to':'exceeds'}\nthe baseline building's energy consumption`:'Import electricity and natural gas for all five simulations','=@Proposed Total Energy <= @Average Baseline Total Energy',{'Proposed Total Energy':proposed??'','Average Baseline Total Energy':baseline??''},energyReady?(less?'metric-pass':'metric-fail'):'');
  }
}

function configureRevision26(){
  delete independentTables.find(t=>t.latentLoadCalculation).headerLinks[7];
  for(const t of independentTables.filter(t=>t.plantCalculation)){
    const ids=t.plantCalculation==='cooling'?['airside-ventilation-cooling','airside-room-cooling']:['airside-preheat','airside-in-unit-reheat','airside-downstream-reheat','airside-room-heating'];
    t.displayEquations[2]='='+ids.map(id=>{const name=independentTables.find(x=>x.id===id).name;return `SUMPRODUCT(([${name}]@Plant=@Plant)*[${name}]@Total Capacity*XLOOKUP([${name}]@Equipment,[Settings]@Equipment,[Settings]@Quantity,1))`;}).join('+');
  }
}
configureRevision26();

function configureRevision27() {
  const summary=independentTables.find(t=>t.energySummary);
  const condition=independentTables.find(t=>t.conditionBaselineCalculation);condition.dropdownColumns[11]={sourceTableId:'ashrae-90-1-baseline-systems',sourceColumns:[0,1],join:' - '};
  summary.standard=summary.name;summary.decimalColumns=[];summary.zeroDecimalColumns=[1,2,3,4,5];summary.sectionStartColumns=[3];
  for(const t of independentTables.filter(t=>t.plantCalculation))t.displayEquations[1]=t.displayEquations[2].replace(/\*\[[^\]]+\]@Total Capacity/g,'');
  const preheat=independentTables.find(t=>t.id==='airside-preheat');
  preheat.headerClasses=Object.fromEntries(preheat.headers.map((_,c)=>[c,c?'preheat-header':'space-group-header']));
  for(const group of preheat.headerGroups||[])if(group.start>0)group.className='preheat-header';
  independentTables.find(t=>t.id==='airside-settings').headerClasses[6]='preheat-header';
  const cooling=independentTables.find(t=>t.id==='airside-ventilation-cooling');
  for(const c of [1,2,3,4,5,6,7,8,24,25,26,27,28,29,30,31,32])cooling.headerClasses[c]='latent-cooling-header';
  for(const group of cooling.headerGroups||[])if([1,24].includes(group.start))group.className='latent-cooling-header';
}
configureRevision27();

function showPasteFormatError(kind='clipboard') {
  let dialog=document.querySelector('#paste-format-error');
  if(!dialog){
    dialog=document.createElement('dialog');dialog.id='paste-format-error';dialog.className='paste-format-error';dialog.setAttribute('aria-labelledby','import-error-title');dialog.setAttribute('aria-describedby','import-error-message');
    dialog.innerHTML='<header><span class="import-error-symbol" aria-hidden="true">!</span><h2 id="import-error-title">Unable to import data</h2><button type="button" class="import-error-close" aria-label="Close">×</button></header><p id="import-error-message"></p><div class="import-error-actions"><button type="button" class="import-error-ok">OK</button></div>';
    dialog.querySelectorAll('button').forEach(button=>button.addEventListener('click',()=>dialog.close()));document.body.appendChild(dialog);
  }
  dialog.querySelector('#import-error-message').textContent=kind==='workbook'?'The selected workbook does not match the expected Room/Zone Loads Report format. Select a valid .xlsx or .xlsm report and try again.':'The clipboard data does not match the expected table format. Copy the complete table, including its headers, and try again.';
  if(!dialog.open)dialog.showModal();dialog.querySelector('.import-error-ok').focus();
}

// Keep source-row identities so a rename can be distinguished from deletion.
function snapshotDropdownReferences(sourceId,changedColumns=null) {
  const snapshots=[];
  for(const table of independentTables)for(const [column,config] of Object.entries(table.dropdownColumns||{})){
    const sources=config.sources||[config];
    if(!sources.some(source=>source.sourceTableId===sourceId&&(!changedColumns||(source.sourceColumns||[source.sourceColumn]).some(c=>changedColumns.includes(c)))))continue;
    const entries=sources.flatMap(source=>{const t=independentTables.find(t=>t.id===source.sourceTableId);return t?projectTableRows(t).map(row=>({row,source,oldValue:dropdownSourceValue(row,source)})):[];});
    snapshots.push({table,column:Number(column),options:new Set(tableDropdownOptions(table,Number(column)).map(requirementKey)),entries});
  }
  const origin=independentTables.find(t=>t.id===sourceId),selected=new Set((activeProject()?.psychChartEquipment||[]).map(requirementKey));snapshots.psychEntries=origin?projectTableRows(origin).flatMap(row=>(changedColumns||row.map((_,c)=>c)).filter(c=>selected.has(requirementKey(row[c]))).map(c=>({row,c,old:row[c]}))):[];
  return snapshots;
}
function dropdownSourceValue(row,source) {
  return String(source.sourceColumns?source.sourceColumns.map(c=>row[c]??'').join(source.join||' '):row[source.sourceColumn]??'');
}
function reconcileRemovedDropdownValues(snapshots,project) {
  for(const {table,column,options,entries=[]} of snapshots){
    const allowed=new Set(tableDropdownOptions(table,column).map(requirementKey)),candidates=new Map();
    for(const entry of entries){const source=independentTables.find(t=>t.id===entry.source.sourceTableId);if(!source||!projectTableRows(source).includes(entry.row))continue;
      const next=dropdownSourceValue(entry.row,entry.source),old=requirementKey(entry.oldValue);
      if(!old||!next.trim()||next===entry.oldValue||!allowed.has(requirementKey(next)))continue;
      if(allowed.has(old)&&old!==requirementKey(next)&&entries.filter(e=>requirementKey(e.oldValue)===old).length>1)continue; // Preserve genuinely ambiguous duplicate choices.
      if(!candidates.has(old))candidates.set(old,new Set());candidates.get(old).add(next);
    }
    const renames=new Map([...candidates].filter(([,values])=>values.size===1).map(([key,values])=>[key,[...values][0]]));
    const removed=new Set([...options].filter(value=>!allowed.has(value)));if(!removed.size&&!renames.size)continue;
    const rows=ensureProjectTableRows(project,table);let changed=false;
    rows.forEach((row,index)=>{
      const keyValue=requirementKey(row[column]);if(!removed.has(keyValue)&&!renames.has(keyValue))return;
      const replacement=renames.get(keyValue)??'';
      for(const record of [recordZoningOverride,recordNetworkZoningOverride,recordAirsideOverride,recordCoilOverride,recordPlantOverride,recordPressurizationOverride,recordScheduleOverride])record(table,row,column,replacement,project);
      if(!replacement){const key=airsideCellKey(row,column);if(project.airsideOverrides)delete project.airsideOverrides[key];if(project.coilOverrides?.[table.id])delete project.coilOverrides[table.id][key];if(project.plantOverrides?.[table.id])delete project.plantOverrides[table.id][key.toLowerCase()];}
      row[column]=replacement;changed=true;
    });
    if(changed){recalculateTable(table,rows,project);for(const row of rows)if(removed.has(requirementKey(row[column])))row[column]='';}
  }
  if(snapshots.psychEntries?.length&&project.psychChartEquipment?.length){const available=new Set(psychEquipmentOptions(project).map(requirementKey));for(const e of snapshots.psychEntries){const next=String(e.row[e.c]??'');if(next&&next!==e.old&&!available.has(requirementKey(e.old))&&available.has(requirementKey(next)))project.psychChartEquipment=project.psychChartEquipment.map(v=>requirementKey(v)===requirementKey(e.old)?next:v);}}
  if(project.psychChartEquipment?.length)syncPsychChartSelections(project);

}

function tabularExportSelection(table,entries) {
  const differing=entries.filter(({row})=>Number(row[tabularColumn.differences])>0);
  if(!differing.length)return {columns:[],entries:[]};
  const columns=table.headers.map((_,c)=>c).filter(c=>tabularFields[c].export!==false&&([tabularColumn.id,tabularColumn.space].includes(c)||tabularMismatchTotal(table,differing,c)>0));
  return {columns,entries:differing};
}

function configureRevision30(){
  const peak=independentTables.find(t=>t.peakAirflowCalculation);peak.autoColumns=[4,10,17];peak.calculatedColumns=peak.calculatedColumns.filter(c=>!peak.autoColumns.includes(c));
  const air=modules.find(g=>g.group==='Airside Equipment');air.items=air.items.filter(i=>i[0]!=='Psychrometric Chart');modules.splice(modules.findIndex(g=>g.group==='Plantside Equipment'),0,{group:'Psychrometric Charts',source:'Psych',noSummary:true,psychSection:true,items:[]});
}
configureRevision30();
configureEquipmentSchedules();

const tree = document.querySelector("#project-tree");
const search = document.querySelector("#browser-search");
const browser = document.querySelector("#project-browser");
const scrim = document.querySelector("#drawer-scrim");
const moduleContent = document.querySelector("#module-content");
const summaryLinks = document.querySelector("#summary-links");
const shell = document.querySelector(".app-shell");
const projectList = document.querySelector("#project-list");
const projectSearch = document.querySelector("#project-search");
const projectDialog = document.querySelector("#project-dialog");
const projectForm = document.querySelector("#project-form");
const newProjectNumber = document.querySelector("#new-project-number");
const projectDialogError = document.querySelector("#project-dialog-error");
const projectSwitcherToggle = document.querySelector("#project-switcher-toggle");
const tableView = document.querySelector("#table-view");
const modelInputsView = document.querySelector("#model-inputs-view");
const equipmentZoningView = document.querySelector("#equipment-zoning-view");
const airsideSystemView = document.querySelector("#airside-system-view");
const tableScroll = document.querySelector(".table-scroll");
const referenceTable = document.querySelector("#reference-table");
const tableSearch = document.querySelector("#table-search");
const spaceFilter = document.querySelector("#space-filter");
const spaceFilterField = document.querySelector("#space-filter-field");
const sharedSpaceSearch = document.querySelector("#shared-space-search");
const sharedSpaceSearchLabel = document.querySelector("#shared-space-search-label");
const spaceFilterToggle = document.querySelector("#space-filter-toggle");
const spaceFilterPopover = document.querySelector("#space-filter-popover");
const spaceFilterSearch = document.querySelector("#space-filter-search");
const spaceFilterOptions = document.querySelector("#space-filter-options");
const spaceFilterAll = document.querySelector("#space-filter-all");
const spaceFilterClear = document.querySelector("#space-filter-clear");
let spaceFilterContext = null;
let spaceFilterDraft = new Set();

const tableCount = document.querySelector("#table-count");
const tableStandard = document.querySelector("#table-standard");
const tableSettings = document.querySelector("#table-settings");
const tableMetric = document.querySelector("#table-metric");
const tableMetricLabel = document.querySelector("#table-metric-label");
const tableMetricValue = document.querySelector("#table-metric-value");
function selectStandaloneControl(node) {
  clearSelectedEquation();
  selectedTableCells.clear(); selectedTableRowIndexes.clear();
  activeCellSelection = null; cellSelectionAnchor = null; selectionAnchorIndex = -1; selectedTableId = "";
  clearFillHandle(); refreshSelectedTableCells();
  referenceTable.querySelectorAll(".selected-row, .selected-cell-row, .table-cell-selected, .equation-cell-selected").forEach((cell) => {
    cell.classList.remove("selected-row", "selected-cell-row", "table-cell-selected", "equation-cell-selected");
    cell.setAttribute("aria-selected", "false");
  });
  removeTableRowButton.disabled = true;
  selectedEquationCell = node;
  node.classList.add("equation-cell-selected");
}

function showMetricEquation(metric, node = tableMetric) {
  if (!metric?.equation) return;
  selectStandaloneControl(node);
  selectedEquationContext={table:independentTables.find(t=>t.id===activeTableId),column:0,summary:true};
  selectedEquation.value = metric.equation;
  displayFormulaFunctions(selectedEquation.value);
  editEquationButton.hidden = true;
  formulaBar.hidden = false;
}
tableMetric.addEventListener("click", () => {
  showMetricEquation(independentTables.find((candidate) => candidate.id === activeTableId)?.topMetric);
});
tableMetric.addEventListener("keydown", (event) => {
  if (event.key === "Enter" || event.key === " ") { event.preventDefault(); tableMetric.click(); }
});
const twoValueSetting = document.querySelector("#two-value-setting");
const twoValueSchedule = document.querySelector("#two-value-schedule");
const minimumSetting = document.querySelector("#minimum-setting");
const minimumLabel = document.querySelector("#minimum-label");
const minimumInput = document.querySelector("#minimum-input");
const loadFactorSettings = document.querySelector("#load-factor-settings");
const sensibleLoadFactor = document.querySelector("#sensible-load-factor");
const latentLoadFactor = document.querySelector("#latent-load-factor");
const heatingLoadFactor = document.querySelector("#heating-load-factor");
const spaceReconcileDialog = document.querySelector("#space-reconcile-dialog");
const newSpaceList = document.querySelector("#new-space-list");
const oldSpaceList = document.querySelector("#old-space-list");
const spaceActionList = document.querySelector("#space-action-list");
const spaceReconcileError = document.querySelector("#space-reconcile-error");
const addTableRowButton = document.querySelector("#add-table-row");
const removeTableRowButton = document.querySelector("#remove-table-row");
const editableKey = document.querySelector(".editable-key");
const calculatedKey = document.querySelector(".calculated-key");
const autoKey = document.querySelector(".auto-key");
const matchKey = document.querySelector(".match-key");
const differentKey = document.querySelector(".different-key");
const formulaBar = document.querySelector("#formula-bar");
const restoreAutoButton = document.querySelector("#restore-auto-value");
let selectedAutoRestore = null;
const selectedEquation = document.querySelector("#selected-equation");
const formulaFunctionView = document.querySelector("#formula-function-view");
const formulaFunctionDetail = document.querySelector("#formula-function-detail");
const editEquationButton = document.querySelector("#edit-equation");
const saveEquationButton = document.querySelector("#save-equation");
const cancelEquationButton = document.querySelector("#cancel-equation");
const formulaError = document.querySelector("#formula-error");
const clipboardActions = document.querySelector("#clipboard-actions");
const excelActions = document.querySelector("#excel-actions");
const importExcelButton = document.querySelector("#import-excel");
const importExcelInput = document.querySelector("#import-excel-input");
const pasteDataButton = document.querySelector("#paste-table-data");
const copyDataButton = document.querySelector("#copy-table-data");
const csvFileStatus = document.querySelector("#csv-file-status");
const templateStatus = document.querySelector("#template-status");
const rowActions = document.querySelector("#row-actions");
const csvComparisonBar = document.querySelector("#csv-comparison-bar");
const csvComparisonColumn = document.querySelector("#csv-comparison-column");
const csvComparisonValue = document.querySelector("#csv-comparison-value");
const csvComparisonStatus = document.querySelector("#csv-comparison-status");
let activeTableId = "";
let tableSort = { tableId: "", column: -1, direction: "asc" };
let selectedTableId = "";
let selectedTableRowIndexes = new Set();
let selectionAnchorIndex = -1;
let selectedTableCells = new Set();
let cellSelectionAnchor = null;
let activeCellSelection = null;
let cellDragSelection = false;
let fillDrag = null;
let fillHandleCell = null;
let fillHandleContext = null;
let fillHandleElement = null;
let fillHandleFrame = 0;
let zoningNetworkResizeObserver = null;
const undoStack = [];
const redoStack = [];
let applyingHistory = false;
let pendingSpaceReconciliation = null;

const PROJECTS_KEY = "hvac-projects-v1";
const ACTIVE_PROJECT_KEY = "hvac-active-project-v1";
const EQUATION_OVERRIDES_KEY = "hvac-equation-overrides-v1";
const EQUIPMENT_EQUATION_SCHEMA_KEY = "hvac-equipment-equation-schema-v1";
const tableNumberFormatter = new Intl.NumberFormat("en-US", { maximumFractionDigits: 20 });
const zeroDecimalFormatter = new Intl.NumberFormat("en-US", { maximumFractionDigits: 0 });
const oneDecimalFormatter = new Intl.NumberFormat("en-US", { minimumFractionDigits: 1, maximumFractionDigits: 1 });
const twoDecimalFormatter = new Intl.NumberFormat("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const threeDecimalFormatter = new Intl.NumberFormat("en-US", { minimumFractionDigits: 3, maximumFractionDigits: 3 });
const fourDecimalFormatter = new Intl.NumberFormat("en-US", { minimumFractionDigits: 4, maximumFractionDigits: 4 });
const fiveDecimalFormatter = new Intl.NumberFormat("en-US", { minimumFractionDigits: 5, maximumFractionDigits: 5 });
const calculatedBtuNumberFormatter = new Intl.NumberFormat("en-US", { maximumFractionDigits: 0 });
const projectFields = [...document.querySelectorAll("[data-project-field]")];
let projects = [];
let activeProjectId = "";
let selectedEquationContext = null;
let selectedEquationCell = null;
let equationOverrides = {};
const csvImportsByProject = new Map();
const excelImportsByProject = new Map();
let selectedCsvComparisonContext = null;
try {
  equationOverrides = JSON.parse(localStorage.getItem(EQUATION_OVERRIDES_KEY) || "{}");
  if (localStorage.getItem(EQUIPMENT_EQUATION_SCHEMA_KEY) !== "4") {
    if (equationOverrides["schedule-equipment-sensible-gain"]) delete equationOverrides["schedule-equipment-sensible-gain"][5];
    if (equationOverrides["schedule-grouped-equipment-sensible-gain"]) delete equationOverrides["schedule-grouped-equipment-sensible-gain"][4];
    localStorage.setItem(EQUATION_OVERRIDES_KEY, JSON.stringify(equationOverrides));
    localStorage.setItem(EQUIPMENT_EQUATION_SCHEMA_KEY, "4");
  }
} catch {
  equationOverrides = {};
}

const slugify = (text) => text.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");

function renderTree(query = "") {
  syncPsychChartSelections(activeProject());
  const normalized = query.trim().toLowerCase();
  tree.innerHTML = "";
  let resultCount = 0;

  modules.forEach((section) => {
    const groupMatch = section.group.toLowerCase().includes(normalized);
    const visibleItems = section.items.filter((item) => !normalized || groupMatch || item[0].toLowerCase().includes(normalized));
    if (normalized && !groupMatch && !visibleItems.length) return;
    resultCount += visibleItems.length + 1;

    const wrapper = document.createElement("section");
    wrapper.className = "tree-group";

    const row = document.createElement("div");
    row.className = "group-row";

    if (section.items.length) {
      const expander = document.createElement("button");
      expander.className = "group-expander";
      expander.type = "button";
      expander.setAttribute("aria-label", `Collapse ${section.group}`);
      expander.setAttribute("aria-expanded", "true");
      expander.innerHTML = '<span class="chevron" aria-hidden="true">▶</span>';
      expander.addEventListener("click", () => {
        wrapper.classList.toggle("collapsed");
        const expanded = !wrapper.classList.contains("collapsed");
        expander.setAttribute("aria-expanded", String(expanded));
        expander.setAttribute("aria-label", `${expanded ? "Collapse" : "Expand"} ${section.group}`);
      });
      row.appendChild(expander);
    } else {
      const spacer = document.createElement("span");
      spacer.className = "group-spacer";
      row.appendChild(spacer);
    }

    const groupLink = document.createElement(section.noSummary ? "span" : "button");
    groupLink.className = "group-link";
    if (section.directView) groupLink.classList.add("featured-group-link");
    if (section.noSummary) groupLink.classList.add("is-static");
    else {
      groupLink.type = "button";
      groupLink.dataset.id = `section-${slugify(section.group)}`;
      groupLink.dataset.title = section.group;
      groupLink.dataset.group = "Project Browser";
      groupLink.dataset.source = section.source;
      groupLink.dataset.description = section.summary;
      if (section.directTable) groupLink.dataset.table = section.directTable;
      else if (section.directView) groupLink.dataset.view = section.directView;
      else groupLink.dataset.summary = "true";
      groupLink.addEventListener("click", () => selectModule(groupLink));
    }
    groupLink.textContent = section.group;
    row.appendChild(groupLink);


    wrapper.appendChild(row);
    if(section.psychSection){wrapper.classList.add('psych-nav-section');wrapper.appendChild(createPsychEquipmentPicker(()=>renderTree(search.value)));}

    if (visibleItems.length) {
      const children = document.createElement("div");
      children.className = "tree-children";
      visibleItems.forEach((item) => children.appendChild(createLeaf(item, section.group)));
      wrapper.appendChild(children);
    }
    tree.appendChild(wrapper);
  });

  if (!resultCount) {
    const empty = document.createElement("p");
    empty.className = "no-results";
    empty.textContent = "No calculations match this search.";
    tree.appendChild(empty);
  }

  syncActiveState();
  updateBrowserRowCounts();
}

function createLeaf(item, group) {
  const button = document.createElement("button");
  button.type = "button";
  button.className = "tree-leaf";
  button.dataset.id = slugify(item[0]);
  button.dataset.title = item[0];
  button.dataset.group = group;
  button.dataset.source = item[1];
  button.dataset.description = item[2];
  if(item[4]){button.dataset.view='psych-chart';button.dataset.equipment=item[4];}
  else if (item[3]) button.dataset.table = item[3];
  const label = document.createElement("span"); label.textContent = item[0]; button.appendChild(label);
  const table = independentTables.find((t) => t.id === item[3]);
  if (table) { const count = document.createElement("span"); count.className = "item-count"; count.dataset.rowCountTable = table.id;
    count.textContent = String((activeProject()?.independentTables?.[table.id] || table.rows).length); button.appendChild(count); }
  button.addEventListener("click", () => selectModule(button));
  return button;
}

function selectModule(button) {
  history.replaceState(null, "", `#${button.dataset.id}`);
  syncActiveState();
  closeBrowser();
}

function openLinkedTable(tableId) {
  if(tableId==="model-inputs"){const target=document.querySelector('[data-view="model-inputs"]');if(target)selectModule(target);return;}
  const target = [...document.querySelectorAll("[data-table]")].find((button) => button.dataset.table === tableId);
  if (target) selectModule(target);
}

const modelInputDefaults = {
  location: "Forest Park, Georgia", countryState: "Curry County, NM", latitude: "33.63 N", longitude: "84.442 W",
  climateZone: "3A", elevation: 1011, weatherFile: "USA_GA_Atlanta-Hartsfield-Jackson_Intl.AP_722190_TMY3.epw",
  coolingPercentile: 1, coolingDb: 91.6, coolingWb: 73.6,
  dehumidificationPercentile: 1, dehumidificationDb: 80.4, dehumidificationHrGr: 128.5,
  heatingPercentile: 99, heatingDb: 27.1, heatingHrGr: 0,
  humidificationPercentile: 99, humidificationDb: 32.1, humidificationHrGr: 9.2,
  ufc: "TRUE",
  proposedWallPrescriptive: "U-", proposedWall: "U-", proposedRoofPrescriptive: "U-", proposedRoof: "U-",
  proposedSwingingDoorPrescriptive: "U-", proposedSwingingDoor: "U-", proposedNonSwingingDoorPrescriptive: "U-", proposedNonSwingingDoor: "U-",
  proposedFenestrationUPrescriptive: "U-", proposedFenestrationShgcPrescriptive: "SHGC-", proposedFenestrationVtPrescriptive: "VT-",
  proposedFenestrationU: "U-", proposedFenestrationShgc: "SHGC-", proposedFenestrationVt: "VT-",
  proposedGroundFloorPrescriptive: "F-", proposedGroundFloor: "F-",
  baselineWall: "U-", baselineRoof: "U-", baselineSwingingDoor: "U-", baselineNonSwingingDoor: "U-",
  baselineFenestrationU: "U-", baselineFenestrationShgc: "SHGC-", baselineFenestrationVt: "VT-", baselineGroundFloor: "F-",
  baselineBuildingType: "Other Nonresidential 4-5 Floors or 25,000-150,000 ft2",
};

function modelInputCalculations(values) {
  const elevation = Number(values.elevation) || 0;
  const pressure = 14.696 * Math.pow(1 - 6.8754e-6 * elevation, 5.2559);
  const weatherValues = (dryBulb, humidityRatio) => {
    const db = Number(dryBulb) || 0;
    const hr = Number(humidityRatio) || 0;
    const absoluteTemperature = db + 459.67;
    const density = 0.075 * (pressure / 14.696) * (530 / absoluteTemperature) / (1 + 1.6078 * hr);
    return {
      sensible: 60 * density * (0.241 + 0.444 * hr),
      latent: 60 * density * (1093 - 0.556 * db),
    };
  };
  const coolingDbC = ((Number(values.coolingDb) || 0) - 32) * 5 / 9;
  const coolingWbC = ((Number(values.coolingWb) || 0) - 32) * 5 / 9;
  const saturationPressureKpa = 0.61094 * Math.exp((17.625 * coolingWbC) / (coolingWbC + 243.04));
  const saturationPressurePsia = saturationPressureKpa / 6.89476;
  const saturatedHumidityRatio = 0.621945 * saturationPressurePsia / (pressure - saturationPressurePsia);
  const coolingHr = ((2501 - 2.326 * coolingWbC) * saturatedHumidityRatio - 1.006 * (coolingDbC - coolingWbC))
    / (2501 + 1.86 * coolingDbC - 4.186 * coolingWbC);
  const dehumidificationHr = (Number(values.dehumidificationHrGr) || 0) / 7000;
  const heatingHr = (Number(values.heatingHrGr) || 0) / 7000;
  const humidificationHr = (Number(values.humidificationHrGr) || 0) / 7000;
  return {
    pressure,
    coolingHr, dehumidificationHr, heatingHr, humidificationHr,
    cooling: weatherValues(values.coolingDb, coolingHr),
    dehumidification: weatherValues(values.dehumidificationDb, dehumidificationHr),
    heating: weatherValues(values.heatingDb, heatingHr),
    humidification: weatherValues(values.humidificationDb, humidificationHr),
    infiltration: String(values.ufc).toUpperCase() === "TRUE" ? 0.25 : 0.6,
  };
}

function syncModelInputsToSourceTable(project) {
  const values = project.modelInputs;
  const sourceTable = independentTables.find((table) => table.id === "project-inputs");
  if (!sourceTable) return;
  project.independentTables ||= {};
  const rows = project.independentTables[sourceTable.id] || sourceTable.rows.map((row) => [...row]);
  const assignments = [
    [0, values.location], [1, values.countryState], [2, values.latitude], [3, values.longitude], [4, values.climateZone],
    [5, values.elevation], [6, values.weatherFile], [7, (Number(values.coolingPercentile) || 0) / 100],
    [8, values.coolingDb], [9, values.coolingWb], [10, values.dehumidificationDb], [11, values.dehumidificationHrGr],
    [12, (Number(values.heatingPercentile) || 0) / 100], [13, values.heatingDb], [14, values.humidificationDb],
    [15, values.humidificationHrGr], [16, values.ufc], [17, Number.isFinite(Number(values.proposedInfiltrationOverride))
      ? Number(values.proposedInfiltrationOverride)
      : String(values.ufc).toUpperCase() === "TRUE" ? 0.25 : 0.6],
  ];
  assignments.forEach(([index, value]) => { if (rows[index]) rows[index][2] = value; });
  project.independentTables[sourceTable.id] = rows;
  project.independentTableSchemaVersions ||= {};
  project.independentTableSchemaVersions[sourceTable.id] = sourceTable.schemaVersion;
}

function renderModelInputs() {
  const project = activeProject();
  if (!project) return;
  if (!project.modelInputs) {
    const sourceRows = project.independentTables?.["project-inputs"];
    if (Array.isArray(sourceRows) && sourceRows.length >= 18) {
      project.modelInputs = {
        ...modelInputDefaults,
        location: sourceRows[0]?.[2], countryState: sourceRows[1]?.[2], latitude: sourceRows[2]?.[2], longitude: sourceRows[3]?.[2],
        climateZone: sourceRows[4]?.[2], elevation: sourceRows[5]?.[2], weatherFile: sourceRows[6]?.[2],
        coolingPercentile: (Number(sourceRows[7]?.[2]) || 0) * 100, coolingDb: sourceRows[8]?.[2], coolingWb: sourceRows[9]?.[2],
        dehumidificationDb: sourceRows[10]?.[2], dehumidificationHrGr: sourceRows[11]?.[2],
        heatingPercentile: (Number(sourceRows[12]?.[2]) || 0) * 100, heatingDb: sourceRows[13]?.[2],
        humidificationDb: sourceRows[14]?.[2], humidificationHrGr: sourceRows[15]?.[2], ufc: sourceRows[16]?.[2],
      };
    }
  }
  project.modelInputs = { ...modelInputDefaults, ...(project.modelInputs || {}) };
  const values = project.modelInputs;
  const calculated = modelInputCalculations(values);
  modelInputsView.innerHTML = "";

  const addSection = (title, className = "") => {
    const section = document.createElement("section");
    section.className = `model-input-section ${className}`.trim();
    const heading = document.createElement("h3");
    heading.textContent = title;
    section.appendChild(heading);
    modelInputsView.appendChild(section);
    return section;
  };
  const addField = (parent, label, key, options = {}) => {
    const field = document.createElement("label");
    if (options.wide) field.classList.add("wide-field");
    if (options.className) field.classList.add(options.className);
    const caption = document.createElement("span");
    appendFormattedText(caption, label);
    const input = document.createElement(options.select ? "select" : "input");
    input.dataset.modelInput = key;
    if (options.select) {
      options.select.map(v=>v==="FALSE"?"":v).forEach((optionValue) => {
        const option = document.createElement("option"); option.value = optionValue; option.textContent = optionValue; input.appendChild(option);
      });
    }
    input.value = values[key] ?? "";
    input.addEventListener("change", () => {
      values[key] = options.number && input.value !== "" ? Number(input.value) : input.value;
      syncModelInputsToSourceTable(project); saveProjects(); renderModelInputs();
    });
    if(['elevation','climateZone'].includes(key)){const mark=document.createElement('small');mark.className='required-marker';mark.textContent=' [required]';caption.appendChild(mark);}
    field.append(caption, input); parent.appendChild(field); return input;
  };
  const addCalculated = (parent, label, value, digits = 5, equation = "") => {
    const field = document.createElement("label");
    const caption = document.createElement("span"); appendFormattedText(caption, label);
    const input = document.createElement("input"); input.className = "calculated-value"; input.readOnly = true;
    input.value = typeof value === "number" && Number.isFinite(value) ? Number(value).toFixed(digits) : value ?? "";
    input.dataset.equation = equation;
    input.addEventListener("click", () => showModelInputEquation(equation));
    field.append(caption, input); parent.appendChild(field); return field;
  };
  const addAutofill = (parent, label, automaticValue, overrideKey, digits, equation) => {
    const field = document.createElement("label");
    const caption = document.createElement("span"); appendFormattedText(caption, label);
    const input = document.createElement("input");
    const overridden = values[overrideKey] !== "" && values[overrideKey] !== null && values[overrideKey] !== undefined
      && Number.isFinite(Number(values[overrideKey])) && Number(values[overrideKey]) !== Number(automaticValue);
    input.value = Number(overridden ? values[overrideKey] : automaticValue).toFixed(digits);
    input.title = `Autopopulated value: ${Number(automaticValue).toFixed(digits)}`;
    if (!overridden) input.classList.add("auto-populated-input");
    input.addEventListener("focus", () => showModelInputEquation(equation,null,overridden?()=>{delete values[overrideKey];syncModelInputsToSourceTable(project);saveProjects();renderModelInputs();showModelInputEquation(equation);}:null));
    input.addEventListener("change", () => {
      const parsed = Number(input.value);
      if (!Number.isFinite(parsed) || parsed === Number(automaticValue)) delete values[overrideKey];
      else values[overrideKey] = parsed;
      syncModelInputsToSourceTable(project); saveProjects(); renderModelInputs();
    });
    field.append(caption, input); parent.appendChild(field); return field;
  };

  const climateOptionsTable = independentTables.find((table) => table.id === "ashrae-climate-zones");
  const climateZoneOptions = (climateOptionsTable?.rows || []).map((row) => String(row[0] ?? "")).filter(Boolean);
  const site = addSection("Site, Location, and Climate", "site-inputs");
  addField(site, "Location & Site Data", "location", { className: "half-field" }); addField(site, "Country, State", "countryState", { className: "half-field" });
  addField(site, "Latitude", "latitude", { className: "third-field" }); addField(site, "Longitude", "longitude", { className: "third-field" }); addField(site, "Climate Zone", "climateZone", { className: "third-field", select: climateZoneOptions });
  addField(site, "Elevation [ft]", "elevation", { number: true, className: "half-field" }); addCalculated(site, "Barometric Pressure [psia]", calculated.pressure, 3, "=14.696 * (1 - 6.8754E-6 * @Elevation)^5.2559");
  addField(site, "Simulation Weather Data", "weatherFile", { wide: true });

  const design = addSection("Design Weather Data", "design-weather-inputs");
  const designHeader = document.createElement("div"); designHeader.className = "design-weather-row design-weather-header";
  ["Condition", "Percentile [%]", "DB [°F]", "WB [°F]", "HR [gr/lb]", "HR [lb/lb]", "Sensible Constant", "Latent Constant"].forEach((text) => { const span = document.createElement("span"); span.textContent = text; designHeader.appendChild(span); });
  design.appendChild(designHeader);
  const weatherRows = [
    ["Cooling", "cooling", "coolingPercentile", "coolingDb", "coolingWb", null, calculated.coolingHr],
    ["Dehumidification", "dehumidification", "dehumidificationPercentile", "dehumidificationDb", null, "dehumidificationHrGr", calculated.dehumidificationHr],
    ["Heating", "heating", "heatingPercentile", "heatingDb", null, "heatingHrGr", calculated.heatingHr],
    ["Humidification", "humidification", "humidificationPercentile", "humidificationDb", null, "humidificationHrGr", calculated.humidificationHr],
  ];
  weatherRows.forEach(([label, calcKey, percentileKey, dbKey, wbKey, grKey, hrValue]) => {
    const row = document.createElement("div"); row.className = "design-weather-row";
    const name = document.createElement("strong"); name.textContent = label;if(['Cooling','Dehumidification','Heating'].includes(label)){const mark=document.createElement('small');mark.className='required-marker';mark.textContent=' [required]';name.appendChild(mark);} row.appendChild(name);
    [percentileKey, dbKey, wbKey, grKey].forEach((key) => {
      const input = document.createElement("input"); input.type = "text"; input.value = key ? values[key] ?? "" : ""; input.disabled = !key;
      if (key === "heatingHrGr") {
        input.title = "Autopopulated value: 0";
        if (Number(input.value) === 0) input.classList.add("auto-populated-input");
        input.addEventListener("focus",()=>showModelInputEquation("=0",null,Number(input.value)!==0?()=>{values[key]=0;syncModelInputsToSourceTable(project);saveProjects();renderModelInputs();showModelInputEquation("=0");}:null));
      }
      if (key) input.addEventListener("change", () => { values[key] = input.value === "" ? "" : Number(input.value); syncModelInputsToSourceTable(project); saveProjects(); renderModelInputs(); });
      row.appendChild(input);
    });
    [hrValue, calculated[calcKey].sensible, calculated[calcKey].latent].forEach((value, index) => {
      const equations = [
        calcKey === "cooling" ? "=PSYCHROMETRIC_HR(@DB, @WB, @Barometric Pressure)" : "=@HR [gr/lb] / 7000",
        "=SENSIBLECONSTANT(@DB, @HR, @Barometric Pressure)",
        "=LATENTCONSTANT(@DB, @HR, @Barometric Pressure)",
      ];
      const input = document.createElement("input"); input.readOnly = true; input.className = "calculated-value"; input.value = Number(value).toFixed(index===0?5:index===1?3:0);
      input.addEventListener("click", () => showModelInputEquation(equations[index],{DB:values[dbKey],WB:values[wbKey],HR:hrValue,"HR [gr/lb]":values[grKey],"Barometric Pressure":calculated.pressure})); row.appendChild(input);
    });
    design.appendChild(row);
  });

  const building = addSection("Proposed Building Construction", "building-inputs");
  const generalTable = independentTables.find((table) => table.id === "calc-general");
  const conditionTable = independentTables.find((table) => table.id === "calc-condition-baseline");
  const generalRows = generalTable ? projectTableRows(generalTable) : [];
  const conditionRows = conditionTable ? projectTableRows(conditionTable) : [];
  if(conditionTable)recalculateTable(conditionTable,conditionRows,project);
  const areaBySpace = new Map(generalRows.map((row) => [String(row[0] ?? ""), Number(row[3]) || 0]));
  const areas = conditionRows.reduce((totals, row) => {
    const condition = String(row[10] ?? "Unconditioned");
    const area = Number(row[3]) || 0;
    if (condition === "Conditioned") totals.conditioned += area;
    else if (condition === "Semi-Heated") totals.semiheated += area;
    else totals.unconditioned += area;
    totals.total += area;
    return totals;
  }, { conditioned: 0, semiheated: 0, unconditioned: 0, total: 0 });
  addCalculated(building, "Conditioned [ft2]", areas.conditioned, 1, '=SUMIF([Condition Type & Baseline System]@Condition Type, "Conditioned", [Condition Type & Baseline System]@Area)');
  addCalculated(building, "Semiheated [ft2]", areas.semiheated, 1, '=SUMIF([Condition Type & Baseline System]@Condition Type, "Semi-Heated", [Condition Type & Baseline System]@Area)');
  addCalculated(building, "Unconditioned [ft2]", areas.unconditioned, 1, '=SUMIF([Condition Type & Baseline System]@Condition Type, "Unconditioned", [Condition Type & Baseline System]@Area)');
  addCalculated(building, "Total Area [ft2]", areas.total, 1, '=SUM([Space Calculations]@Area)');
  values.ufc = String(values.ufc).toUpperCase() === "TRUE" ? "TRUE" : "";
  addField(building, "UFC", "ufc", { select: ["TRUE", "FALSE"] });
  const proposedInfiltration = addAutofill(building, "Infiltration at 0.3 in. Pressure Differential [CFM/ft2]", calculated.infiltration, "proposedInfiltrationOverride", 2, '=IF(@UFC="TRUE", 0.25, 0.60)');
  proposedInfiltration.classList.add("infiltration-field");

  const cleanConstructionValue = (value) => String(value ?? "").replace(/^(?:SHGC|VT|U|F)-/, "");
  values.proposedAssemblies ||= [
    ["External Walls", values.proposedWallPrescriptive, "", "", values.proposedWall, "", ""],
    ["Roof", values.proposedRoofPrescriptive, "", "", values.proposedRoof, "", ""],
    ["Swinging Doors", values.proposedSwingingDoorPrescriptive, "", "", values.proposedSwingingDoor, "", ""],
    ["Non-Swinging Doors", values.proposedNonSwingingDoorPrescriptive, "", "", values.proposedNonSwingingDoor, "", ""],
    ["Fenestrations", values.proposedFenestrationUPrescriptive, values.proposedFenestrationShgcPrescriptive, values.proposedFenestrationVtPrescriptive, values.proposedFenestrationU, values.proposedFenestrationShgc, values.proposedFenestrationVt],
    ["Perimeter Room Ground Floors", values.proposedGroundFloorPrescriptive, "", "", values.proposedGroundFloor, "", ""],
  ].map(([name, ...entries]) => ({ name, prescriptiveUF: cleanConstructionValue(entries[0]), prescriptiveSHGC: cleanConstructionValue(entries[1]), prescriptiveVT: cleanConstructionValue(entries[2]), proposedUF: cleanConstructionValue(entries[3]), proposedSHGC: cleanConstructionValue(entries[4]), proposedVT: cleanConstructionValue(entries[5]) }));
  values.baselineAssemblies ||= [
    ["External Walls", values.baselineWall, "", ""], ["Roof", values.baselineRoof, "", ""],
    ["Swinging Doors", values.baselineSwingingDoor, "", ""], ["Non-Swinging Doors", values.baselineNonSwingingDoor, "", ""],
    ["Fenestrations", values.baselineFenestrationU, values.baselineFenestrationShgc, values.baselineFenestrationVt],
    ["Perimeter Room Ground Floors", values.baselineGroundFloor, "", ""],
  ].map(([name, ...entries]) => ({ name, uf: cleanConstructionValue(entries[0]), shgc: cleanConstructionValue(entries[1]), vt: cleanConstructionValue(entries[2]) }));

  const addConstructionGrid = (parent, collectionKey, baseline = false) => {
    const rows = values[collectionKey];
    const grid = document.createElement("div"); grid.className = `construction-grid ${baseline ? "baseline-grid" : "proposed-grid"}`;
    const addButton = document.createElement("button"); addButton.type = "button"; addButton.className = "construction-add"; addButton.textContent = "+"; addButton.title = "Add line item";
    addButton.addEventListener("click", () => {
      rows.push(baseline ? { name: "", uf: "", shgc: "", vt: "" } : { name: "", prescriptiveUF: "", prescriptiveSHGC: "", prescriptiveVT: "", proposedUF: "", proposedSHGC: "", proposedVT: "" });
      saveProjects(); renderModelInputs();
    });
    grid.appendChild(addButton);
    const headings = baseline ? ["Assembly", "U/F", "SHGC", "VT"] : ["Assembly", "Prescriptive U/F", "Prescriptive SHGC", "Prescriptive VT", "Proposed U/F", "Proposed SHGC", "Proposed VT"];
    headings.forEach((heading) => { const span = document.createElement("span"); span.className = "construction-heading"; span.textContent = heading; grid.appendChild(span); });
    const fields = baseline ? ["name", "uf", "shgc", "vt"] : ["name", "prescriptiveUF", "prescriptiveSHGC", "prescriptiveVT", "proposedUF", "proposedSHGC", "proposedVT"];
    rows.forEach((row, rowIndex) => {
      const removeButton = document.createElement("button"); removeButton.type = "button"; removeButton.className = "construction-remove"; removeButton.textContent = "←"; removeButton.title = "Remove line item";
      removeButton.addEventListener("click", () => { rows.splice(rowIndex, 1); saveProjects(); renderModelInputs(); });
      grid.appendChild(removeButton);
      fields.forEach((field) => {
        const input = document.createElement("input"); input.value = row[field] ?? "";
        const updateState = () => input.classList.toggle("has-value", input.value.trim() !== "");
        updateState();
        input.addEventListener("input", () => { row[field] = input.value; updateState(); saveProjects(); });
        grid.appendChild(input);
      });
    });
    parent.appendChild(grid);
  };
  addIesveConstructionNote(building);
  addConstructionGrid(building, "proposedAssemblies");

  const baseline = addSection("ASHRAE Baseline Building Construction", "baseline-building-inputs");
  addAutofill(baseline, "Infiltration at 0.3 in. Pressure Differential [CFM/ft2]", 1, "baselineInfiltrationOverride", 2, "=1.00");
  addIesveConstructionNote(baseline);
  const climateTable = independentTables.find((table) => table.id === "ashrae-climate-zones");
  const systemTable = independentTables.find((table) => table.id === "ashrae-90-1-baseline-systems");
  const buildingTypes = (climateTable?.headers || []).slice(2, 10).map((header) => header.label);
  if (!buildingTypes.includes(values.baselineBuildingType)) values.baselineBuildingType = buildingTypes[6] || values.baselineBuildingType;
  const baselineType=addField(baseline, "Building Type - Area Based on Conditioned Area", "baselineBuildingType", { select: buildingTypes });
  const baselineTop=document.createElement('div');baselineTop.className='baseline-input-top';baselineTop.append(baselineType.closest('label'),baseline.querySelector('label'));baseline.appendChild(baselineTop);
  const climateRow = (climateTable?.rows || []).find((row) => String(row[0]) === String(values.climateZone));
  const buildingTypeIndex = (climateTable?.headers || []).findIndex((header) => header.label === values.baselineBuildingType);
  const systemNumber = climateRow?.[buildingTypeIndex] || "";
  const system = (systemTable?.rows || []).find((row) => String(row[0]) === String(systemNumber)) || [];
  [
    ["Number", systemNumber, '=XLOOKUP(@Climate Zone, [Climate Zones]@Climate Zone, [Climate Zones]@Building Type)'],
    ["System", system[1] ?? "", '=XLOOKUP(@Number, [Baseline System Descriptions]@Number, @System)'],
    ["System Type", system[2] ?? "", '=XLOOKUP(@Number, [Baseline System Descriptions]@Number, @System Type)'],
    ["Fan Control", system[3] ?? "", '=XLOOKUP(@Number, [Baseline System Descriptions]@Number, @Fan Control)'],
    ["Cooling Type", system[4] ?? "", '=XLOOKUP(@Number, [Baseline System Descriptions]@Number, @Cooling Type)'],
    ["Heating Type", system[5] ?? "", '=XLOOKUP(@Number, [Baseline System Descriptions]@Number, @Heating Type)'],
  ].forEach(([label, value, equation]) => addCalculated(baseline, label, value, 0, equation));

  addConstructionGrid(baseline, "baselineAssemblies", true);
  const formula = document.createElement("div"); formula.className = "model-input-formula"; formula.hidden = true;
  const symbol = document.createElement("span"); symbol.textContent = "fx";
  const output = document.createElement("output");
  formula.append(symbol, output); modelInputsView.appendChild(formula);
}

function showModelInputEquation(equation,debugValues = null,restore = null) {
  const bar = modelInputsView.querySelector(".model-input-formula");
  const output = modelInputsView.querySelector(".model-input-formula output");
  if (!bar || !output) return;
  if (!equation) { bar.hidden = true; return; }
  output.className = "formula-function-view";
  let detail = bar.querySelector(".formula-function-detail");
  if (!detail) {detail=document.createElement("div");detail.className="formula-function-detail";bar.appendChild(detail);}
  bar.debugValues=debugValues;bar.debugEquation=equation;bar.restoreAutomatic=restore;
  let evaluate=bar.querySelector(".evaluate-model-formula");if(!evaluate){evaluate=document.createElement("button");evaluate.type="button";evaluate.className="evaluate-model-formula";evaluate.textContent="Evaluate";evaluate.addEventListener("click",()=>bar.restoreAutomatic?bar.restoreAutomatic():openFormulaEvaluator({equation:bar.debugEquation,values:bar.debugValues,model:true}));bar.appendChild(evaluate);}
  evaluate.textContent=restore?"Restore":"Evaluate";bar.classList.toggle("formula-overridden",Boolean(restore));
  displayFormulaFunctions(equation, output, detail);
  bar.hidden = false;
}

function hideModelInputEquation() {
  const bar = modelInputsView.querySelector(".model-input-formula");
  if (bar) bar.hidden = true;
}

function updateWorkspace(data) {
  const isPsych=data.view==="psych-chart";
  shell.classList.add("uniform-page-heading");
  document.querySelector("#psych-chart-view")?.remove();
  const isSummary = data.summary === "true";
  const isEquipmentZoning = false;
  const isAirsideSystem = ["airside-building-systems", "airside-exhaust-relief-systems"].includes(data.table);
  const isTable = Boolean(data.table) && !isEquipmentZoning && !isAirsideSystem;
  const isModelInputs = data.view === "model-inputs";
  document.querySelector("#crumb-group").textContent = data.group;
  document.querySelector("#crumb-page").textContent = data.title;
  document.querySelector("#page-kicker").textContent = isSummary ? "SECTION SUMMARY" : data.group.toUpperCase();
  document.querySelector("#page-title").textContent = data.title;
  document.querySelector("#page-description").textContent = data.description;
  document.querySelector("#source-sheet").textContent = data.source;
  document.querySelector(".section-label").textContent = isSummary ? "TABLE CONTENTS" : "CURRENT MODULE";
  document.querySelector("#module-heading").textContent = data.title;
  document.querySelector("#module-status").textContent = isTable || isModelInputs || isEquipmentZoning || isAirsideSystem ? "Migrated" : "Structure ready";
  document.querySelector("#parity-status").textContent = isTable || isModelInputs || isEquipmentZoning || isAirsideSystem ? "Workbook data matched" : "Not tested";
  document.querySelector("#revision-status").textContent = isTable || isModelInputs || isEquipmentZoning || isAirsideSystem ? "Workbook source preserved" : "Source preserved";
  document.querySelector("#module-action").textContent = isAirsideSystem ? "System configuration" : isEquipmentZoning ? "Interactive zoning" : isModelInputs ? "Project inputs" : isTable ? "Editable table" : "Calculation pending";
  document.querySelector("#empty-title").textContent = isSummary ? `${data.title} summary` : "Ready for workbook logic";
  document.querySelector("#empty-copy").textContent = isSummary
    ? data.description
    : "The navigation and source mapping are in place. Inputs, equations, units, validation, and Excel parity tests will be added in the next migration increment.";
  moduleContent.classList.toggle("is-summary", isSummary);
  shell.classList.toggle("summary-mode", isSummary);
  shell.classList.toggle("table-mode", isTable);
  shell.classList.toggle("model-inputs-mode", isModelInputs);
  shell.classList.toggle("equipment-zoning-mode", isEquipmentZoning);
  moduleContent.hidden = isTable || isModelInputs || isEquipmentZoning || isAirsideSystem || !isSummary;
  tableView.hidden = !isTable;
  document.querySelector(".cell-keys").hidden = !isTable && !isModelInputs;
  tableCount.hidden = !isTable;
  if (isModelInputs) {
    editableKey.hidden = false; editableKey.lastChild.textContent = "User-input";
    autoKey.hidden = false; calculatedKey.hidden = false; calculatedKey.classList.remove("not-specified-key"); calculatedKey.lastChild.textContent = "Calculated";
    document.querySelectorAll(".match-key, .different-key, .not-specified-key").forEach((key) => key.hidden = true);
  }
  modelInputsView.hidden = !isModelInputs;
  equipmentZoningView.hidden = !isEquipmentZoning;
  airsideSystemView.hidden = !isAirsideSystem;
  if (isTable) {
    tableSearch.value = "";
    renderReferenceTable(data.table);
  } else if(isPsych){activeTableId="";renderPsychChart(data.equipment);
  } else if (isModelInputs) {
    activeTableId = "";
    renderModelInputs();
  } else if (isEquipmentZoning) {
    activeTableId = "calc-equipment-zoning";
    renderEquipmentZoningTool();
  } else if (isAirsideSystem) {
    activeTableId = data.table;
    renderAirsideSystemTool(data.table === "airside-building-systems" ? "supply" : "exhaust");
  } else {
    activeTableId = "";
    renderSummaryLinks(isSummary ? data.title : null);
  }
  renderCalculationDocumentation(data);
  document.title = `${data.title} · HVAC Design Workbook`;
}

const ZONING_SYMBOLS = [
  { id: "oa", label: "Entering OA", kind: "node", node: "oa", short: "OA" },
  { id: "ea", label: "Leaving EA", kind: "node", node: "ea", short: "EA" },
  { id: "louver", label: "Louver", kind: "accessory", short: "LVR" },
  { id: "heating-coil", label: "Heating Coil", kind: "device", slots: 1, heating: true, short: "HC" },
  { id: "preheat-cooling", label: "Preheat + Cooling", kind: "device", slots: 2, heating: true, cooling: true, short: "PH+C" },
  { id: "preheat-cooling-reheat", label: "Preheat + Cooling + Reheat", kind: "device", slots: 2, heating: true, cooling: true, short: "PH+C+RH" },
  { id: "cooling-heating", label: "Cooling FCU + Heating FCU", kind: "device", slots: 2, heating: true, cooling: true, short: "C+H" },
  { id: "valve", label: "Valve", kind: "device", slots: 1, cooling: true, short: "V" },
];

const zoningSymbol = (id) => ZONING_SYMBOLS.find((symbol) => symbol.id === id);
const cloneZoningConfiguration = (assignment) => ({
  buildingId: assignment.buildingId || "",
  devices: [...(assignment.devices || [])],
  louver: Boolean(assignment.louver),
  nodeOverrides: { ...(assignment.nodeOverrides || {}) },
});

function zoningSourceSpaces(project) {
  const table = independentTables.find((candidate) => candidate.id === "calc-equipment-zoning");
  if (!table) return [];
  return ensureProjectTableRows(project, table).map((row) => ({
    group: String(row[0] ?? "").trim() || "UNGROUPED",
    zone: String(row[1] ?? "").trim(),
    space: String(row[2] ?? "").trim(),
    legacy: row,
  })).filter((item) => item.space);
}

function inferBuildingEquipmentType(id) {
  const value = String(id).toUpperCase();
  if (value.includes("DOAS")) return "DOAS";
  if (value.includes("VALVE") || value.includes("VLV")) return "Central Valve";
  return "Central AHU";
}

function equipmentZoningState(project) {
  const spaces = zoningSourceSpaces(project);
  project.equipmentZoningTool ||= { library: [], assignments: {}, templates: {}, selectedGroup: "", selectedSpace: "", pendingSymbol: "" };
  const state = project.equipmentZoningTool;
  state.library ||= []; state.assignments ||= {}; state.templates ||= {};
  if (!state.initialized) {
    const libraryIds = new Set();
    spaces.forEach(({ legacy }) => [legacy[3], legacy[4], legacy[9]].forEach((value) => {
      const id = String(value ?? "").trim();
      if (!id || id === "-" || libraryIds.has(id.toLowerCase())) return;
      libraryIds.add(id.toLowerCase()); state.library.push({ id, type: inferBuildingEquipmentType(id) });
    }));
    state.initialized = true;
  }
  const validSpaces = new Set(spaces.map((item) => item.space));
  Object.keys(state.assignments).forEach((space) => { if (!validSpaces.has(space)) delete state.assignments[space]; });
  spaces.forEach(({ group, zone, space, legacy }) => {
    if (!state.assignments[space]) {
      const devices = [];
      if (legacy[5]) devices.push("valve");
      if (legacy[6]) devices.push("heating-coil");
      if (!devices.length && legacy[7] && legacy[8]) devices.push("cooling-heating");
      state.assignments[space] = {
        group, zone, space,
        buildingId: String(legacy[4] || legacy[3] || legacy[9] || ""),
        devices: devices.slice(0, 2), louver: false, nodeOverrides: {},
      };
    }
    state.assignments[space].group = group;
    state.assignments[space].zone = zone;
  });
  const groups = [...new Set(spaces.map((item) => item.group))];
  if (!groups.includes(state.selectedGroup)) state.selectedGroup = groups[0] || "";
  if (!validSpaces.has(state.selectedSpace)) state.selectedSpace = "";
  return { state, spaces, groups };
}

function automaticZoningNodes(assignment, library) {
  const equipment = library.find((item) => item.id === assignment.buildingId);
  const automatic = { oa: false, sa: false, ra: false, ea: false };
  if (equipment?.type === "DOAS") { automatic.oa = true; automatic.sa = true; }
  if (equipment?.type === "Central AHU") { automatic.oa = true; automatic.sa = true; automatic.ra = true; }
  if (equipment?.type === "Central Valve") automatic.sa = true;
  if ((assignment.devices || []).length) { automatic.sa = true; automatic.ra = true; }
  if (assignment.louver) automatic.oa = true;
  const nodes = {};
  Object.keys(automatic).forEach((node) => {
    const override = assignment.nodeOverrides?.[node];
    nodes[node] = typeof override === "boolean" ? override : automatic[node];
  });
  return nodes;
}

function zoningConfigurationMatches(left, right) {
  if (!right) return false;
  return JSON.stringify(cloneZoningConfiguration(left)) === JSON.stringify(cloneZoningConfiguration(right));
}

function syncZoningToolToCalc(project, state) {
  const table = independentTables.find((candidate) => candidate.id === "calc-equipment-zoning");
  if (!table) return;
  const rows = ensureProjectTableRows(project, table);
  const libraryById = new Map(state.library.map((item) => [item.id, item]));
  rows.forEach((row) => {
    const assignment = state.assignments[String(row[2] ?? "")];
    if (!assignment) return;
    row[0] = assignment.group; row[1] = assignment.zone;
    [3, 4, 5, 6, 7, 8, 9, 10].forEach((column) => { row[column] = ""; });
    const building = libraryById.get(assignment.buildingId);
    if (building?.type === "DOAS") row[3] = building.id;
    else if (building?.type === "Central AHU") row[4] = building.id;
    else if (building?.type === "Central Valve") row[5] = building.id;
    const equipmentBase = assignment.space.replace(/\s+/g, "-").replace(/[^A-Za-z0-9-]/g, "");
    (assignment.devices || []).forEach((device) => {
      if (device === "valve") row[5] = `${equipmentBase}-VLV`;
      if (device === "heating-coil") row[6] = `${equipmentBase}-RHC`;
      if (["preheat-cooling", "preheat-cooling-reheat", "cooling-heating"].includes(device)) {
        row[7] = `${equipmentBase}-FCU`; row[8] = `${equipmentBase}-FCU`;
        if (device === "preheat-cooling-reheat") row[6] = `${equipmentBase}-RHC`;
      }
    });
  });
}

function saveEquipmentZoning(project, state, rerender = true) {
  syncZoningToolToCalc(project, state);
  saveProjects();
  if (rerender) renderEquipmentZoningTool();
}

function validateZoningSymbol(assignment, symbolId) {
  const symbol = zoningSymbol(symbolId);
  if (!symbol) return "Unknown equipment symbol.";
  if (symbol.kind !== "device") return "";
  const devices = assignment.devices || [];
  if (devices.includes(symbolId)) return `${symbol.label} is already assigned to this space.`;
  const existingSymbols = devices.map(zoningSymbol).filter(Boolean);
  if (existingSymbols.some((item) => item.slots === 2)) return "This space already contains a two-slot equipment assembly.";
  if (symbol.slots === 2 && devices.length) return "A two-slot assembly requires both equipment slots to be empty.";
  const usedSlots = existingSymbols.reduce((sum, item) => sum + (item.slots || 0), 0);
  if (usedSlots + symbol.slots > 2) return "A space cannot contain more than two zone-equipment slots.";
  if (symbol.heating && existingSymbols.some((item) => item.heating)) return "A space cannot contain more than one heating-type device.";
  if (symbol.cooling && existingSymbols.some((item) => item.cooling)) return "A space cannot contain more than one cooling-type device.";
  return "";
}

function applyZoningSymbol(project, state, assignment, symbolId) {
  const symbol = zoningSymbol(symbolId);
  if (!symbol) return "Unknown equipment symbol.";
  if (symbol.kind === "node") {
    assignment.nodeOverrides ||= {}; assignment.nodeOverrides[symbol.node] = true;
  } else if (symbol.kind === "accessory") {
    assignment.louver = true;
  } else {
    const error = validateZoningSymbol(assignment, symbolId);
    if (error) return error;
    assignment.devices ||= []; assignment.devices.push(symbolId);
  }
  state.selectedSpace = assignment.space;
  state.notice = `${symbol.label} added to ${assignment.space}.`;
  saveEquipmentZoning(project, state);
  return "";
}

function zoningSymbolElement(symbol, compact = false) {
  const element = document.createElement("span");
  element.className = `zoning-symbol symbol-${symbol.id}${compact ? " compact" : ""}`;
  const icon = document.createElement("i"); icon.setAttribute("aria-hidden", "true"); icon.textContent = symbol.short;
  const label = document.createElement("span"); label.textContent = symbol.label;
  element.append(icon, label);
  return element;
}

function renderLegacyEquipmentZoningTool() {
  const project = activeProject();
  if (!project) return;
  const { state, spaces, groups } = equipmentZoningState(project);
  equipmentZoningView.innerHTML = "";
  const status = document.createElement("div"); status.className = "zoning-status"; status.setAttribute("role", "status"); status.setAttribute("aria-live", "polite");
  const setStatus = (message, error = false) => { status.textContent = message; status.classList.toggle("is-error", error); };
  if (state.notice) setStatus(state.notice);

  const librarySection = document.createElement("section"); librarySection.className = "zoning-library-section";
  const libraryHeading = document.createElement("div"); libraryHeading.className = "zoning-section-heading";
  libraryHeading.innerHTML = "<div><span>Shared equipment</span><h3>Building-level equipment</h3></div>";
  const addForm = document.createElement("form"); addForm.className = "building-equipment-form";
  const idInput = document.createElement("input"); idInput.required = true; idInput.placeholder = "Equipment ID"; idInput.setAttribute("aria-label", "New building equipment ID");
  const typeSelect = document.createElement("select"); typeSelect.setAttribute("aria-label", "New building equipment type");
  ["DOAS", "Central AHU", "Central Valve"].forEach((type) => { const option = document.createElement("option"); option.value = type; option.textContent = type; typeSelect.appendChild(option); });
  const addButton = document.createElement("button"); addButton.type = "submit"; addButton.textContent = "Add equipment";
  addForm.append(idInput, typeSelect, addButton); libraryHeading.appendChild(addForm); librarySection.appendChild(libraryHeading);
  addForm.addEventListener("submit", (event) => {
    event.preventDefault(); const id = idInput.value.trim();
    if (!id) return;
    if (state.library.some((item) => item.id.toLowerCase() === id.toLowerCase())) { setStatus("That building equipment ID already exists.", true); return; }
    state.library.push({ id, type: typeSelect.value }); saveEquipmentZoning(project, state);
  });
  const libraryList = document.createElement("div"); libraryList.className = "building-equipment-list";
  state.library.forEach((item, index) => {
    const row = document.createElement("div"); row.className = `building-equipment-item type-${slugify(item.type)}`;
    const mark = document.createElement("i"); mark.textContent = item.type === "DOAS" ? "D" : item.type === "Central AHU" ? "A" : "V";
    const id = document.createElement("input"); id.value = item.id; id.setAttribute("aria-label", `${item.type} equipment ID`);
    const type = typeSelect.cloneNode(true); type.value = item.type; type.setAttribute("aria-label", `${item.id} equipment type`);
    const remove = document.createElement("button"); remove.type = "button"; remove.className = "zoning-icon-button danger"; remove.textContent = "×"; remove.title = `Remove ${item.id}`;
    id.addEventListener("change", () => {
      const nextId = id.value.trim(); if (!nextId) { id.value = item.id; return; }
      if (state.library.some((candidate, candidateIndex) => candidateIndex !== index && candidate.id.toLowerCase() === nextId.toLowerCase())) { id.value = item.id; setStatus("That building equipment ID already exists.", true); return; }
      const previous = item.id; item.id = nextId;
      Object.values(state.assignments).forEach((assignment) => { if (assignment.buildingId === previous) assignment.buildingId = nextId; });
      saveEquipmentZoning(project, state);
    });
    type.addEventListener("change", () => { item.type = type.value; saveEquipmentZoning(project, state); });
    remove.addEventListener("click", () => {
      state.library.splice(index, 1); Object.values(state.assignments).forEach((assignment) => { if (assignment.buildingId === item.id) assignment.buildingId = ""; });
      saveEquipmentZoning(project, state);
    });
    row.append(mark, id, type, remove); libraryList.appendChild(row);
  });
  if (!state.library.length) { const empty = document.createElement("p"); empty.className = "zoning-empty-copy"; empty.textContent = "Add a DOAS, central AHU, or central valve to make it available to spaces."; libraryList.appendChild(empty); }
  librarySection.appendChild(libraryList);

  const designSection = document.createElement("section"); designSection.className = "zoning-design-section";
  const controls = document.createElement("div"); controls.className = "zoning-controls";
  const groupLabel = document.createElement("label"); groupLabel.innerHTML = "<span>Zone group</span>";
  const groupSelect = document.createElement("select"); groups.forEach((group) => { const option = document.createElement("option"); option.value = group; option.textContent = group; groupSelect.appendChild(option); }); groupSelect.value = state.selectedGroup;
  groupSelect.addEventListener("change", () => { state.selectedGroup = groupSelect.value; state.selectedSpace = ""; saveEquipmentZoning(project, state); }); groupLabel.appendChild(groupSelect);
  const applyButton = document.createElement("button"); applyButton.type = "button"; applyButton.className = "apply-template-button"; applyButton.textContent = "Apply selected space to group"; applyButton.disabled = !state.selectedSpace;
  applyButton.addEventListener("click", () => {
    const source = state.assignments[state.selectedSpace]; if (!source) return;
    const configuration = cloneZoningConfiguration(source); state.templates[source.group] = configuration;
    Object.values(state.assignments).filter((assignment) => assignment.group === source.group).forEach((assignment) => Object.assign(assignment, cloneZoningConfiguration(configuration)));
    saveEquipmentZoning(project, state);
  });
  const exportButton = document.createElement("button"); exportButton.type = "button"; exportButton.className = "zoning-export-button"; exportButton.textContent = "Export CSV"; exportButton.addEventListener("click", () => exportEquipmentZoningCsv(project));
  controls.append(groupLabel, applyButton, exportButton); designSection.appendChild(controls);

  const palette = document.createElement("div"); palette.className = "zoning-palette"; palette.setAttribute("aria-label", "Equipment symbol palette");
  const paletteHeading = document.createElement("div"); paletteHeading.className = "zoning-palette-heading"; paletteHeading.innerHTML = "<span>Symbol palette and legend</span><strong>Drag onto a space, or select a symbol and then select a space</strong>";
  ZONING_SYMBOLS.forEach((symbol) => {
    const button = document.createElement("button"); button.type = "button"; button.draggable = true; button.className = "zoning-palette-item"; button.title = `Drag ${symbol.label} onto a space`;
    button.appendChild(zoningSymbolElement(symbol)); button.classList.toggle("is-active", state.pendingSymbol === symbol.id);
    button.addEventListener("dragstart", (event) => { event.dataTransfer.setData("text/plain", symbol.id); event.dataTransfer.effectAllowed = "copy"; });
    button.addEventListener("click", () => { state.pendingSymbol = state.pendingSymbol === symbol.id ? "" : symbol.id; saveEquipmentZoning(project, state); });
    palette.appendChild(button);
  });
  designSection.append(paletteHeading, palette, status);

  const cards = document.createElement("div"); cards.className = "space-card-grid";
  spaces.filter((item) => item.group === state.selectedGroup).forEach(({ space }) => cards.appendChild(renderZoningSpaceCard(project, state, state.assignments[space], setStatus)));
  if (!cards.children.length) { const empty = document.createElement("p"); empty.className = "zoning-empty-copy"; empty.textContent = "No spaces are available in this zone group."; cards.appendChild(empty); }
  designSection.appendChild(cards);

  const tableSection = document.createElement("section"); tableSection.className = "zoning-data-section";
  const tableHeading = document.createElement("div"); tableHeading.className = "zoning-section-heading"; tableHeading.innerHTML = `<div><span>Zone-level data</span><h3>Space equipment assignments</h3></div><strong>${spaces.length} spaces</strong>`;
  tableSection.append(tableHeading, renderZoningAssignmentTable(state, spaces));
  equipmentZoningView.append(librarySection, designSection, tableSection);
}

function renderZoningSpaceCard(project, state, assignment, setStatus) {
  const card = document.createElement("article"); card.className = "zoning-space-card"; card.dataset.space = assignment.space;
  card.classList.toggle("is-selected", state.selectedSpace === assignment.space);
  card.classList.toggle("is-drop-target", Boolean(state.pendingSymbol));
  const template = state.templates[assignment.group];
  const badge = document.createElement("span"); badge.className = `space-template-state ${template && !zoningConfigurationMatches(assignment, template) ? "override" : "match"}`; badge.textContent = template ? (zoningConfigurationMatches(assignment, template) ? "Template" : "Override") : "Individual";
  const header = document.createElement("header");
  const title = document.createElement("div"); const zone = document.createElement("span"); zone.textContent = assignment.zone || "No zone"; const name = document.createElement("h4"); name.textContent = assignment.space; title.append(zone, name); header.append(title, badge);

  const equipmentLabel = document.createElement("label"); equipmentLabel.className = "building-equipment-tag"; equipmentLabel.innerHTML = "<span>Building equipment</span>";
  const equipmentSelect = document.createElement("select"); const blank = document.createElement("option"); blank.value = ""; blank.textContent = "None"; equipmentSelect.appendChild(blank);
  state.library.forEach((item) => { const option = document.createElement("option"); option.value = item.id; option.textContent = `${item.id} · ${item.type}`; equipmentSelect.appendChild(option); }); equipmentSelect.value = assignment.buildingId || "";
  equipmentSelect.addEventListener("change", () => { assignment.buildingId = equipmentSelect.value; state.selectedSpace = assignment.space; saveEquipmentZoning(project, state); }); equipmentLabel.appendChild(equipmentSelect);

  const box = document.createElement("div"); box.className = "space-box";
  const nodes = automaticZoningNodes(assignment, state.library);
  Object.entries(nodes).forEach(([node, active]) => { if (!active) return; const marker = document.createElement("span"); marker.className = `connection-node node-${node}`; marker.textContent = node.toUpperCase(); box.appendChild(marker); });
  const slots = document.createElement("div"); slots.className = "zone-equipment-slots";
  (assignment.devices || []).forEach((deviceId) => {
    const symbol = zoningSymbol(deviceId); if (!symbol) return;
    const chip = document.createElement("div"); chip.className = `zone-device-chip slots-${symbol.slots}`; chip.appendChild(zoningSymbolElement(symbol, true));
    const remove = document.createElement("button"); remove.type = "button"; remove.textContent = "×"; remove.title = `Remove ${symbol.label}`; remove.addEventListener("click", (event) => { event.stopPropagation(); assignment.devices = assignment.devices.filter((id) => id !== deviceId); saveEquipmentZoning(project, state); });
    chip.appendChild(remove); slots.appendChild(chip);
  });
  const usedSlots = (assignment.devices || []).map(zoningSymbol).filter(Boolean).reduce((sum, item) => sum + (item.slots || 0), 0);
  for (let slot = usedSlots; slot < 2; slot += 1) { const empty = document.createElement("div"); empty.className = "zone-device-empty"; empty.textContent = `Slot ${slot + 1}`; slots.appendChild(empty); }
  if (assignment.louver) { const louver = document.createElement("div"); louver.className = "space-louver"; louver.appendChild(zoningSymbolElement(zoningSymbol("louver"), true)); const remove = document.createElement("button"); remove.type = "button"; remove.textContent = "×"; remove.title = "Remove louver"; remove.addEventListener("click", (event) => { event.stopPropagation(); assignment.louver = false; saveEquipmentZoning(project, state); }); louver.appendChild(remove); box.appendChild(louver); }
  box.appendChild(slots);

  const nodeControls = document.createElement("div"); nodeControls.className = "node-controls";
  ["oa", "sa", "ra", "ea"].forEach((node) => {
    const label = document.createElement("label"); const input = document.createElement("input"); input.type = "checkbox"; input.checked = nodes[node];
    input.addEventListener("change", () => { assignment.nodeOverrides ||= {}; assignment.nodeOverrides[node] = input.checked; state.selectedSpace = assignment.space; saveEquipmentZoning(project, state); });
    label.append(input, document.createTextNode(node.toUpperCase())); nodeControls.appendChild(label);
  });
  const autoNodes = document.createElement("button"); autoNodes.type = "button"; autoNodes.textContent = "Auto"; autoNodes.title = "Reset connection nodes to automatic"; autoNodes.addEventListener("click", () => { assignment.nodeOverrides = {}; saveEquipmentZoning(project, state); }); nodeControls.appendChild(autoNodes);
  card.append(header, equipmentLabel, box, nodeControls);
  const applySymbol = (symbolId) => {
    const error = applyZoningSymbol(project, state, assignment, symbolId);
    if (error) setStatus(error, true); else setStatus(`${zoningSymbol(symbolId)?.label || "Symbol"} added to ${assignment.space}.`);
  };
  card.addEventListener("dragover", (event) => { event.preventDefault(); card.classList.add("drag-over"); event.dataTransfer.dropEffect = "copy"; });
  card.addEventListener("dragleave", () => card.classList.remove("drag-over"));
  card.addEventListener("drop", (event) => { event.preventDefault(); card.classList.remove("drag-over"); applySymbol(event.dataTransfer.getData("text/plain")); });
  card.addEventListener("click", (event) => {
    if (event.target.closest("button, select, input, label")) return;
    if (state.pendingSymbol) {
      const symbol = state.pendingSymbol;
      const validation = validateZoningSymbol(assignment, symbol);
      if (validation) { setStatus(validation, true); return; }
      state.pendingSymbol = ""; applySymbol(symbol);
    }
    else { state.selectedSpace = assignment.space; saveEquipmentZoning(project, state); }
  });
  return card;
}

function renderZoningAssignmentTable(state, spaces) {
  const wrap = document.createElement("div"); wrap.className = "zoning-table-wrap";
  const table = document.createElement("table"); table.className = "zoning-assignment-table";
  const headers = ["Space", "Zone Group", "Zone", "Slot 1", "Slot 2", "Building Equipment", "OA", "SA", "RA", "EA", "Louver"];
  const head = document.createElement("thead"); const headRow = document.createElement("tr"); headers.forEach((text) => { const th = document.createElement("th"); th.textContent = text; headRow.appendChild(th); }); head.appendChild(headRow); table.appendChild(head);
  const body = document.createElement("tbody");
  spaces.forEach(({ space }) => {
    const assignment = state.assignments[space]; const nodes = automaticZoningNodes(assignment, state.library); const devices = assignment.devices.map((id) => zoningSymbol(id)?.label || id);
    const values = [space, assignment.group, assignment.zone, devices[0] || "", devices[1] || (zoningSymbol(assignment.devices[0])?.slots === 2 ? "Occupied by assembly" : ""), assignment.buildingId || "", nodes.oa ? "TRUE" : "", nodes.sa ? "TRUE" : "", nodes.ra ? "TRUE" : "", nodes.ea ? "TRUE" : "", assignment.louver ? "TRUE" : ""];
    const row = document.createElement("tr"); values.forEach((value) => { const td = document.createElement("td"); td.textContent = value; row.appendChild(td); }); body.appendChild(row);
  });
  table.appendChild(body); wrap.appendChild(table); return wrap;
}

function exportEquipmentZoningCsv(project) {
  const { state, spaces } = equipmentZoningState(project);
  const rows = [["Space", "Zone Group", "Zone", "Zone Equipment Slot 1", "Zone Equipment Slot 2", "Building Equipment", "OA", "SA", "RA", "EA", "Louver"]];
  spaces.forEach(({ space }) => {
    const assignment = state.assignments[space]; const nodes = automaticZoningNodes(assignment, state.library); const devices = assignment.devices.map((id) => zoningSymbol(id)?.label || id);
    rows.push([space, assignment.group, assignment.zone, devices[0] || "", devices[1] || (zoningSymbol(assignment.devices[0])?.slots === 2 ? "Occupied by assembly" : ""), assignment.buildingId || "", nodes.oa ? "TRUE" : "", nodes.sa ? "TRUE" : "", nodes.ra ? "TRUE" : "", nodes.ea ? "TRUE" : "", assignment.louver ? "TRUE" : ""]);
  });
  const csv = rows.map((row) => row.map((value) => `"${String(value ?? "").replace(/"/g, '""')}"`).join(",")).join("\r\n");
  const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
  const link = document.createElement("a"); link.href = url; link.download = `equipment-zoning-${project.number || "project"}.csv`; document.body.appendChild(link); link.click(); link.remove(); URL.revokeObjectURL(url);
}

function airsideSystemModel(project) {
  project.airsideSystemModel ||= { supply: [], exhaust: [], selectedSupply: "", selectedExhaust: "" };
  const model = project.airsideSystemModel;
  model.supply ||= []; model.exhaust ||= [];
  if (!model.initialized) {
    const legacy = [...(project.equipmentZoningTool?.library || [])];
    if (!legacy.length) {
      const zoning = independentTables.find((candidate) => candidate.id === "calc-equipment-zoning");
      const rows = zoning ? ensureProjectTableRows(project, zoning) : [];
      const seen = new Set();
      rows.forEach((row) => [row[3], row[4]].forEach((value) => {
        const id = String(value ?? "").trim(); const key = id.toLowerCase();
        if (!id || id === "-" || seen.has(key)) return; seen.add(key); legacy.push({ id, type: inferBuildingEquipmentType(id) });
      }));
    }
    legacy.filter((item) => item.type === "DOAS" || item.type === "Central AHU").forEach((item) => {
      if (!model.supply.some((system) => system.tag.toLowerCase() === item.id.toLowerCase())) {
        model.supply.push({ tag: item.id, ezCool: 1, ezHeat: 1, enteringLouver: "", supplyFan: `${item.id}-SF`, preheat: "In Unit", cooling: "In Unit", reheat: "In Unit", overrides: {} });
      }
    });
    model.initialized = true;
  }
  return model;
}

function defaultSupplySystem() {
  return { tag: "", ezCool: 1, ezHeat: 1, enteringLouver: "", supplyFan: "", preheat: "In Unit", cooling: "In Unit", reheat: "In Unit", overrides: {} };
}

function defaultExhaustSystem() {
  return { tag: "", mode: "", supplySystem: "", louver: "" };
}

function saveAirsideSystemModel(project, rerenderMode = "") {
  recalculateNetworkZoningTable(project);
  saveProjects();
  if (rerenderMode) renderAirsideSystemTool(rerenderMode);
}

function systemPreview(system, mode) {
  const preview = document.createElement("div"); preview.className = `inline-system-preview ${mode}`;
  const stage = document.createElement("div"); stage.className = "inline-system-stage";
  const add = (className, label) => { const item = document.createElement("span"); item.className = className; item.textContent = label; stage.appendChild(item); };
  if (mode === "supply") {
    if (system.enteringLouver) add("preview-louver", system.enteringLouver);
    add("preview-air entering", "OA");
    const box = document.createElement("div"); box.className = "preview-equipment-box";
    [["PH", system.preheat], ["CC", system.cooling], ["RH", system.reheat]].forEach(([label, value]) => { if (value === "In Unit") { const coil = document.createElement("i"); coil.textContent = label; box.appendChild(coil); } });
    stage.appendChild(box);
    if (system.supplyFan) add("preview-fan", system.supplyFan);
    add("preview-air leaving", "SA");
  } else {
    if (system.louver) add("preview-louver", system.louver);
    add("preview-air entering exhaust", "EA");
    add("preview-fan", system.tag || "Fan");
    add("preview-air leaving exhaust", "REL");
  }
  preview.appendChild(stage); return preview;
}

function renderAirsideSystemTool(mode) {
  const project = activeProject(); if (!project) return;
  const model = airsideSystemModel(project); const supplyMode = mode === "supply";
  const rows = supplyMode ? model.supply : model.exhaust;
  airsideSystemView.innerHTML = "";
  const toolbar = document.createElement("div"); toolbar.className = "system-tool-toolbar";
  const title = document.createElement("div"); title.innerHTML = `<span>${supplyMode ? "Supply air" : "Exhaust and relief"}</span><h3>${supplyMode ? "Building level systems" : "Building level exhaust / relief systems"}</h3>`;
  const add = document.createElement("button"); add.type = "button"; add.textContent = supplyMode ? "Add supply system" : "Add exhaust / relief system";
  add.addEventListener("click", () => { rows.push(supplyMode ? defaultSupplySystem() : defaultExhaustSystem()); saveAirsideSystemModel(project, mode); });
  toolbar.append(title, add); airsideSystemView.appendChild(toolbar);
  const tableWrap = document.createElement("div"); tableWrap.className = "system-table-wrap";
  const table = document.createElement("table"); table.className = `system-definition-table ${mode}`;
  const headers = supplyMode
    ? ["Tag", "Ez Cool", "Ez Heat", "Entering Louver Tag", "Supply Fan Tag", "Preheat Coil", "Cooling Coil", "Reheat Coil", ""]
    : ["Tag", "Mode", "Associated Supply System", "Louver Tag", ""];
  const head = document.createElement("thead"); const headerRow = document.createElement("tr"); headers.forEach((label) => { const th = document.createElement("th"); th.textContent = label; headerRow.appendChild(th); }); head.appendChild(headerRow); table.appendChild(head);
  const body = document.createElement("tbody");
  rows.forEach((system, index) => {
    const row = document.createElement("tr"); row.classList.toggle("selected", (supplyMode ? model.selectedSupply : model.selectedExhaust) === system.tag && Boolean(system.tag));
    row.addEventListener("click", (event) => { if (event.target.closest("input, select, button")) return; if (supplyMode) model.selectedSupply = system.tag; else model.selectedExhaust = system.tag; saveAirsideSystemModel(project, mode); });
    const appendCell = (control, className = "") => { const cell = document.createElement("td"); if (className) cell.className = className; cell.appendChild(control); row.appendChild(cell); };
    const textInput = (value, update, placeholder = "") => { const input = document.createElement("input"); input.value = value || ""; input.placeholder = placeholder; input.addEventListener("change", () => update(input.value.trim())); return input; };
    const tag = textInput(system.tag, (value) => {
      const previous = system.tag; system.tag = value;
      model.exhaust.forEach((candidate) => { if (candidate.supplySystem === previous) candidate.supplySystem = value; });
      if (supplyMode && model.selectedSupply === previous) model.selectedSupply = value;
      if (!supplyMode && model.selectedExhaust === previous) model.selectedExhaust = value;
      saveAirsideSystemModel(project, mode);
    }, "System tag"); appendCell(tag, "tag-cell");
    if (supplyMode) {
      system.overrides ||= {};
      [["ezCool", "1.0"], ["ezHeat", "1.0"]].forEach(([key, automatic]) => {
        const input = textInput(Number(system[key] ?? 1).toFixed(1), (value) => { const parsed = Number(value); system[key] = Number.isFinite(parsed) ? parsed : 1; system.overrides[key] = system[key] !== 1; saveAirsideSystemModel(project, mode); });
        input.classList.toggle("system-autofill", !system.overrides[key]); input.title = "Autopopulated value: 1.0"; appendCell(input);
      });
      appendCell(textInput(system.enteringLouver, (value) => { system.enteringLouver = value; saveAirsideSystemModel(project, mode); }, "Louver tag"));
      appendCell(textInput(system.supplyFan, (value) => { system.supplyFan = value; saveAirsideSystemModel(project, mode); }, "Fan tag"));
      ["preheat", "cooling", "reheat"].forEach((key) => {
        const select = document.createElement("select"); [["In Unit", "In Unit"], ["", "Clear"]].forEach(([value, label]) => { const option = document.createElement("option"); option.value = value; option.textContent = label; select.appendChild(option); }); select.value = system[key] ?? "In Unit";
        select.classList.toggle("system-autofill", select.value === "In Unit"); select.title = "Autopopulated value: In Unit";
        select.addEventListener("change", () => { system[key] = select.value; saveAirsideSystemModel(project, mode); }); appendCell(select);
      });
    } else {
      const modeSelect = document.createElement("select"); [["", "Blank"], ["Energy Recovery", "Energy Recovery"], ["Economizing", "Economizing"]].forEach(([value, label]) => { const option = document.createElement("option"); option.value = value; option.textContent = label; modeSelect.appendChild(option); }); modeSelect.value = system.mode || "";
      modeSelect.addEventListener("change", () => { system.mode = modeSelect.value; if (!system.mode) system.supplySystem = ""; saveAirsideSystemModel(project, mode); }); appendCell(modeSelect);
      const supplySelect = document.createElement("select"); const blank = document.createElement("option"); blank.value = ""; blank.textContent = system.mode ? "Select supply system" : "Not applicable"; supplySelect.appendChild(blank); model.supply.filter((candidate) => candidate.tag).forEach((candidate) => { const option = document.createElement("option"); option.value = candidate.tag; option.textContent = candidate.tag; supplySelect.appendChild(option); }); supplySelect.value = system.supplySystem || ""; supplySelect.disabled = !system.mode; supplySelect.title = system.mode ? "Select the related building level supply system." : "Select an energy recovery or economizing mode first.";
      supplySelect.addEventListener("change", () => { system.supplySystem = supplySelect.value; saveAirsideSystemModel(project, mode); }); appendCell(supplySelect, supplySelect.disabled ? "system-locked-cell" : "");
      appendCell(textInput(system.louver, (value) => { system.louver = value; saveAirsideSystemModel(project, mode); }, "Louver tag"));
    }
    const remove = document.createElement("button"); remove.type = "button"; remove.className = "system-remove-row"; remove.textContent = "×"; remove.title = `Remove ${system.tag || "row"}`; remove.addEventListener("click", () => { rows.splice(index, 1); saveAirsideSystemModel(project, mode); }); appendCell(remove);
    body.appendChild(row);
  });
  table.appendChild(body); tableWrap.appendChild(table); airsideSystemView.appendChild(tableWrap);
  if (!rows.length) { const empty = document.createElement("p"); empty.className = "zoning-empty-copy"; empty.textContent = `Add the first ${supplyMode ? "building level supply" : "exhaust / relief"} system.`; airsideSystemView.appendChild(empty); }
  const selectedTag = supplyMode ? model.selectedSupply : model.selectedExhaust;
  const selected = rows.find((system) => system.tag === selectedTag) || rows[0];
  if (selected) { const previewHeading = document.createElement("div"); previewHeading.className = "system-preview-heading"; previewHeading.innerHTML = `<span>Selected configuration</span><strong>${selected.tag || "Untitled system"}</strong>`; airsideSystemView.append(previewHeading, systemPreview(selected, mode)); }
}

function zoningNetworkModel(project) {
  project.zoningNetwork ||= { groups: {} };
  const network = project.zoningNetwork; network.groups ||= {};
  const { spaces, groups } = equipmentZoningState(project);
  groups.forEach((group) => {
    if (network.groups[group]) return;
    const legacyAssignment = spaces.map((item) => project.equipmentZoningTool.assignments[item.space]).find((assignment) => assignment?.group === group && assignment.buildingId);
    network.groups[group] = { ventilationSystem: legacyAssignment?.buildingId || "", supplySystem: "", exhaustSystem: "", returnSystem: "" };
  });
  Object.keys(network.groups).forEach((group) => { if (!groups.includes(group)) delete network.groups[group]; });
  return { network, spaces, groups };
}

function saveZoningNetwork(project, rerender = true) {
  recalculateNetworkZoningTable(project);
  saveProjects();
  if (rerender) renderEquipmentZoningTool();
}

function networkSystemCard(system, mode) {
  const card = document.createElement("article"); card.className = `network-system-card ${mode}`; card.dataset.systemId = system.tag;
  const header = document.createElement("header"); const label = document.createElement("span"); label.textContent = mode === "supply" ? "Supply system" : "Exhaust / relief"; const title = document.createElement("strong"); title.textContent = system.tag || "Untitled"; header.append(label, title);
  const details = document.createElement("div"); details.className = "network-system-details";
  if (mode === "supply") {
    [system.enteringLouver && `Louver ${system.enteringLouver}`, system.supplyFan && `Fan ${system.supplyFan}`, system.preheat === "In Unit" && "PH", system.cooling === "In Unit" && "CC", system.reheat === "In Unit" && "RH"].filter(Boolean).forEach((text) => { const chip = document.createElement("span"); chip.textContent = text; details.appendChild(chip); });
  } else {
    [system.mode, system.supplySystem && `Linked ${system.supplySystem}`, system.louver && `Louver ${system.louver}`].filter(Boolean).forEach((text) => { const chip = document.createElement("span"); chip.textContent = text; details.appendChild(chip); });
  }
  card.append(header, details); return card;
}

function networkSystemSelect(options, value, blankLabel, onChange) {
  const select = document.createElement("select"); const blank = document.createElement("option"); blank.value = ""; blank.textContent = blankLabel; select.appendChild(blank);
  options.filter((item) => item.tag).forEach((item) => { const option = document.createElement("option"); option.value = item.tag; option.textContent = item.tag; select.appendChild(option); }); select.value = value || "";
  select.addEventListener("change", () => onChange(select.value)); return select;
}

function renderEquipmentZoningTool() {
  const project = activeProject(); if (!project) return;
  const systems = airsideSystemModel(project); const { network, spaces, groups } = zoningNetworkModel(project);
  equipmentZoningView.innerHTML = "";
  const toolbar = document.createElement("div"); toolbar.className = "network-toolbar";
  const heading = document.createElement("div"); heading.innerHTML = `<span>System network</span><h3>Building systems to zone groups</h3>`;
  const summary = document.createElement("strong"); summary.textContent = `${systems.supply.filter((item) => item.tag).length} supply · ${groups.length} zone groups · ${systems.exhaust.filter((item) => item.tag).length} exhaust / relief`;
  toolbar.append(heading, summary); equipmentZoningView.appendChild(toolbar);
  const stage = document.createElement("div"); stage.className = "zoning-network-stage";
  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg"); svg.classList.add("zoning-network-lines"); svg.setAttribute("aria-hidden", "true"); stage.appendChild(svg);
  const supplyColumn = document.createElement("section"); supplyColumn.className = "network-column supply-column"; supplyColumn.innerHTML = "<h4>Building Level Supply</h4>";
  systems.supply.filter((system) => system.tag).forEach((system) => supplyColumn.appendChild(networkSystemCard(system, "supply")));
  if (supplyColumn.children.length === 1) { const empty = document.createElement("p"); empty.textContent = "Define supply systems in Airside Equipment."; supplyColumn.appendChild(empty); }
  const groupColumn = document.createElement("section"); groupColumn.className = "network-column group-column"; groupColumn.innerHTML = "<h4>Zone Groups</h4>";
  groups.forEach((group) => {
    const config = network.groups[group]; const spacesInGroup = spaces.filter((item) => item.group === group).length;
    const card = document.createElement("article"); card.className = "network-zone-card"; card.dataset.group = group;
    const title = document.createElement("header"); title.innerHTML = `<strong>${group}</strong><span>${spacesInGroup} spaces</span>`; card.appendChild(title);
    const body = document.createElement("div"); body.className = "network-zone-body";
    const addNode = (side, key, label, className, options, blank) => {
      const node = document.createElement("label"); node.className = `network-node ${side} ${className}`; node.dataset.networkKey = key;
      const text = document.createElement("span"); text.textContent = label;
      const select = networkSystemSelect(options, config[key], blank, (value) => { config[key] = value; saveZoningNetwork(project); });
      node.append(text, select); body.appendChild(node);
    };
    addNode("left", "ventilationSystem", "VENT · OA", "vent-node", systems.supply, "No ventilation system");
    addNode("left", "supplySystem", "SA / OA", "supply-node", systems.supply, "No supply system");
    addNode("right", "exhaustSystem", "EXH · EA", "exhaust-node", systems.exhaust, "No exhaust system");
    addNode("right", "returnSystem", "RA / EA", "return-node", systems.exhaust, "No return / relief system");
    const room = document.createElement("div"); room.className = "network-zone-room"; room.textContent = group; body.appendChild(room); card.appendChild(body); groupColumn.appendChild(card);
  });
  const exhaustColumn = document.createElement("section"); exhaustColumn.className = "network-column exhaust-column"; exhaustColumn.innerHTML = "<h4>Exhaust / Relief</h4>";
  systems.exhaust.filter((system) => system.tag).forEach((system) => exhaustColumn.appendChild(networkSystemCard(system, "exhaust")));
  if (exhaustColumn.children.length === 1) { const empty = document.createElement("p"); empty.textContent = "Define exhaust / relief systems in Airside Equipment."; exhaustColumn.appendChild(empty); }
  stage.append(supplyColumn, groupColumn, exhaustColumn); equipmentZoningView.appendChild(stage);
  const note = document.createElement("p"); note.className = "network-note"; note.textContent = "Connections apply to every space in a zone group. Use Equipment Zoning Table for individual valve, coil, and equipment overrides."; equipmentZoningView.appendChild(note);
  const redraw = () => drawZoningNetworkConnections(stage, svg, network.groups);
  requestAnimationFrame(redraw); zoningNetworkResizeObserver?.disconnect();
  if ("ResizeObserver" in window) { zoningNetworkResizeObserver = new ResizeObserver(redraw); zoningNetworkResizeObserver.observe(stage); }
}

function drawZoningNetworkConnections(stage, svg, groups) {
  const namespace = "http://www.w3.org/2000/svg"; const rect = stage.getBoundingClientRect();
  svg.setAttribute("viewBox", `0 0 ${rect.width} ${rect.height}`); svg.setAttribute("width", String(rect.width)); svg.setAttribute("height", String(rect.height)); svg.replaceChildren();
  const defs = document.createElementNS(namespace, "defs");
  [["vent", "#4b9dcc"], ["supply", "#79a98c"], ["exhaust", "#7b3540"], ["return", "#003b8c"]].forEach(([id, color]) => {
    const marker = document.createElementNS(namespace, "marker"); marker.id = `arrow-${id}`; marker.setAttribute("markerWidth", "8"); marker.setAttribute("markerHeight", "8"); marker.setAttribute("refX", "7"); marker.setAttribute("refY", "4"); marker.setAttribute("orient", "auto"); const path = document.createElementNS(namespace, "path"); path.setAttribute("d", "M0,0 L8,4 L0,8 Z"); path.setAttribute("fill", color); marker.appendChild(path); defs.appendChild(marker);
  }); svg.appendChild(defs);
  const systemCard = (columnClass, id) => [...stage.querySelectorAll(`.${columnClass} .network-system-card`)].find((card) => card.dataset.systemId === id);
  const connect = (from, to, type, reverse = false) => {
    if (!from || !to) return; const a = from.getBoundingClientRect(); const b = to.getBoundingClientRect();
    const startX = reverse ? a.left - rect.left : a.right - rect.left; const startY = a.top + a.height / 2 - rect.top;
    const endX = reverse ? b.right - rect.left : b.left - rect.left; const endY = b.top + b.height / 2 - rect.top; const bend = (startX + endX) / 2;
    const path = document.createElementNS(namespace, "path"); path.setAttribute("d", `M${startX},${startY} C${bend},${startY} ${bend},${endY} ${endX},${endY}`); path.setAttribute("class", `network-line ${type}`); path.setAttribute("marker-end", `url(#arrow-${type})`); svg.appendChild(path);
  };
  Object.entries(groups).forEach(([group, config]) => {
    const card = [...stage.querySelectorAll(".network-zone-card")].find((candidate) => candidate.dataset.group === group); if (!card) return;
    connect(systemCard("supply-column", config.ventilationSystem), card.querySelector('[data-network-key="ventilationSystem"]'), "vent");
    connect(systemCard("supply-column", config.supplySystem), card.querySelector('[data-network-key="supplySystem"]'), "supply");
    connect(card.querySelector('[data-network-key="exhaustSystem"]'), systemCard("exhaust-column", config.exhaustSystem), "exhaust");
    connect(card.querySelector('[data-network-key="returnSystem"]'), systemCard("exhaust-column", config.returnSystem), "return");
  });
}

function updateTableSettings(table) {
  const scheduleVisible = Boolean(table.twoValueScheduleDefault);
  const factorsVisible = Boolean(table.roomLoadCalculation);
  const metricVisible = Boolean(table.topMetric);
  const minimumDefault = table.ventilationMinimumDefault ?? table.exhaustMinimumDefault ?? table.supplyMinimumDefault;
  const minimumVisible = minimumDefault !== undefined;
  tableSettings.hidden = !scheduleVisible && !factorsVisible && !minimumVisible && !metricVisible;
  tableMetric.hidden = !metricVisible;
  twoValueSetting.hidden = !scheduleVisible;
  loadFactorSettings.hidden = !factorsVisible;
  minimumSetting.hidden = !minimumVisible;
  if (!scheduleVisible && !factorsVisible && !minimumVisible) return;
  const project = activeProject();
  if (minimumVisible) {
    minimumLabel.textContent = table.ventilationMinimumDefault !== undefined ? "Ventilation Minimum [CFM]"
      : table.exhaustMinimumDefault !== undefined ? "Exhaust Minimum [CFM]" : "Supply Minimum [CFM]";
    const stored = project?.calcSettings?.airflowMinimums?.[table.id];
    minimumInput.value = String(stored ?? minimumDefault);
    minimumInput.classList.toggle("auto-default", stored === undefined || Number(stored) === Number(minimumDefault));
    minimumInput.dataset.tableId = table.id;
    minimumInput.title = `Autopopulated value: ${minimumDefault} CFM`;
  }
  if (!project) {
    if (scheduleVisible) { twoValueSchedule.value = table.twoValueScheduleDefault; twoValueSchedule.classList.add("auto-default"); twoValueSchedule.title = `Autopopulated value: ${table.twoValueScheduleDefault}`; }
    if (factorsVisible) [sensibleLoadFactor, latentLoadFactor, heatingLoadFactor].forEach((input) => { input.value = "10"; input.classList.add("auto-default"); input.title = "Autopopulated value: 10%"; });
    return;
  }
  project.calcSettings ||= {};
  if (scheduleVisible) {
    twoValueSchedule.value = project.calcSettings.twoValueSchedule || table.twoValueScheduleDefault;
    twoValueSchedule.classList.toggle("auto-default", twoValueSchedule.value === table.twoValueScheduleDefault);
    twoValueSchedule.title = `Autopopulated value: ${table.twoValueScheduleDefault}`;
  }
  if (factorsVisible) {
    project.calcSettings.spaceLoadFactors ||= { sensible: 0.1, latent: 0.1, heating: 0.1 };
    sensibleLoadFactor.value = tableNumberFormatter.format(project.calcSettings.spaceLoadFactors.sensible * 100);
    latentLoadFactor.value = tableNumberFormatter.format(project.calcSettings.spaceLoadFactors.latent * 100);
    heatingLoadFactor.value = tableNumberFormatter.format(project.calcSettings.spaceLoadFactors.heating * 100);
    [[sensibleLoadFactor, "sensible"], [latentLoadFactor, "latent"], [heatingLoadFactor, "heating"]]
      .forEach(([input, key]) => { input.classList.toggle("auto-default", Number(project.calcSettings.spaceLoadFactors[key]) === 0.1); input.title = "Autopopulated value: 10%"; });
  }
}

function refreshTableMetric(table, rows) {
  document.querySelectorAll(".additional-table-metric").forEach((node) => node.remove());
  if (!table.topMetric) return;
  const sum = (column) => rows.reduce((total, row) => total + (Number(row[column]) || 0), 0);
  (table.topMetrics || [table.topMetric]).forEach((metric, index) => {
    const node = index === 0 ? tableMetric : document.createElement("div");
    if (index > 0) {
      node.className = "table-metric additional-table-metric";
      node.append(document.createElement("span"), document.createElement("output"));
      node.addEventListener("click", () => showMetricEquation(metric, node));
      node.addEventListener("keydown", (event) => {
        if (event.key === "Enter" || event.key === " ") { event.preventDefault(); showMetricEquation(metric, node); }
      });
      tableMetric.parentElement.appendChild(node);
    }
    const denominator = sum(metric.denominator);
    const numerator = metric.numeratorDifference ? sum(metric.numeratorDifference[0]) - sum(metric.numeratorDifference[1]) : sum(metric.numerator);
    node.querySelector("span").textContent = metric.label;
    node.querySelector("output").textContent = table.displayZeroAsDash && numerator === 0 ? "-"
      : denominator > 0 ? `${oneDecimalFormatter.format(numerator / denominator * 100)}%` : "-";
    node.classList.toggle("calculated-metric", Boolean(metric.calculated));
    node.tabIndex = metric.calculated ? 0 : -1;
    node.setAttribute("role", "button");
    node.title = "Select to view the equation";
  });
}

function isConditionalCalculatedCell(table, row, columnIndex) {
  const config = table.conditionalCalculatedColumns?.[columnIndex];
  if (!config) return false;
  const value = row[config.whenColumn];
  return value !== "" && value !== null && value !== undefined;
}

function isUnusedGainCell(table, row, columnIndex) {
  const populated = (value) => value !== "" && value !== null && value !== undefined;
  if (table.id === "calc-lighting-gains") {
    if (columnIndex === 3) return populated(row[6]) || populated(row[5]);
    if (columnIndex === 5) return populated(row[6]);
  }
  if (table.id === "calc-people-gains" && columnIndex === 3) return populated(row[4]);
  if (table.id === "calc-misc-gains" && columnIndex === 3) return populated(row[4]);
  return false;
}

function humidityRatio(dryBulbF, relativeHumidity) {
  const dryBulb = Number(dryBulbF);
  const humidity = Number(relativeHumidity);
  if (!Number.isFinite(dryBulb) || !Number.isFinite(humidity)) return "";
  const dryBulbC = (dryBulb - 32) * 5 / 9;
  const saturationPressure = 0.145038 * 0.61094 * Math.exp((17.625 * dryBulbC) / (dryBulbC + 243.04));
  const vaporPressure = saturationPressure * humidity;
  return 0.621945 * vaporPressure / (14.166979464192584 - vaporPressure);
}

function recalculateSpecialTableRow(table, row) {
  if (table.id !== "calc-space-condition-setpoints") return;
  if (isConditionalCalculatedCell(table, row, 8)) {
    const rise = Number(row[7]);
    row[8] = Number.isFinite(rise) ? 91.6 + rise : "";
  }
  row[5] = humidityRatio(row[3], row[2]);
  row[10] = humidityRatio(row[8], row[2]);
}

function clearFillPreview() {
  referenceTable.querySelectorAll(".fill-preview").forEach((cell) => cell.classList.remove("fill-preview"));
}

function clearFillHandle() {
  if (fillHandleFrame) cancelAnimationFrame(fillHandleFrame);
  fillHandleFrame = 0;
  fillHandleElement?.remove();
  fillHandleElement = null;
  fillHandleCell?.classList.remove("fill-source");
  fillHandleCell = null;
  fillHandleContext = null;
}

function paintTableTones() {
  referenceTable.querySelectorAll("tbody td, tfoot td").forEach(cell=>{
    const c=cell.classList;
    cell.dataset.tone=c.contains("csv-different")?"yellow":c.contains("csv-match")?"purple":c.contains("auto-populated-cell")?"green":c.contains("editable-cell")&&!c.contains("dynamically-locked-cell")?"blue":c.contains("identity-cell")||c.contains("empty-difference-count")||c.contains("summary-label")?"white":c.contains("calculated-cell")||c.contains("locked-cell")||c.contains("not-specified-cell")||cell.closest("tfoot")?"grey":"white";
  });
}
function clearTableHover() {
  referenceTable.querySelectorAll(".hover-row,.hover-column,.hover-cell").forEach(c=>c.classList.remove("hover-row","hover-column","hover-cell"));
}
function hoverTableCell(event) {
  const cell=event.target.closest("tbody td, tfoot td");if(!cell||cell.classList.contains("hover-cell"))return;
  clearTableHover();const column=Number(cell.dataset.columnIndex??cell.cellIndex);
  cell.parentElement.classList.add("hover-row");cell.classList.add("hover-cell");
  referenceTable.querySelectorAll("tbody tr, tfoot tr").forEach(row=>{
    let offset=0;for(const c of row.cells){if(column>=offset&&column<offset+(c.colSpan||1)){c.classList.add("hover-column");break;}offset+=c.colSpan||1;}
  });
}

function positionFillHandle() {
  if (!fillHandleElement || !fillHandleCell?.isConnected) return;
  const rect=fillHandleCell.getBoundingClientRect(), viewport=tableScroll.getBoundingClientRect();
  const visibleRects=selector=>[...referenceTable.querySelectorAll(selector)].filter(c=>c.getClientRects().length).map(c=>c.getBoundingClientRect());
  const top=Math.max(viewport.top,...visibleRects("thead th").map(r=>r.bottom));
  const bottom=Math.min(viewport.top+tableScroll.clientHeight,...visibleRects("tfoot td").map(r=>r.top));
  const frozen=[...fillHandleCell.parentElement.cells].find(c=>c.classList.contains("frozen-edge"));
  const left=fillHandleCell.style.left!=="auto" ? viewport.left : Math.max(viewport.left,frozen?.getBoundingClientRect().right||viewport.left);
  fillHandleElement.hidden=rect.bottom-8<top || rect.bottom+1>bottom || rect.right<left+7 || rect.right>viewport.left+tableScroll.clientWidth;
  fillHandleElement.style.left=`${rect.right-7}px`;fillHandleElement.style.top=`${rect.bottom-7}px`;
}

function scheduleFillHandlePosition() {
  if (!fillHandleElement || fillHandleFrame) return;
  fillHandleFrame = requestAnimationFrame(() => {
    fillHandleFrame = 0;
    positionFillHandle();
  });
}

function showFillHandle(cell, table, rows, sourceIndex, columnIndex) {
  if (!cell.classList.contains("editable-cell")) { clearFillHandle(); return; }
  fillHandleCell?.classList.remove("fill-source");
  fillHandleCell = cell;
  fillHandleContext = { table, rows, sourceIndex, columnIndex };
  cell.classList.add("fill-source");
  if (!fillHandleElement) {
    fillHandleElement = document.createElement("span");
    fillHandleElement.className = "fill-handle";
    fillHandleElement.setAttribute("role", "button");
    fillHandleElement.setAttribute("aria-label", "Drag to fill cells below");
    fillHandleElement.addEventListener("pointerdown", (event) => {
      event.preventDefault();
      event.stopPropagation();
      fillHandleElement.setPointerCapture?.(event.pointerId);
      const { table, rows, sourceIndex, columnIndex } = fillHandleContext;
      fillDrag = { table, rows, sourceIndex, columnIndex, sourceValue: rows[sourceIndex][columnIndex], targetIndexes: [] };
    });
    document.body.appendChild(fillHandleElement);
  }
  scheduleFillHandlePosition();
}

function updateFillPreview(clientX, clientY) {
  if (!fillDrag) return;
  const target = document.elementFromPoint(clientX, clientY)?.closest?.("td");
  if (!target || Number(target.dataset.columnIndex) !== fillDrag.columnIndex) return;
  const bodyRows = [...referenceTable.querySelectorAll("tbody tr:not(.table-summary-row)")];
  const originRow = bodyRows.findIndex((row) => Number(row.dataset.sourceIndex) === fillDrag.sourceIndex);
  const targetRow = bodyRows.indexOf(target.parentElement);
  if (originRow < 0 || targetRow < 0) return;
  const [start, end] = originRow <= targetRow ? [originRow, targetRow] : [targetRow, originRow];
  fillDrag.targetIndexes = bodyRows.slice(start, end + 1).map((row) => Number(row.dataset.sourceIndex));
  clearFillPreview();
  bodyRows.slice(start, end + 1).forEach((row) => row.cells[fillDrag.columnIndex]?.classList.add("fill-preview"));
}

function finishFillDrag() {
  if (!fillDrag) return;
  const { table, rows, sourceIndex, columnIndex, sourceValue, targetIndexes } = fillDrag;
  if (targetIndexes.length < 2) { clearFillPreview(); fillDrag = null; return; }
  const dropdownSnapshots=snapshotDropdownReferences(table.id,[columnIndex]);
  targetIndexes.filter((index) => index !== sourceIndex).forEach((index) => {
    if (table.lockedCellStates?.get(index)?.has(columnIndex)) return;
    recordPressurizationOverride(table, rows[index], columnIndex, sourceValue, activeProject());
    recordScheduleOverride(table, rows[index], columnIndex, sourceValue, activeProject());
    recordZoningOverride(table, rows[index], columnIndex, sourceValue, activeProject());
    recordNetworkZoningOverride(table, rows[index], columnIndex, sourceValue, activeProject());
    recordAirsideOverride(table, rows[index], columnIndex, sourceValue, activeProject());
    rows[index][columnIndex] = sourceValue;
    recalculateSpecialTableRow(table, rows[index]);
  });
  clearFillPreview();
  fillDrag = null;
  recalculateTable(table, rows);
  reconcileRemovedDropdownValues(dropdownSnapshots,activeProject());
  recalculateDependentTables(table);
  saveProjects();
  renderReferenceTable(table.id, tableSearch.value, { skipRecalculation: true });
}

function supportsEquipmentFilter(table) {return Boolean(table.airsideSection) && !table.plantCalculation;}
function rowSpaceValues(table, row) {
  if(supportsEquipmentFilter(table))return [row[0]];
  return table.transferAirCalculation ? [row[4], row[6]] : [row[table.thermalTemplateCalculation ? 0 : table.spaceColumn]];
}
function rowMatchesSpaceSet(table, row, spaces) {
  return !spaces || rowSpaceValues(table, row).some((value) => spaces.has(requirementKey(value)));
}
function sharedSpaceSearchMatches(table, row, project) {
  const search = String((supportsEquipmentFilter(table) ? project?.equipmentSearch : table.thermalTemplateCalculation ? project?.thermalTableSearch : project?.sharedSpaceSearch) || "").trim().toLowerCase();
  return !search || rowSpaceValues(table, row).some((value) => String(value ?? "").toLowerCase().includes(search));
}

function supportsSharedSpaceFilter(table) {
  return supportsEquipmentFilter(table) || table.thermalTemplateCalculation || table.id === "room-zone-loads-report" || table.tabularCalculation || modules.some((module) => ["Space Calculations", "Air Balances", "Selected Space Requirements"].includes(module.group)
    && module.items.some((item) => item[3] === table.id));
}

function spaceFilterColumnLabel(table, column) {
  const header = table.headers[column];
  const group = table.headerGroups?.find((group) => column >= group.start && column < group.start + group.span);
  const label = `${header.label}${header.subscript || ""}${header.unit ? ` [${header.unit}]` : ""}`;
  const duplicates = table.headers.filter((item) => item.label === header.label).length;
  const occurrence = table.headers.slice(0, column + 1).filter((item) => item.label === header.label).length;
  return group ? `${group.label} — ${label}` : duplicates > 1 ? `${label} (${occurrence})` : label;
}

function spaceFilterDescriptor(field) {
  if(field==="equipment:unitType")return {field,meta:"unitType",label:"Unit Type"};
  const labels = { zoneGroup: "Zone Group", zone: "Zone", space: "Space", type: "Thermal Template" };
  if (field.startsWith("meta:")) return labels[field.slice(5)] ? { field, meta: field.slice(5), label: labels[field.slice(5)] } : null;
  const [, id, index] = field.split(":");
  const table = independentTables.find((table) => table.id === id);
  const column = Number(index);
  if (!table || !supportsSharedSpaceFilter(table) || !Number.isInteger(column) || !table.headers[column]) return null;
  return { field, table, column, label: spaceFilterColumnLabel(table, column) };
}

function prepareSharedSpaceFilter(table, sourceRows, project, calculate = true) {
  if(supportsEquipmentFilter(table))return prepareEquipmentFilter(table,sourceRows,project,calculate);
  if (!supportsSharedSpaceFilter(table) || !project) return null;
  const thermal = table.thermalTemplateCalculation;
  const state = thermal ? project.thermalTableFilter ||= { field: `col:${table.id}:0`, values: null }
    : project.sharedSpaceFilter ||= { field: "meta:zoneGroup", values: null };
  if (!thermal && (state.field === "meta:space" || (spaceFilterDescriptor(state.field)?.table && spaceFilterDescriptor(state.field).column === spaceFilterDescriptor(state.field).table.spaceColumn))) { state.field = "meta:zoneGroup"; state.values = null; }
  let descriptor = spaceFilterDescriptor(state.field);
  if (!descriptor) { state.field = "meta:zoneGroup"; state.values = null; descriptor = spaceFilterDescriptor(state.field); }
  const source = (id) => { const t = independentTables.find((t) => t.id === id); return t ? (calculate ? ensureProjectTableRows(project,t) : project.independentTables?.[t.id]||t.rows) : []; };
  let entries;
  if (thermal) {
    entries = sourceRows.map((row) => ({ space: requirementKey(row[0]), value: String(row[descriptor.column ?? 0] ?? "") }));
  } else if (descriptor.meta) {
    const zoning = new Map(source("calc-equipment-zoning").map((row) => [requirementKey(row[2]), row]));
    const conditions = new Map(source("calc-space-condition-setpoints").map((row) => [requirementKey(row[0]), row]));
    entries = source("iesve-tabular-space-data").map((row) => {
      const space = requirementKey(row[tabularColumn.space]);
      const values = { zoneGroup: zoning.get(space)?.[0], zone: zoning.get(space)?.[1], space: row[tabularColumn.space], type: conditions.get(space)?.[1] };
      return { space, value: String(values[descriptor.meta] ?? "") };
    });
  } else {
    const otherRows = descriptor.table.id === table.id ? sourceRows : source(descriptor.table.id);
    if (calculate && descriptor.table.id !== table.id) recalculateTable(descriptor.table, otherRows, project);
    entries = otherRows.map((row) => ({ space: requirementKey(row[descriptor.table.spaceColumn]), value: String(row[descriptor.column] ?? "") }));
  }
  const counts = new Map();
  entries.forEach(({ value }) => counts.set(value, (counts.get(value) || 0) + 1));
  const options = [...counts].sort(([left], [right]) => left.localeCompare(right, undefined, { numeric: true, sensitivity: "base" }))
    .map(([value, count]) => ({ value, label: value === "" ? "(Blanks)" : value, count }));
  const selected = Array.isArray(state.values) ? new Set(state.values.map(String)) : null;
  let matchingSpaces = selected ? new Set(entries.filter(({ value }) => selected.has(value)).map(({ space }) => space)) : null;
  const matchingRows = selected && descriptor.table?.id === table.id
    ? new Set(sourceRows.filter((row) => selected.has(String(row[descriptor.column] ?? "")))) : null;
  const spaceOptions = thermal ? [] : [...new Map(sourceRows.filter((row) =>
    rowMatchesSpaceSet(table, row, matchingSpaces) && (!matchingRows || matchingRows.has(row)) && sharedSpaceSearchMatches(table, row, project))
    .flatMap((row) => rowSpaceValues(table, row).map((value) => [requirementKey(value), String(value ?? "")]))).entries()]
    .filter(([key]) => key).map(([value,label]) => ({ value,label })).sort((a,b) => a.label.localeCompare(b.label, undefined, { numeric: true }));
  if (!thermal && project.excludedSpaces?.length) {
    const excluded = new Set(project.excludedSpaces);
    const eligible = matchingSpaces || new Set(sourceRows.flatMap((row) => rowSpaceValues(table, row).map(requirementKey)));
    matchingSpaces = new Set([...eligible].filter((space) => !excluded.has(space)));
  }
  return { state, descriptor, options, matchingSpaces, matchingRows, spaceOptions, thermal };
}

function prepareEquipmentFilter(table,sourceRows,project,calculate=true) {
  if(!project)return null;
  const state=project.equipmentFilter ||= {field:"equipment:unitType",values:null};
  let descriptor=spaceFilterDescriptor(state.field);
  if(!descriptor || (!descriptor.meta && (!supportsEquipmentFilter(descriptor.table) || descriptor.column===0))) {state.field="equipment:unitType";state.values=null;descriptor=spaceFilterDescriptor(state.field);}
  const sourceTable=descriptor.meta ? independentTables.find(t=>t.id==="airside-settings") : descriptor.table;
  const other=sourceTable===table?sourceRows:calculate?ensureProjectTableRows(project,sourceTable):project.independentTables?.[sourceTable.id]||sourceTable.rows;
  if(calculate && sourceTable!==table)recalculateTable(sourceTable,other,project);
  const column=descriptor.meta?3:descriptor.column;
  const entries=other.map(r=>({tag:requirementKey(r[0]),value:String(r[column]??"")}));
  const counts=new Map();entries.forEach(e=>counts.set(e.value,(counts.get(e.value)||0)+1));
  const options=[...counts].sort(([a],[b])=>a.localeCompare(b,undefined,{numeric:true})).map(([value,count])=>({value,label:value||"(Blanks)",count}));
  const selected=Array.isArray(state.values)?new Set(state.values):null;
  let matchingSpaces=selected?new Set(entries.filter(e=>selected.has(e.value)).map(e=>e.tag)):null;
  const spaceOptions=sourceRows.filter(r=>rowMatchesSpaceSet(table,r,matchingSpaces)&&sharedSpaceSearchMatches(table,r,project)).map(r=>({value:requirementKey(r[0]),label:String(r[0])}));
  if(project.excludedEquipment?.length){const excluded=new Set(project.excludedEquipment);matchingSpaces=new Set([...(matchingSpaces||new Set(sourceRows.map(r=>requirementKey(r[0]))))].filter(t=>!excluded.has(t)));}
  return {state,descriptor,options,matchingSpaces,spaceOptions,equipment:true,thermal:false,matchingRows:null};
}
function updateBrowserRowCounts() {
  const project=activeProject();if(!project)return;
  const contexts=new Map(),data=t=>project.independentTables?.[t.id]||t.rows;
  document.querySelectorAll('[data-row-count-table]').forEach(badge=>{
    const t=independentTables.find(t=>t.id===badge.dataset.rowCountTable);if(!t)return;
    const rows=data(t),total=rows.length;
    let visible=total;
    if(supportsSharedSpaceFilter(t)) {
      const category=supportsEquipmentFilter(t)?'equipment':t.thermalTemplateCalculation?'thermal':'space';
      if(!contexts.has(category))contexts.set(category,prepareSharedSpaceFilter(t,rows,project,false));
      const context=contexts.get(category);
      visible=rows.filter(r=>rowMatchesSpaceSet(t,r,context?.matchingSpaces)&&sharedSpaceSearchMatches(t,r,project)&&(!context?.matchingRows||context.descriptor.table?.id!==t.id||context.matchingRows.has(r))).length;
    } else if(t.id===activeTableId && !t.plantCalculation && tableSearch.value.trim()) {
      const q=tableSearch.value.trim().toLowerCase();visible=rows.filter(r=>r.some(v=>String(v??'').toLowerCase().includes(q))).length;
    }
    badge.textContent=visible===total?String(total):`${visible}/${total}`;badge.classList.toggle('is-filtered',visible<total);
    badge.title=visible===total?`${total} rows`:`${visible} of ${total} rows visible`;
  });
}

function currentFilterExclusions(project=activeProject()) {return project?.[spaceFilterContext?.equipment?"excludedEquipment":"excludedSpaces"]||[];}

function closeCellDropdown() {
  document.querySelector('.cell-dropdown-popup')?.remove();
}

function configureCellDropdown(cell, table, rows, sourceIndex, column, value, options) {
  if(value==="FALSE" && options.some(v=>String(v).toUpperCase()==="TRUE"))value="";
  cell.classList.add('editable-cell', 'dropdown-cell'); cell.tabIndex = 0;
  const text = document.createElement('span'); text.className = 'dropdown-value'; text.textContent = String(value ?? '');
  const arrow = document.createElement('button'); arrow.type = 'button'; arrow.className = 'cell-dropdown-arrow'; arrow.tabIndex = -1;
  arrow.setAttribute('aria-label', `Open ${table.headers[column].label} choices`); arrow.innerHTML = '<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M5 7.5L10 12.5L15 7.5"/></svg>';
  cell.setAttribute('aria-haspopup', 'listbox'); cell.setAttribute('aria-expanded', 'false');
  const open = (initial = '') => openCellDropdown(cell, table, rows, sourceIndex, column, options, initial);
  arrow.addEventListener('pointerdown', (e) => { e.preventDefault(); e.stopPropagation(); });
  arrow.addEventListener('click', (e) => { e.stopPropagation(); cell.focus({ preventScroll: true }); open(); });
  cell.addEventListener('click', (e) => { if (!cell.classList.contains('editing-cell')&&!e.target.closest('.cell-note-flag,.dropdown-inline-editor')) cell.focus({ preventScroll: true }); });
  cell.addEventListener('focus', () => { if (activeCellSelection?.tableId !== table.id || activeCellSelection?.sourceIndex !== sourceIndex || activeCellSelection?.columnIndex !== column) selectTableCell(table.id, sourceIndex, column); showFillHandle(cell, table, rows, sourceIndex, column); });
  cell.addEventListener('keydown', (e) => {
    if (e.target !== cell) return;
    if (e.key === 'F4' || e.key === 'F2' || (e.altKey && e.key === 'ArrowDown')) { e.preventDefault(); open(); }
    else if (!e.ctrlKey && !e.metaKey && !e.altKey && (e.key.length === 1 || e.key === 'Backspace')) { e.preventDefault(); e.stopPropagation(); open(e.key === 'Backspace' ? '' : e.key); }
    else if (['ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Enter','Tab'].includes(e.key)) { e.preventDefault(); moveToAdjacentCell(cell, e.key === 'Enter' ? 'ArrowDown' : e.key === 'Tab' ? e.shiftKey ? 'ArrowLeft' : 'ArrowRight' : e.key, e.shiftKey); }
  });
  cell.startCellEdit=()=>{
    if(cell.querySelector('.dropdown-inline-editor'))return;
    const editor=document.createElement('input');editor.className='dropdown-inline-editor';editor.value=String(rows[sourceIndex][column]??'');editor.setAttribute('aria-label',table.headers[column].label);text.hidden=true;cell.appendChild(editor);cell.classList.add('editing-cell');
    const finish=(cancel=false)=>{if(!editor.isConnected)return;const raw=editor.value,match=options.find(v=>String(v).toLowerCase()===raw.toLowerCase());editor.remove();text.hidden=false;cell.classList.remove('editing-cell');if(!cancel&&(raw===''||match!==undefined))updateTableCell(table,rows,sourceIndex,column,match??'');};
    editor.addEventListener('pointerdown',e=>e.stopPropagation());editor.addEventListener('click',e=>e.stopPropagation());
    editor.addEventListener('input',()=>{const initial=editor.value;finish(true);open(initial);});
    editor.addEventListener('blur',()=>finish());
    editor.addEventListener('keydown',e=>{e.stopPropagation();if(e.key==='Escape'||e.key==='Enter'){e.preventDefault();finish(e.key==='Escape');const next=referenceTable.querySelector(`td[data-source-index="${sourceIndex}"][data-column-index="${column}"]`);next?.focus({preventScroll:true});}});
    editor.focus({preventScroll:true});editor.setSelectionRange(editor.value.length,editor.value.length);
  };
  cell.append(text, arrow);
}

function positionCellPopup(popup, cell) {
  const rect = cell.getBoundingClientRect();
  popup.style.left = `${Math.max(8, Math.min(rect.left, window.innerWidth - popup.offsetWidth - 8))}px`;
  popup.style.top = `${rect.bottom + popup.offsetHeight < window.innerHeight - 8 ? rect.bottom : Math.max(8, rect.top - popup.offsetHeight)}px`;
}

function openCellDropdown(cell, table, rows, sourceIndex, column, options, initial) {
  closeCellDropdown();
  const popup = document.createElement('div'); popup.className = 'cell-dropdown-popup'; popup.setAttribute('role', 'dialog'); popup.setAttribute('aria-label', `${table.headers[column].label} choices`);
  const search = document.createElement('input'); search.type = 'search'; search.autocomplete = 'off'; search.value = initial; search.placeholder = 'Type to filter'; search.setAttribute('aria-label', 'Filter choices');
  const list = document.createElement('div'); list.className = 'cell-dropdown-options'; list.setAttribute('role', 'listbox');
  const automatic = autoCellDescriptor(table, rows[sourceIndex], sourceIndex, column, activeProject());
  const boolean = options.some(v=>String(v).toUpperCase()==='TRUE') && options.every(v=>['TRUE','FALSE',''].includes(String(v).toUpperCase()));
  const values = boolean ? ['', 'TRUE'] : [...new Set((automatic ? [] : ['']).concat(options.map(String)))];
  let matches = [], cursor = 0, shownCount = 80;
  const choose = (selected) => {
    closeCellDropdown(); cell.setAttribute('aria-expanded', 'false');
    if (String(rows[sourceIndex][column] ?? "") !== String(selected)) updateTableCell(table, rows, sourceIndex, column, selected);
    const next = referenceTable.querySelector(`tbody tr[data-source-index="${sourceIndex}"] td[data-column-index="${column}"]`);
    const valueNode = next?.querySelector('.dropdown-value'); if (valueNode) valueNode.textContent = String(rows[sourceIndex][column] ?? '');
    next?.focus({ preventScroll: true });
  };
  const draw = (align = true) => {
    matches = values.filter((v) => v.toLowerCase().includes(search.value.toLowerCase()));
    cursor = Math.max(0, Math.min(cursor, matches.length - 1)); list.replaceChildren();
    matches.slice(0, Math.max(shownCount, cursor + 1)).forEach((v, i) => {
      const option = document.createElement('button'); option.type = 'button'; option.setAttribute('role', 'option'); option.setAttribute('aria-selected', String(i === cursor)); option.textContent = v || '(Blank)'; option.classList.toggle('active-option', i === cursor);
      option.addEventListener('pointerdown', (e) => e.preventDefault()); option.addEventListener('click', () => choose(v)); list.appendChild(option);
    });
    if (!matches.length) { const empty = document.createElement('p'); empty.textContent = 'No matching values'; list.appendChild(empty); }
    if (align) list.children[cursor]?.scrollIntoView({ block: 'nearest' });
  };
  list.addEventListener('scroll', () => { if (list.scrollTop + list.clientHeight >= list.scrollHeight - 30 && shownCount < matches.length) { const previousTop = list.scrollTop; shownCount += 80; draw(false); list.scrollTop = previousTop; } });
  search.addEventListener('input', () => { cursor = 0; shownCount = 80; draw(); });
  search.addEventListener('keydown', (e) => {
    e.stopPropagation();
    if (e.key === 'Escape') { e.preventDefault(); closeCellDropdown(); cell.setAttribute('aria-expanded','false'); cell.focus({ preventScroll: true }); }
    else if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); cursor += e.key === 'ArrowDown' ? 1 : -1; draw(); }
    else if (e.key === 'Enter' && matches.length) { e.preventDefault(); choose(matches[cursor]); }
    else if (e.key === 'Tab') { e.preventDefault(); if (matches.length) choose(matches[cursor]); else closeCellDropdown(); }
  });
  popup.append(search, list); document.body.appendChild(popup);
  popup.style.minWidth = `${Math.max(220, cell.getBoundingClientRect().width)}px`;
  draw(); positionCellPopup(popup, cell); cell.setAttribute('aria-expanded','true'); search.focus(); search.setSelectionRange(initial.length, initial.length);
}

function cellNoteKey(project, table, row, index, column) {
  let identity;
  if (table.tabularCalculation) identity = `id:${requirementKey(row[table.idColumn])}`;
  else if (table.noteSummary) identity = 'summary';
  else if (table.id.startsWith('calc-') || table.id === 'room-zone-loads-report') identity = `space:${requirementKey(row[table.spaceColumn])}`;
  else if (table.airsideSection || table.plantCalculation) identity = `equipment:${requirementKey(row[0])}`;
  else {
    project.tableRowIds ||= {}; const ids = project.tableRowIds[table.id] ||= [];
    identity = ids[index] ||= `row:${crypto.randomUUID()}`;
  }
  return `${table.id}::${identity}::${column}`;
}

function attachCellNote(cell, table, row, index, column) {
  if(table.psychCalculation)return;
  const project = activeProject(); if (!project) return;
  const key = cellNoteKey(project, table, row, index, column);
  if (table.noteSummary) cell.tabIndex = 0;
  const originalTitle = cell.title;
  const flag = document.createElement('button'); flag.type = 'button'; flag.className = 'cell-note-flag'; flag.tabIndex = -1; flag.setAttribute('aria-label', 'Add note');
  const refresh = () => { const exists = Boolean(project.cellNotes?.[key]); cell.classList.toggle('has-note', exists); cell.title = exists ? '' : originalTitle; flag.title = exists ? 'Edit note' : 'Add note'; flag.setAttribute('aria-label',flag.title); };
  flag.addEventListener('pointerenter', () => document.querySelector('.cell-note-tooltip')?.remove());
  flag.addEventListener('pointerdown', (e) => { e.preventDefault(); e.stopPropagation(); });
  flag.addEventListener('click', (e) => { e.stopPropagation(); cell.focus({ preventScroll: true }); openCellNoteEditor(cell, key, project, refresh); });
  cell.addEventListener('pointerenter', () => {
    const note = project.cellNotes?.[key]; if (!note) return;
    document.querySelector('.cell-note-tooltip')?.remove();
    const popup = document.createElement('div'); popup.className = 'cell-note-tooltip'; popup.setAttribute('role','tooltip');
    if (originalTitle) { const hint = document.createElement('div'); hint.className = 'cell-note-hint'; hint.textContent = originalTitle; popup.appendChild(hint); }
    const content = document.createElement('div'); content.className = 'cell-note-content'; content.textContent = note; popup.appendChild(content); document.body.appendChild(popup); positionCellPopup(popup, cell);
  });
  cell.addEventListener('pointerleave', () => document.querySelector('.cell-note-tooltip')?.remove());
  refresh(); cell.appendChild(flag);
}

function openCellNoteEditor(cell, key, project, refresh) {
  document.querySelector('.cell-note-editor')?.remove(); document.querySelector('.cell-note-tooltip')?.remove();
  const popup = document.createElement('div'); popup.className = 'cell-note-editor'; popup.setAttribute('role','dialog'); popup.setAttribute('aria-label','Cell note');
  const heading = document.createElement('strong'); heading.textContent = 'Note';
  const input = document.createElement('textarea'); input.value = project.cellNotes?.[key] || ''; input.setAttribute('aria-label','Cell note'); input.placeholder = 'Add a note…';
  const save = () => { project.cellNotes ||= {}; if (input.value.trim()) project.cellNotes[key] = input.value; else delete project.cellNotes[key]; refresh(); saveProjects(); };
  input.addEventListener('input', save);
  const close = document.createElement('button'); close.type='button'; close.textContent='Done'; close.addEventListener('click', () => { save(); popup.remove(); cell.focus({ preventScroll: true }); });
  const remove = document.createElement('button'); remove.type='button'; remove.textContent='Delete note'; remove.addEventListener('click', () => { input.value=''; save(); popup.remove(); cell.focus({ preventScroll: true }); });
  input.addEventListener('keydown', (e) => { e.stopPropagation(); if (e.key === 'Escape') { popup.remove(); cell.focus({ preventScroll: true }); } });
  popup.append(heading,input,remove,close); document.body.appendChild(popup); positionCellPopup(popup,cell); input.focus();
}

function renderSpaceChoices() {
  const search = document.querySelector('#space-choice-search').value.toLowerCase();
  const shown = (spaceFilterContext?.spaceOptions || []).filter((o) => o.label.toLowerCase().includes(search));
  const container = document.querySelector('#space-choice-options'); container.replaceChildren();
  for (const option of shown) {
    const label=document.createElement('label'); label.className='filter-option'; const checkbox=document.createElement('input'); checkbox.type='checkbox'; checkbox.checked=!spaceChoiceExcluded.has(option.value);
    checkbox.addEventListener('change', () => { if (checkbox.checked) spaceChoiceExcluded.delete(option.value); else spaceChoiceExcluded.add(option.value); updateSpaceChoiceAll(shown); });
    const text=document.createElement('span'); text.textContent=option.label; label.append(checkbox,text); container.appendChild(label);
  }
  updateSpaceChoiceAll(shown);
}

function updateSpaceChoiceAll(shown) {
  const all=document.querySelector('#space-choice-all'); const count=shown.filter((o) => !spaceChoiceExcluded.has(o.value)).length;
  all.checked=shown.length>0 && count===shown.length; all.indeterminate=count>0 && count<shown.length; all.disabled=!shown.length;
}

function closeSharedFilter() {
  spaceFilterPopover.hidden = true;
  spaceFilterToggle.setAttribute("aria-expanded", "false");
}

function renderSharedSpaceFilter(table, context) {
  closeSharedFilter();
  spaceFilterContext = context;
  spaceFilter.hidden = !context;
  tableSearch.closest("label").hidden = Boolean(context) || Boolean(table.plantCalculation) || Boolean(table.energySimulation || table.energySummary);
  if (!context) return;
  sharedSpaceSearch.value = context.equipment ? activeProject()?.equipmentSearch || "" : context.thermal ? activeProject()?.thermalTableSearch || "" : activeProject()?.sharedSpaceSearch || "";
  sharedSpaceSearchLabel.textContent = context.equipment ? "Search Equipment" : context.thermal ? "Search Space Types" : "Search Space";
  sharedSpaceSearch.setAttribute("aria-label", sharedSpaceSearchLabel.textContent);
  sharedSpaceSearch.placeholder=context.equipment?"Search equipment":"Search spaces";
  document.querySelector("#space-choice-control .filter-control-label").textContent=context.equipment?"Equipment":"Spaces";
  document.querySelector("#space-choice-search").placeholder=context.equipment?"Search equipment":"Search spaces";
  spaceFilterField.replaceChildren();
  const addOption = (parent, value, label) => {
    const option = document.createElement("option"); option.value = value; option.textContent = label; parent.appendChild(option);
  };
  const common = document.createElement("optgroup"); common.label = context.equipment ? "All Airside Equipment" : "Space fields";
  for (const [key, label] of context.equipment ? [["unitType","Unit Type"]] : context.thermal ? [] : [["zoneGroup", "Zone Group"], ["zone", "Zone"], ["type", "Thermal Template"]]) addOption(common, `${context.equipment?"equipment":"meta"}:${key}`, key === "space" && table.id === "selected-transfer-air" ? "Transfer Air From Space" : label);
  spaceFilterField.appendChild(common);
  const columns = document.createElement("optgroup"); columns.label = table.name;
  table.headers.forEach((header, column) => {
    if (!(context.equipment && column===0) && !table.hiddenColumns?.includes(column) && (context.thermal || (column !== table.spaceColumn && !/^(?:from |to )?space(?: name)?$|^room$/i.test(header.label)))) addOption(columns, `col:${table.id}:${column}`, spaceFilterColumnLabel(table, column));
  });
  spaceFilterField.appendChild(columns);
  if (context.descriptor.table && context.descriptor.table.id !== table.id) {
    const previous = document.createElement("optgroup"); previous.label = context.descriptor.table.name;
    addOption(previous, context.state.field, context.descriptor.label); spaceFilterField.appendChild(previous);
  }
  spaceFilterField.value = context.state.field;
  const active = context.state.values !== null;
  spaceFilterToggle.textContent = active ? `${context.state.values.length} selected` : "All values";
  spaceFilterToggle.classList.toggle("filter-active", active);
  spaceFilterClear.hidden = !active && !sharedSpaceSearch.value && (context.thermal || !currentFilterExclusions().length);
  document.querySelector("#space-choice-control").hidden = Boolean(context.thermal);
  const excluded = new Set(currentFilterExclusions());
  document.querySelector("#space-choice-toggle").textContent = context.spaceOptions.some((o) => excluded.has(o.value)) ? `${context.spaceOptions.filter((o) => !excluded.has(o.value)).length} ${context.equipment?"equipment":"spaces"} selected` : context.equipment?"All equipment":"All spaces";
  document.querySelector("#space-choice-popover").hidden = true;
}

function shownFilterOptions() {
  const search = spaceFilterSearch.value.trim().toLowerCase();
  return (spaceFilterContext?.options || []).filter((option) => !search || option.label.toLowerCase().includes(search));
}

function renderSharedFilterOptions() {
  const options = shownFilterOptions();
  spaceFilterOptions.replaceChildren();
  options.forEach((option) => {
    const label = document.createElement("label"); label.className = "filter-option";
    const checkbox = document.createElement("input"); checkbox.type = "checkbox"; checkbox.checked = spaceFilterDraft.has(option.value);
    checkbox.addEventListener("change", () => {
      if (checkbox.checked) spaceFilterDraft.add(option.value); else spaceFilterDraft.delete(option.value);
      updateSharedFilterSelectAll();
    });
    const text = document.createElement("span"); text.textContent = `${option.label} (${option.count})`;
    label.append(checkbox, text); spaceFilterOptions.appendChild(label);
  });
  if (!options.length) { const empty = document.createElement("p"); empty.textContent = "No matching values"; spaceFilterOptions.appendChild(empty); }
  updateSharedFilterSelectAll();
}

function updateSharedFilterSelectAll() {
  const options = shownFilterOptions(), count = options.filter((option) => spaceFilterDraft.has(option.value)).length;
  spaceFilterAll.checked = options.length > 0 && count === options.length;
  spaceFilterAll.indeterminate = count > 0 && count < options.length;
  spaceFilterAll.disabled = options.length === 0;
}

function applySharedFilterChange() {
  closeSharedFilter(); saveProjects();
  if (activeTableId) renderReferenceTable(activeTableId, "", { skipRecalculation: true });
}

function renderReferenceTable(tableId, query = tableSearch.value, { skipRecalculation = false } = {}) {
  closeCellDropdown();
  document.querySelector('.table-toolbar').hidden=false;
  document.querySelector(".cell-note-tooltip")?.remove();
  document.querySelector(".cell-note-editor")?.remove();
  const table = independentTables.find((candidate) => candidate.id === tableId);
  if (!table) return;
  clearFillHandle();
  if(table.energySimulation)configureEnergyColumns(table,activeProject());
  if (activeTableId !== tableId) tableScroll.scrollLeft = 0;
  activeTableId = tableId;
  tableStandard.textContent = table.standard;
  updateTableSettings(table);
  document.querySelector(".table-toolbar").classList.toggle("plant-toolbar",Boolean(table.plantCalculation));
  referenceTable.classList.toggle("psych-shared-table",Boolean(table.psychCalculation));
  referenceTable.classList.toggle("thermal-template-layout", Boolean(table.thermalTemplateCalculation));
  referenceTable.classList.toggle("plant-layout", Boolean(table.plantCalculation));
  referenceTable.classList.toggle("tabular-layout", Boolean(table.tabularCalculation));
  referenceTable.classList.toggle("zero-frozen-columns", table.frozenColumns === 0);
  referenceTable.classList.toggle("two-frozen-columns", table.frozenColumns === 2);
  referenceTable.classList.toggle("three-frozen-columns", table.frozenColumns === 3);
  referenceTable.classList.toggle("four-frozen-columns", table.frozenColumns === 4);
  referenceTable.classList.toggle("six-frozen-columns", table.frozenColumns === 6);
  referenceTable.classList.toggle("general-exhaust-layout", Boolean(table.generalRequirementsLayout));
  calculatedKey.hidden = ![...(table.calculatedColumns || []), ...(table.lockedColumns || [])].length;
  updateCsvToolbar(table);
  clearCsvComparison();
  clearSelectedEquation();
  const normalized = supportsSharedSpaceFilter(table) || table.plantCalculation || table.energySimulation || table.energySummary ? "" : query.trim().toLowerCase();
  const sourceRows = projectTableRows(table);
  if (!skipRecalculation) recalculateTable(table, sourceRows);
  const headers = displayedTableHeaders(table);
  const thermalTable = independentTables.find((t) => t.thermalTemplateCalculation);
  const thermalTypes = new Set((thermalTable ? projectTableRows(thermalTable) : []).map((r) => thermalTypeKey(r[0])));
  if (selectedTableId !== tableId) {
    selectedTableId = "";
    selectedTableRowIndexes.clear();
    selectionAnchorIndex = -1;
    selectedTableCells.clear();
    cellSelectionAnchor = null;
  } else {
    selectedTableRowIndexes = new Set([...selectedTableRowIndexes].filter((index) => index < sourceRows.length));
  }
  removeTableRowButton.disabled = selectedTableRowIndexes.size === 0 && selectedTableCells.size === 0;
  const sharedFilter = prepareSharedSpaceFilter(table, sourceRows, activeProject());
  const pending = pendingTableRow?.tableId === table.id ? pendingTableRow.row : null;
  renderSharedSpaceFilter(table, sharedFilter);
  const rows = sourceRows
    .map((row, sourceIndex) => ({ row, sourceIndex }))
    .filter(({ row }) => (row === pending && !rowSpaceValues(table,row).some(Boolean)) || ((!normalized || row.some((value) => String(value ?? "").toLowerCase().includes(normalized)))
      && rowMatchesSpaceSet(table, row, sharedFilter?.matchingSpaces)
      && (!sharedFilter?.matchingRows || sharedFilter.matchingRows.has(row))
      && (!sharedFilter || sharedSpaceSearchMatches(table, row, activeProject()))));
  refreshTableMetric(table, rows.map(({ row }) => row));
  renderRevision25Controls(table,sourceRows);
  updateBrowserRowCounts();

  orderTableRows(table,sourceRows,rows,activeProject());

  referenceTable.innerHTML = "";
  referenceTable.setAttribute("aria-multiselectable", "true");
  const head = document.createElement("thead");
  if (table.headerGroups?.length) {
    const groupRow = document.createElement("tr");
    groupRow.className = "group-header-row";
    table.headerGroups.forEach((group) => {
      const visibleSpan = Array.from({ length: group.span }, (_, index) => group.start + index)
        .filter((index) => !table.hiddenColumns?.includes(index)).length;
      if (!visibleSpan) return;
      const cell = document.createElement("th");
      cell.colSpan = visibleSpan;
      cell.dataset.groupStart = String(group.start);
      cell.dataset.groupSpan = String(group.span);
      cell.scope = "colgroup";
      if (group.linkTableId) {
        const link = document.createElement("button"); link.type = "button"; link.className = "header-link group-header-link"; link.textContent = group.label;
        link.title = `Open ${independentTables.find((candidate) => candidate.id === group.linkTableId)?.name || "source table"}`;
        link.addEventListener("click", () => openLinkedTable(group.linkTableId)); cell.appendChild(link);
      } else {
        cell.textContent = group.label;
      }
      if (group.className) cell.classList.add(group.className);
      if ((table.sectionStartColumns || []).includes(group.start)) cell.classList.add("section-divider");
      groupRow.appendChild(cell);
    });
    head.appendChild(groupRow);
  }
  const headerRow = document.createElement("tr");
  headers.forEach((header, columnIndex) => {
    const cell = document.createElement("th");
    if (table.hiddenColumns?.includes(columnIndex)) cell.style.display = "none";
    cell.scope = "col";
    if ((table.calculatedColumns || []).includes(columnIndex)) cell.classList.add("calculated-header");
    if (table.headerClasses?.[columnIndex]) cell.classList.add(table.headerClasses[columnIndex]);
    if ((table.sectionStartColumns || []).includes(columnIndex)) cell.classList.add("section-divider");
    const content = document.createElement("div");
    content.className = "table-header-content";

    const linkedTableId = table.headerLinks?.[columnIndex];
    const label = document.createElement(linkedTableId ? "button" : "span");
    label.className = linkedTableId ? "column-label header-link" : "column-label";
    if (linkedTableId) {
      label.type = "button";
      label.title = `Open ${independentTables.find((candidate) => candidate.id === linkedTableId)?.name || "source table"}`;
      label.addEventListener("click", () => openLinkedTable(linkedTableId));
    }
    if (header.subscripts?.length) {
      Array.from(String(header.label)).forEach((character, position) => {
        if (header.subscripts.includes(position)) {
          const subscript = document.createElement("sub");
          subscript.textContent = character;
          label.appendChild(subscript);
        } else {
          appendFormattedText(label, character);
        }
      });
    } else {
      appendFormattedText(label, header.label);
    }
    if (header.subscript) {
      const subscript = document.createElement("sub");
      subscript.textContent = header.subscript;
      label.appendChild(subscript);
    }
    content.appendChild(label);

    if (header.unit) {
      const unit = document.createElement("span");
      unit.className = "column-unit";
      appendFormattedText(unit, header.unit);
      content.appendChild(unit);
    }

    const sortButton = document.createElement("button");
    sortButton.type = "button";
    sortButton.className = "column-sort-control";
    sortButton.title = `Sort by ${header.label}`;
    sortButton.setAttribute("aria-label", `Sort by ${header.label}`);
    if (tableSort.tableId === tableId && tableSort.column === columnIndex) {
      sortButton.textContent = tableSort.direction === "asc" ? "↑" : "↓";
      cell.setAttribute("aria-sort", tableSort.direction === "asc" ? "ascending" : "descending");
    } else {
      sortButton.textContent = "↕";
    }
    sortButton.addEventListener("click", () => sortReferenceTable(tableId, columnIndex));
    if(!table.energySimulation&&!table.energySummary&&!table.psychCalculation&&!table.equipmentScheduleCalculation)content.appendChild(sortButton);
    cell.appendChild(content);
    headerRow.appendChild(cell);
  });
  head.appendChild(headerRow);

  const dropdownOptionsByColumn = new Map(
    Object.keys(table.dropdownColumns || {}).map((columnIndex) => {
      const index = Number(columnIndex);
      return [index, tableDropdownOptions(table, index)];
    }),
  );

  const body = document.createElement("tbody");
  rows.forEach(({ row, sourceIndex }) => {
    const tableRow = document.createElement("tr");
    tableRow.dataset.sourceIndex = String(sourceIndex);
    if(table.energySummary){tableRow.classList.toggle("energy-major-row",sourceIndex<2);tableRow.classList.toggle("energy-baseline-divider",sourceIndex===2);}
    tableRow.classList.toggle("selected-row", selectedTableId === tableId && selectedTableRowIndexes.has(sourceIndex));
    tableRow.setAttribute("aria-selected", String(selectedTableId === tableId && selectedTableRowIndexes.has(sourceIndex)));
    tableRow.addEventListener("click", (event) => {
      if (event.target.closest("td.editable-cell")) return;
      selectTableRow(tableId, tableRow, sourceIndex, event);
    });
    row.forEach((value, index) => {
      const cell = document.createElement("td");
      if (table.hiddenColumns?.includes(index)) cell.style.display = "none";
      cell.dataset.sourceIndex = String(sourceIndex);
      cell.dataset.columnIndex = String(index);
      if (typeof value === "number" || table.columnTypes[index] === "number") cell.classList.add("numeric-cell");
      if ((table.sectionStartColumns || []).includes(index)) cell.classList.add("section-divider");
      if (isUnusedGainCell(table, row, index)) cell.classList.add("inactive-gain-cell");
      if ((table.identityColumns || []).includes(index)) {
        cell.classList.add("identity-cell");
      }
      const conditionalCalculated = isConditionalCalculatedCell(table, row, index);
      const calculated = (table.calculatedColumns || []).includes(index) || conditionalCalculated;
      const dynamicLocked = table.lockedCellStates?.get(sourceIndex)?.has(index);
      const locked = (table.lockedColumns || []).includes(index) || conditionalCalculated || dynamicLocked;
      if (table.autoCellStates?.get(sourceIndex)?.has(index) && !dynamicLocked) cell.classList.add("auto-populated-cell");
      if (dynamicLocked) cell.classList.add("dynamically-locked-cell");
      if (table.mutedCellStates?.get(sourceIndex)?.has(index)) cell.classList.add("muted-calculation-cell");
      if (calculated || locked) {
        cell.textContent = formatTableValue(value, table, index);
        cell.classList.add("calculated-cell");
        if (locked) cell.classList.add("locked-cell");
        cell.tabIndex = 0;
        const imported = Boolean(table.excelImport);
        cell.title = imported ? "Imported value" : dynamicLocked
          ? table.lockedCellMessages?.get(sourceIndex)?.get(index) || "Locked by the active equipment path"
          : calculated ? "Calculated value; select to view the equation" : "Calculated value";
        cell.setAttribute("aria-label", `${imported ? "Imported" : "Calculated"} ${table.headers[index].label}, row ${sourceIndex + 1}`);
        if (calculated || table.displayEquations?.[index]) {
          cell.addEventListener("click", () => showSelectedEquation(table, cell, index));
          cell.addEventListener("focus", () => showSelectedEquation(table, cell, index));
        } else {
          cell.addEventListener("focus", clearSelectedEquation);
        }
        cell.addEventListener("keydown", (event) => {
          if (event.key === "Enter" || ["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(event.key)) {
            event.preventDefault();
            moveToAdjacentCell(cell, event.key === "Enter" ? "ArrowDown" : event.key, event.shiftKey);
          }
        });
      } else if (table.suggestColumns?.[index]) {
        cell.classList.add("editable-cell", "suggest-cell");
        const input = document.createElement("input");
        input.className = "table-cell-suggest";
        input.value = String(value ?? "");
        input.setAttribute("aria-label", `${table.headers[index].label}, row ${sourceIndex + 1}`);
        const list = document.createElement("datalist");
        list.id = `suggest-${table.id}-${sourceIndex}-${index}`;
        table.suggestColumns[index].forEach((option) => { const choice = document.createElement("option"); choice.value = option; list.appendChild(choice); });
        input.setAttribute("list", list.id);
        input.addEventListener("change", () => updateTableCell(table, sourceRows, sourceIndex, index, input.value));
        input.addEventListener("focus", () => { selectTableCell(table.id, sourceIndex, index); showFillHandle(cell, table, sourceRows, sourceIndex, index); });
        input.addEventListener("keydown", (event) => {
          if (event.key === "Enter") { event.preventDefault(); input.blur(); moveToAdjacentCell(cell, "ArrowDown"); }
        });
        cell.append(input, list);
      } else if (table.dropdownColumns?.[index] || table.cellDropdownRows?.[sourceIndex]?.[index]) {
        configureCellDropdown(cell, table, sourceRows, sourceIndex, index, value,
          table.cellDropdownRows?.[sourceIndex]?.[index] || dropdownOptionsByColumn.get(index) || []);
      } else {
        cell.textContent = formatTableValue(value, table, index);
        cell.classList.add("editable-cell");
        cell.tabIndex = 0;
        cell.spellcheck = false;
        cell.setAttribute("aria-label", `${table.headers[index].label}, row ${sourceIndex + 1}. Type or press F2 to edit`);
        let editor=null;
        const finishEdit=(cancel=false)=>{if(!editor)return;const node=editor,raw=node.value,previous=cell.dataset.originalValue;editor=null;node.remove();cell.classList.remove('editing-cell');delete cell.dataset.originalValue;if(!cancel&&raw!==previous)updateTableCell(table,sourceRows,sourceIndex,index,raw);};
        const startEdit=(replacement)=>{
          if(editor)return;cell.dataset.originalValue=String(row[index]??'');editor=document.createElement('input');editor.type='text';editor.className='table-inline-editor';editor.value=replacement!==undefined?replacement:isPercentageColumn(table,index)&&typeof row[index]==='number'?String(row[index]*100):String(row[index]??'');cell.dataset.originalValue=isPercentageColumn(table,index)&&typeof row[index]==='number'?String(row[index]*100):String(row[index]??'');editor.setAttribute('aria-label',table.headers[index].label);cell.classList.add('editing-cell');cell.appendChild(editor);
          editor.addEventListener('pointerdown',e=>e.stopPropagation());editor.addEventListener('click',e=>e.stopPropagation());editor.addEventListener('blur',()=>finishEdit());
          editor.addEventListener('keydown',e=>{e.stopPropagation();if(['Enter','Escape','Tab'].includes(e.key)){e.preventDefault();finishEdit(e.key==='Escape');const next=referenceTable.querySelector(`td[data-source-index="${sourceIndex}"][data-column-index="${index}"]`);if(next){next.focus({preventScroll:true});if(e.key==='Tab')moveToAdjacentCell(next,e.shiftKey?'ArrowLeft':'ArrowRight');else {selectTableCell(table.id,sourceIndex,index);showSelectedEquation(table,next,index);}}}});
          editor.focus({preventScroll:true});editor.setSelectionRange(editor.value.length,editor.value.length);
        };
        cell.addEventListener("focus", () => {
          clearSelectedEquation();
          showFillHandle(cell, table, sourceRows, sourceIndex, index);
        });
        cell.startCellEdit = startEdit;
        cell.addEventListener("dblclick", () => startEdit());
        cell.addEventListener("keydown", (event) => {
          if (cell.isContentEditable) {
            if (event.key === "Escape") {
              event.preventDefault();
              finishEdit(true);
            } else if (event.key === "Enter") {
              event.preventDefault(); event.stopPropagation();
              finishEdit();
              const selected = referenceTable.querySelector(`tbody tr[data-source-index="${sourceIndex}"] td[data-column-index="${index}"]`);
              selected?.focus({preventScroll:true});
              if(selected) {selectTableCell(table.id,sourceIndex,index);markSelectedTableCell(selected);showSelectedEquation(table,selected,index);}
            } else if (event.key === "Tab") {
              event.preventDefault();
              moveToAdjacentCell(cell, event.shiftKey ? "ArrowLeft" : "ArrowRight");
            }
            return;
          }
          if (event.key === "F2") {
            event.preventDefault();
            startEdit();
          } else if (event.key === "Backspace") {
            event.preventDefault();
            startEdit("");
          } else if (event.key === "Enter") {
            event.preventDefault();
            moveToAdjacentCell(cell, "ArrowDown");
          } else if (event.key === "Tab") {
            event.preventDefault();
            moveToAdjacentCell(cell, event.shiftKey ? "ArrowLeft" : "ArrowRight");
          } else if (!event.ctrlKey && !event.metaKey && !event.altKey && event.key.length === 1) {
            event.preventDefault();
            startEdit(event.key);
          } else if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(event.key)) {
            event.preventDefault();
            moveToAdjacentCell(cell, event.key, event.shiftKey);
          }
        });

      }
      if (table.autoCellStates?.get(sourceIndex)?.has(index) && !dynamicLocked) {
        cell.title = `Autopopulated value: ${formatTableValue(value, table, index) || "(blank)"}`;
        const dropdown = cell.querySelector("select");
        if (dropdown) dropdown.title = cell.title;
      }
      if (table.scheduleCalculation && index === table.scheduleColumn) {
        const proposed = activeProject()?.consumptionScheduleAutos?.[`${table.id}::${requirementKey(row[0])}`] || "";
        cell.title = `Autopopulated value: ${proposed || "(blank)"}`;
        if (table.displayEquations?.[index]) {
          cell.addEventListener("click", () => showSelectedEquation(table, cell, index));
          cell.addEventListener("focus", () => showSelectedEquation(table, cell, index));
        }
      }
      if (table.thermalTemplateCalculation && index >= 2 && !calculated && !dynamicLocked) {
        const autoValue = activeProject()?.thermalAutoValues?.[`${requirementKey(row[0])}::${index}`];
        if (autoValue !== undefined) {
          cell.title = `Autopopulated value: ${formatTableValue(autoValue, table, index) || "(blank)"}`;
          const dropdown = cell.querySelector("select"); if (dropdown) dropdown.title = cell.title;
        }
      }
      if (table.equipmentZoningCalculation && (table.autoColumns || []).includes(index) && !dynamicLocked) {
        const autoValue = activeProject()?.zoningAutoValues?.[table.id]?.[zoningCellKey(row, index)] ?? "";
        cell.title = `Autopopulated value: ${autoValue || "(blank)"}`;
      }
      if (table.roomLoadCalculation && (table.autoColumns || []).includes(index)) {
        const autoValue = activeProject()?.spaceLoadFactorAutos?.[`${String(row[0] ?? "")}::${index}`] ?? 0;
        cell.title = `Autopopulated value: ${tableNumberFormatter.format(Number(autoValue) * 100)}%`;
      }
      if (table.airsideSettingsCalculation && (table.autoColumns || []).includes(index) && !dynamicLocked) {
        const autoValue = activeProject()?.airsideAutoValues?.[airsideCellKey(row, index)] ?? "";
        cell.title = `Autopopulated value: ${isPercentageColumn(table, index) ? `${zeroDecimalFormatter.format(Number(autoValue) * 100)}%` : autoValue || "(blank)"}`;
      }
      if (table.coilCalculation && (table.autoColumns || []).includes(index) && !dynamicLocked) {
        const autoValue = activeProject()?.coilAutoValues?.[table.id]?.[airsideCellKey(row, index)] ?? "";
        cell.title = `Autopopulated value: ${isPercentageColumn(table, index) ? `${oneDecimalFormatter.format(Number(autoValue) * 100)}%` : oneDecimalFormatter.format(Number(autoValue))}`;
      }
      if (table.plantCalculation && (table.autoColumns || []).includes(index) && !dynamicLocked) {
        const autoValue = activeProject()?.plantAutoValues?.[table.id]?.[airsideCellKey(row, index).toLowerCase()] ?? row[index];
        cell.title = `Autopopulated value: ${formatTableValue(autoValue, table, index)}`;
      }
      if (table.plantCalculation && table.displayEquations?.[index] && !calculated && !locked) {
        cell.addEventListener("focusin", () => showSelectedEquation(table, cell, index));
      }
      if (table.zoningNetworkTableCalculation && (table.autoColumns || []).includes(index) && !dynamicLocked) {
        const autoValue = activeProject()?.networkZoningAutoValues?.[`${String(row[2] ?? "")}::${index}`] ?? "";
        cell.title = `Autopopulated value: ${autoValue || "(blank)"}`;
      }
      const automaticDescriptor=autoCellDescriptor(table,row,sourceIndex,index,activeProject());
      if(automaticDescriptor?.editable && !dynamicLocked)cell.title=`Autopopulated value: ${formatTableValue(automaticDescriptor.value,table,index)||'(blank)'}`;
      const validationMessage = table.validationCellStates?.get(sourceIndex)?.get(index);
      if (validationMessage) {
        cell.classList.add("equipment-conflict-cell");
        cell.title = validationMessage;
      }
      if (table.roomLoadCalculation && table.missingRoomLoadSpaces?.has(String(row[0] ?? "")) && [2, 7, 8, 13, 14, 17].includes(index)) {
        cell.classList.add("missing-source-cell");
        cell.title = "Space not in Room/Zone Loads Report.";
      }
      if(table.underPeakCellStates?.get(sourceIndex)?.has(index)){cell.classList.add('below-peak-default');cell.title='Entered airflow is below the calculated peak requirement.';}
      decorateCsvComparisonCell(table, cell, row, sourceIndex, index);
      decorateRoomValidationCell(table, cell, value, index);
      if (table.id.startsWith("calc-") && /^(?:Type|Thermal Template|Space Type)$/.test(table.headers[index]?.label) && !table.ventilationRequirementsCalculation && value && !thermalTypes.has(thermalTypeKey(value))) {
        cell.classList.add("missing-thermal-template"); cell.title = "Add Space Type to Thermal Templates tab";
      }
      cell.addEventListener("pointerdown", (event) => {
        if (event.button !== 0 || !(table.lockedColumns || []).includes(index)) return;
        cell.focus({ preventScroll: true });
        markSelectedTableCell(cell);
      });
      cell.addEventListener("focusin", () => {
        if ((table.lockedColumns || []).includes(index)) markSelectedTableCell(cell);
        showCsvComparison(table, sourceRows, sourceIndex, index);
      });
      cell.addEventListener("click", () => {
        if ((table.lockedColumns || []).includes(index)) {
          cell.focus({ preventScroll: true });
          markSelectedTableCell(cell);
        }
        showCsvComparison(table, sourceRows, sourceIndex, index);
      });
      const automatic = autoCellDescriptor(table, row, sourceIndex, index, activeProject());
      if (automatic && !dynamicLocked) {
        cell.title = `Autopopulated value: ${formatTableValue(automatic.value, table, index) || "(blank)"}${table.underPeakCellStates?.get(sourceIndex)?.has(index)?' — Entered airflow is below the calculated peak requirement.':''}`;
        const dropdown = cell.querySelector("select"); if (dropdown) dropdown.title = cell.title;
        cell.addEventListener("click", () => showSelectedEquation(table, cell, index));
        cell.addEventListener("focusin", () => showSelectedEquation(table, cell, index));
      }
      if (selectedTableCells.has(`${sourceIndex}:${index}`)) cell.classList.add("multi-cell-selected");
      attachCellNote(cell, table, row, sourceIndex, index);
      tableRow.appendChild(cell);
    });
    body.appendChild(tableRow);
  });

  let foot = null;
  if (table.tabularCalculation) {
    foot = createTabularSummary(table, rows);
  } else if (table.forceSummary || (table.summaryColumns || []).length) {
    foot = document.createElement("tfoot");
    const summaryRow = document.createElement("tr");
    summaryRow.className = "table-summary-row";
    headers.forEach((_, columnIndex) => {
      const cell = document.createElement("td");
      if (table.hiddenColumns?.includes(columnIndex)) cell.style.display = "none";
      if (columnIndex === 0) cell.textContent = table.summaryLabel || "Total";
      if ((table.summaryColumns || []).includes(columnIndex)) {
        const aggregation = table.summaryAggregations?.[columnIndex] || "sum";
        const total = summaryValue(rows.map(({ row }) => row), columnIndex, aggregation);
        cell.textContent = columnIndex === 0 && aggregation === "unique-count" ? `Total: ${total}` : formatTableValue(total, table, columnIndex);
        cell.classList.add("numeric-cell");
        cell.tabIndex = 0;
        cell.classList.add("summary-equation-cell");
        cell.title = "Select to view the total formula";
        cell.addEventListener("click", () => showSummaryEquation(table, cell, columnIndex, aggregation));
        cell.addEventListener("focus", () => showSummaryEquation(table, cell, columnIndex, aggregation));
      }
      if ((table.identityColumns || []).includes(columnIndex)) cell.classList.add("identity-cell");
      if (table.sectionStartColumns?.includes(columnIndex)) cell.classList.add("section-divider");
      attachCellNote(cell, { ...table, tabularCalculation: false, noteSummary: true }, [], 0, columnIndex);
      summaryRow.appendChild(cell);
    });
    foot.appendChild(summaryRow);
  }

  const widths = calculateColumnWidths(table, headers, sourceRows, dropdownOptionsByColumn);
  const columnGroup = document.createElement("colgroup");
  widths.forEach((width, index) => {
    const column = document.createElement("col");
    column.style.width = `${width}px`;
    if (table.hiddenColumns?.includes(index)) column.style.display = "none";
    columnGroup.appendChild(column);
  });
  referenceTable.append(columnGroup, head, body, ...(foot ? [foot] : []));
  paintTableTones();
  editableKey.hidden = !table.energySummary && !referenceTable.querySelector("tbody .editable-cell:not(.auto-populated-cell)");
  autoKey.hidden = !referenceTable.querySelector("tbody .auto-populated-cell") && !table.ventilationMinimumDefault && !table.exhaustMinimumDefault && !table.supplyMinimumDefault && !table.twoValueScheduleDefault && !table.roomLoadCalculation;
  calculatedKey.hidden = !referenceTable.querySelector("tbody .calculated-cell, tbody .locked-cell, tbody .not-specified-cell");
  matchKey.hidden = !referenceTable.querySelector("tbody .csv-match"); differentKey.hidden = !referenceTable.querySelector("tbody .csv-different");
  editableKey.lastChild.textContent = "User-input";
  referenceTable.style.width = `${widths.reduce((total, width) => total + width, 0)}px`;
  referenceTable.style.setProperty("--first-column-width", `${widths[0]}px`);
  referenceTable.style.setProperty("--second-column-width", `${widths[1] || 0}px`);
  referenceTable.style.setProperty("--third-column-width", `${widths[2] || 0}px`);
  [3, 4].forEach((index) => referenceTable.style.setProperty(`--frozen-left-${index + 1}`, `${widths.slice(0, index + 1).reduce((total, width) => total + width, 0)}px`));
  tableCount.textContent = rows.length === sourceRows.length
    ? `${sourceRows.length} rows`
    : `${rows.length} of ${sourceRows.length} rows`;
  applyTableFreezeLayout(table, widths);
  referenceTable.classList.toggle('energy-summary-table',Boolean(table.energySummary));
  if(table.energySummary){const controls=document.querySelector('.energy-summary-controls');if(controls)controls.style.width=referenceTable.style.width;}
  if(table.psychCalculation)decoratePsychSharedTable(table);
  configureScheduleExportButton(table);
  if(table.tabularCalculation)copyDataButton.disabled=!csvImportState(table)||!tabularExportSelection(table,rows).entries.length;
}

function appendFormattedText(element, text) {
  String(text).split(/(ft[23])/gi).forEach((part) => {
    if (/^ft[23]$/i.test(part)) {
      element.append("ft");
      const superscript = document.createElement("sup");
      superscript.textContent = part.slice(-1);
      element.appendChild(superscript);
    } else {
      element.append(part);
    }
  });
}

function ensureProjectTableRows(project, table, airsideContext = null) {
  const cache=typeof activeCalculationCache!=="undefined" && activeCalculationCache?.project===project ? activeCalculationCache : null;
  if(!cache)return loadProjectTableRows(project,table,airsideContext);
  cache.tableRows ||= new Map();
  if(cache.tableRows.has(table.id))return cache.tableRows.get(table.id);
  const rows=loadProjectTableRows(project,table,airsideContext);cache.tableRows.set(table.id,rows);return rows;
}
function loadProjectTableRows(project, table, airsideContext = null) {
  if(table.equipmentScheduleCalculation)return loadEquipmentScheduleRows(project,table);
  if (!project) return table.rows;
  project.independentTables ||= {};
  project.independentTableSchemaVersions ||= {};
  let savedRows = project.independentTables[table.id];
  if(table.energySimulation) {configureEnergyColumns(table,project);return project.independentTables[table.id] ||= [];}
  if(table.conditionBaselineCalculation && Array.isArray(savedRows) && project.independentTableSchemaVersions[table.id]!==25){
    savedRows=project.independentTables[table.id]=savedRows.map(r=>['',r[0],'','',0,0,0,0,0,r[8]===true||String(r[8]).toUpperCase()==='TRUE'?'TRUE':'',r[10],r[11]||'']);project.independentTableSchemaVersions[table.id]=25;
    const columns={0:1,1:4,2:7,3:10,4:6,5:8,6:10,7:10,8:9,9:10,10:10,11:11,12:11};
    if(project.cellNotes){const next={};for(const [key,note] of Object.entries(project.cellNotes)){const m=key.startsWith(table.id+'::')&&key.match(/::(\d+)$/);const dest=m?key.replace(/::\d+$/,'::'+columns[Number(m[1])]):key;next[dest]=next[dest]?next[dest]+'\n'+note:note;}project.cellNotes=next;}
    const filter=project.sharedSpaceFilter;if(filter?.field?.startsWith('col:'+table.id+':')){const old=Number(filter.field.split(':').at(-1));filter.field='col:'+table.id+':'+(columns[old]??1);}
    if(project.tableViewOrders)delete project.tableViewOrders[table.id];
  }
  if(table.exhaustRequirementsCalculation && Array.isArray(savedRows) && savedRows.some(r=>r.length===12)) {
    savedRows=project.independentTables[table.id]=savedRows.map(r=>r.length===12?[...r.slice(0,7),0,0,...r.slice(7)]:r);
    project.independentTableSchemaVersions[table.id]=table.schemaVersion;
    if(project.cellNotes) project.cellNotes=Object.fromEntries(Object.entries(project.cellNotes).map(([key,value])=>{
      const match=key.startsWith(`${table.id}::`) && key.match(/::(\d+)$/);
      return [match && Number(match[1])>=7 ? key.replace(/::\d+$/,`::${Number(match[1])+2}`) : key,value];
    }));
    const f=project.sharedSpaceFilter;if(f?.field?.startsWith(`col:${table.id}:`)){const c=Number(f.field.split(":").at(-1));if(c>=7)f.field=`col:${table.id}:${c+2}`;}
  }
  if (table.id === "schedule-pressurization-types" && !project.pressurizationTypesComplete) {
    const rows = Array.isArray(savedRows) ? savedRows : table.rows.map((row) => [...row]);
    const names = new Set(rows.map((row) => requirementKey(row[0])));
    table.rows.forEach((row) => { if (!names.has(requirementKey(row[0]))) rows.push([...row]); });
    rows.sort((a, b) => (parseInt(a[0], 10) || Infinity) - (parseInt(b[0], 10) || Infinity));
    savedRows = project.independentTables[table.id] = rows;
    project.pressurizationTypesComplete = true;
  }
  if (["selected-lighting-loads", "selected-misc-loads"].includes(table.id) && Array.isArray(savedRows)) {
    savedRows = savedRows.map((row, index) => {
      if (row.length !== table.columns.length + 1) return row;
      const note = row.at(-1), next = row.slice(0, -1);
      if (note) { project.cellNotes ||= {}; const key = cellNoteKey(project, table, next, index, table.id === "selected-lighting-loads" ? 2 : 5); project.cellNotes[key] ||= String(note); }
      return next;
    });
    project.independentTables[table.id] = savedRows;
    project.independentTableSchemaVersions[table.id] = table.schemaVersion;
  }
  if (table.conditionScheduleCalculation && Array.isArray(savedRows)) {
    savedRows = savedRows.map((row) => row.length === 10 ? [...row.slice(0, 6), "", ...row.slice(6), ""] : row);
    project.independentTables[table.id] = savedRows;
    project.independentTableSchemaVersions[table.id] = table.schemaVersion;
  }
  if (table.scheduleCalculation && Array.isArray(savedRows)) {
    savedRows = savedRows.map((row) => row.length === table.columns.length - 1 ? [...row, ""] : row);
    project.independentTables[table.id] = savedRows;
  }
  if (table.airsideSection) {
    const zoning = independentTables.find((candidate) => candidate.id === "calc-equipment-zoning");
    const zoningRows = airsideContext?.zoningRows || (zoning ? ensureProjectTableRows(project, zoning) : []);
    if (zoning && !airsideContext) recalculateEquipmentZoning(zoning, zoningRows, project);
    let equipment = [];
    const seen = new Set();
    zoningRows.forEach((row) => [3, 4, 5, 6, 7, 8, 9, 10].forEach((column) => {
      const value = String(row[column] ?? "").trim();
      const key = value.toLowerCase();
      if (!value || value === "-" || seen.has(key)) return;
      seen.add(key); equipment.push(value);
    }));
    const detailTable=independentTables.find(t=>t.id==="selected-exhaust-equipment");
    const detailRows=project.independentTables?.[detailTable?.id]||detailTable?.rows||[];
    detailRows.filter(r=>zoningRows.some(z=>requirementKey(z[2])===requirementKey(r[0]))).forEach(r=>[1,2].forEach(c=>{const value=String(r[c]??"").trim(),key=requirementKey(value);if(key&&key!=="-"&&!seen.has(key)){seen.add(key);equipment.push(value);}}));
    if (table.coilCalculation) {
      const settingsTable = independentTables.find((candidate) => candidate.id === "airside-settings");
      const settingsRows = airsideContext?.settingsRows || (settingsTable ? ensureProjectTableRows(project, settingsTable) : []);
      if (settingsTable && !airsideContext) recalculateAirsideSettings(settingsTable, settingsRows, project);
      const unique = (values) => [...new Map(values.filter(Boolean).map((value) => [String(value).toLowerCase(), String(value)])).values()];
      if (table.coilCalculation === "preheat") {
        equipment = unique(settingsRows.filter((row) => String(row[6] ?? "").toUpperCase() === "TRUE").map((row) => row[0]));
      } else if (["cooling", "ventilation-cooling", "room-air-cooling"].includes(table.coilCalculation)) {
        equipment = unique([
          ...settingsRows.filter((row) => String(row[7] ?? "").toUpperCase() === "TRUE").map((row) => row[0]),
          ...zoningRows.map((row) => row[4]), ...zoningRows.map((row) => row[9]),
        ]);
        if (table.coilCalculation === "ventilation-cooling") equipment = unique(settingsRows.filter((row) => String(row[7] ?? "").toUpperCase() === "TRUE").map((row) => row[0]));
        if (table.coilCalculation === "room-air-cooling") {
          const ventilationNames = new Set(zoningRows.map((row) => String(row[3] ?? "").trim().toLowerCase()).filter(Boolean));
          equipment = unique([...zoningRows.map((row) => row[4]), ...zoningRows.map((row) => row[9])]
            .filter((value) => !ventilationNames.has(String(value ?? "").trim().toLowerCase())));
        }
      } else if (["heating", "in-unit-reheat", "downstream-reheat", "room-air-heating"].includes(table.coilCalculation)) {
        equipment = unique([
          ...settingsRows.filter((row) => String(row[11] ?? "") === "In Unit RHC").map((row) => row[0]),
          ...zoningRows.map((row) => row[6]), ...zoningRows.map((row) => row[10]),
        ]);
        if (table.coilCalculation === "in-unit-reheat") equipment = unique(settingsRows.filter((row) => String(row[11] ?? "") === "In Unit RHC").map((row) => row[0]));
        if (table.coilCalculation === "downstream-reheat") equipment = unique(zoningRows.map((row) => row[6]));
        if (table.coilCalculation === "room-air-heating") equipment = unique(zoningRows.map((row) => row[10]));
      }
    }
    const existing = new Map((Array.isArray(savedRows) ? savedRows : [])
      .filter((row) => row.length === table.columns.length)
      .map((row) => [String(row[0] ?? "").toLowerCase(), row]));
    table.sourceRowsLookup ||= new Map(Object.entries(table.sourceRows || {}).map(([key, row]) => [key.toLowerCase(), row]));
    const source = table.sourceRowsLookup;
    savedRows = equipment.map((name) => {
      const row = existing.get(name.toLowerCase()) || source.get(name.toLowerCase()) || Array(table.columns.length).fill("");
      const copy = [...row]; copy[0] = name; return copy;
    });
    project.independentTables[table.id] = savedRows;
    return savedRows;
  }
  if (table.schemaVersion && project.independentTableSchemaVersions[table.id] !== table.schemaVersion) {
    const migratedEquipmentZoning = table.id === "calc-equipment-zoning" && Array.isArray(savedRows)
      ? savedRows.filter((row) => row.length === 11).map((row) => [
        row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[10], row[9], row[7], row[8],
      ])
      : null;
    const migratedVentilation = table.id === "calc-ventilation-exhaust" && Array.isArray(savedRows)
      ? savedRows.filter((row) => [14, 15, 18, 20].includes(row.length)).map((row) => {
        const previous = row.length === 20 ? [row[1], row[0], ...row.slice(3, 15)]
          : row.length === 18 ? [row[0], row[2], ...row.slice(3, 15)] : row;
        return previous.length === 14 ? [...previous.slice(0, 6), "", ...previous.slice(6)] : previous;
      })
      : null;
    const migratedExhaustSummary = table.id === "calc-exhaust-requirements" && Array.isArray(savedRows)
      ? savedRows.filter((row) => [10, 12, 14, 16].includes(row.length)).map((row) => row.length === 16
        ? [...row.slice(0, 3), ...row.slice(10, 14), ...row.slice(5, 10)]
        : row.length === 10 ? [...row.slice(0, 3), ...Array(4).fill(""), ...row.slice(5, 10)] : row).map(r=>r.length===12?[...r.slice(0,7),0,0,...r.slice(7)]:r)
      : null;
    const migratedPlant = table.plantCalculation && Array.isArray(savedRows)
      ? savedRows.filter((row) => row.length === (table.plantCalculation === "cooling" ? 20 : 18))
        .map((row) => table.plantCalculation === "cooling"
          ? [...row.slice(0, 12), "TRUE", ...row.slice(12, 19)]
          : [...row.slice(0, 10), "TRUE", ...row.slice(10, 17)])
      : null;
    const migratedGeneralExhaust = table.id === "selected-general-exhaust" && Array.isArray(savedRows)
      ? savedRows.filter((row) => [14, 16].includes(row.length)).map((row) => row.length === 16
        ? [row[0], row[12], row[9], row[2], row[3], row[4], row[5], row[7], row[10], row[13], row[6], row[8], row[11], row[14]] : row)
      : null;
    const migratedEquipmentExhaust = table.id === "selected-exhaust-equipment" && Array.isArray(savedRows)
      ? savedRows.filter((row) => [7, 10].includes(row.length)).map((row) => row.length === 10
        ? [row[0], row[4] || "", row[3], row[2], row[1], row[7], row[8]] : row)
      : null;
    if (table.id === "selected-transfer-air" && project.sharedSpaceFilter?.field?.startsWith(`col:${table.id}:`)) {
      const oldColumn = Number(project.sharedSpaceFilter.field.split(":").at(-1));
      const mapped = { 0:0, 2:5, 4:10, 5:11 }[oldColumn];
      if (mapped !== undefined) project.sharedSpaceFilter.field = `col:${table.id}:${mapped}`;
      else project.sharedSpaceFilter = { field: "meta:zoneGroup", values: null };
    }
    const migratedTransfer = table.id === "selected-transfer-air" && Array.isArray(savedRows)
      ? savedRows.filter((row) => [7,11,12].includes(row.length)).map((row) => {
        if (row.length === 12) return row;
        const r = row.length === 11 ? [2,3,4,5,6,9,10].map((i) => row[i]) : row;
        const result = ["", "", "", "", r[1], r[2], r[3], "", "", "", "", r[5]];
        if (r[6]) { project.cellNotes ||= {}; const key = cellNoteKey(project, table, result, savedRows.indexOf(row), 5); project.cellNotes[key] ||= String(r[6]); }
        return result;
      }) : null;
    const migratedPress = table.id === "calc-pressurization" && Array.isArray(savedRows)
      ? savedRows.filter((row) => [23, 22, 21].includes(row.length)).map((row) => {
        if (row.length === 22) return row;
        if (row.length === 21) return ["", ...row];
        if (row[12] !== "" && row[12] !== undefined) {
          project.legacyManualBalances ||= {};
          project.legacyManualBalances[requirementKey(row[0])] = row[12];
        }
        const next = Array(21).fill(""); next[0] = row[0]; next[12] = row[8] || "";
        next[16] = row[15] ?? ""; next[17] = row[16] ?? ""; return ["", ...next];
      }) : null;
    const migratedBalancing = table.id === "calc-air-balancing-requirements" && Array.isArray(savedRows)
      ? savedRows.filter((row) => [11, 12, 13].includes(row.length)).map((row) => row.length === 11 ? ["", ...row, ""]
        : row.length === 12 ? [...row, ""] : row) : null;
    const migratedCombinedAirflow = table.id === "calc-airflow-requirements" && Array.isArray(savedRows)
      ? savedRows.filter((row) => [13, 15].includes(row.length)).map((row) => row.length === 13
        ? [...row.slice(0, 6), "", row[6], ...row.slice(7, 12), "", row[12]] : row) : null;
    const migratedPeak = table.id === "calc-peak-airflows" && Array.isArray(savedRows)
      ? savedRows.filter((row) => [19, 20].includes(row.length)).map((row) => row.length === 20
        ? [...row.slice(0, 17), row[18], row[19]] : row) : null;
    if (migratedEquipmentZoning?.length) {
      if (project.zoningOverrides) delete project.zoningOverrides[table.id];
      if (project.zoningAutoValues) delete project.zoningAutoValues[table.id];
    }
    project.independentTables[table.id] = migratedPress?.length ? migratedPress
      : migratedBalancing?.length ? migratedBalancing
      : migratedCombinedAirflow?.length ? migratedCombinedAirflow
      : migratedPeak?.length ? migratedPeak
      : migratedTransfer?.length ? migratedTransfer
      : migratedPlant?.length ? migratedPlant
      : migratedExhaustSummary?.length ? migratedExhaustSummary
      : migratedGeneralExhaust?.length ? migratedGeneralExhaust
      : migratedEquipmentExhaust?.length ? migratedEquipmentExhaust
      : migratedVentilation?.length ? migratedVentilation : migratedEquipmentZoning?.length
      ? migratedEquipmentZoning
      : table.rows.map((row) => [...row]);
    project.independentTableSchemaVersions[table.id] = table.schemaVersion;
    savedRows = project.independentTables[table.id];
    saveProjects();
  }
  if (!Array.isArray(savedRows) && table.sourceTableId && Array.isArray(project.independentTables[table.sourceTableId])) {
    const sourceRows = project.independentTables[table.sourceTableId];
    if (sourceRows.every((row) => row.length >= Math.max(...table.sourceColumnIndexes) + 1)) {
      savedRows = sourceRows.map((row) => table.sourceColumnIndexes.map((index) => row[index]));
      project.independentTables[table.id] = savedRows;
      saveProjects();
    }
  }
  if (table.id === "schedule-equipment-sensible-gain" && project.independentTableSchemaVersions[table.id] !== 3) {
    if (Array.isArray(savedRows)) {
      project.independentTables[table.id] = savedRows.map((row) => {
        if (row.length === 6) return [row[0], row[1], row[2] ?? "", row[3] ?? "", "", row[4], row[5]];
        const kilowatts = row[2] !== "" && row[2] !== null && row[2] !== undefined
          ? numberFromTableValue(row[2]) / 1000
          : row[3] ?? "";
        return [row[0], row[1], kilowatts, row[4] ?? "", "", row[5], row[6]];
      });
    } else {
      project.independentTables[table.id] = table.rows.map((row) => [...row]);
    }
    project.independentTableSchemaVersions[table.id] = 3;
    savedRows = project.independentTables[table.id];
    saveProjects();
  }
  if (table.tabularCalculation && project.independentTableSchemaVersions[table.id] !== 4) {
    const oldVersion = project.independentTableSchemaVersions[table.id];
    const oldColumns = savedRows?.[0]?.length === 44 || oldVersion === 3;
    const migrate = (row, empty = "") => row.length === tabularFields.length ? row : tabularFields.map((field) => {
      const index = row.length === 44 ? tabularV3Keys.indexOf(field.key) : field.legacy;
      return index !== undefined && index >= 0 ? row[index] ?? empty : empty;
    });
    savedRows = (Array.isArray(savedRows) ? savedRows : []).map((row) => migrate(row));
    project.independentTables[table.id] = savedRows;
    const upload = project.clipboardImports?.[table.id];
    if (upload) {
      upload.sourceRows = (upload.sourceRows || []).map((row) => migrate(row));
      upload.mappedColumns = migrate(upload.mappedColumns || [], false).map(Boolean);
      if (upload.rawHeaders && upload.rawRows) upload.metadataBySpace = extractTabularMetadata(upload.rawHeaders, upload.rawRows);
    }
    const filter = project.sharedSpaceFilter;
    if (filter?.field?.startsWith(`col:${table.id}:`)) {
      const previous = Number(filter.field.split(":")[2]);
      const column = oldColumns ? tabularColumn[tabularV3Keys[previous]] : tabularFields.findIndex((field) => field.legacy === previous);
      if (column !== undefined && column >= 0) filter.field = `col:${table.id}:${column}`;
      else { filter.field = "meta:space"; filter.values = null; }
    }
    project.independentTableSchemaVersions[table.id] = 4;
    if (typeof csvImportsByProject !== "undefined") csvImportsByProject.delete(`${project.id || "default"}::${table.id}`);
    saveProjects();
  }
  if (table.id === "room-zone-loads-report" && project.independentTableSchemaVersions[table.id] !== 1) {
    project.independentTables[table.id] = [];
    project.excelImports ||= {};
    delete project.excelImports[table.id];
    project.independentTableSchemaVersions[table.id] = 1;
    savedRows = project.independentTables[table.id];
    saveProjects();
  }
  if (table.id === "calc-room-loads" && Array.isArray(savedRows)) {
    const typeBySpace = new Map(table.rows.map((row) => [String(row[0] ?? ""), row[1] ?? ""]));
    if (savedRows.some((row) => row.length === 14)) {
      savedRows = savedRows.map((row) => [row[0], typeBySpace.get(String(row[0] ?? "")) || "", ...row.slice(1)]);
    }
    if (savedRows.some((row) => row.length === 15)) {
      savedRows = savedRows.map((row) => [
        ...row.slice(0, 6), 0.1, row[6],
        ...row.slice(7, 11), 0.1, row[11],
        ...row.slice(12, 14), 0.1, row[14],
      ]);
    }
    savedRows.forEach((row) => {
      row[4] = String(row[4] ?? "").toUpperCase() === "TRUE" ? "TRUE" : "";
      row[10] = String(row[10] ?? "").toUpperCase() === "TRUE" ? "TRUE" : "";
    });
    project.independentTables[table.id] = savedRows;
  }
  if (table.id === "ashrae-90-1-baseline-systems" && Array.isArray(savedRows) && savedRows.some((row) => row.length === 7)) {
    project.independentTables[table.id] = savedRows.map((row) => row.length === 7 ? row.filter((_, index) => index !== 2) : row);
    saveProjects();
  } else if (!Array.isArray(savedRows) || savedRows.some((row) => row.length !== table.columns.length)) {
    project.independentTables[table.id] = table.rows.map((row) => [...row]);
    saveProjects();
  }
  const result = project.independentTables[table.id];
  if (table.thermalTemplateCalculation && !project.thermalDefaultsVersion) {
    if (String(project.number) !== "185021") {
      const retained = result.filter((row) => !isProjectThermalType(row[0]));
      result.splice(0, result.length, ...retained);
    } else {
      const existing = new Set(result.map((row) => requirementKey(row[0])));
      table.thermalDefaultRows.filter((row) => isProjectThermalType(row[0]) && !existing.has(requirementKey(row[0])))
        .forEach((row) => result.push([...row]));
    }
    project.thermalDefaultsVersion = 1;
  }
  if (table.tabularCalculation) populateTabularSourceColumns(table, result, project);
  enforceSpaceMembership(project, table, result);
  applyTabularSpaceMetadata(project, table, result);
  return result;
}

function isProjectThermalType(value) {
  return ["bio vest", "janitor", "telecom"].includes(requirementKey(value).replace(/^space:\s*/, ""));
}

function recalculateThermalTemplates(table, rows, project) {
  const defaults = new Map(table.thermalDefaultRows.map((row) => [requirementKey(row[0]), row]));
  const previous = project?.thermalAutoValues || {}, overrides = project ? (project.thermalOverrides ||= {}) : {};
  const next = {};
  table.autoCellStates = new Map(); table.lockedCellStates = new Map(); table.lockedCellMessages = new Map();
  const equal = (left, right) => String(left ?? "") === String(right ?? "");
  rows.forEach((row, index) => {
    const name = requirementKey(row[0]), baseline = defaults.get(name);
    const builtin = Boolean(baseline && !isProjectThermalType(name));
    if (builtin) {
      table.lockedCellStates.set(index, new Set([0]));
      table.lockedCellMessages.set(index, new Map([[0, "Preloaded space type"]]));
    }
    const auto = new Set();
    // Set category defaults before evaluating dependent values.
    const columns = [...table.autoColumns.filter((column) => !table.thermalLookupColumns.includes(column)), ...table.thermalLookupColumns];
    columns.forEach((column) => {
      const key = `${name}::${column}`;
      const lookup = table.thermalLookupColumns.includes(column);
      if (!name || (!lookup && !builtin)) return;
      const category = [3, 4, 5].includes(column) ? 2 : [7, 8].includes(column) ? 6 : column === 10 ? 9 : 11;
      const defaultValue = lookup ? row[category] ? evaluateProjectEquation(table.equations[column], table, row, rows, project) : "" : baseline[column];
      if (lookup) { row[column] = defaultValue; delete overrides[key]; return; }
      const prior = Object.hasOwn(previous, key) ? previous[key] : defaultValue;
      if (row[column] === "" || row[column] === undefined || equal(row[column], defaultValue)) delete overrides[key];
      else if (!equal(row[column], prior)) overrides[key] = true;
      if (!overrides[key]) { row[column] = defaultValue; auto.add(column); }
      next[key] = defaultValue;
    });
    row[1] = name ? evaluateProjectEquation(table.equations[1], table, row, rows, project) : "";
    table.autoCellStates.set(index, auto);
  });
  if (project) project.thermalAutoValues = next;
}

function selectedSpaceReferenceTables() {
  return independentTables.filter((table) => table.id.startsWith("selected-")).map((table) => ({
    table, columns: table.id === "selected-transfer-air" ? [4, 6] : [0],
  }));
}

function enforceSpaceMembership(project, table, rows) {
  const calculation = table.id.startsWith("calc-") && Number.isInteger(table.spaceColumn);
  const selected = table.id.startsWith("selected-");
  if (!calculation && !selected) return;
  const tabular = project.independentTables["iesve-tabular-space-data"] || [];
  const spaces = [...new Map(tabular.map((row) => [requirementKey(row[tabularColumn.space]), String(row[tabularColumn.space] ?? "").trim()]).filter(([key]) => key)).values()];
  const valid = new Set(spaces.map(requirementKey));
  let next;
  if (calculation && !table.systemAirBalanceMode) {
    const existing = new Map(rows.map((row) => [requirementKey(row[table.spaceColumn]), row]));
    next = spaces.map((space) => existing.get(requirementKey(space)) || blankCalculationRow(table, space));
  } else {
    const columns = calculation ? [table.spaceColumn] : table.id === "selected-transfer-air" ? [4, 6] : [0];
    next = rows.filter((row) => columns.every((column) => !requirementKey(row[column]) || valid.has(requirementKey(row[column]))));
  }
  if (next.length !== rows.length || next.some((row, index) => row !== rows[index])) {
    const ids = project.tableRowIds?.[table.id];
    if (ids) { const oldIds = new Map(rows.map((row,i) => [row,ids[i]])); project.tableRowIds[table.id] = next.map((row) => oldIds.get(row) || `row:${crypto.randomUUID()}`); }
    rows.splice(0, rows.length, ...next);
  }
}

function synchronizeProjectSpaceReferences(project) {
  if (!project) return;
  const tabular = independentTables.find((table) => table.id === "iesve-tabular-space-data");
  const tabularRows = ensureProjectTableRows(project, tabular);
  const valid = new Set(tabularRows.map((row) => requirementKey(row[tabularColumn.space])).filter(Boolean));
  const removed = new Set();
  Object.entries(project.independentTables || {}).forEach(([id, rows]) => {
    const table = independentTables.find((candidate) => candidate.id === id);
    if (table?.id.startsWith("calc-") && Number.isInteger(table.spaceColumn)) rows.forEach((row) => {
      const space = String(row[table.spaceColumn] ?? ""); if (space && !valid.has(requirementKey(space))) removed.add(space);
    });
  });
  Object.keys(project.equipmentZoningTool?.assignments || {}).forEach((space) => {
    if (!valid.has(requirementKey(space))) removed.add(space);
  });
  removed.forEach((space) => remapProjectSpaceKeys(project, space));
  [...calculationSpaceTables(), ...selectedSpaceReferenceTables().map(({ table }) => table),
    ...independentTables.filter((table) => table.systemAirBalanceMode)].forEach((table) => ensureProjectTableRows(project, table));
  const thermal = independentTables.find((table) => table.thermalTemplateCalculation);
  if (thermal) ensureProjectTableRows(project, thermal);
}

function normalizedTabularHeader(value) {
  return String(value ?? "").toLowerCase().replace(/\((real|proposed|baseline)\)\s*$/, "")
    .replace(/²/g, "2").replace(/³/g, "3").replace(/[^a-z0-9]+/g, " ").trim().replace(/\s+/g, " ");
}

function extractTabularMetadata(headers, rows) {
  const normalized = headers.map(normalizedTabularHeader);
  const find = (pattern) => normalized.findIndex((header) => pattern.test(header));
  const nameColumn = find(/^(space|room) name$/), idColumn = find(/^(space|room) id$/);
  const typeColumn = find(/^(?:(?:assigned )?thermal template(?: name)?|(?:space|room) (?:type|template)|template(?: name)?|type)$/);
  const areaColumn = find(/^(?:(?:space|room|net|internal) )?(?:floor )?area(?: (?:ft2|ft 2|sq ft|square feet|m2|m 2|sq m))?$/);
  const volumeColumn = find(/^(?:(?:space|room|net|internal) )?volume(?: (?:ft3|ft 3|cu ft|cubic feet|m3|m 3|cu m))?$/);
  const gainColumns = [1, 2, 3].map((slot) => find(new RegExp(`^gain ${slot} (?:type|name|category)$`)));
  const kind = (value) => /people|occupan/i.test(value) ? "people" : /light/i.test(value) ? "lighting" : /computer|equipment|misc|process/i.test(value) ? "equipment" : "";
  const measure = (value, column, dimension) => {
    const text = String(value ?? "").replace(/,/g, "").trim();
    if (!text) return "";
    const number = Number(text.replace(/\s*(?:ft|m|sq\s*ft|cu\s*ft)[²³23]?(?:\s*)$/i, ""));
    if (!Number.isFinite(number)) return "";
    const metric = /(?:^| )m ?[23](?: |$)|sq m|cu m/.test(normalized[column] || "");
    return metric ? number * (dimension === 2 ? 10.76391041671 : 35.31466672149) : number;
  };
  const result = {};
  if (nameColumn < 0) return result;
  rows.forEach((row) => {
    const space = String(row[nameColumn] ?? "").trim(); if (!space) return;
    const record = { spaceId: idColumn >= 0 ? row[idColumn] : "", gainSlots: gainColumns.map((column) => column < 0 ? "" : kind(row[column])),
      gainTypes: gainColumns.map((column) => column < 0 ? "" : String(row[column] ?? "")),
      gainModes: [1, 2, 3].map((slot) => { const column = find(new RegExp(`^gain ${slot} input mode$`)); return column < 0 ? "" : String(row[column] ?? ""); }),
    };
    if (typeColumn >= 0) record.type = String(row[typeColumn] ?? "").trim();
    if (areaColumn >= 0) record.area = measure(row[areaColumn], areaColumn, 2);
    if (volumeColumn >= 0) record.volume = measure(row[volumeColumn], volumeColumn, 3);
    for (const [field, pattern] of [["heatingSetpoint", /^heating setpoint(?: f| degf)?$/], ["coolingSetpoint", /^cooling setpoint(?: f| degf)?$/], ["relativeHumidity", /^(?:saturation upper limit|relative humidity)(?: percent)?$/]]) {
      const column = find(pattern);
      if (column >= 0 && String(row[column] ?? "").trim() !== "") {
        const rawValue = String(row[column]).trim();
        const profile = field !== "relativeHumidity" && rawValue.match(/^Two-value:\s*([-+\d.]+)\s*;\s*([-+\d.]+)\s*;\s*(.*)$/i);
        const value = Number((profile ? profile[1] : rawValue).replace(/[% ,]/g, ""));
        if (Number.isFinite(value)) record[field] = field === "relativeHumidity" && value > 1 ? value / 100 : value;
        if (profile && Number.isFinite(Number(profile[2]))) record[field === "heatingSetpoint" ? "heatingSetback" : "coolingSetback"] = Number(profile[2]);
      }
    }
    result[requirementKey(space)] = record;
  });
  return result;
}

function tabularMetadata(project, space) {
  const source = project?.clipboardImports?.["iesve-tabular-space-data"];
  if (source && !source.metadataBySpace && source.rawHeaders && source.rawRows) source.metadataBySpace = extractTabularMetadata(source.rawHeaders, source.rawRows);
  const metadata = source?.metadataBySpace?.[requirementKey(space)];
  const row = project?.independentTables?.["iesve-tabular-space-data"]?.find((row) => requirementKey(row[tabularColumn.space]) === requirementKey(space));
  if (!row || row.length !== tabularFields.length) return metadata || null;
  const result = { ...(metadata || {}) };
  for (const [key, column] of [["type", tabularColumn.thermal], ["volume", tabularColumn.volume], ["area", tabularColumn.area]]) {
    if (row[column] !== "" || metadata && Object.hasOwn(metadata, key)) result[key] = row[column];
  }
  result.gainTypes = [1, 2, 3].map((slot) => row[tabularColumn[`gain${slot}Type`]]);
  return metadata || Object.hasOwn(result, "type") || Object.hasOwn(result, "area") ? result : null;
}

function applyTabularSpaceMetadata(project, table, rows) {
  if (!Number.isInteger(table.spaceColumn) || table.systemAirBalanceMode) return;
  const typeColumn = ["calc-space-condition-setpoints", "calc-room-loads", "calc-lighting-gains", "calc-people-gains", "calc-misc-gains"].includes(table.id) ? 1 : -1;
  const areaColumn = table.gainCalculation ? 2 : -1;
  rows.forEach((row) => {
    const metadata = tabularMetadata(project, row[table.spaceColumn]);
    if (!metadata) return;
    if (typeColumn >= 0 && Object.hasOwn(metadata, "type")) row[typeColumn] = metadata.type;
    if (table.id === "calc-space-condition-setpoints") {
      for (const [column, field] of [[2, "relativeHumidity"], [3, "heatingSetpoint"], [4, "heatingSetback"], [8, "coolingSetpoint"], [9, "coolingSetback"]]) {
        if (row[column] === "" && Object.hasOwn(metadata, field)) row[column] = metadata[field];
      }
    }
    if (areaColumn >= 0 && Object.hasOwn(metadata, "area")) row[areaColumn] = metadata.area;
  });
  table.displayEquations ||= {};
  if (typeColumn >= 0) table.displayEquations[typeColumn] = '=XLOOKUP(@Space,[Tabular Space Data]@Space Name,[Tabular Space Data]@Thermal Template)';
  if (areaColumn >= 0) table.displayEquations[areaColumn] = '=XLOOKUP(@Space,[Tabular Space Data]@Space Name,[Tabular Space Data]@Floor Area)';
}

function populateTabularSourceColumns(table, rows, project) {
  const upload = project?.clipboardImports?.[table.id];
  if (!upload) return;
  if (!upload.metadataBySpace && upload.rawHeaders && upload.rawRows) upload.metadataBySpace = extractTabularMetadata(upload.rawHeaders, upload.rawRows);
  rows.forEach((row) => {
    const metadata = upload.metadataBySpace?.[requirementKey(row[tabularColumn.space])];
    if (!metadata) return;
    for (const [field, key] of [["type", "thermal"], ["volume", "volume"], ["area", "area"]]) {
      if (Object.hasOwn(metadata, field)) row[tabularColumn[key]] = metadata[field];
    }
    [1, 2, 3].forEach((slot) => {
      row[tabularColumn[`gain${slot}Type`]] = metadata.gainTypes?.[slot - 1] ?? "";
    });
  });
}

function recalculateConditionSchedules(table, rows, project) {
  const defaults = project?.calcSettings?.twoValueSchedule || table.twoValueScheduleDefault;
  const previous = project ? (project.conditionScheduleAutos ||= {}) : {};
  const overrides = project ? (project.conditionScheduleOverrides ||= {}) : {};
  table.autoCellStates = new Map(); table.lockedCellStates = new Map(); table.lockedCellMessages = new Map();
  rows.forEach((row, index) => {
    recalculateSpecialTableRow(table, row);
    const auto = new Set(), locked = new Set();
    for (const [column, setback] of [[6, 4], [11, 9]]) {
      const key = `${requirementKey(row[0])}::${column}`;
      if (row[setback] === "" || row[setback] == null) {
        row[column] = ""; locked.add(column); delete overrides[key];
      } else {
        if (!row[column] || row[column] === defaults) delete overrides[key];
        else if (previous[key] !== undefined && row[column] !== previous[key]) overrides[key] = true;
        if (!overrides[key]) { row[column] = defaults; auto.add(column); }
      }
      previous[key] = defaults;
    }
    table.autoCellStates.set(index, auto); table.lockedCellStates.set(index, locked);
    table.lockedCellMessages.set(index, new Map([...locked].map((column) => [column, "Enter a temperature setback to enable this schedule."])));
  });
}

function recordScheduleOverride(table, row, column, value, project) {
  releaseTableSort(table,project);
  if(table.peakAirflowCalculation&&[4,10,17].includes(column)){project.peakAirflowOverrides||={};const key=requirementKey(row[0])+'::'+column,n=Number(String(value).replace(/,/g,''));if(value===''||!Number.isFinite(n)||n===Number(project.peakAirflowAutos?.[key]))delete project.peakAirflowOverrides[key];else project.peakAirflowOverrides[key]=n;return;}

  if(table.conditionBaselineCalculation&&column===11&&project){project.baselineSystemOverrides ||= {};const key=requirementKey(row[1]);if(value===''||value===project.baselineSystemAutos?.[key])delete project.baselineSystemOverrides[key];else project.baselineSystemOverrides[key]=value;}
  if ((table.equipmentAirflowsCalculation || table.combinedAirflowCalculation) && table.autoColumns?.includes(column) && project) {
    project.airflowOverrides ||= {};
    const key = `${table.id}::${requirementKey(row[0])}::${column}`;
    if (String(value).trim()==="" || Number(value)===Number(project.airflowAutos?.[key])) delete project.airflowOverrides[key];
    else project.airflowOverrides[key]=Number(value);
  }
  if (table.ventilationRequirementsCalculation && [10, 12].includes(column) && project) {
    project.ventilationEzOverrides ||= {};
    const key = `${requirementKey(row[1])}::${column}`;
    if (!String(value).trim() || Number(value) === Number(project.ventilationEzAutos?.[key])) delete project.ventilationEzOverrides[key];
    else project.ventilationEzOverrides[key] = true;
  }
  if (table.ventilationRequirementsCalculation && column === 2 && project) {
    project.ventilationTypeOverrides ||= {};
    const key = requirementKey(row[1]);
    if (!value || value === project.ventilationTypeAutos?.[key]) delete project.ventilationTypeOverrides[key];
    else project.ventilationTypeOverrides[key] = true;
  }
  if (table.conditionScheduleCalculation && table.autoColumns.includes(column) && project) {
    const key = `${requirementKey(row[0])}::${column}`;
    project.conditionScheduleOverrides ||= {};
    if (!String(value).trim() || value === project.conditionScheduleAutos?.[key]) delete project.conditionScheduleOverrides[key];
    else project.conditionScheduleOverrides[key] = true;
    return;
  }
  if (!table.scheduleCalculation || column !== table.scheduleColumn || !project) return;
  const key = `${table.id}::${requirementKey(row[0])}`;
  project.consumptionScheduleOverrides ||= {};
  if (!String(value).trim() || String(value) === String(project.consumptionScheduleAutos?.[key] ?? "")) delete project.consumptionScheduleOverrides[key];
  else project.consumptionScheduleOverrides[key] = true;
}

function recalculateConsumptionSchedules(table, rows, project) {
  const defaults = table.id === "femp-shw-calculator" ? null : (() => {
    const femp = independentTables.find((t) => t.id === "femp-shw-calculator");
    const rows = ensureProjectTableRows(project, femp); recalculateConsumptionSchedules(femp, rows, project);
    return new Map(rows.map((row) => [requirementKey(row[0]), row[2]]));
  })();
  const previous = project?.consumptionScheduleAutos || {};
  const overrides = project ? (project.consumptionScheduleOverrides ||= {}) : {};
  table.autoCellStates = new Map();
  rows.forEach((row, index) => {
    const building = String(row[defaults ? 1 : 0] ?? "").trim();
    const proposed = defaults ? building ? defaults.get(requirementKey(building)) || "" : "" : fempConsumptionSchedules[building] || "";
    const key = `${table.id}::${requirementKey(row[0])}`, column = table.scheduleColumn;
    if (!row[column] || row[column] === proposed) delete overrides[key];
    else if (previous[key] !== undefined && row[column] !== previous[key]) overrides[key] = true;
    if (!building) { row[column] = ""; delete overrides[key]; }
    else if (!overrides[key]) row[column] = proposed;
    if (!overrides[key] && building) table.autoCellStates.set(index, new Set([column]));
    if (project) { project.consumptionScheduleAutos ||= {}; project.consumptionScheduleAutos[key] = proposed; }
    if (defaults) row[3] = row[0] ? evaluateProjectEquation(tableEquations(table)[3], table, row, rows, project) : "";
  });
}

function recalculateTabularSpaceData(table, rows, project) {
  const source = (id) => {
    const t = independentTables.find((candidate) => candidate.id === id);
    if (!t) return [];
    const result = ensureProjectTableRows(project, t); recalculateTable(t, result, project); return result;
  };
  source("iesve-thermal-template");
  const bySpace = (rows, column = 0) => new Map(rows.map((row) => [requirementKey(row[column]), row]));
  const conditions = bySpace(source("calc-space-condition-setpoints"));
  const people = bySpace(source("calc-people-gains")), lighting = bySpace(source("calc-lighting-gains")), equipment = bySpace(source("calc-misc-gains"));
  const water = bySpace(source("calc-dhw")), airflow = bySpace(source("calc-airflow-requirements"));
  const balancing = bySpace(source("calc-air-balancing-requirements"), 1);
  const uploaded = project?.clipboardImports?.[table.id];
  const csvById = new Map((uploaded?.sourceRows || []).map((row) => [requirementKey(row[tabularColumn.id]), row]));
  const num = (value) => Number.isFinite(Number(value)) ? Number(value) : 0;
  const present = (value) => value !== "" && value !== undefined && value !== null && value !== "-";
  const schedule = project?.calcSettings?.twoValueSchedule || "System extended hours";
  table.cellDisplayEquations = new Map(); table.specifiedCellStates = new Map(); table.cellDifferenceEquations = new Map();
  rows.forEach((row, index) => {
    const key = requirementKey(row[tabularColumn.space]), csv = csvById.get(requirementKey(row[tabularColumn.id])) || [];
    const metadata = tabularMetadata(project, row[tabularColumn.space]);
    const setpoints = conditions.get(key) || [], af = airflow.get(key) || [], dhw = water.get(key) || [], balance = balancing.get(key) || [];
    const p = people.get(key) || [], l = lighting.get(key) || [], e = equipment.get(key) || [];
    for (let column = 3; column < row.length; column += 1) row[column] = csv[column] ?? "";
    const specified = new Set([tabularColumn.id, tabularColumn.space]);
    const equations = new Map(tabularFields.map((_, column) => [column, "Not specified in calc"]));
    const set = (key, value, equation) => { const column = tabularColumn[key]; row[column] = value; specified.add(column); equations.set(column, equation); };
    if (metadata) {
      for (const [field, key] of [["type", "thermal"], ["volume", "volume"], ["area", "area"]]) if (Object.hasOwn(metadata, field)) row[tabularColumn[key]] = metadata[field];
    }
    const dhwAmount = num(dhw[3]);
    set("dhwEnabled", dhwAmount > 0 ? "Yes" : "No", '=IF([Domestic Water Heating]@DHW Consumption>0,"Yes","No")');
    if (dhwAmount > 0) {
      set("dhw", `${dhwAmount.toFixed(5)} USgall/hour`, '=IF(@DHW Consumption Room-level Setting="Yes",TEXT([Domestic Water Heating]@DHW Consumption,"0.00000") & " USgall/hour","Not specified in calc")');
      set("dhwPattern", "Independent profile", '=IF(@DHW Consumption Room-level Setting="Yes","Independent profile","Not specified in calc")');
      set("dhwSchedule", dhw[4] || "", '=IF(@DHW Consumption Room-level Setting="Yes",[Domestic Water Heating]@DHW Consumption Schedule,"Not specified in calc")');
    }
    for (const [key, column, label] of [["heatingSupply", 12, "Heating"], ["coolingSupply", 5, "Cooling"]]) {
      if (present(af[column])) set(key, num(af[column]).toFixed(1), `=[Cooling & Heating Airflow Requirements]@${label} Equipment Dry-Bulb`);
    }
    for (const [key, main, setback, label, scheduleColumn] of [["heatingSetpoint", 3, 4, "Heating", 6], ["coolingSetpoint", 8, 9, "Cooling", 11]]) {
      if (!present(setpoints[main])) continue;
      const value = present(setpoints[setback]) ? `Two-value: ${num(setpoints[main]).toFixed(1)}; ${num(setpoints[setback]).toFixed(1)}; ${setpoints[scheduleColumn] || schedule}` : num(setpoints[main]).toFixed(1);
      set(key, value, `=IF([Space Condition Setpoints]@${label} Setback<>"","Two-value: " & TEXT([Space Condition Setpoints]@${label} Main Setpoint,"0.0") & "; " & TEXT([Space Condition Setpoints]@${label} Setback,"0.0") & "; " & [Space Condition Setpoints]@${label} Schedule,TEXT([Space Condition Setpoints]@${label} Main Setpoint,"0.0"))`);
    }
    if (present(setpoints[2])) set("rh", num(setpoints[2]) * 100, '=[Space Condition Setpoints]@Relative Humidity * 100');
    for (let slot = 1; slot <= 3; slot += 1) {
      const prefix = `gain${slot}`, type = metadata?.gainTypes?.[slot - 1] || csv[tabularColumn[`${prefix}Type`]] || "";
      row[tabularColumn[`${prefix}Type`]] = type;
      const normalized = requirementKey(type), lightingType = normalized === "general lighting";
      const mode = normalized === "people" ? "People" : normalized === "computers" || lightingType ? "Btu/h" : "";
      const modeEquation = `=IF(@Gain ${slot} Type="People","People",IF(OR(@Gain ${slot} Type="Computers",@Gain ${slot} Type="General Lighting"),"Btu/h","Not specified in calc"))`;
      equations.set(tabularColumn[`${prefix}Mode`], modeEquation);
      if (mode) set(`${prefix}Mode`, mode, modeEquation);
      for (const [suffix, column, label] of [["Occupancy", 5, "Actual People"], ["PersonSensible", 6, "Sensible Heat"], ["PersonLatent", 7, "Latent Heat"]]) {
        const equation = `=IF(@Gain ${slot} Type="People",[People Gains]@${label},"Not specified in calc")`;
        equations.set(tabularColumn[`${prefix}${suffix}`], equation);
        if (normalized === "people") set(`${prefix}${suffix}`, num(p[column]), equation);
      }
      const baseline = uploaded?.templateType === "Baseline";
      const total = lightingType ? num(l[baseline ? 8 : 7]) : num(e[5]);
      const totalEquation = `=IF(@Gain ${slot} Type="People","Not specified in calc",IF(@Gain ${slot} Type="Computers",[Miscellaneous Sensible Gains]@Miscellaneous Sensible Load,IF(@Gain ${slot} Type="General Lighting",IF([Template]="Baseline",[Lighting Gains]@Baseline Lighting Gain,[Lighting Gains]@Proposed Lighting Gain),"Not specified in calc")))`;
      for (const suffix of ["Sensible", "Power"]) {
        equations.set(tabularColumn[`${prefix}${suffix}`], totalEquation);
        if (normalized === "computers" || lightingType) set(`${prefix}${suffix}`, total, totalEquation);
      }
    }
    set("oaBasis", "OA requirement (per room data or user edit)", '="OA requirement (per room data or user edit)"');
    set("oaType", "Single Requirement", '="Single Requirement"');
    set("ventilation", num(balance[10]), '=[Air Balancing Requirements]@Ventilation');
    set("useExhaust", "Yes", '="Yes"');
    set("relief", num(balance[11]), '=[Air Balancing Requirements]@Relief');
    set("exhaustUnit", "CFM", '="CFM"');
    const compared = [...specified].filter((column) => column > tabularColumn.space && uploaded?.mappedColumns?.[column]);
    row[tabularColumn.differences] = compared.filter((column) => (!csv.length || !csvValuesMatch(table, row[column], csv[column], column))).length;
    specified.add(tabularColumn.differences);
    const terms = compared.map((column) => {
      const h = table.headers[column], label = `${h.label}${h.unit ? ` (${h.unit})` : ""}`;
      const actual = `@[${label}]`, source = `[Current IESVE Values]@[${label}]`;
      return `  ${csvDifferenceExpression(table, column, actual, source)}`;
    });
    table.cellDifferenceEquations.set(index, terms.length ? `SUM(\n${terms.join(",\n")}\n)` : '0');
    equations.set(tabularColumn.differences, '=DIFFERINGVALUES(@Compared Values, @Current IESVE Values)');
    table.cellDisplayEquations.set(index, equations); table.specifiedCellStates.set(index, specified);
  });
}

function projectTableRows(table) {
  if(table.psychCalculation)return table.rows;
  return ensureProjectTableRows(activeProject(), table);
}

function ensureProjectTableHeaders(project, table) {
  if (!project) return table.headers;
  project.independentTableHeaders ||= {};
  let savedHeaders = project.independentTableHeaders[table.id];
  if (!Array.isArray(savedHeaders) && table.sourceTableId && Array.isArray(project.independentTableHeaders[table.sourceTableId])) {
    const sourceHeaders = project.independentTableHeaders[table.sourceTableId];
    if (sourceHeaders.length >= Math.max(...table.sourceColumnIndexes) + 1) {
      savedHeaders = table.sourceColumnIndexes.map((index) => ({ ...sourceHeaders[index] }));
      project.independentTableHeaders[table.id] = savedHeaders;
      saveProjects();
    }
  }
  if (table.id === "ashrae-90-1-baseline-systems" && Array.isArray(savedHeaders) && savedHeaders.length === 7) {
    project.independentTableHeaders[table.id] = savedHeaders.filter((_, index) => index !== 2);
    saveProjects();
  } else if (!Array.isArray(savedHeaders) || savedHeaders.length !== table.headers.length) {
    project.independentTableHeaders[table.id] = table.headers.map((header) => ({ ...header }));
    saveProjects();
  }
  return project.independentTableHeaders[table.id];
}

function projectTableHeaders(table) {
  return table.headers;
}

function displayedTableHeaders(table) {
  return projectTableHeaders(table);
}

function isPercentageColumn(table, columnIndex) {
  return table.headers[columnIndex]?.unit === "%";
}

function formatTableValue(value, table, columnIndex) {
  if(table?.equipmentAirflowsCalculation && value===0 && columnIndex>0)return "-";
  if (table?.tabularCalculation && columnIndex === tabularColumn.differences && value === 0) return "";
  if (table?.tabularCalculation && table.headers[columnIndex]?.unit === "°F" && value !== "" && value !== null && value !== undefined && Number.isFinite(Number(value))) return Number(value).toFixed(1);
  if (table?.tabularCalculation && table.threeDecimalColumns?.includes(columnIndex) && value !== "" && value != null && Number.isFinite(Number(value))) return Number(value).toFixed(3);
  if (typeof value === "boolean") return value ? "TRUE" : "";
  if(value==="FALSE" && table?.dropdownColumns?.[columnIndex]?.options?.includes("TRUE"))return "";
  if (value === 0 && table?.displayZeroAsDash && (table.calculatedColumns || []).includes(columnIndex)
    && columnIndex >= (table.zeroDashStartColumn ?? 3)) return "-";
  if (typeof value === "number" && Number.isFinite(value) && table && Number.isInteger(columnIndex)) {
    if ((table.zeroDecimalColumns || []).includes(columnIndex)) {
      return isPercentageColumn(table, columnIndex)
        ? `${zeroDecimalFormatter.format(value * 100)}%`
        : zeroDecimalFormatter.format(value);
    }
    if ((table.oneDecimalColumns || []).includes(columnIndex)) return oneDecimalFormatter.format(value);
    if ((table.threeDecimalColumns || []).includes(columnIndex)) return threeDecimalFormatter.format(value);
    if ((table.fourDecimalColumns || []).includes(columnIndex)) return fourDecimalFormatter.format(value);
    if ((table.fiveDecimalColumns || []).includes(columnIndex)) return fiveDecimalFormatter.format(value);
    if ((table.decimalColumns || []).includes(columnIndex)) return twoDecimalFormatter.format(value);
    if (isPercentageColumn(table, columnIndex)) return `${tableNumberFormatter.format(value * 100)}%`;
    if ([...(table.calculatedColumns || []), ...(table.lockedColumns || [])].includes(columnIndex)
      && String(table.headers[columnIndex]?.unit || "").startsWith("Btu/h")) {
      return calculatedBtuNumberFormatter.format(value);
    }
  }
  return typeof value === "number" && Number.isFinite(value) ? tableNumberFormatter.format(value) : value ?? "";
}

function normalizedTableInput(table, columnIndex, rawValue) {
  const value = String(rawValue ?? "").trim();
  const percentage = isPercentageColumn(table, columnIndex);
  const normalizedNumber = value.replace(/,/g, "").replace(/\s*%$/, "");
  return table.columnTypes[columnIndex] === "number" && normalizedNumber !== "" && Number.isFinite(Number(normalizedNumber))
    ? Number(normalizedNumber) / (percentage ? 100 : 1)
    : value;
}

function updateTableCell(table, rows, rowIndex, columnIndex, rawValue) {
  const dropdownSnapshots=snapshotDropdownReferences(table.id,[columnIndex]);
  const value = String(rawValue ?? "").trim();
  recordZoningOverride(table, rows[rowIndex], columnIndex, value, activeProject());
  recordNetworkZoningOverride(table, rows[rowIndex], columnIndex, value, activeProject());
  recordAirsideOverride(table, rows[rowIndex], columnIndex, value, activeProject());
  recordCoilOverride(table, rows[rowIndex], columnIndex, value, activeProject());
  recordPlantOverride(table, rows[rowIndex], columnIndex, value, activeProject());
  recordSpaceLoadFactorOverride(table, rows[rowIndex], columnIndex, value, activeProject());
  recordPressurizationOverride(table, rows[rowIndex], columnIndex, value, activeProject());
  recordScheduleOverride(table, rows[rowIndex], columnIndex, value, activeProject());
  rows[rowIndex][columnIndex] = normalizedTableInput(table, columnIndex, value);
  recalculateSpecialTableRow(table, rows[rowIndex]);
  recalculateTable(table, rows);
  reconcileRemovedDropdownValues(dropdownSnapshots,activeProject());
  recalculateDependentTables(table);
  saveProjects();
  if (table.equipmentAirflowsCalculation || supportsSharedSpaceFilter(table) || table.scheduleCalculation || table.thermalTemplateCalculation || table.conditionalCalculatedColumns || table.equipmentZoningCalculation || table.zoningNetworkTableCalculation || table.roomLoadCalculation || table.airsideSettingsCalculation || table.coilCalculation || table.plantCalculation || table.ventilationRequirementsCalculation || table.generalExhaustCalculation || table.equipmentExhaustCalculation || table.exhaustRequirementsCalculation || table.pressurizationCalculation || table.airBalancingCalculation || table.peakAirflowCalculation || table.combinedAirflowCalculation) renderReferenceTable(table.id, tableSearch.value, { skipRecalculation: true });
  else {
    refreshRenderedTableValues(table, rows);
    refreshTableSummary(table, rows);
  }
  updateCsvComparisonDecorations(table, rows);
  if (selectedCsvComparisonContext?.tableId === table.id) {
    const { rowIndex: selectedRow, columnIndex: selectedColumn } = selectedCsvComparisonContext;
    showCsvComparison(table, rows, selectedRow, selectedColumn);
  }
}

function refreshTableSummary(table, rows) {
  const summaryRow = referenceTable.querySelector("tfoot .table-summary-row");
  if (!summaryRow) return;
  const visibleRows = [...referenceTable.querySelectorAll("tbody tr[data-source-index]")]
    .map((row) => rows[Number(row.dataset.sourceIndex)]).filter(Boolean);
  (table.summaryColumns || []).forEach((columnIndex) => {
    const aggregation = table.summaryAggregations?.[columnIndex] || "sum";
    const total = summaryValue(visibleRows, columnIndex, aggregation);
    const cell = summaryRow.cells[columnIndex];
    if (cell) cell.textContent = columnIndex === 0 && aggregation === "unique-count" ? `Total: ${total}` : formatTableValue(total, table, columnIndex);
  });
  refreshTableMetric(table, visibleRows);
}

function tabularMismatchTotal(table, visibleRows, column) {
  if (column === tabularColumn.differences) return visibleRows.reduce((sum, { row }) => sum + (Number(row[column]) || 0), 0);
  return visibleRows.reduce((sum, { row, sourceIndex }) => {
    const comparison = csvComparisonForCell(table, row, sourceIndex, column);
    return sum + (comparison?.mapped && !comparison.matches ? 1 : 0);
  }, 0);
}

function createTabularSummary(table, visibleRows) {
  const foot = document.createElement("tfoot"), row = document.createElement("tr");
  row.className = "table-summary-row tabular-mismatch-summary";
  table.headers.forEach((header, column) => {
    if (column === tabularColumn.space) return;
    const cell = document.createElement("td"); cell.dataset.columnIndex = String(column);
    if (column === tabularColumn.id) {
      cell.colSpan = 2; cell.textContent = "Total Differing Values"; cell.classList.add("summary-label");
    } else {
      const total = tabularMismatchTotal(table, visibleRows, column);
      cell.textContent = total === 0 ? "" : String(total);
      cell.classList.add("numeric-cell", "summary-equation-cell");
      if (total) cell.classList.add("csv-different");
      else cell.classList.add("empty-difference-count");
      cell.tabIndex = 0; cell.title = "Differing values in visible spaces; select to view the equation";
      const show = () => {
        selectStandaloneControl(cell); clearCsvComparison();
        const label = header.label;
        const equation = column === tabularColumn.differences ? '=SUBTOTAL(109,[# of Differing Values])'
          : `=SUMPRODUCT([Visible Rows], [Compared Values], ${csvDifferenceExpression(table, column, `[${label}]`, `[Current IESVE Values]@[${label}]`)})`;
        selectedEquation.value = equation; displayFormulaFunctions(equation); editEquationButton.hidden = true; formulaBar.hidden = false;
      };
      cell.addEventListener("click", show); cell.addEventListener("focus", show);
    }
    if (table.sectionStartColumns?.includes(column)) cell.classList.add("section-divider");
    attachCellNote(cell, { ...table, tabularCalculation: false, noteSummary: true }, [], 0, column);
    row.appendChild(cell);
  });
  foot.appendChild(row); return foot;
}

function summaryValue(rows, columnIndex, aggregation) {
  if (aggregation === "unique-list-count") return new Set(rows.flatMap((row) => String(row[columnIndex] ?? "").split(",")).map((v) => v.trim().toLowerCase()).filter((v) => v && v !== "-")).size;
  if (aggregation === "count") return rows.filter((row) => row[columnIndex] !== "" && row[columnIndex] !== null && row[columnIndex] !== undefined).length;
  if (aggregation === "unique-count") return new Set(rows.map((row) => String(row[columnIndex] ?? "").trim().toLowerCase()).filter((value) => value && value !== "-")).size;
  return rows.reduce((sum, row) => sum + (Number(row[columnIndex]) || 0), 0);
}

function showSummaryEquation(table, cell, column, aggregation) {
  selectStandaloneControl(cell);
  selectedEquationContext={table,column,summary:true};
  const label = table.headers[column]?.label || "Column";
  const equation = aggregation === "unique-list-count"
    ? `=LET(valves,TRIM(TOCOL(TEXTSPLIT(TEXTJOIN(",",TRUE,FILTER([${label}],[Visible Rows])),","))),IFERROR(ROWS(UNIQUE(FILTER(valves,(valves<>"")*(valves<>"-")))),0))`
    : aggregation === "unique-count"
    ? `=IFERROR(ROWS(UNIQUE(FILTER([${label}],([${label}]<>"")*([${label}]<>"-")*(SUBTOTAL(103,OFFSET(INDEX([${label}],1),ROW([${label}])-ROW(INDEX([${label}],1)),0))>0)))),0)`
    : aggregation === "count" ? `=SUBTOTAL(103,[${label}])` : `=SUBTOTAL(109,[${label}])`;
  selectedEquation.value = equation;
  displayFormulaFunctions(equation);
  editEquationButton.hidden = true;
  formulaBar.hidden = false;
}

function refreshRenderedTableValues(table, rows) {
  referenceTable.querySelectorAll("tbody tr").forEach((tableRow) => {
    const row = rows[Number(tableRow.dataset.sourceIndex)];
    if (!row) return;
    table.headers.forEach((_, columnIndex) => {
      if (!(table.calculatedColumns || []).includes(columnIndex) && !isPercentageColumn(table, columnIndex)) return;
      const cell = tableRow.cells[columnIndex];
      if (!cell) return;
      cell.textContent = formatTableValue(row[columnIndex], table, columnIndex);
      attachCellNote(cell, table, row, Number(tableRow.dataset.sourceIndex), columnIndex);
      cell.classList.toggle("numeric-cell", typeof row[columnIndex] === "number" || table.columnTypes[columnIndex] === "number");
    });
  });
  paintTableTones();
  autoFitRenderedTable(table, displayedTableHeaders(table), rows);
}

function csvImportKey(table) {
  return `${activeProject()?.id || "default"}::${table.id}`;
}

function csvImportState(table) {
  if (!table?.csvHeaders) return null;
  const key = csvImportKey(table);
  if (csvImportsByProject.has(key)) return csvImportsByProject.get(key);
  const saved = activeProject()?.clipboardImports?.[table.id];
  if (!saved || !Array.isArray(saved.sourceRows) || !Array.isArray(saved.mappedColumns) || !saved.importedAt || !saved.templateType) return null;
  const state = {
    importedAt: saved.importedAt,
    mappedColumns: saved.mappedColumns,
    sourceRows: saved.sourceRows,
    templateType: saved.templateType,
    rawHeaders: saved.rawHeaders, rawRows: saved.rawRows, metadataBySpace: saved.metadataBySpace,
  };
  csvImportsByProject.set(key, state);
  return state;
}

function excelImportState(table) {
  if (!table?.excelImport) return null;
  const key = csvImportKey(table);
  if (excelImportsByProject.has(key)) return excelImportsByProject.get(key);
  const saved = activeProject()?.excelImports?.[table.id];
  if (!saved?.importedAt || !saved?.fileName) return null;
  const state = {
    importedAt: saved.importedAt,
    fileName: saved.fileName,
    simulationRunAt: saved.simulationRunAt || "",
    simulationRunPrecision: saved.simulationRunPrecision || "time",
  };
  excelImportsByProject.set(key, state);
  return state;
}

function setCsvFileStatus(message, isError = false) {
  csvFileStatus.textContent = message;
  csvFileStatus.title = message;
  csvFileStatus.classList.toggle("is-error", isError);
}

function updateCsvToolbar(table) {
  const supportsCsv = Array.isArray(table.csvHeaders);
  calculatedKey.classList.toggle("not-specified-key", Boolean(table.tabularCalculation));
  const supportsExcel = Boolean(table.excelImport);
  templateStatus.classList.toggle("simulation-status", supportsExcel);
  clipboardActions.hidden = !supportsCsv;
  excelActions.hidden = !supportsExcel;
  rowActions.hidden = supportsCsv || supportsExcel || table.fixedRows;
  csvFileStatus.hidden = !supportsCsv && !supportsExcel;
  templateStatus.hidden = !supportsCsv && !supportsExcel;
  editableKey.hidden = supportsCsv || supportsExcel;
  autoKey.hidden = !table.conditionScheduleCalculation && !table.scheduleCalculation && !table.thermalTemplateCalculation && !table.equipmentZoningCalculation && !table.zoningNetworkTableCalculation && !table.roomLoadCalculation && !table.airsideSettingsCalculation && !table.coilCalculation && !table.plantCalculation && !table.generalExhaustCalculation && !table.equipmentExhaustCalculation && !table.ventilationRequirementsCalculation && !table.exhaustMinimumDefault && !table.supplyMinimumDefault && !table.pressurizationCalculation;
  matchKey.hidden = !supportsCsv;
  differentKey.hidden = !supportsCsv;
  editableKey.lastChild.textContent = "User-input";
  calculatedKey.lastChild.textContent = table.equipmentZoningCalculation || table.zoningNetworkTableCalculation ? "Locked" : supportsCsv ? "Not specified in calc" : supportsExcel ? "Imported" : "Calculated";
  if (!supportsCsv && !supportsExcel) {
    copyDataButton.disabled = true;
    setCsvFileStatus("");
    templateStatus.textContent = "";
    return;
  }
  if (supportsExcel) {
    copyDataButton.disabled = true;
    const state = excelImportState(table);
    const importedAt = state ? new Date(state.importedAt) : null;
    const dateText = importedAt && Number.isFinite(importedAt.getTime())
      ? new Intl.DateTimeFormat(undefined, { dateStyle: "medium", timeStyle: "short" }).format(importedAt)
      : "";
    setCsvFileStatus(state ? `Last upload: ${dateText}` : "No Excel imported");
    const simulationRunAt = state?.simulationRunAt ? new Date(state.simulationRunAt) : null;
    const simulationText = simulationRunAt && Number.isFinite(simulationRunAt.getTime())
      ? new Intl.DateTimeFormat(undefined, state.simulationRunPrecision === "date"
        ? { dateStyle: "medium" }
        : { dateStyle: "medium", timeStyle: "short" }).format(simulationRunAt)
      : "";
    templateStatus.textContent = state ? `Simulation run: ${simulationText || "Not available"}` : "";
    templateStatus.title = state?.fileName || "";
    templateStatus.hidden = !state;
    return;
  }
  const state = csvImportState(table);
  copyDataButton.disabled = !state || !projectTableRows(table).length || table.tabularCalculation && !tabularExportSelection(table,projectTableRows(table).map((row,sourceIndex)=>({row,sourceIndex})).filter(({row})=>sharedSpaceSearchMatches(table,row,activeProject())&&rowMatchesSpaceSet(table,row,spaceFilterContext?.matchingSpaces))).entries.length;
  const importedAt = state ? new Date(state.importedAt) : null;
  const dateText = importedAt && Number.isFinite(importedAt.getTime())
    ? new Intl.DateTimeFormat(undefined, { dateStyle: "medium", timeStyle: "short" }).format(importedAt)
    : "";
  setCsvFileStatus(state ? `Last upload: ${dateText}` : "No data pasted");
  templateStatus.textContent = state ? `${state.templateType} Template` : "";
  templateStatus.hidden = !state;
}

function clearCsvComparison() {
  selectedCsvComparisonContext = null;
  csvComparisonBar.hidden = true;
  csvComparisonBar.classList.remove("is-different", "is-unmapped");
  csvComparisonColumn.textContent = "";
  csvComparisonValue.textContent = "";
  csvComparisonStatus.textContent = "";
}

function tableValueForCsv(table, value, columnIndex) {
  if (isPercentageColumn(table, columnIndex) && typeof value === "number") return value * 100;
  return value ?? "";
}

function csvComparisonDecimals(table, column) {
  if (table.tabularCalculation && table.headers[column]?.unit === "°F") return 1;
  for (const [property, digits] of [["zeroDecimalColumns",0],["oneDecimalColumns",1],["threeDecimalColumns",3],["fourDecimalColumns",4],["fiveDecimalColumns",5],["decimalColumns",2]]) {
    if (table[property]?.includes(column)) return digits;
  }
  return tableNumberFormatter.resolvedOptions().maximumFractionDigits;
}

function csvDifferenceExpression(table, column, actual, source) {
  const digits = csvComparisonDecimals(table, column);
  return `IFERROR(--(ROUND(NUMBERVALUE(${actual}),${digits})<>ROUND(NUMBERVALUE(${source}),${digits})),--(LOWER(TRIM(${actual}))<>LOWER(TRIM(${source}))))`;
}

function csvValuesMatch(table, tableValue, csvValue, columnIndex) {
  const current = tableValueForCsv(table, tableValue, columnIndex);
  const left = String(current ?? "").trim();
  const right = String(csvValue ?? "").trim();
  const leftNumber = Number(left.replace(/,/g, ""));
  const rightNumber = Number(right.replace(/,/g, ""));
  if (left !== "" && right !== "" && Number.isFinite(leftNumber) && Number.isFinite(rightNumber)) {
    const digits = csvComparisonDecimals(table, columnIndex);
    return Number(leftNumber.toFixed(digits)) === Number(rightNumber.toFixed(digits));
  }
  return left.localeCompare(right, undefined, { sensitivity: "base" }) === 0;
}

function csvComparisonForCell(table, row, sourceIndex, columnIndex) {
  if (table.tabularCalculation && columnIndex === tabularColumn.differences) return {
    specified: true, mapped: true, matches: Number(row[columnIndex]) === 0, linked: true, synthetic: true, csvValue: "",
  };
  const state = csvImportState(table);
  if (state && !state.rowsById) state.rowsById = new Map(state.sourceRows.map((source) => [requirementKey(source[table.idColumn ?? 0]), source]));
  const csvRow = state?.rowsById?.get(requirementKey(row[table.idColumn ?? 0]));
  const csvValue = csvRow?.[columnIndex] ?? "";
  if (table.tabularCalculation && !table.specifiedCellStates?.get(sourceIndex)?.has(columnIndex)) {
    return { specified: false, mapped: false, matches: false, linked: Boolean(csvRow), csvValue };
  }
  if (!state) return null;
  if (!state.mappedColumns[columnIndex]) return { specified: true, mapped: false, matches: false, csvValue: "" };
  return { specified: true, mapped: true, linked: Boolean(csvRow), matches: Boolean(csvRow) && csvValuesMatch(table, row[columnIndex], csvValue, columnIndex), csvValue };
}

function decorateCsvComparisonCell(table, cell, row, sourceIndex, columnIndex) {
  cell.classList.remove("csv-match", "csv-different", "not-specified-cell");
  if (!table.csvHeaders || table.tabularCalculation && table.identityColumns.includes(columnIndex)) return;
  const comparison = csvComparisonForCell(table, row, sourceIndex, columnIndex);
  if (comparison?.specified === false) {
    cell.classList.add("not-specified-cell"); cell.title = "Not specified in calc; uploaded source value retained"; return;
  }
  if (!comparison?.mapped) return;
  cell.classList.toggle("empty-difference-count", Boolean(comparison.synthetic && comparison.matches));
  if (!(comparison.synthetic && comparison.matches)) cell.classList.add(comparison.matches ? "csv-match" : "csv-different");
}

function markSelectedTableCell(cell) {
  referenceTable.querySelectorAll(".table-cell-selected").forEach((candidate) => {
    candidate.classList.remove("table-cell-selected");
    candidate.removeAttribute("aria-current");
  });
  cell.classList.add("table-cell-selected");
  cell.setAttribute("aria-current", "true");
}

function decorateRoomValidationCell(table, cell, value, columnIndex) {
  if (table.id !== "room-zone-loads-report" || columnIndex !== 2) return;
  const tabularTable = independentTables.find((candidate) => candidate.id === "iesve-tabular-space-data");
  const tabularRows = tabularTable ? projectTableRows(tabularTable) : [];
  const room = String(value ?? "").trim();
  const exists = tabularRows.some((row) => String(row[tabularColumn.space] ?? "").trim().localeCompare(room, undefined, { sensitivity: "base" }) === 0);
  if (exists) return;
  cell.classList.add("room-not-in-tabular");
  cell.title = "Room not in Tabular Space Data";
  cell.setAttribute("aria-label", `${cell.getAttribute("aria-label")}. Room not in Tabular Space Data`);
}

function updateCsvComparisonDecorations(table, rows) {
  if (!table.csvHeaders) return;
  referenceTable.querySelectorAll("tbody tr").forEach((tableRow) => {
    const sourceIndex = Number(tableRow.dataset.sourceIndex);
    const row = rows[sourceIndex];
    if (!row) return;
    [...tableRow.cells].forEach((cell, columnIndex) => {
      decorateCsvComparisonCell(table, cell, row, sourceIndex, columnIndex);
    });
  });
}

function showCsvComparison(table, rows, sourceIndex, columnIndex) {
  const state = csvImportState(table);
  if (!state) {
    clearCsvComparison();
    return;
  }
  const row = rows[sourceIndex];
  if (!row) return;
  selectedCsvComparisonContext = { tableId: table.id, rowIndex: sourceIndex, columnIndex };
  const header = table.headers[columnIndex];
  csvComparisonColumn.textContent = `${header.label}${header.unit ? ` (${header.unit})` : ""}`;
  const comparison = csvComparisonForCell(table, row, sourceIndex, columnIndex);
  csvComparisonBar.hidden = false;
  csvComparisonBar.classList.toggle("is-unmapped", !comparison?.mapped);
  csvComparisonBar.classList.toggle("is-different", Boolean(comparison?.mapped && !comparison.matches));
  if (comparison?.synthetic) {
    csvComparisonValue.textContent = "Count of calculated values that differ from the current IESVE values";
    csvComparisonStatus.textContent = `${row[columnIndex]} differing values`;
  } else if (comparison?.specified === false) {
    csvComparisonValue.textContent = String(comparison.csvValue || row[columnIndex] || "(blank)");
    csvComparisonStatus.textContent = "Not specified in calc";
  } else if (!comparison?.mapped) {
    csvComparisonValue.textContent = "No matching column in uploaded data";
    csvComparisonStatus.textContent = "Not compared";
  } else {
    csvComparisonValue.textContent = comparison.linked
      ? (String(comparison.csvValue) || "(blank)")
      : "No source row";
    csvComparisonStatus.textContent = comparison.matches ? "Matches source" : "Differs from source";
  }
}

function csvHeaderForTemplate(header, templateType) {
  if (!header || header === "Space ID") return header;
  return header.replace(/ \(Real\)$/, ` (${templateType})`);
}

function detectTemplateType(headers) {
  if (CsvTools.normalizeHeader(headers[0]) !== "space id") {
    throw new Error("The first pasted column must be Space ID.");
  }
  const spaceName = String(headers[1] ?? "").trim();
  const match = spaceName.match(/^Space Name \((Real|Proposed|Baseline)\)$/i);
  if (!match) throw new Error("The second pasted column must be Space Name (Real), Space Name (Proposed), or Space Name (Baseline).");
  const templateType = match[1][0].toUpperCase() + match[1].slice(1).toLowerCase();
  const suffix = ` (${templateType})`.toLowerCase();
  const invalidHeader = headers.slice(1).find((header) => {
    const value = String(header ?? "").trim();
    return /\((Real|Proposed|Baseline)\)$/i.test(value) && !value.toLowerCase().endsWith(suffix);
  });
  if (invalidHeader !== undefined) {
    throw new Error(`Source template columns must use (${templateType}). Check: ${invalidHeader}`);
  }
  return templateType;
}

function csvColumnMap(table, headers, templateType) {
  const headerIndexes = new Map();
  headers.forEach((header, index) => {
    const normalized = CsvTools.normalizeHeader(header);
    if (normalized && !headerIndexes.has(normalized)) headerIndexes.set(normalized, index);
  });
  return table.csvHeaders.map((header) => header === null
    ? -1
    : (headerIndexes.get(CsvTools.normalizeHeader(csvHeaderForTemplate(header, templateType))) ?? -1));
}

function saveClipboardImport(table, state) {
  const project = activeProject();
  if (!project) return;
  project.clipboardImports ||= {};
  project.clipboardImports[table.id] = {
    importedAt: state.importedAt,
    mappedColumns: state.mappedColumns,
    sourceRows: state.sourceRows,
    templateType: state.templateType,
    rawHeaders: state.rawHeaders, rawRows: state.rawRows, metadataBySpace: state.metadataBySpace,
  };
  saveProjects();
}

function calculationSpaceTables() {
  return independentTables.filter((table) => table.id.startsWith("calc-") && Number.isInteger(table.spaceColumn) && !table.systemAirBalanceMode);
}

function blankCalculationRow(table, space) {
  const source = table.rows.find((row) => String(row[table.spaceColumn] ?? "") === space);
  const row = source ? [...source] : Array(table.columns.length).fill("");
  row[table.spaceColumn] = space;
  return row;
}

function moveSpaceMetadata(table, oldSpace, newSpace) {
  ["activityBySpace", "volumeBySpace"].forEach((property) => {
    if (!table[property] || !Object.hasOwn(table[property], oldSpace)) return;
    table[property][newSpace] = table[property][oldSpace];
    delete table[property][oldSpace];
  });
}

function setInitialCalculationSpaces(spaces) {
  const project = activeProject();
  calculationSpaceTables().forEach((table) => {
    const rows = ensureProjectTableRows(project, table);
    const existing = new Map(rows.map((row) => [String(row[table.spaceColumn] ?? ""), row]));
    project.independentTables[table.id] = spaces.map((space) => existing.has(space) ? [...existing.get(space)] : blankCalculationRow(table, space));
  });

}

function remapProjectSpaceKeys(project, oldSpace, newSpace = "") {
  const remap = (record) => {
    if (!record) return;
    Object.keys(record).forEach((key) => {
      if (!key.startsWith(`${oldSpace}::`)) return;
      if (newSpace) record[`${newSpace}${key.slice(oldSpace.length)}`] = record[key];
      delete record[key];
    });
  };
  Object.values(project.zoningOverrides || {}).forEach(remap);
  Object.values(project.zoningAutoValues || {}).forEach(remap);
  remap(project.spaceLoadFactorOverrides);
  remap(project.spaceLoadFactorAutos);
  remap(project.conditionScheduleAutos); remap(project.conditionScheduleOverrides);
  [project.consumptionScheduleAutos, project.consumptionScheduleOverrides].forEach((record) => {
    const key = `calc-dhw::${requirementKey(oldSpace)}`;
    if (!record || !Object.hasOwn(record, key)) return;
    if (newSpace) record[`calc-dhw::${requirementKey(newSpace)}`] = record[key];
    delete record[key];
  });
  remap(project.networkZoningOverrides); remap(project.networkZoningAutoValues);
  [project.pressurizationOverrides, project.legacyManualBalances, project.ventilationTypeOverrides, project.ventilationTypeAutos].forEach((record) => {
    const key = requirementKey(oldSpace);
    if (!record || !Object.hasOwn(record, key)) return;
    if (newSpace) record[requirementKey(newSpace)] = record[key];
    delete record[key];
  });
  if (project.cellNotes) Object.keys(project.cellNotes).forEach((key) => {
    const token = `::space:${requirementKey(oldSpace)}::`;
    if (!key.includes(token)) return;
    if (newSpace) project.cellNotes[key.replace(token, `::space:${requirementKey(newSpace)}::`)] = project.cellNotes[key];
    delete project.cellNotes[key];
  });
  if (project.excludedSpaces) project.excludedSpaces = project.excludedSpaces.flatMap((space) => space === requirementKey(oldSpace) ? newSpace ? [requirementKey(newSpace)] : [] : [space]);
  const assignments = project.equipmentZoningTool?.assignments;
  if (assignments) Object.keys(assignments).forEach((key) => {
    if (requirementKey(key) !== requirementKey(oldSpace)) return;
    if (newSpace) assignments[newSpace] = assignments[key];
    delete assignments[key];
  });
  if (project.equipmentZoningTool?.selectedSpace === oldSpace) project.equipmentZoningTool.selectedSpace = newSpace;
  const filter = project.sharedSpaceFilter;
  if (filter?.field === "meta:space" && filter.values) filter.values = filter.values.flatMap((value) =>
    requirementKey(value) === requirementKey(oldSpace) ? newSpace ? [newSpace] : [] : [value]);
}

function applyCalculationSpaceChanges(newSpaces, oldSpaces) {
  const project = activeProject();
  calculationSpaceTables().forEach((table) => {
    let rows = ensureProjectTableRows(project, table);
    const pairCount = Math.min(newSpaces.length, oldSpaces.length);
    for (let index = 0; index < pairCount; index += 1) {
      const oldSpace = oldSpaces[index];
      const newSpace = newSpaces[index];
      const row = rows.find((candidate) => String(candidate[table.spaceColumn] ?? "") === oldSpace);
      if (row) row[table.spaceColumn] = newSpace;
      else rows.push(blankCalculationRow(table, newSpace));
      moveSpaceMetadata(table, oldSpace, newSpace);
    }
    newSpaces.slice(pairCount).forEach((space) => rows.push(blankCalculationRow(table, space)));
    const removed = new Set(oldSpaces.slice(pairCount));
    if (removed.size) rows = rows.filter((row) => !removed.has(String(row[table.spaceColumn] ?? "")));
    project.independentTables[table.id] = rows;
  });
  const pairCount = Math.min(newSpaces.length, oldSpaces.length);
  for (let index = 0; index < pairCount; index += 1) remapProjectSpaceKeys(project, oldSpaces[index], newSpaces[index]);
  oldSpaces.slice(pairCount).forEach((space) => remapProjectSpaceKeys(project, space));
  selectedSpaceReferenceTables().forEach(({ table, columns }) => {
    const rows = ensureProjectTableRows(project, table);
    rows.forEach((row) => columns.forEach((column) => {
      const index = oldSpaces.findIndex((space) => requirementKey(space) === requirementKey(row[column]));
      if (index >= 0 && index < pairCount) row[column] = newSpaces[index];
    }));
  });

}

function commitTabularImport(table, importedRows, state) {
  const rows = projectTableRows(table);
  rows.splice(0, rows.length, ...importedRows);
  csvImportsByProject.set(csvImportKey(table), state);
  saveClipboardImport(table, state);
  synchronizeProjectSpaceReferences(activeProject());
  selectedTableId = "";
  selectedTableRowIndexes.clear();
  selectionAnchorIndex = -1;
  tableSearch.value = "";
  tableSort = { tableId: table.id, column: -1, direction: "asc" };
  renderReferenceTable(table.id);
}

function renderSpaceReconciliation() {
  if (!pendingSpaceReconciliation) return;
  const { newSpaces, oldSpaces } = pendingSpaceReconciliation;
  const renderList = (container, values, side) => {
    container.innerHTML = "";
    values.forEach((value, index) => {
      const row = document.createElement("div"); row.className = "space-change-row";
      const label = document.createElement("span"); label.textContent = value; label.title = value;
      const controls = document.createElement("span"); controls.className = "space-change-controls";
      [["↑", -1], ["↓", 1]].forEach(([symbol, direction]) => {
        const button = document.createElement("button"); button.type = "button"; button.textContent = symbol;
        button.title = `${direction < 0 ? "Move up" : "Move down"} ${value}`;
        button.disabled = direction < 0 ? index === 0 : index === values.length - 1;
        button.addEventListener("click", () => {
          const nextIndex = index + direction;
          [values[index], values[nextIndex]] = [values[nextIndex], values[index]];
          renderSpaceReconciliation();
        });
        controls.appendChild(button);
      });
      row.append(label, controls); container.appendChild(row);
    });
  };
  renderList(newSpaceList, newSpaces, "new");
  renderList(oldSpaceList, oldSpaces, "old");
  spaceActionList.innerHTML = "";
  const count = Math.max(newSpaces.length, oldSpaces.length);
  for (let index = 0; index < count; index += 1) {
    const action = newSpaces[index] && oldSpaces[index] ? "REPLACE" : newSpaces[index] ? "ADD" : "REMOVE";
    const row = document.createElement("div"); row.className = `space-action-row ${action.toLowerCase()}`;
    row.textContent = action === "REPLACE" ? "← REPLACE" : action === "ADD" ? "+ ADD" : "− REMOVE";
    spaceActionList.appendChild(row);
  }
}

function openSpaceReconciliation(payload) {
  pendingSpaceReconciliation = payload;
  spaceReconcileError.textContent = "";
  renderSpaceReconciliation();
  spaceReconcileDialog.showModal();
}

function pasteTabularData(text) {
  const table = independentTables.find((candidate) => candidate.id === activeTableId);
  if (!table?.csvHeaders) return;
  const grid = CsvTools.parseClipboard(text);
  const headerRowIndex = grid.findIndex((row) => CsvTools.normalizeHeader(row[0]) === "space id");
  if (headerRowIndex < 0) throw new Error("The pasted header row must begin with Space ID and Space Name.");
  const headers = grid[headerRowIndex];
  const templateType = detectTemplateType(headers);
  const columnMap = csvColumnMap(table, headers, templateType);
  if (columnMap[tabularColumn.id] < 0 || columnMap[tabularColumn.space] < 0) throw new Error("Space ID or Space Name is missing from the pasted data.");

  const pastedRows = grid.slice(headerRowIndex + 1)
    .filter((row) => row.some((value) => String(value ?? "").trim() !== ""))
    .map((row) => Array.from({ length: headers.length }, (_, index) => row[index] ?? ""))
    .filter((row) => row[columnMap[tabularColumn.id]].trim() !== "" || row[columnMap[tabularColumn.space]].trim() !== "");
  if (!pastedRows.length) throw new Error("The pasted data does not contain any space rows.");

  const previousImport = csvImportState(table);
  const rows = projectTableRows(table);
  const existingBySpaceId = new Map(rows.map((row) => [String(row[tabularColumn.id] ?? "").trim().toLowerCase(), row]));
  const sourceRows = pastedRows.map((pastedRow) => table.csvHeaders.map((header, columnIndex) => {
    const pastedColumnIndex = columnMap[columnIndex];
    return header && pastedColumnIndex >= 0 ? pastedRow[pastedColumnIndex] : null;
  }));
  const importedRows = sourceRows.map((sourceRow) => {
    const spaceId = String(sourceRow[tabularColumn.id] ?? "").trim();
    const existing = existingBySpaceId.get(spaceId.toLowerCase());
    const row = existing ? [...existing] : Array(table.columns.length).fill("");
    row[tabularColumn.id] = spaceId;
    row[tabularColumn.space] = String(sourceRow[tabularColumn.space] ?? "").trim();
    return row;
  });
  const state = {
    importedAt: new Date().toISOString(),
    mappedColumns: columnMap.map((columnIndex) => columnIndex >= 0),
    sourceRows,
    templateType,
    rawHeaders: [...headers], rawRows: pastedRows.map((row) => [...row]),
    metadataBySpace: extractTabularMetadata(headers, pastedRows),
  };
  const nextSpaces = [...new Set(importedRows.map((row) => String(row[tabularColumn.space] ?? "").trim()).filter(Boolean))];
  if (!previousImport && !rows.length) {
    setInitialCalculationSpaces(nextSpaces);
    commitTabularImport(table, importedRows, state);
    return;
  }
  const currentSpaces = [...new Set(calculationSpaceTables()[0]
    ? ensureProjectTableRows(activeProject(), calculationSpaceTables()[0]).map((row) => String(row[calculationSpaceTables()[0].spaceColumn] ?? "").trim()).filter(Boolean)
    : [])];
  const currentSet = new Set(currentSpaces);
  const nextSet = new Set(nextSpaces);
  const newSpaces = nextSpaces.filter((space) => !currentSet.has(space));
  const oldSpaces = currentSpaces.filter((space) => !nextSet.has(space));
  if (newSpaces.length || oldSpaces.length) {
    openSpaceReconciliation({ table, importedRows, state, newSpaces, oldSpaces });
    return;
  }
  commitTabularImport(table, importedRows, state);
}

async function pasteDataFromClipboard() {
  pasteDataButton.disabled = true;
  try {
    if (!navigator.clipboard?.readText || !window.isSecureContext) {
      throw new Error("Direct clipboard access is unavailable. Press Ctrl+V while this table is open.");
    }
    const text = await navigator.clipboard.readText();
    if (!text.trim()) throw new Error("The clipboard does not contain text data.");
    pasteTabularData(text);
  } catch (error) {
    showPasteFormatError();
  } finally {
    pasteDataButton.disabled = false;
  }
}

async function writeClipboardText(text) {
  if (navigator.clipboard?.writeText && window.isSecureContext) {
    await navigator.clipboard.writeText(text);
    return;
  }
  const helper = document.createElement("textarea");
  helper.value = text;
  helper.setAttribute("readonly", "");
  helper.style.position = "fixed";
  helper.style.opacity = "0";
  document.body.appendChild(helper);
  helper.select();
  const copied = document.execCommand("copy");
  helper.remove();
  if (!copied) throw new Error("Clipboard access was blocked by the browser.");
}

async function copyTabularData() {
  const table = independentTables.find((candidate) => candidate.id === activeTableId);
  const state = csvImportState(table);
  if (!table?.csvHeaders || !state) return;
  const rows = projectTableRows(table);
  recalculateTable(table, rows);
  const entries=rows.map((row,sourceIndex)=>({row,sourceIndex})).filter(({row})=>!supportsSharedSpaceFilter(table)||sharedSpaceSearchMatches(table,row,activeProject())).filter(({row})=>rowMatchesSpaceSet(table,row,spaceFilterContext?.matchingSpaces));
  const selection=table.tabularCalculation?tabularExportSelection(table,entries):{columns:table.headers.map((_,c)=>c),entries};
  if(!selection.entries.length)return;
  const sourceMap=state.rawHeaders?csvColumnMap(table,state.rawHeaders,state.templateType):null;
  if(sourceMap)selection.columns.sort((a,b)=>(sourceMap[a]<0?Infinity:sourceMap[a])-(sourceMap[b]<0?Infinity:sourceMap[b]));
  const headers=selection.columns.map(c=>sourceMap&&sourceMap[c]>=0?state.rawHeaders[sourceMap[c]]:csvHeaderForTemplate(table.csvHeaders[c],state.templateType));
  const values=selection.entries.map(({row})=>selection.columns.map(c=>{const display=formatTableValue(row[c],table,c);return typeof row[c]==='number'?(display==='-'?String(row[c]):String(display).replace(/,/g,'')):display;}));
  copyDataButton.disabled = true;
  try {
    await writeClipboardText(CsvTools.stringifyClipboard([headers, ...values]));
    copyDataButton.textContent = "Copied to clipboard";
    setTimeout(() => {
      copyDataButton.textContent = "Copy data to clipboard...";
      if(activeTableId===table.id)updateCsvToolbar(table);
    }, 1200);
  } catch (error) {
    setCsvFileStatus(error.message || "The table could not be copied.", true);
    copyDataButton.disabled = false;
    setTimeout(() => updateCsvToolbar(table), 2500);
  }
}

function normalizedLoadHeader(value) {
  return String(value ?? "").replace(/\s+/g, " ").trim().toLowerCase();
}

function findRoomZoneLoadSheet(workbook) {
  for (const sheet of workbook.sheets) {
    let columns = null;
    const headerRowIndex = sheet.rows.findIndex((row, index) => {
      if (index > 30 || !row) return false;
      const zoneGroup = row.findIndex((value) => normalizedLoadHeader(value) === "zone group");
      const sensibleHeader = row.findIndex((value) => normalizedLoadHeader(value).includes("sensible cooling load"));
      const latent = row.findIndex((value) => normalizedLoadHeader(value).includes("latent cooling load"));
      const heating = row.findIndex((value) => normalizedLoadHeader(value).includes("heating load"));
      if (zoneGroup < 0 || sensibleHeader < 0 || latent < 0 || heating < 0) return false;
      if (normalizedLoadHeader(row[zoneGroup + 1]) !== "zone" || normalizedLoadHeader(row[zoneGroup + 2]) !== "room") return false;
      columns = {
        zoneGroup,
        zone: zoneGroup + 1,
        room: zoneGroup + 2,
        sensible: sensibleHeader + 1,
        latent,
        heating,
      };
      return true;
    });
    if (headerRowIndex >= 0) return { sheet, headerRowIndex, columns };
  }
  throw new Error("The workbook does not contain the expected Room/Zone Loads Report headers.");
}

function loadNumber(value, rowNumber, label) {
  if (value === "" || value === null || value === undefined) return "";
  if (typeof value === "number" && Number.isFinite(value)) return value;
  const number = Number(String(value).replace(/,/g, "").trim());
  if (!Number.isFinite(number)) throw new Error(`${label} is not numeric on Excel row ${rowNumber}.`);
  return number;
}

function roomZoneRowsFromWorkbook(workbook) {
  const { sheet, headerRowIndex, columns } = findRoomZoneLoadSheet(workbook);
  let zoneGroup = "";
  let zone = "";
  const rows = [];
  sheet.rows.slice(headerRowIndex + 2).forEach((sourceRow, offset) => {
    if (!sourceRow) return;
    const sourceGroup = String(sourceRow[columns.zoneGroup] ?? "").trim();
    const sourceZone = String(sourceRow[columns.zone] ?? "").trim();
    const room = String(sourceRow[columns.room] ?? "").trim();
    if (sourceGroup) zoneGroup = sourceGroup;
    if (sourceZone) zone = sourceZone;
    if (!room) return;
    const excelRow = headerRowIndex + 3 + offset;
    rows.push([
      zoneGroup,
      zone,
      room,
      loadNumber(sourceRow[columns.sensible], excelRow, "Sensible cooling load"),
      loadNumber(sourceRow[columns.latent], excelRow, "Latent cooling load"),
      loadNumber(sourceRow[columns.heating], excelRow, "Heating load"),
    ]);
  });
  if (!rows.length) throw new Error("The Room/Zone Loads Report does not contain any room rows beginning at row 10.");
  return rows;
}

async function importRoomZoneLoads(file) {
  const table = independentTables.find((candidate) => candidate.id === activeTableId);
  if (!table?.excelImport || !file) return;
  if (!/\.(xlsx|xlsm)$/i.test(file.name)) {
    showPasteFormatError('workbook');
    importExcelInput.value = "";
    return;
  }
  importExcelButton.disabled = true;
  setCsvFileStatus("Importing Excel workbook...");
  try {
    const workbook = await XlsxReader.read(await file.arrayBuffer(), {
      sheetNamePattern: /ies loads|room.*zone.*loads|loads report/i,
    });
    const { simulationRunAt, simulationRunPrecision } = simulationRunTimeFromWorkbook(workbook, file);
    const importedRows = roomZoneRowsFromWorkbook(workbook);
    const rows = projectTableRows(table);
    rows.splice(0, rows.length, ...importedRows);
    const state = { importedAt: new Date().toISOString(), fileName: file.name, simulationRunAt, simulationRunPrecision };
    excelImportsByProject.set(csvImportKey(table), state);
    const project = activeProject();
    project.excelImports ||= {};
    project.excelImports[table.id] = state;
    selectedTableId = "";
    selectedTableRowIndexes.clear();
    selectionAnchorIndex = -1;
    tableSearch.value = "";
    tableSort = { tableId: table.id, column: -1, direction: "asc" };
    saveProjects();
    renderReferenceTable(table.id);
  } catch (error) {
    showPasteFormatError('workbook');setCsvFileStatus('');
  } finally {
    importExcelButton.disabled = false;
    importExcelInput.value = "";
  }
}

function simulationRunTimeFromFile(file) {
  const relativePath = String(file.webkitRelativePath || "");
  const nativePath = String(file.path || "").replace(/\\/g, "/");
  const parentFolders = [relativePath, nativePath]
    .map((path) => path.split("/").filter(Boolean).slice(-2, -1)[0] || "")
    .filter(Boolean);
  const fileStem = String(file.name || "").replace(/\.(xlsx|xlsm)$/i, "");
  const match = [...parentFolders, fileStem]
    .map((value) => value.match(/(\d{8})[ _-](\d{6})$/))
    .find(Boolean);
  if (!match) return "";
  const [, date, time] = match;
  const year = Number(date.slice(0, 4));
  const month = Number(date.slice(4, 6));
  const day = Number(date.slice(6, 8));
  const hour = Number(time.slice(0, 2));
  const minute = Number(time.slice(2, 4));
  const second = Number(time.slice(4, 6));
  const value = new Date(year, month - 1, day, hour, minute, second);
  if (value.getFullYear() !== year || value.getMonth() !== month - 1 || value.getDate() !== day
    || value.getHours() !== hour || value.getMinutes() !== minute || value.getSeconds() !== second) {
    throw new Error("The simulation timestamp in the report folder name is not a valid date and time.");
  }
  return value.toISOString();
}

function simulationRunTimeFromWorkbook(workbook, file) {
  const createdAt = new Date(workbook.createdAt || "");
  if (Number.isFinite(createdAt.getTime())) {
    return { simulationRunAt: createdAt.toISOString(), simulationRunPrecision: "time" };
  }
  const reportDate = workbook.sheets?.[0]?.rows?.[3]?.[1];
  const dateMatch = String(reportDate || "").match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (dateMatch) {
    const value = new Date(Number(dateMatch[1]), Number(dateMatch[2]) - 1, Number(dateMatch[3]));
    return { simulationRunAt: value.toISOString(), simulationRunPrecision: "date" };
  }
  const fromPath = simulationRunTimeFromFile(file);
  return { simulationRunAt: fromPath, simulationRunPrecision: fromPath ? "time" : "date" };
}

function tableDropdownOptions(table, columnIndex) {
  const config = table.dropdownColumns?.[columnIndex];
  if (!config) return [];
  if (Array.isArray(config.options)) return config.options.map(String);
  const sources = config.sources || [config];
  return [...new Set(sources.flatMap((source) => {
    const sourceTable = independentTables.find((candidate) => candidate.id === source.sourceTableId);
    return sourceTable ? projectTableRows(sourceTable).map((row) => source.sourceColumns?source.sourceColumns.map(c=>row[c]).join(source.join||' '):row[source.sourceColumn]) : [];
  })
    .filter((value) => value !== null && value !== undefined && value !== "")
    .map(String))];
}

function tableEquations(table) {
  return { ...(table.equations || {}), ...(equationOverrides[table.id] || {}) };
}

function equationColumnIndex(table, name) {
  const normalize = (value) => String(value || "").replace(/^@/, "").replace(/[^A-Za-z0-9]+/g, "").toLowerCase();
  const normalized = normalize(name);
  let index = table.headers.findIndex((header) => normalize(`${header.label || ""}${header.unit || ""}`) === normalized);
  if (index < 0) index = table.headers.findIndex((header) => normalize(header.label) === normalized);
  if (index < 0) index = (table.columns || []).findIndex((column) => normalize(column) === normalized);
  return index;
}

function tokenizeEquation(expression) {
  const source = String(expression || "").trim().replace(/^=/, "");
  const tokens = [];
  let index = 0;
  while (index < source.length) {
    const character = source[index];
    if (/\s/.test(character)) { index += 1; continue; }
    if (character === "@") {
      const reference = source.slice(index + 1).match(/^[A-Za-z_][A-Za-z0-9_]*/);
      if (!reference) throw new Error("Enter a column reference after @");
      tokens.push({ type: "reference", value: reference[0] });
      index += reference[0].length + 1;
      continue;
    }
    if (character === '"') {
      let value = "";
      index += 1;
      while (index < source.length && source[index] !== '"') value += source[index++];
      if (source[index] !== '"') throw new Error("Missing closing quote");
      tokens.push({ type: "string", value });
      index += 1;
      continue;
    }
    const number = source.slice(index).match(/^(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?/i);
    if (number) {
      tokens.push({ type: "number", value: Number(number[0]) });
      index += number[0].length;
      continue;
    }
    const identifier = source.slice(index).match(/^[A-Za-z_][A-Za-z0-9_]*/);
    if (identifier) {
      tokens.push({ type: "identifier", value: identifier[0].toUpperCase() });
      index += identifier[0].length;
      continue;
    }
    const pair = source.slice(index, index + 2);
    if ([">=", "<=", "<>", "!=", "=="].includes(pair)) {
      tokens.push({ type: "operator", value: pair });
      index += 2;
      continue;
    }
    if ("+-*/&=><(),".includes(character)) {
      tokens.push({ type: ["(", ")", ","].includes(character) ? character : "operator", value: character });
      index += 1;
      continue;
    }
    throw new Error(`Unsupported character: ${character}`);
  }
  tokens.push({ type: "end", value: "" });
  return tokens;
}

function evaluateEquation(expression, table, row) {
  const tokens = tokenizeEquation(expression);
  let position = 0;
  const current = () => tokens[position];
  const take = (type) => {
    if (current().type !== type) throw new Error(`Expected ${type}`);
    return tokens[position++];
  };
  const numeric = (value) => numberFromTableValue(value);
  const functions = {
    IF: (condition, yes, no) => condition ? yes : no,
    N: numeric,
    ROUND: (value, digits = 0) => {
      const factor = 10 ** numeric(digits);
      return Math.round(numeric(value) * factor) / factor;
    },
    MIN: (...values) => Math.min(...values.map(numeric)),
    MAX: (...values) => Math.max(...values.map(numeric)),
    ABS: (value) => Math.abs(numeric(value)),
    LOOKUP: (value) => value === "" || value === null || value === undefined ? "" : table.lookup?.[String(value)] ?? 0,
  };

  function primary() {
    const token = current();
    if (token.type === "number" || token.type === "string") { position += 1; return token.value; }
    if (token.type === "reference") {
      position += 1;
      const column = equationColumnIndex(table, token.value);
      if (column < 0) throw new Error(`Unknown column @${token.value}`);
      return row[column];
    }
    if (token.type === "identifier") {
      position += 1;
      if (token.value === "TRUE") return true;
      if (token.value === "FALSE") return false;
      const fn = functions[token.value];
      if (!fn) throw new Error(`Unsupported function ${token.value}`);
      take("(");
      const args = [];
      if (current().type !== ")") {
        args.push(comparison());
        while (current().type === ",") { position += 1; args.push(comparison()); }
      }
      take(")");
      return fn(...args);
    }
    if (token.type === "(") {
      position += 1;
      const value = comparison();
      take(")");
      return value;
    }
    throw new Error("Expected a value");
  }

  function unary() {
    if (current().type === "operator" && ["+", "-"].includes(current().value)) {
      const operator = tokens[position++].value;
      const value = numeric(unary());
      return operator === "-" ? -value : value;
    }
    return primary();
  }
  function multiply() {
    let value = unary();
    while (current().type === "operator" && ["*", "/"].includes(current().value)) {
      const operator = tokens[position++].value;
      const right = numeric(unary());
      value = operator === "*" ? numeric(value) * right : numeric(value) / right;
    }
    return value;
  }
  function add() {
    let value = multiply();
    while (current().type === "operator" && ["+", "-"].includes(current().value)) {
      const operator = tokens[position++].value;
      const right = numeric(multiply());
      value = operator === "+" ? numeric(value) + right : numeric(value) - right;
    }
    return value;
  }
  function concatenate() {
    let value = add();
    while (current().type === "operator" && current().value === "&") {
      position += 1;
      value = String(value ?? "") + String(add() ?? "");
    }
    return value;
  }
  function comparison() {
    let value = concatenate();
    if (current().type === "operator" && ["=", "==", "!=", "<>", ">", "<", ">=", "<="].includes(current().value)) {
      const operator = tokens[position++].value;
      const right = concatenate();
      if (["=", "=="].includes(operator)) return value == right;
      if (["!=", "<>"].includes(operator)) return value != right;
      if (operator === ">") return value > right;
      if (operator === "<") return value < right;
      if (operator === ">=") return value >= right;
      return value <= right;
    }
    return value;
  }

  const result = comparison();
  if (current().type !== "end") throw new Error("Unexpected text after formula");
  return result;
}

const formulaFunctionDefinitions = {
  DIFFERINGVALUES: () => selectedEquationContext?.table?.cellDifferenceEquations?.get(Number(selectedEquationCell?.dataset.sourceIndex)) || "SUM of nonmatching compared values; source-only values are excluded",

  COILFLOW: ([capacity, plant]) =>
    `Cp = XLOOKUP(${plant}, [Plant]@Plant, [Plant]@Cp)\nDensity = XLOOKUP(${plant}, [Plant]@Plant, [Plant]@Density)\nEWT = XLOOKUP(${plant}, [Plant]@Plant, [Plant]@EWT)\nLWT = XLOOKUP(${plant}, [Plant]@Plant, [Plant]@LWT)\n(${capacity}) * 1000 / (60 * Cp * Density * ABS(LWT - EWT))`,
  EQUIPMENTASSOCIATION: ([eq="@Equipment"]) =>
    `LET(equipment,${eq},cooling,COUNTIF([Equipment Zoning]@Cooling Equipment,equipment)>0,heating,COUNTIF([Equipment Zoning]@Heating Equipment,equipment)>0,central,COUNTIF([Equipment Zoning]@Central Equipment,equipment)>0,vent,COUNTIF([Equipment Zoning]@Ventilation Equipment,equipment)>0,downstream,COUNTA(UNIQUE(FILTER([Equipment Zoning]@Reheat Coil,([Equipment Zoning]@Central Equipment=equipment)*([Equipment Zoning]@Reheat Coil<>""),""))),IF(AND(cooling,heating),"CLG&HTG Recirc",IF(cooling,"CLG Recirc",IF(heating,"HTG Recirc",IF(AND(central,downstream>0),downstream&IF(downstream=1," Downstream RHC"," Downstream RHCs"),IF(COUNTIF([Equipment Zoning]@Reheat Coil,equipment)>0,TRIM(IF(XLOOKUP(equipment,[Equipment Zoning]@Reheat Coil,[Equipment Zoning]@Central Equipment,"")<>"",XLOOKUP(equipment,[Equipment Zoning]@Reheat Coil,[Equipment Zoning]@Central Equipment,""),XLOOKUP(equipment,[Equipment Zoning]@Reheat Coil,[Equipment Zoning]@Ventilation Equipment,""))&" RHC"),IF(COUNTIF([Equipment Zoning]@Supply Air Valve,equipment)>0,TRIM(XLOOKUP(equipment,[Equipment Zoning]@Supply Air Valve,[Equipment Zoning]@Central Equipment,"")&" Valve"),IF(COUNTIF([Equipment Zoning]@General Exhaust Valve,equipment)>0,TRIM(XLOOKUP(equipment,[Equipment Zoning]@General Exhaust Valve,[Equipment Zoning]@Exhaust Equipment,"")&" Valve"),IF(OR(AND(vent,@Ventilation Cooling Coil="TRUE",NOT(central)),AND(NOT(vent),central,downstream=0)),"In Unit RHC",IF(COUNTIFS([Equipment Zoning]@Exhaust Equipment,equipment,[Equipment Zoning]@General Exhaust Valve,"<>")>0,"Exhaust Fan",""))))))))))`,
  PSYCHROMETRIC_HR: ([db,wb,pressure]) =>
    `DB°C = ((${db}) - 32) * 5 / 9
WB°C = ((${wb}) - 32) * 5 / 9
Psat = 0.61094 * EXP(17.625 * WB°C / (WB°C + 243.04)) / 6.89476
Ws = 0.621945 * Psat / ((${pressure}) - Psat)
((2501 - 2.326 * WB°C) * Ws - 1.006 * (DB°C - WB°C)) / (2501 + 1.86 * DB°C - 4.186 * WB°C)`,
  SENSIBLECONSTANT: ([db, hr, pressure = "[Model Inputs]@Barometric Pressure"]) =>
    `Density = 0.075 * (${pressure} / 14.696) * (530 / ((${db}) + 459.67)) / (1 + 1.6078 * (${hr}))\n60 * Density * (0.241 + 0.444 * (${hr}))`,
  LATENTCONSTANT: ([db, hr, pressure = "[Model Inputs]@Barometric Pressure"]) =>
    `Density = 0.075 * (${pressure} / 14.696) * (530 / ((${db}) + 459.67)) / (1 + 1.6078 * (${hr}))\n60 * Density * (1093 - 0.556 * (${db}))`,
  HUMIDITYRATIO: ([db, rh, pressure = "[Model Inputs]@Barometric Pressure"]) =>
    `T°C = ((${db}) - 32) * 5 / 9\nPsat = 0.145038 * 0.61094 * EXP(17.625 * T°C / (T°C + 243.04))\nPv = Psat * (${rh})\n0.621945 * Pv / ((${pressure}) - Pv)`,
  HUMIDITY_RATIO: ([db, rh, pressure = "[Model Inputs]@Barometric Pressure"]) =>
    formulaFunctionDefinitions.HUMIDITYRATIO([db, rh, pressure]),
  WETBULB: ([db, hr, pressure = "[Model Inputs]@Barometric Pressure"]) =>
    `LET(TDB,${db},HR,${hr},p,${pressure},WB,SEQUENCE(ROUND((TDB+50)*10,0)+1,,-50,0.1),TR,WB+459.67,Pws,IF(WB>=32,EXP(-10440.397/TR-11.29465-0.027022355*TR+0.00001289036*TR^2-0.0000000024780681*TR^3+6.5459673*LN(TR)),EXP(-10214.165/TR-4.8932428-0.0053765794*TR+0.00000019202377*TR^2+0.00000000035575832*TR^3-9.0344688E-14*TR^4+4.1635019*LN(TR))),Ws,0.621945*Pws/(p-Pws),WCALC,IF(WB>=32,((1093-0.556*WB)*Ws-0.24*(TDB-WB))/(1093+0.444*TDB-WB),((1220-0.04*WB)*Ws-0.24*(TDB-WB))/(1220+0.444*TDB-0.48*WB)),INDEX(WB,XMATCH(MIN(ABS(WCALC-HR)),ABS(WCALC-HR),0)))`,
  INTERPOLATE: ([x0 = "x0", y0 = "y0", x1 = "x1", y1 = "y1", x = "x"]) =>
    `${y0} + ((${x}) - (${x0})) * ((${y1}) - (${y0})) / ((${x1}) - (${x0}))`,
};

function formulaArguments(equation, openIndex) {
  const args = []; let depth = 0; let start = openIndex + 1; let quote = false;
  for (let index = start; index < equation.length; index += 1) {
    const character = equation[index];
    if (character === '"') quote = !quote;
    if (quote) continue;
    if (character === "(") depth += 1;
    if (character === ")") {
      if (depth === 0) { args.push(equation.slice(start, index).trim()); break; }
      depth -= 1;
    }
    if (character === "," && depth === 0) { args.push(equation.slice(start, index).trim()); start = index + 1; }
  }
  return args;
}

function displayFormulaFunctions(equation, view = formulaFunctionView, detail = formulaFunctionDetail) {
  view.replaceChildren();
  detail.hidden = true;
  if(view===formulaFunctionView){restoreAutoButton.hidden=false;restoreAutoButton.textContent=selectedAutoRestore?"Restore":"Evaluate";}
  const pattern = /\b([A-Za-z_][A-Za-z0-9_.]*)(?=\()/g;
  let index = 0;
  for (const match of equation.matchAll(pattern)) {
    const definition = formulaFunctionDefinitions[match[1].toUpperCase()];
    if (!definition) continue;
    view.append(document.createTextNode(equation.slice(index, match.index)));
    const functionName = match[1];
    const token = document.createElement("button");
    token.type = "button";
    token.className = "formula-function-token";
    token.textContent = functionName;
    token.setAttribute("aria-label", `Show ${functionName} equation`);
    const show = () => {
      detail.textContent = definition(formulaArguments(equation, match.index + functionName.length));
      detail.hidden = false;
    };
    token.addEventListener("pointerenter", show);
    token.addEventListener("focus", show);
    token.addEventListener("pointerleave", () => { detail.hidden = true; });
    token.addEventListener("blur", () => { detail.hidden = true; });
    view.append(token);
    index = match.index + functionName.length;
  }
  view.append(document.createTextNode(equation.slice(index)));
  view.hidden = false;
  if (view === formulaFunctionView) selectedEquation.hidden = true;
}

function showTopAutomaticEquation(input) {
  const table = independentTables.find((t) => t.id === activeTableId);
  if (!table) return;
  const fallback = input === twoValueSchedule ? table.twoValueScheduleDefault
    : input === minimumInput ? table.ventilationMinimumDefault ?? table.exhaustMinimumDefault ?? table.supplyMinimumDefault : 10;
  selectStandaloneControl(input);
  const overridden = String(input.value) !== String(fallback);
  selectedEquation.value = `=${typeof fallback === "number" ? fallback : JSON.stringify(fallback)}`;
  displayFormulaFunctions(selectedEquation.value); formulaBar.hidden = false; editEquationButton.hidden = true;
  formulaBar.classList.toggle("formula-overridden", overridden); restoreAutoButton.hidden=false;restoreAutoButton.textContent=overridden?"Restore":"Evaluate";
  selectedAutoRestore = overridden ? () => { input.value = fallback; input.dispatchEvent(new Event("change", { bubbles: true })); showTopAutomaticEquation(input); } : null;
}

function autoCellDescriptor(table, row, index, column, project) {
  if (!row || table.lockedCellStates?.get(index)?.has(column)) return null;
  const key = `${requirementKey(row[0])}::${column}`;
  let value, equation;
  if(table.equipmentScheduleCalculation&&column===91)value=.1;
  else if(table.peakAirflowCalculation&&[4,10,17].includes(column))value=project?.peakAirflowAutos?.[key];
  else if(table.conditionBaselineCalculation&&column===11)value=project?.baselineSystemAutos?.[requirementKey(row[1])];
  else if ((table.equipmentAirflowsCalculation || table.combinedAirflowCalculation) && table.autoColumns?.includes(column)) value = project?.airflowAutos?.[`${table.id}::${requirementKey(row[0])}::${column}`];
  else if (table.conditionScheduleCalculation && [6, 11].includes(column)) value = project?.conditionScheduleAutos?.[key];
  else if (table.scheduleCalculation && column === table.scheduleColumn) value = project?.consumptionScheduleAutos?.[`${table.id}::${requirementKey(row[0])}`];
  else if (table.thermalTemplateCalculation) value = project?.thermalAutoValues?.[key];
  else if (table.equipmentZoningCalculation) value = project?.zoningAutoValues?.[table.id]?.[zoningCellKey(row, column)];
  else if (table.zoningNetworkTableCalculation) value = project?.networkZoningAutoValues?.[`${row[2]}::${column}`];
  else if (table.roomLoadCalculation) value = project?.spaceLoadFactorAutos?.[`${row[0]}::${column}`];
  else if (table.airsideSettingsCalculation) value = project?.airsideAutoValues?.[airsideCellKey(row, column)];
  else if (table.coilCalculation) value = project?.coilAutoValues?.[table.id]?.[airsideCellKey(row, column)];
  else if (table.plantCalculation) value = project?.plantAutoValues?.[table.id]?.[airsideCellKey(row, column).toLowerCase()];
  else if (table.generalExhaustCalculation && column === 5) value = 1;
  else if (table.equipmentExhaustCalculation && column === 1) value = project?.exhaustEquipmentAutoValues?.[index];
  else if (table.equipmentExhaustCalculation && column === 4) value = 1;
  else if (table.ventilationRequirementsCalculation && [10, 12].includes(column)) value = project?.ventilationEzAutos?.[`${requirementKey(row[1])}::${column}`];
  else if (table.ventilationRequirementsCalculation && column === 2) value = project?.ventilationTypeAutos?.[requirementKey(row[1])];
  else if (table.pressurizationCalculation && column === 7) value = "";
  if (value === undefined && table.autoCellStates?.get(index)?.has(column)) value = row[column];
  if (value === undefined) return null;
  equation = table.displayEquations?.[column] || table.equations?.[column] || `=${typeof value === "number" ? value : JSON.stringify(value)}`;
  return { value, equation, editable: !table.calculatedColumns?.includes(column) && !table.lockedColumns?.includes(column) };
}

function restoreAutoCell(table, index, column, value) {
  const rows = projectTableRows(table);
  const raw = isPercentageColumn(table, column) && typeof value === "number" ? String(value * 100) : String(value ?? "");
  updateTableCell(table, rows, index, column, raw);
  const cell = referenceTable.querySelector(`tbody tr[data-source-index="${index}"] td[data-column-index="${column}"]`);
  if (cell) { cell.focus({ preventScroll: true }); markSelectedTableCell(cell); showSelectedEquation(table, cell, column); }
}

function clearTableSelection() {
  if (referenceTable.contains(document.activeElement)) document.activeElement.blur();
  clearSelectedEquation(); clearCsvComparison(); clearFillHandle();
  selectedTableCells.clear(); selectedTableRowIndexes.clear();
  activeCellSelection = null; cellSelectionAnchor = null; selectionAnchorIndex = -1; selectedTableId = "";
  refreshSelectedTableCells();
  referenceTable.querySelectorAll(".selected-row, .selected-cell-row, .table-cell-selected, .equation-cell-selected, .multi-cell-selected").forEach((cell) => {
    cell.classList.remove("selected-row", "selected-cell-row", "table-cell-selected", "equation-cell-selected", "multi-cell-selected");
    cell.removeAttribute("aria-current"); cell.setAttribute("aria-selected", "false");
  });
  removeTableRowButton.disabled = true;
}

function clearSelectedEquation() {
  selectedAutoRestore = null; restoreAutoButton.hidden = true; formulaBar.classList.remove("formula-overridden");
  formulaBar.hidden = true;
  selectedEquation.value = "";
  selectedEquation.readOnly = true;
  selectedEquation.hidden = false;
  formulaFunctionView.hidden = true;
  formulaFunctionDetail.hidden = true;
  selectedEquationContext = null;
  editEquationButton.hidden = true;
  saveEquationButton.hidden = true;
  cancelEquationButton.hidden = true;
  formulaError.hidden = true;
  formulaError.textContent = "";
  selectedEquationCell?.classList.remove("equation-cell-selected");
  selectedEquationCell = null;
}

function showSelectedEquation(table, cell, column) {
  if(table.psychCalculation){const index=Number(cell.dataset.sourceIndex);selectedAutoRestore=null;selectedEquationContext=psychCellFormula(table.psychCalculation.lines[index],column,table.psychCalculation.pressure);selectedEquation.value=selectedEquationContext.equation;displayFormulaFunctions(selectedEquation.value);formulaBar.classList.remove('formula-overridden');formulaBar.hidden=false;restoreAutoButton.hidden=false;restoreAutoButton.textContent='Evaluate';return;}

  const sourceIndex = Number(cell.dataset.sourceIndex);
  const rows = activeProject()?.independentTables?.[table.id] || table.rows;
  const automatic = autoCellDescriptor(table, rows[sourceIndex], sourceIndex, column, activeProject());
  selectedAutoRestore = automatic?.editable && !table.autoCellStates?.get(sourceIndex)?.has(column)
    ? () => restoreAutoCell(table, sourceIndex, column, automatic.value) : null;
  restoreAutoButton.hidden=false;restoreAutoButton.textContent=selectedAutoRestore?"Restore":"Evaluate";
  formulaBar.classList.toggle("formula-overridden", Boolean(selectedAutoRestore));
  selectedEquationCell?.classList.remove("equation-cell-selected");
  selectedEquationCell = cell;
  cell.classList.add("equation-cell-selected");
  selectedEquationContext = { table, column, sourceIndex };
  const equation = equationOverrides[table.id]?.[column]
    || table.cellDisplayEquations?.get(Number(cell.dataset.sourceIndex))?.get(column)
    || table.displayEquations?.[column]
    || table.equations?.[column]
    || automatic?.equation
    || "";
  if (!equation) {
    clearSelectedEquation();
    return;
  }
  selectedEquation.value = equation;
  selectedEquation.readOnly = true;
  displayFormulaFunctions(equation);
  editEquationButton.hidden = true;
  saveEquationButton.hidden = true;
  cancelEquationButton.hidden = true;
  formulaError.hidden = true;
  formulaBar.hidden = false;
}

function beginEquationEdit() {
  return; // Formulas are read-only throughout the workbook.

  if (!selectedEquationContext) return;
  const { table, column } = selectedEquationContext;
  if (table.readonlyEquations) return;
  selectedEquation.value = tableEquations(table)[column] || "=0";
  selectedEquation.readOnly = false;
  selectedEquation.hidden = false;
  formulaFunctionView.hidden = true;
  formulaFunctionDetail.hidden = true;
  editEquationButton.hidden = true;
  saveEquationButton.hidden = false;
  cancelEquationButton.hidden = false;
  formulaError.hidden = true;
  selectedEquation.focus();
  selectedEquation.select();
}

function cancelEquationEdit() {
  if (!selectedEquationContext) return;
  const { table, column } = selectedEquationContext;
  selectedEquation.value = equationOverrides[table.id]?.[column]
    || table.displayEquations?.[column]
    || table.equations?.[column]
    || "";
  selectedEquation.readOnly = true;
  displayFormulaFunctions(selectedEquation.value);
  editEquationButton.hidden = true;
  saveEquationButton.hidden = true;
  cancelEquationButton.hidden = true;
  formulaError.hidden = true;
}

function sourceTableForEquation(name) {
  const normalized = String(name).replace(/[^A-Za-z0-9]+/g, "").toLowerCase();
  return independentTables.find((table) => [table.id, table.name, table.standard]
    .some((value) => String(value || "").replace(/[^A-Za-z0-9]+/g, "").toLowerCase() === normalized));
}

function evaluateProjectEquation(expression, table, row, rows, project) {
  const qualifiedCountif = String(expression || "").trim().match(/^=COUNTIF\(\s*\[([^\]]+)\]@([A-Za-z_][A-Za-z0-9_]*)\s*,\s*@([A-Za-z_][A-Za-z0-9_]*)\s*\)$/i);
  if (qualifiedCountif) {
    const sourceTable = sourceTableForEquation(qualifiedCountif[1]);
    if (!sourceTable) throw new Error(`Unknown COUNTIF table [${qualifiedCountif[1]}]`);
    const sourceColumn = equationColumnIndex(sourceTable, qualifiedCountif[2]);
    let criteriaColumn = equationColumnIndex(table, qualifiedCountif[3]);
    if (criteriaColumn < 0 && table.id === "iesve-thermal-template" && qualifiedCountif[3].toLowerCase() === "type") criteriaColumn = 0;
    if (sourceColumn < 0 || criteriaColumn < 0) throw new Error("Unknown COUNTIF column reference");
    const criteria = String(row[criteriaColumn] ?? "");
    const sourceRows = sourceTable.id === table.id ? rows : ensureProjectTableRows(project, sourceTable);
    return sourceRows.filter((candidate) => thermalTypeKey(candidate[sourceColumn]) === thermalTypeKey(criteria)).length;
  }
  const qualifiedSumif = String(expression || "").trim().match(/^=SUMIF\(\s*\[([^\]]+)\]@([A-Za-z_][A-Za-z0-9_]*)\s*,\s*@([A-Za-z_][A-Za-z0-9_]*)\s*,\s*\[([^\]]+)\]@([A-Za-z_][A-Za-z0-9_]*)\s*\)$/i);
  if (qualifiedSumif) {
    const rangeTable = sourceTableForEquation(qualifiedSumif[1]);
    const sumTable = sourceTableForEquation(qualifiedSumif[4]);
    if (!rangeTable || rangeTable !== sumTable) throw new Error("SUMIF range and sum columns must use the same table");
    const rangeColumn = equationColumnIndex(rangeTable, qualifiedSumif[2]);
    const criteriaColumn = equationColumnIndex(table, qualifiedSumif[3]);
    const sumColumn = equationColumnIndex(sumTable, qualifiedSumif[5]);
    if ([rangeColumn, criteriaColumn, sumColumn].some((index) => index < 0)) throw new Error("Unknown SUMIF column reference");
    const sourceRows = rangeTable.id === table.id ? rows : ensureProjectTableRows(project, rangeTable);
    const criteria = row[criteriaColumn];
    return sourceRows.reduce((total, candidate) => candidate[rangeColumn] == criteria ? total + numberFromTableValue(candidate[sumColumn]) : total, 0);
  }
  const sumif = String(expression || "").trim().match(/^=SUMIF\(\s*@([A-Za-z_][A-Za-z0-9_]*)\s*,\s*@([A-Za-z_][A-Za-z0-9_]*)\s*,\s*@([A-Za-z_][A-Za-z0-9_]*)\s*\)$/i);
  if (sumif) {
    const rangeColumn = equationColumnIndex(table, sumif[1]);
    const criteriaColumn = equationColumnIndex(table, sumif[2]);
    const sumColumn = equationColumnIndex(table, sumif[3]);
    if ([rangeColumn, criteriaColumn, sumColumn].some((index) => index < 0)) throw new Error("Unknown SUMIF column reference");
    const criteria = row[criteriaColumn];
    return rows.reduce((total, candidate) => candidate[rangeColumn] == criteria ? total + numberFromTableValue(candidate[sumColumn]) : total, 0);
  }

  const withLookups = String(expression || "").replace(/XLOOKUP\(\s*@([A-Za-z_][A-Za-z0-9_]*)\s*,\s*\[([^\]]+)\]@([A-Za-z_][A-Za-z0-9_]*)\s*,\s*\[([^\]]+)\]@([A-Za-z_][A-Za-z0-9_]*)\s*\)/gi, (reference, currentColumnName, lookupTableName, lookupColumnName, resultTableName, resultColumnName) => {
    const lookupTable = sourceTableForEquation(lookupTableName);
    const resultTable = sourceTableForEquation(resultTableName);
    if (!lookupTable || lookupTable !== resultTable) throw new Error(`Unknown XLOOKUP table in ${reference}`);
    const currentColumn = equationColumnIndex(table, currentColumnName);
    const lookupColumn = equationColumnIndex(lookupTable, lookupColumnName);
    const resultColumn = equationColumnIndex(resultTable, resultColumnName);
    if ([currentColumn, lookupColumn, resultColumn].some((index) => index < 0)) throw new Error(`Unknown XLOOKUP column in ${reference}`);
    const sourceRows = ensureProjectTableRows(project, lookupTable);
    const lookupValue = String(row[currentColumn] ?? "");
    const sourceRow = sourceRows.find((candidate) => thermalTypeKey(candidate[lookupColumn]) === thermalTypeKey(lookupValue));
    const value = sourceRow?.[resultColumn] ?? 0;
    return typeof value === "number" ? String(value) : JSON.stringify(String(value));
  });

  const resolved = withLookups.replace(/\[([^\]]+)\]@([A-Za-z_][A-Za-z0-9_]*)/g, (reference, tableName, columnName) => {
    const sourceTable = sourceTableForEquation(tableName);
    if (!sourceTable) throw new Error(`Unknown table [${tableName}]`);
    const sourceColumn = equationColumnIndex(sourceTable, columnName);
    const lookupColumn = equationColumnIndex(table, sourceTable.headers[0].label);
    if (sourceColumn < 0 || lookupColumn < 0) throw new Error(`Unknown reference ${reference}`);
    const sourceRows = ensureProjectTableRows(project, sourceTable);
    const lookupValue = String(row[lookupColumn] ?? "");
    const sourceRow = sourceRows.find((candidate) => String(candidate[0] ?? "").localeCompare(lookupValue, undefined, { sensitivity: "base" }) === 0);
    const value = sourceRow?.[sourceColumn] ?? 0;
    return typeof value === "number" ? String(value) : JSON.stringify(String(value));
  });
  return evaluateEquation(resolved, table, row);
}

function recalculateGainTable(table, rows, project) {
  const thermal = independentTables.find((candidate) => candidate.id === "iesve-thermal-template");
  const thermalRows = thermal ? (project ? ensureProjectTableRows(project, thermal) : thermal.rows) : [];
  const thermalByType = new Map(thermalRows.map((row) => [thermalTypeKey(row[0]), row]));
  const lightingLoads = independentTables.find((candidate) => candidate.id === "selected-lighting-loads");
  const lightingRows = lightingLoads ? (project ? ensureProjectTableRows(project, lightingLoads) : lightingLoads.rows) : [];
  const miscLoads = independentTables.find((candidate) => candidate.id === "selected-misc-loads");
  const miscRows = miscLoads ? (project ? ensureProjectTableRows(project, miscLoads) : miscLoads.rows) : [];
  const lightingPowerDensity = (value, space, area) => {
    const numeric = Number(value);
    if (Number.isFinite(numeric)) return numeric;
    const height = area ? (Number(tabularMetadata(project, space)?.volume ?? table.volumeBySpace?.[space]) || 0) / area : 0;
    const text = String(value || "");
    if (text.includes("0.050") && text.includes("0.025")) return 0.05 - 0.025 * height;
    if (text.includes("0.0375")) return 0.037 * height;
    return 0;
  };

  rows.forEach((row) => {
    const space = String(row[0] ?? "");
    const metadata = tabularMetadata(project, space);
    const gainKind = table.gainCalculation === "misc" ? "equipment" : table.gainCalculation;
    const explicitGains = metadata?.gainSlots?.filter(Boolean) || [];
    const active = explicitGains.length ? explicitGains.includes(gainKind) : metadata ? (table.activityBySpace?.[space] ?? true) : Boolean(table.activityBySpace?.[space]);
    const template = thermalByType.get(thermalTypeKey(row[1])) || [];
    const area = Number(row[2]) || 0;
    if (table.gainCalculation === "people") {
      if (!active) {
        [3, 5, 6, 7, 8, 9].forEach((index) => { row[index] = ""; });
        return;
      }
      row[3] = (Number(template[5]) || 0) / 1000;
      const manualPeople = row[4] !== "" && row[4] !== null && row[4] !== undefined ? Number(row[4]) : NaN;
      row[5] = Number.isFinite(manualPeople) ? manualPeople : Math.round((Number(row[3]) || 0) * area);
      row[6] = template[7] ?? "";
      row[7] = template[8] ?? "";
      row[8] = (Number(row[5]) || 0) * (Number(row[6]) || 0);
      row[9] = (Number(row[5]) || 0) * (Number(row[7]) || 0);
      return;
    }
    if (table.gainCalculation === "lighting") {
      if (!active) {
        [3, 4, 6, 7, 8].forEach((index) => { row[index] = ""; });
        return;
      }
      row[3] = template[12] ?? "";
      row[4] = lightingPowerDensity(template[10], space, area);
      const matches = lightingRows.filter((candidate) => String(candidate[0] ?? "") === space);
      row[6] = matches.length ? matches.reduce((sum, candidate) => sum + (Number(candidate[4]) || 0), 0) : "";
      const manual = row[5] !== "" && row[5] !== null && row[5] !== undefined ? Number(row[5]) : NaN;
      const proposedWatts = row[6] !== "" ? Number(row[6]) || 0 : Number.isFinite(manual) ? manual : (Number(row[3]) || 0) * area;
      row[7] = 3.412 * proposedWatts;
      row[8] = 3.412 * (Number(row[4]) || 0) * area;
      return;
    }
    if (table.gainCalculation === "misc") {
      if (!active) {
        [3, 4, 5].forEach((index) => { row[index] = ""; });
        return;
      }
      row[3] = template[13] ?? "";
      const matches = miscRows.filter((candidate) => String(candidate[0] ?? "") === space);
      row[4] = matches.length ? matches.reduce((sum, candidate) => sum + (Number(candidate[9]) || 0), 0) : "";
      row[5] = row[4] !== "" ? Number(row[4]) || 0 : 3.412 * (Number(row[3]) || 0) * area;
    }
  });
}

function recalculateMiscLoadTable(table, rows, project) {
  const peopleTable = independentTables.find((candidate) => candidate.id === "calc-people-gains");
  const equipmentTable = independentTables.find((candidate) => candidate.id === "schedule-equipment-sensible-gain");
  const groupedTable = independentTables.find((candidate) => candidate.id === "schedule-grouped-equipment-sensible-gain");
  const peopleRows = peopleTable ? ensureProjectTableRows(project, peopleTable) : [];
  if (peopleTable) recalculateGainTable(peopleTable, peopleRows, project);
  const peopleBySpace = new Map(peopleRows.map((row) => [String(row[0] ?? ""), row[5]]));
  const equipmentRows = equipmentTable ? ensureProjectTableRows(project, equipmentTable) : [];
  const groupedRows = groupedTable ? ensureProjectTableRows(project, groupedTable) : [];
  if (equipmentTable) recalculateTable(equipmentTable, equipmentRows, project);
  if (groupedTable) recalculateTable(groupedTable, groupedRows, project);
  const heatGainByEquipment = new Map(equipmentRows.map((row) => [String(row[0] ?? ""), Number(row[5]) || 0]));
  groupedRows.forEach((row) => heatGainByEquipment.set(String(row[0] ?? ""), Number(row[4]) || 0));

  rows.forEach((row) => {
    if (row[0] === "" || row[0] === null || row[0] === undefined) {
      [4, 5, 6, 9].forEach((index) => { row[index] = ""; });
      return;
    }
    const perPerson = String(row[3] ?? "").toUpperCase() === "TRUE";
    row[4] = perPerson ? (peopleBySpace.get(String(row[0])) ?? 0) : "-";
    row[5] = row[2] === "" || row[2] === null || row[2] === undefined ? 1 : Number(row[2]) || 0;
    row[6] = heatGainByEquipment.get(String(row[1] ?? "")) ?? 0;
    const peopleMultiplier = perPerson ? Number(row[4]) || 0 : 1;
    row[9] = peopleMultiplier * (Number(row[5]) || 0) * (Number(row[6]) || 0)
      + 3412.142 * (Number(row[7]) || 0) + (Number(row[8]) || 0);
  });
}

function recalculateRoomLoadTable(rows, project) {
  const reportTable = independentTables.find((candidate) => candidate.id === "room-zone-loads-report");
  const reportRows = reportTable ? ensureProjectTableRows(project, reportTable) : [];
  const reportByRoom = new Map(reportRows.map((row) => [String(row[2] ?? ""), row]));
  const gainTable = (id) => independentTables.find((candidate) => candidate.id === id);
  const lightingTable = gainTable("calc-lighting-gains");
  const peopleTable = gainTable("calc-people-gains");
  const miscTable = gainTable("calc-misc-gains");
  const lightingRows = lightingTable ? ensureProjectTableRows(project, lightingTable) : [];
  const peopleRows = peopleTable ? ensureProjectTableRows(project, peopleTable) : [];
  const miscRows = miscTable ? ensureProjectTableRows(project, miscTable) : [];
  if (lightingTable) recalculateGainTable(lightingTable, lightingRows, project);
  if (peopleTable) recalculateGainTable(peopleTable, peopleRows, project);
  if (miscTable) recalculateGainTable(miscTable, miscRows, project);
  const bySpace = (sourceRows) => new Map(sourceRows.map((row) => [String(row[0] ?? ""), row]));
  const lightingBySpace = bySpace(lightingRows);
  const peopleBySpace = bySpace(peopleRows);
  const miscBySpace = bySpace(miscRows);
  const enabled = (value) => value === true || String(value ?? "").toUpperCase() === "TRUE";
  project.calcSettings ||= {};
  project.calcSettings.spaceLoadFactors ||= { sensible: 0.1, latent: 0.1, heating: 0.1 };
  project.spaceLoadFactorOverrides ||= {};
  project.spaceLoadFactorAutos ||= {};
  const factors = project.calcSettings.spaceLoadFactors;
  const factorColumns = [[6, factors.sensible], [12, factors.latent], [16, factors.heating]];
  const nextAutos = {};
  const roomLoadsTable = independentTables.find((candidate) => candidate.id === "calc-room-loads");
  roomLoadsTable.autoCellStates = new Map();roomLoadsTable.mutedCellStates=new Map();
  roomLoadsTable.missingRoomLoadSpaces = new Set();

  rows.forEach((row, rowIndex) => {
    const space = String(row[0] ?? "");
    if (!space) {
      [2, 3, 7, 8, 9, 13, 14, 17].forEach((index) => { row[index] = ""; });
      return;
    }
    const report = reportByRoom.get(space);
    if (!report) roomLoadsTable.missingRoomLoadSpaces.add(space);
    const lighting = lightingBySpace.get(space) || [];
    const people = peopleBySpace.get(space) || [];
    const misc = miscBySpace.get(space) || [];
    const autoCells = new Set();
    factorColumns.forEach(([column, defaultValue]) => {
      const key = `${space}::${column}`;
      const normalizedDefault = Number(defaultValue) || 0;
      if (project.spaceLoadFactorOverrides[key] && Number(row[column]) === normalizedDefault) delete project.spaceLoadFactorOverrides[key];
      if (!project.spaceLoadFactorOverrides[key]) {
        const previous = project.spaceLoadFactorAutos[key];
        if (previous !== undefined && row[column] !== "" && Number(row[column]) !== Number(previous) && Number(row[column]) !== normalizedDefault) {
          project.spaceLoadFactorOverrides[key] = true;
        }
      }
      if (!project.spaceLoadFactorOverrides[key]) {
        row[column] = normalizedDefault;
        autoCells.add(column);
      }
      nextAutos[key] = normalizedDefault;
    });
    roomLoadsTable.autoCellStates.set(rowIndex, autoCells);
    roomLoadsTable.mutedCellStates.set(rowIndex,new Set([enabled(row[4])?2:3,enabled(row[10])?9:8]));
    row[2] = report ? Number(report[3]) || 0 : "";
    row[3] = ((Number(lighting[7]) || 0) + (Number(people[8]) || 0) + (Number(misc[5]) || 0)) / 1000;
    const sensibleBasis = enabled(row[4]) ? row[3] : row[2];
    row[7] = Math.max((1 + (Number(row[6]) || 0)) * ((Number(sensibleBasis) || 0) + (Number(row[5]) || 0)), 0);
    row[8] = report ? Number(report[4]) || 0 : "";
    row[9] = (Number(people[9]) || 0) / 1000;
    const latentBasis = enabled(row[10]) ? row[8] : row[9];
    row[13] = Math.max((1 + (Number(row[12]) || 0)) * ((Number(latentBasis) || 0) + (Number(row[11]) || 0)), 0);
    row[14] = report ? Number(report[5]) || 0 : "";
    row[17] = Math.max((1 + (Number(row[16]) || 0)) * ((Number(row[14]) || 0) + (Number(row[15]) || 0)), 0);
  });
  project.spaceLoadFactorAutos = nextAutos;
}

function recordSpaceLoadFactorOverride(table, row, column, value, project) {
  if (!table.roomLoadCalculation || !(table.autoColumns || []).includes(column) || !project) return;
  project.spaceLoadFactorOverrides ||= {};
  const key = `${String(row[0] ?? "")}::${column}`;
  const numericValue = Number(String(value ?? "").replace(/%$/, "")) / 100;
  const autoValue = Number(project.spaceLoadFactorAutos?.[key]);
  if (Number.isFinite(numericValue) && numericValue === autoValue) delete project.spaceLoadFactorOverrides[key];
  else project.spaceLoadFactorOverrides[key] = true;
}

function loadCalculationSources(project, cooling) {
  const byId = (id) => independentTables.find((candidate) => candidate.id === id);
  const cache = activeCalculationCache?.project === project ? activeCalculationCache : null;
  const cacheKey = cooling ? "coolingSources" : "heatingSources";
  if (cache?.[cacheKey]) return cache[cacheKey];
  const context = cache?.coilContext || coilCalculationContext(project);
  if (cache) cache.coilContext = context;
  const loadsTable = byId("calc-room-loads");
  const loadsRows = loadsTable ? ensureProjectTableRows(project, loadsTable) : [];
  if (loadsTable && !cache?.roomLoadsCalculated) recalculateRoomLoadTable(loadsRows, project);
  if (cache) cache.roomLoadsCalculated = true;
  const coilIds = cooling
    ? ["airside-ventilation-cooling", "airside-room-cooling"]
    : ["airside-in-unit-reheat", "airside-downstream-reheat", "airside-room-heating"];
  const coilByEquipment = new Map();
  context.calculatedCoils ||= new Set();
  coilIds.forEach((id) => {
    const table = byId(id);
    if (!table) return;
    const coilRows = ensureProjectTableRows(project, table, context);
    if (coilRows.length && !context.calculatedCoils.has(id)) recalculateCoilTable(table, coilRows, project, context);
    coilRows.forEach((row) => coilByEquipment.set(String(row[0] ?? "").trim().toLowerCase(), row));
  });
  const result = {
    zoningBySpace: new Map(context.zoningRows.map((row) => [String(row[2] ?? ""), row])),
    loadsBySpace: new Map(loadsRows.map((row) => [String(row[0] ?? ""), row])),
    setpointsBySpace: context.setpointsBySpace,
    coilByEquipment,
  };
  if (cache) cache[cacheKey] = result;
  return result;
}

const firstAssignedEquipment = (...values) => values.map((value) => String(value ?? "").trim())
  .find((value) => value && value !== "-") || "";
let activeCalculationCache = null;
const roundAirflowUp = (value) => Number(value) > 0 ? Math.ceil(Number(value) / 5) * 5 : 0;
function airflowMinimum(project, tableId, fallback) {
  const stored = Number(project?.calcSettings?.airflowMinimums?.[tableId]);
  return Number.isFinite(stored) && stored >= 0 && project?.calcSettings?.airflowMinimums?.[tableId] !== undefined ? stored : fallback;
}

function recalculateHeatingLoads(rows, project) {
  const sources = loadCalculationSources(project, false);
  rows.forEach((row) => {
    const space = String(row[0] ?? "");
    if (!space) { row.fill("", 1); return; }
    const zoning = sources.zoningBySpace.get(space) || [];
    const loads = sources.loadsBySpace.get(space) || [];
    const setpoints = sources.setpointsBySpace.get(space) || [];
    row[1] = loads[17] ?? "";
    row[2] = setpoints[3] ?? "";
    row[3] = firstAssignedEquipment(zoning[10], zoning[6]);
    const coil = sources.coilByEquipment.get(row[3].toLowerCase());
    if (!row[3] || !coil) { row[4] = row[5] = ""; row[6] = row[3] ? roundAirflowUp(airflowMinimum(project, "calc-airflow-requirements", 50)) : ""; return; }
    row[4] = coil[4] ?? "";
    row[5] = coil[1] ?? "";
    const delta = Number(row[5]) - Number(row[2]);
    row[6] = roundAirflowUp(Math.max(Number(row[4]) > 0 && delta > 0 ? Math.max(0, Number(row[1]) || 0) * 1000 / (Number(row[4]) * delta) : 0, airflowMinimum(project, "calc-airflow-requirements", 50)));
  });
}

function recalculateCoolingLoads(rows, project) {
  const sources = loadCalculationSources(project, true);
  rows.forEach((row) => {
    const space = String(row[0] ?? "");
    if (!space) { row.fill("", 1); return; }
    const zoning = sources.zoningBySpace.get(space) || [];
    const loads = sources.loadsBySpace.get(space) || [];
    const setpoints = sources.setpointsBySpace.get(space) || [];
    row[1] = loads[7] ?? "";
    row[2] = setpoints[8] ?? "";
    row[3] = firstAssignedEquipment(zoning[9], zoning[4]);
    const coil = sources.coilByEquipment.get(row[3].toLowerCase());
    if (!row[3] || !coil) { row[4] = row[5] = ""; row[6] = row[3] ? roundAirflowUp(airflowMinimum(project, "calc-airflow-requirements", 50)) : ""; return; }
    row[4] = coil[13] ?? "";
    row[5] = coil[9] ?? "";
    const delta = Number(row[2]) - Number(row[5]);
    row[6] = roundAirflowUp(Math.max(Number(row[4]) > 0 && delta > 0 ? Math.max(0, Number(row[1]) || 0) * 1000 / (Number(row[4]) * delta) : 0, airflowMinimum(project, "calc-airflow-requirements", 50)));
  });
}

function zoningCellKey(row, column) {
  return `${String(row[2] ?? "")}::${column}`;
}

function recordZoningOverride(table, row, column, value, project) {
  if (!table.equipmentZoningCalculation || !(table.autoColumns || []).includes(column)) return;
  project.zoningOverrides ||= {};
  project.zoningOverrides[table.id] ||= {};
  const defaults = project.zoningAutoValues?.[table.id] || {};
  const key = zoningCellKey(row, column);
  if (String(value ?? "") === String(defaults[key] ?? "")) delete project.zoningOverrides[table.id][key];
  else project.zoningOverrides[table.id][key] = true;
}

function recordNetworkZoningOverride(table, row, column, value, project) {
  if (!table.zoningNetworkTableCalculation || !(table.autoColumns || []).includes(column) || !project) return;
  project.networkZoningOverrides ||= {};
  const key = `${String(row[2] ?? "")}::${column}`;
  const automatic = project.networkZoningAutoValues?.[key] ?? "";
  if (String(value ?? "") === String(automatic ?? "")) delete project.networkZoningOverrides[key];
  else project.networkZoningOverrides[key] = true;
}

function syncNetworkTableToLegacy(project, rows) {
  const legacy = independentTables.find((candidate) => candidate.id === "calc-equipment-zoning"); if (!legacy) return;
  const legacyRows = ensureProjectTableRows(project, legacy); const bySpace = new Map(legacyRows.map((row) => [String(row[2] ?? ""), row]));
  rows.forEach((row) => {
    const target = bySpace.get(String(row[2] ?? "")); if (!target) return;
    target[0] = row[0]; target[1] = row[1]; target[3] = row[3]; target[4] = row[4]; target[9] = row[5] || row[6];
    target[5] = row[7]; target[6] = row[8]; target[7] = row[9]; target[8] = row[10]; target[10] = row[11];
  });
}

function recalculateNetworkZoningTable(project) {
  const table = independentTables.find((candidate) => candidate.id === "calc-equipment-zoning-table"); if (!table || !project) return;
  const rows = ensureProjectTableRows(project, table); const { network, spaces } = zoningNetworkModel(project); const systems = airsideSystemModel(project);
  const spaceByName = new Map(spaces.map((item) => [item.space, item])); const supplyByTag = new Map(systems.supply.map((system) => [system.tag, system]));
  project.networkZoningOverrides ||= {}; project.networkZoningAutoValues ||= {};
  const overrides = project.networkZoningOverrides; const previousAutos = project.networkZoningAutoValues; const nextAutos = {};
  table.autoCellStates = new Map(); table.lockedCellStates = new Map(); table.lockedCellMessages = new Map();
  rows.forEach((row, rowIndex) => {
    const identity = spaceByName.get(String(row[2] ?? "")); if (identity) { row[0] = identity.group; row[1] = identity.zone; }
    const config = network.groups[row[0]] || {}; row[3] = config.ventilationSystem || ""; row[4] = config.supplySystem || ""; row[5] = config.exhaustSystem || ""; row[6] = config.returnSystem || "";
    const supply = supplyByTag.get(row[4]); const hasSupply = Boolean(row[4]); const inUnitReheat = supply?.reheat === "In Unit";
    const autoCells = new Set(); const locked = new Set(); const messages = new Map();
    const keyFor = (column) => `${String(row[2] ?? "")}::${column}`;
    const applyAuto = (column, value) => {
      const key = keyFor(column); const automatic = value ?? "";
      if (overrides[key] && String(row[column] ?? "") === String(automatic)) delete overrides[key];
      if (!overrides[key]) {
        const previous = previousAutos[key]; const current = row[column] ?? "";
        if (previous !== undefined && current !== "" && String(current) !== String(previous) && String(current) !== String(automatic)) overrides[key] = true;
      }
      if (!overrides[key]) { row[column] = automatic; autoCells.add(column); }
      nextAutos[key] = automatic;
    };
    const lock = (column, message) => { row[column] = ""; locked.add(column); messages.set(column, message); delete overrides[keyFor(column)]; };
    if (!hasSupply) { lock(7, "Attach a system to the SA / OA node to enable Supply Air Valve."); lock(8, "Attach a system to the SA / OA node to enable Reheat Coil."); }
    else if (inUnitReheat) { lock(7, `${row[4]} has an in-unit reheat coil.`); lock(8, `${row[4]} has an in-unit reheat coil.`); }
    else { applyAuto(7, row[1] || ""); applyAuto(8, row[7] || row[1] || ""); }
    if (hasSupply) lock(9, "Cooling Equipment is provided by the attached SA / OA system."); else applyAuto(9, row[1] || "");
    if (hasSupply && (inUnitReheat || row[8])) lock(10, inUnitReheat ? `${row[4]} has an in-unit reheat coil.` : "Clear Reheat Coil to enable Heating Equipment.");
    else applyAuto(10, row[9] || row[1] || "");
    if (!row[5] && !row[6]) lock(11, "Attach an EA or RA / EA system to enable General Exhaust Valve."); else applyAuto(11, row[1] || "");
    table.autoCellStates.set(rowIndex, autoCells); table.lockedCellStates.set(rowIndex, locked); table.lockedCellMessages.set(rowIndex, messages);
  });
  project.networkZoningAutoValues = nextAutos; syncNetworkTableToLegacy(project, rows);
}

function airsideCellKey(row, column) {
  return `${String(row[0] ?? "")}::${column}`;
}

function recordAirsideOverride(table, row, column, value, project) {
  if (!table.airsideSettingsCalculation || !(table.autoColumns || []).includes(column) || !project) return;
  project.airsideOverrides ||= {};
  const key = airsideCellKey(row, column);
  const defaultValue = project.airsideAutoValues?.[key] ?? "";
  const normalized = isPercentageColumn(table, column)
    ? Number(String(value ?? "").replace(/%$/, "")) / 100
    : value;
  if (String(normalized ?? "") === String(defaultValue ?? "")) delete project.airsideOverrides[key];
  else project.airsideOverrides[key] = true;
}

function recordCoilOverride(table, row, column, value, project) {
  if (!table.coilCalculation || !(table.autoColumns || []).includes(column) || !project) return;
  project.coilOverrides ||= {};
  project.coilOverrides[table.id] ||= {};
  const key = airsideCellKey(row, column);
  const automatic = project.coilAutoValues?.[table.id]?.[key] ?? "";
  const normalized = isPercentageColumn(table, column) ? Number(String(value).replace(/%$/, "")) / 100 : Number(value);
  if (Number.isFinite(normalized) && Number(normalized) === Number(automatic)) delete project.coilOverrides[table.id][key];
  else project.coilOverrides[table.id][key] = true;
}

function recordPlantOverride(table, row, column, value, project) {
  if (!table.plantCalculation || !(table.autoColumns || []).includes(column) || !project) return;
  project.plantOverrides ||= {};
  project.plantOverrides[table.id] ||= {};
  const key = airsideCellKey(row, column).toLowerCase();
  const automatic = project.plantAutoValues?.[table.id]?.[key];
  const normalized = normalizedTableInput(table, column, value);
  const boolean = table.dropdownColumns?.[column]?.options?.includes("TRUE");
  if ((!boolean && normalized === "") || String(normalized) === String(automatic)) delete project.plantOverrides[table.id][key];
  else project.plantOverrides[table.id][key] = true;
}

function humidityRatioForPressure(dryBulbF, relativeHumidity, pressure) {
  const dryBulbC = (Number(dryBulbF) - 32) * 5 / 9;
  const saturationPressure = 0.145038 * 0.61094 * Math.exp((17.625 * dryBulbC) / (dryBulbC + 243.04));
  const vaporPressure = saturationPressure * Math.max(0, Math.min(1, Number(relativeHumidity) || 0));
  return 0.621945 * vaporPressure / (pressure - vaporPressure);
}

function relativeHumidityForRatio(dryBulbF, humidityRatioValue, pressure) {
  const dryBulbC = (Number(dryBulbF) - 32) * 5 / 9;
  const saturationPressure = 0.145038 * 0.61094 * Math.exp((17.625 * dryBulbC) / (dryBulbC + 243.04));
  const vaporPressure = Number(humidityRatioValue) * pressure / (0.621945 + Number(humidityRatioValue));
  return Math.max(0, Math.min(1, vaporPressure / saturationPressure));
}

function wetBulbFromState(dryBulbF, humidityRatioValue, pressure) {
  const cache=activeCalculationCache?(activeCalculationCache.wetBulbValues ||= new Map()):null;
  const key=[dryBulbF,humidityRatioValue,pressure].join('|');if(cache?.has(key))return cache.get(key);
  const value=wetBulbGrid(Number(dryBulbF),Number(humidityRatioValue),Number(pressure));cache?.set(key,value);return value;
}

function airConstantsForState(dryBulbF, humidityRatioValue, pressure) {
  const db = Number(dryBulbF) || 0;
  const hr = Number(humidityRatioValue) || 0;
  const density = 0.075 * (pressure / 14.696) * (530 / (db + 459.67)) / (1 + 1.6078 * hr);
  return {
    sensible: 60 * density * (0.241 + 0.444 * hr),
    latent: 60 * density * (1093 - 0.556 * db),
  };
}

function coilCalculationContext(project) {
  project.modelInputs = { ...modelInputDefaults, ...(project.modelInputs || {}) };
  const model = project.modelInputs;
  const calculated = modelInputCalculations(model);
  const zoningTable = independentTables.find((candidate) => candidate.id === "calc-equipment-zoning");
  const setpointTable = independentTables.find((candidate) => candidate.id === "calc-space-condition-setpoints");
  const zoningRows = zoningTable ? ensureProjectTableRows(project, zoningTable) : [];
  if (zoningTable) recalculateEquipmentZoning(zoningTable, zoningRows, project);
  const setpointRows = setpointTable ? ensureProjectTableRows(project, setpointTable) : [];
  const settingsTable = independentTables.find((candidate) => candidate.id === "airside-settings");
  const settingsRows = settingsTable ? ensureProjectTableRows(project, settingsTable) : [];
  if (settingsTable) recalculateAirsideSettings(settingsTable, settingsRows, project);
  return {
    model,
    calculated,
    pressure: calculated.pressure,
    zoningRows,
    setpointsBySpace: new Map(setpointRows.map((row) => [String(row[0] ?? ""), row])),
    settingsByEquipment: new Map(settingsRows.map((row) => [String(row[0] ?? "").toLowerCase(), row])),
    settingsRows,
  };
}

function averageServedCondition(context, equipment, temperatureColumn, humidityColumn) {
  const key = String(equipment).toLowerCase();
  const spaces = [...new Set(context.zoningRows
    .filter((row) => [3, 4, 5, 6, 7, 8, 9, 10].some((column) => String(row[column] ?? "").toLowerCase() === key))
    .map((row) => String(row[2] ?? "")).filter(Boolean))];
  const values = spaces.map((space) => context.setpointsBySpace.get(space)).filter(Boolean);
  const average = (column) => {
    const numbers = values.filter((row) => row[column] !== "" && row[column] !== null && row[column] !== undefined)
      .map((row) => Number(row[column])).filter(Number.isFinite);
    return numbers.length ? numbers.reduce((sum, value) => sum + value, 0) / numbers.length : 0;
  };
  return { dryBulb: average(temperatureColumn), humidityRatio: average(humidityColumn), spaces };
}

function recalculateCoilTable(table, rows, project, sharedContext = null) {
  const airflows = equipmentAirflowMap(project);
  const context = sharedContext || coilCalculationContext(project);
  project.coilOverrides ||= {}; project.coilOverrides[table.id] ||= {};
  project.coilAutoValues ||= {}; project.coilAutoValues[table.id] ||= {};
  const overrides = project.coilOverrides[table.id];
  const previousAutos = project.coilAutoValues[table.id];
  const nextAutos = {};
  table.autoCellStates = new Map(); table.lockedCellStates = new Map(); table.lockedCellMessages = new Map(); table.mutedCellStates = new Map();
  const applyAuto = (row, autoCells, column, value) => {
    const key = airsideCellKey(row, column);
    if (overrides[key] && Number(row[column]) === Number(value)) delete overrides[key];
    if (!overrides[key] && previousAutos[key] !== undefined && row[column] !== "" && Number(row[column]) !== Number(previousAutos[key]) && Number(row[column]) !== Number(value)) overrides[key] = true;
    if (!overrides[key]) { row[column] = value; autoCells.add(column); }
    nextAutos[key] = value;
  };
  const lockRange = (row, locked, messages, start, end, message) => {
    for (let column = start; column <= end; column += 1) {
      row[column] = ""; locked.add(column); messages.set(column, message); delete overrides[airsideCellKey(row, column)];
    }
  };
  const state = (db, hr) => ({ db, hr, wb: wetBulbFromState(db, hr, context.pressure), ...airConstantsForState(db, hr, context.pressure) });
  const heatingMode = ["heating", "in-unit-reheat", "downstream-reheat", "room-air-heating"].includes(table.coilCalculation);
  const preheatTable = heatingMode ? independentTables.find((candidate) => candidate.id === "airside-preheat") : null;
  const preheatRows = preheatTable ? ensureProjectTableRows(project, preheatTable, context) : [];
  if (preheatTable && preheatRows.length && !context.calculatedCoils?.has(preheatTable.id)) recalculateCoilTable(preheatTable, preheatRows, project, context);
  const coolingRows = new Map();
  if (heatingMode) for (const id of ["airside-ventilation-cooling", "airside-room-cooling"]) {
    const source = independentTables.find((candidate) => candidate.id === id);
    if (!source) continue;
    const sourceRows = ensureProjectTableRows(project, source, context);
    if (sourceRows.length && !context.calculatedCoils?.has(id)) recalculateCoilTable(source, sourceRows, project, context);
    sourceRows.forEach((coolingRow) => coolingRows.set(`${id}:${String(coolingRow[0] ?? "").toLowerCase()}`, coolingRow));
  }
  const plantFlow = (plantName, capacity, cooling) => {
    const id = cooling ? "cooling-plant" : "heating-plant";
    const plantTable = independentTables.find((candidate) => candidate.id === id);
    const plants = plantTable ? (project.independentTables?.[id] || ensureProjectTableRows(project, plantTable)) : [];
    const plant = plants.find((candidate) => String(candidate[0] ?? "").toLowerCase() === String(plantName ?? "").toLowerCase());
    if (!plant) return 0;
    const offset = cooling ? 12 : 10;
    if (String(plant[offset] ?? "TRUE").toUpperCase() !== "TRUE") return 0;
    const delta = Math.abs(Number(plant[offset + 2]) - Number(plant[offset + 1]));
    const cp = Number(plant[offset + 4]) || 1;
    const density = Number(plant[offset + 5]) || 8.34;
    return delta > 0 ? Math.max(0, Number(capacity) || 0) * 1000 / (60 * cp * density * delta) : 0;
  };

  rows.forEach((row, rowIndex) => {
    const equipment = String(row[0] ?? "");
    const autoCells = new Set(); const locked = new Set(); const messages = new Map();
    const flow = airflows?.get(requirementKey(equipment));
    if(flow) {
      if(table.coilCalculation==="preheat")row[9]=flow[1];
      else if(table.coilCalculation==="ventilation-cooling") [20,29,38].forEach(c=>row[c]=flow[1]);
      else if(table.coilCalculation==="room-air-cooling")row[38]=flow[4];
      else if(table.coilCalculation==="room-air-heating")row[15]=flow[5];
    }
    if (table.coilCalculation === "preheat") {
      applyAuto(row, autoCells, 1, 38);
      const entering = state(Number(context.model.heatingDb) || 0, context.calculated.heatingHr);
      row[5] = entering.db; row[6] = entering.hr; row[7] = entering.wb; row[8] = entering.sensible;
      const leaving = state(row[1], entering.hr);
      row[2] = entering.hr; row[3] = leaving.wb; row[4] = leaving.sensible;
      row[10] = entering.sensible * (leaving.db - entering.db) * (Number(row[9]) || 0) / 1000;
      row[12] = plantFlow(row[11], row[10], false);
    } else if (["cooling", "ventilation-cooling", "room-air-cooling"].includes(table.coilCalculation)) {
      const key = equipment.toLowerCase();
      const isVentilation = context.zoningRows.some((candidate) => String(candidate[3] ?? "").toLowerCase() === key);
      const isCentral = context.zoningRows.some((candidate) => String(candidate[4] ?? "").toLowerCase() === key);
      const isCooling = context.zoningRows.some((candidate) => String(candidate[9] ?? "").toLowerCase() === key);
      const justCooling = isCooling && !isVentilation && !isCentral;
      if (justCooling || table.coilCalculation === "room-air-cooling") lockRange(row, locked, messages, 1, 8, "Dehumidification mode is only used by ventilation cooling coils.");
      else {
        applyAuto(row, autoCells, 3, 50); applyAuto(row, autoCells, 4, 0.994);
        const dehumLeaving = state(row[3], humidityRatioForPressure(row[3], row[4], context.pressure));
        row[5] = dehumLeaving.hr; row[6] = dehumLeaving.wb; row[7] = dehumLeaving.sensible; row[8] = dehumLeaving.latent;
      }
      applyAuto(row, autoCells, 9, 55); applyAuto(row, autoCells, 10, 0.994);
      const normalLeaving = state(row[9], humidityRatioForPressure(row[9], row[10], context.pressure));
      row[11] = normalLeaving.hr; row[12] = normalLeaving.wb; row[13] = normalLeaving.sensible; row[14] = normalLeaving.latent;
      const populateEntering = (start, entering, leavingStart, airflowColumn) => {
        row[start] = entering.db; row[start + 1] = entering.hr; row[start + 2] = entering.wb; row[start + 3] = entering.sensible; row[start + 4] = entering.latent;
        const airflow = Number(row[airflowColumn]) || 0;
        row[start + 6] = entering.sensible * (entering.db - Number(row[leavingStart])) * airflow / 1000;
        row[start + 7] = entering.latent * (entering.hr - Number(row[leavingStart + 2])) * airflow / 1000;
        row[start + 8] = row[start + 6] + row[start + 7];
      };
      if (isVentilation) {
        populateEntering(15, state(Number(context.model.coolingDb) || 0, context.calculated.coolingHr), 9, 20);
        populateEntering(24, state(Number(context.model.dehumidificationDb) || 0, context.calculated.dehumidificationHr), justCooling ? 9 : 3, 29);
      } else {
        lockRange(row, locked, messages, 15, 23, "This equipment is not used as ventilation equipment.");
        lockRange(row, locked, messages, 24, 32, "This equipment is not used as ventilation equipment.");
      }
      const room = averageServedCondition(context, equipment, 8, 10);
      populateEntering(33, state(room.dryBulb, room.humidityRatio), 9, 38);
      if (table.coilCalculation === "room-air-cooling") {
        row[42] = Number(row[39]) || 0;
        row[43] = Number(row[40]) || 0;
      } else {
        const coolingWins = (Number(row[23]) || 0) >= (Number(row[32]) || 0);
        row[42] = Number(row[coolingWins ? 21 : 30]) || 0;
        row[43] = Number(row[coolingWins ? 22 : 31]) || 0;
        if (table.coilCalculation === "ventilation-cooling" && isVentilation) {
          const muted = coolingWins ? Array.from({ length: 9 }, (_, index) => index + 24) : Array.from({ length: 9 }, (_, index) => index + 15);
          table.mutedCellStates.set(rowIndex, new Set(muted));
        }
      }
      row[44] = row[42] + row[43];
      row[46] = plantFlow(row[45], row[44], true);
    } else if (["heating", "in-unit-reheat", "downstream-reheat", "room-air-heating"].includes(table.coilCalculation)) {
      applyAuto(row, autoCells, 1, table.coilCalculation === "in-unit-reheat" ? 73 : 90);
      const room = averageServedCondition(context, equipment, 3, 5);
      const roomState = state(room.dryBulb, room.humidityRatio);
      const inUnit = table.coilCalculation === "in-unit-reheat";
      const downstream = table.coilCalculation === "downstream-reheat";
      const useRoom = table.coilCalculation === "room-air-heating";
      const related = context.zoningRows.find((candidate) => String(candidate[downstream ? 6 : useRoom ? 10 : 3] ?? "").toLowerCase() === equipment.toLowerCase()
        || (inUnit && String(candidate[4] ?? "").toLowerCase() === equipment.toLowerCase()));
      const upstream = inUnit ? equipment : String(related?.[4] || related?.[3] || "");
      const upstreamVentilation = context.zoningRows.some((candidate) => String(candidate[3] ?? "").toLowerCase() === upstream.toLowerCase());
      const coolingId = upstreamVentilation ? "airside-ventilation-cooling" : "airside-room-cooling";
      const cooled = coolingRows.get(`${coolingId}:${upstream.toLowerCase()}`);
      const dehumidified = upstreamVentilation && cooled && cooled[3] !== "" && cooled[5] !== "";
      const inlet = dehumidified ? { db: cooled[3], hr: cooled[5], airflow: cooled[29] }
        : cooled ? { db: cooled[9], hr: cooled[11], airflow: cooled[upstreamVentilation ? 20 : 38] } : null;
      const preheat = preheatRows.find((candidate) => String(candidate[0] ?? "").toLowerCase() === upstream.toLowerCase());
      const candidates = [preheat ? preheat[1] : upstreamVentilation ? context.model.heatingDb : null,
        cooled ? cooled[upstreamVentilation ? 3 : 9] : null].filter((v) => v !== "" && v != null && Number.isFinite(Number(v))).map(Number);
      const entering = !useRoom && candidates.length ? {
        db: Math.min(...candidates), hr: upstreamVentilation ? context.calculated.heatingHr : cooled?.[11] ?? roomState.hr,
        airflow: inlet?.airflow ?? preheat?.[9] ?? 0,
      } : null;
      const enteringState = entering ? state(Number(entering.db), Number(entering.hr)) : roomState;
      row[2] = useRoom ? roomState.hr : upstreamVentilation ? context.calculated.heatingHr : cooled?.[11] ?? "";
      const leaving = state(row[1], row[2]);
      row[3] = leaving.wb; row[4] = leaving.sensible;
      if (entering && !useRoom) {
        row[5] = enteringState.db; row[6] = enteringState.hr; row[7] = enteringState.wb; row[8] = enteringState.sensible;
        row[9] = flow ? (table.coilCalculation==="in-unit-reheat" && flow[5]==="" ? flow[1] : flow[5]) : Number(entering.airflow) || 0;
        row[10] = enteringState.sensible * (leaving.db - enteringState.db) * row[9] / 1000;
      } else lockRange(row, locked, messages, 5, 10, useRoom ? "Room air heating uses room air as its entering condition." : "Assign an upstream cooling or preheat coil to calculate entering air.");
      if(flow && !useRoom) {row[9]=table.coilCalculation==="in-unit-reheat" && flow[5]==="" ? flow[1] : flow[5];locked.delete(9);messages.delete(9);}
      row[11] = roomState.db; row[12] = roomState.hr; row[13] = roomState.wb; row[14] = roomState.sensible;
      row[16] = useRoom ? roomState.sensible * (leaving.db - roomState.db) * (Number(row[15]) || 0) / 1000 : 0;
      row[17] = useRoom ? row[16] : Number(row[10]) || 0;
      row[19] = plantFlow(row[18], row[17], false);
    }
    table.autoCellStates.set(rowIndex, autoCells); table.lockedCellStates.set(rowIndex, locked); table.lockedCellMessages.set(rowIndex, messages);
  });
  project.independentTables ||= {}; project.independentTables[table.id] = rows;
  project.coilAutoValues[table.id] = nextAutos;
  context.calculatedCoils?.add(table.id);
  if(table.coilCalculation==="ventilation-cooling" && !activeCalculationCache?.buildingEquipmentAirflows && !activeCalculationCache?.buildingLatentLoads) refreshLatentLoads(project,context);
}

function recalculateAirsideSettings(table, rows, project) {
  const pass=activeCalculationCache?.project===project?activeCalculationCache:null;
  if(pass){pass.completedCalculations ||= new Map();const key="recalculateAirsideSettings::"+table.id;
    if(pass.completedCalculations.get(key)===rows)return;pass.completedCalculations.set(key,rows);}

  const zoningTable = independentTables.find((candidate) => candidate.id === "calc-equipment-zoning");
  const zoningRows = zoningTable ? ensureProjectTableRows(project, zoningTable) : [];
  project.airsideOverrides ||= {};
  project.airsideAutoValues ||= {};
  const overrides = project.airsideOverrides;
  const previousAutos = project.airsideAutoValues;
  const nextAutos = {};
  table.autoCellStates = new Map();
  table.lockedCellStates = new Map();
  table.lockedCellMessages = new Map();
  table.validationCellStates = new Map();
  const matches = (value, equipment) => String(value ?? "").localeCompare(equipment, undefined, { sensitivity: "base" }) === 0;
  const servedByEquipment = new Map();
  zoningRows.forEach((candidate) => [3, 4, 5, 6, 7, 8, 9, 10].forEach((column) => {
    const key = String(candidate[column] ?? "").trim().toLowerCase();
    if (!key) return;
    if (!servedByEquipment.has(key)) servedByEquipment.set(key, []);
    servedByEquipment.get(key).push(candidate);
  }));
  const firstMatch = (column, equipment) => zoningRows.find((candidate) => matches(candidate[column], equipment));

  rows.forEach((row, rowIndex) => {
    const equipment = String(row[0] ?? "").trim();
    const servedRows = servedByEquipment.get(equipment.toLowerCase()) || [];
    const detail=independentTables.find(t=>t.id==='selected-exhaust-equipment'),detailRows=project.independentTables?.[detail?.id]||detail?.rows||[],validSpaces=new Set(zoningRows.map(r=>requirementKey(r[2])));
    row[1] = new Set([...servedRows.map(candidate=>requirementKey(candidate[2])),...detailRows.filter(r=>validSpaces.has(requirementKey(r[0]))&&[1,2].some(c=>String(r[c]??'').split(',').some(v=>requirementKey(v)===requirementKey(equipment)))).map(r=>requirementKey(r[0]))].filter(Boolean)).size;
    const autoCells = new Set();
    const lockedCells = new Set();
    const lockMessages = new Map();
    const applyAuto = (column, defaultValue) => {
      const key = airsideCellKey(row, column);
      const normalizedDefault = defaultValue ?? "";
      const equivalent = (left, right) => {
        const leftNumber = Number(left); const rightNumber = Number(right);
        return left !== "" && right !== "" && Number.isFinite(leftNumber) && Number.isFinite(rightNumber)
          ? Math.abs(leftNumber - rightNumber) < 1e-12 : String(left ?? "") === String(right ?? "");
      };
      if (overrides[key] && equivalent(row[column], normalizedDefault)) delete overrides[key];
      if (!overrides[key]) {
        const previous = previousAutos[key];
        const current = row[column] ?? "";
        if (previous === undefined && current !== "" && !equivalent(current, normalizedDefault)) overrides[key] = true;
        else if (previous !== undefined && current !== "" && !equivalent(current, previous) && !equivalent(current, normalizedDefault)) overrides[key] = true;
      }
      if (!overrides[key]) {
        row[column] = normalizedDefault;
        autoCells.add(column);
      }
      nextAutos[key] = normalizedDefault;
    };

    applyAuto(4, 1);
    applyAuto(5, 1 / Math.max(Number(row[4]) || 1, 1));
    const isVentilation = Boolean(firstMatch(3, equipment));
    [6, 7].forEach((column) => {
      if (isVentilation) { if (String(row[column]).toUpperCase() === "FALSE") { row[column] = ""; overrides[airsideCellKey(row, column)] = true; } applyAuto(column, "TRUE"); }
      else {
        row[column] = "";
        lockedCells.add(column);
        lockMessages.set(column, "Equipment must appear in Equipment Zoning > Ventilation Equipment to make this cell editable.");
        delete overrides[airsideCellKey(row, column)];
      }
    });
    [8, 9].forEach((column) => {
      if (String(row[7] ?? "").toUpperCase() === "TRUE") applyAuto(column, 1);
      else {
        row[column] = "";
        lockedCells.add(column);
        lockMessages.set(column, "Set Ventilation Cooling Coil to TRUE to make this cell editable.");
        delete overrides[airsideCellKey(row, column)];
      }
    });
    // Energy is an explicit selection; it is never rewritten merely by focusing an EZ value.
    if (!["", "ER", "Econ"].includes(String(row[10] ?? ""))) row[10] = "";

    const reheatRow = firstMatch(6, equipment);
    const supplyValveRow = firstMatch(5, equipment);
    const exhaustValveRow = firstMatch(8, equipment);
    const centralRows = servedRows.filter((candidate) => matches(candidate[4], equipment));
    const isCentral = centralRows.length > 0;
    const hasReheat = centralRows.some((candidate) => String(candidate[6] ?? "").trim() !== "");
    const downstreamRhcs = [...new Set(centralRows.map((candidate) => String(candidate[6] ?? "").trim()).filter(Boolean))];
    const isCoolingRecirc = servedRows.some((candidate) => matches(candidate[9], equipment));
    const isHeatingRecirc = servedRows.some((candidate) => matches(candidate[10], equipment));
    if (isCoolingRecirc && isHeatingRecirc) row[11] = "CLG&HTG Recirc";
    else if (isCoolingRecirc) row[11] = "CLG Recirc";
    else if (isHeatingRecirc) row[11] = "HTG Recirc";
    else if (isCentral && downstreamRhcs.length) row[11] = `${downstreamRhcs.length} Downstream RHC${downstreamRhcs.length === 1 ? "" : "s"}`;
    else if (reheatRow) row[11] = `${reheatRow[4] || reheatRow[3] || ""} RHC`.trim();
    else if (supplyValveRow) row[11] = `${supplyValveRow[4] || ""} Valve`.trim();
    else if (exhaustValveRow) row[11] = `${exhaustValveRow[7] || ""} Valve`.trim();
    else if (isVentilation && String(row[7]).toUpperCase() === "TRUE" && !isCentral) row[11] = "In Unit RHC";
    else if (!isVentilation && isCentral && !hasReheat) row[11] = "In Unit RHC";
    else if (servedRows.some((candidate) => matches(candidate[7], equipment) && String(candidate[8] ?? "").trim())) row[11] = "Exhaust Fan";
    else row[11] = "";

    const roles = [
      [3, "Ventilation Equipment"], [4, "Central Equipment"], [5, "Supply Air Valve"], [6, "Reheat Coil"],
      [7, "Exhaust Equipment"], [8, "General Exhaust Valve"], [9, "Cooling Equipment"], [10, "Heating Equipment"],
    ];
    const conflictingRoles = roles.filter(([column]) => servedRows.some((candidate) => matches(candidate[column], equipment)))
      .filter(([column]) => ![3, 4, 7, 9, 10].includes(column));
    if (conflictingRoles.length > 1) {
      table.validationCellStates.set(rowIndex, new Map([[11, `Equipment cannot be used in all roles at once. Also assigned as: ${conflictingRoles.map(([, label]) => label).join(", ")}.`]]));
    }

    table.autoCellStates.set(rowIndex, autoCells);
    table.lockedCellStates.set(rowIndex, lockedCells);
    table.lockedCellMessages.set(rowIndex, lockMessages);
  });
  project.airsideAutoValues = nextAutos;
}

function recalculateEquipmentZoning(table, rows, project) {
  const pass=activeCalculationCache?.project===project?activeCalculationCache:null;
  if(pass){pass.completedCalculations ||= new Map();const key="recalculateEquipmentZoning::"+table.id;
    if(pass.completedCalculations.get(key)===rows)return;pass.completedCalculations.set(key,rows);}

  const reportTable = independentTables.find((candidate) => candidate.id === "room-zone-loads-report");
  const reportRows = reportTable ? ensureProjectTableRows(project, reportTable) : [];
  const reportByRoom = new Map(reportRows.map((row) => [String(row[2] ?? ""), row]));
  project.zoningOverrides ||= {};
  project.zoningOverrides[table.id] ||= {};
  project.zoningAutoValues ||= {};
  project.zoningAutoValues[table.id] ||= {};
  const overrides = project.zoningOverrides[table.id];
  const previousAutos = project.zoningAutoValues[table.id];
  const nextAutos = {};
  table.autoCellStates = new Map();
  table.lockedCellStates = new Map();
  table.lockedCellMessages = new Map();

  rows.forEach((row, rowIndex) => {
    const report = reportByRoom.get(String(row[2] ?? ""));
    if (report) { row[0] = report[0] ?? ""; row[1] = report[1] ?? ""; }
    const autoCells = new Set();
    const lockedCells = new Set();
    const lockMessages = new Map();
    const applyAuto = (column, defaultValue) => {
      const key = zoningCellKey(row, column);
      const normalizedDefault = defaultValue ?? "";
      if (overrides[key] && String(row[column] ?? "") === String(normalizedDefault)) delete overrides[key];
      if (!overrides[key]) {
        const previous = previousAutos[key];
        const current = row[column] ?? "";
        if (previous === undefined && current !== "" && String(current) !== String(normalizedDefault)) overrides[key] = true;
        else if (previous !== undefined && current !== "" && String(current) !== String(previous) && String(current) !== String(normalizedDefault)) overrides[key] = true;
      }
      if (!overrides[key]) {
        row[column] = normalizedDefault;
        autoCells.add(column);
      }
      nextAutos[key] = normalizedDefault;
    };

    const lock = (column, message) => {
      lockedCells.add(column);
      lockMessages.set(column, message);
      row[column] = "";
      delete overrides[zoningCellKey(row, column)];
    };

    if (row[9]) lock(4, "Clear Cooling Equipment to make Central Equipment editable.");
    else {
      const centralKey = zoningCellKey(row, 4);
      // A central assignment that matched the previous ventilation equipment
      // follows that equipment when it changes, even if it was typed manually.
      if (previousAutos[centralKey] !== undefined
        && String(row[4] ?? "") === String(previousAutos[centralKey])) delete overrides[centralKey];
      applyAuto(4, row[3] || "");
    }

    if (!row[4]) lock(5, "Populate AHU to make Supply Air Valve editable.");

    if (!row[4]) lock(6, "Populate AHU to make Reheat Coil editable.");
    else if (row[10]) lock(6, "Clear Heating Equipment to make Reheat Coil editable.");
    else applyAuto(6, row[5] || "");

    applyAuto(7, row[3]);
    if (!row[7]) lock(8, "Populate Exhaust Equipment to make General Exhaust Valve editable.");

    if (row[4]) lock(9, "Clear AHU to make Cooling Equipment editable.");

    applyAuto(10, row[9] || "");
    table.autoCellStates.set(rowIndex, autoCells);
    table.lockedCellStates.set(rowIndex, lockedCells);
    table.lockedCellMessages.set(rowIndex, lockMessages);
  });
  project.zoningAutoValues[table.id] = nextAutos;
}

function recalculatePlantTable(table, rows, project) {
  const cooling = table.plantCalculation === "cooling";
  const coilIds = cooling ? ['airside-ventilation-cooling','airside-room-cooling'] : ['airside-preheat','airside-in-unit-reheat','airside-downstream-reheat','airside-room-heating'];
  const coilRows=[];
  for(const id of coilIds){const source=independentTables.find(t=>t.id===id);if(!source)continue;const rs=ensureProjectTableRows(project,source);recalculateCoilTable(source,rs,project);for(const row of rs)coilRows.push({row,capacity:id==='airside-preheat'?10:cooling?44:17,plant:id==='airside-preheat'?11:cooling?45:18});}
  const settingsTable=independentTables.find(t=>t.id==='airside-settings'),settingsRows=ensureProjectTableRows(project,settingsTable);recalculateAirsideSettings(settingsTable,settingsRows,project);
  const quantities=new Map(settingsRows.map(r=>[requirementKey(r[0]),r[4]===''?1:Number(r[4])]));
  const equipmentStart = cooling ? 8 : 7;
  const waterStart = cooling ? 12 : 10;
  table.autoCellStates = new Map(); table.lockedCellStates = new Map(); table.lockedCellMessages = new Map(); table.mutedCellStates = new Map();
  project.plantAutoValues ||= {};
  project.plantAutoValues[table.id] ||= {};
  project.plantOverrides ||= {};
  project.plantOverrides[table.id] ||= {};
  const previous = project.plantAutoValues[table.id];
  const overrides = project.plantOverrides[table.id];
  const next = {};
  const nist = independentTables.find((candidate) => candidate.id === "water-nist-properties")?.rows || [];
  const waterProperties = (temperature) => {
    const sorted = nist.filter((source) => Number.isFinite(Number(source[0]))).slice().sort((a, b) => Number(a[0]) - Number(b[0]));
    if (!sorted.length) return { cp: 1, density: 8.34 };
    const low = [...sorted].reverse().find((source) => Number(source[0]) <= temperature) || sorted[0];
    const high = sorted.find((source) => Number(source[0]) >= temperature) || sorted.at(-1);
    const fraction = low === high ? 0 : (temperature - Number(low[0])) / (Number(high[0]) - Number(low[0]));
    const interpolate = (column) => Number(low[column]) + fraction * (Number(high[column]) - Number(low[column]));
    return { cp: interpolate(8), density: interpolate(2) / 7.48052 };
  };
  const glycolProperty = (tableId, temperature, concentration) => {
    const source = independentTables.find((candidate) => candidate.id === tableId);
    if (!source) return NaN;
    const columns = source.headers.map((header, index) => ({ concentration: Number(String(header.label).replace("%", "")), index }))
      .filter((item) => item.index > 0 && Number.isFinite(item.concentration));
    const lower = [...columns].reverse().find((item) => item.concentration <= concentration) || columns[0];
    const upper = columns.find((item) => item.concentration >= concentration) || columns.at(-1);
    if (!lower || !upper) return NaN;
    const atConcentration = (column) => {
      const valid = source.rows.filter((candidate) => Number.isFinite(Number(candidate[column])) && candidate[column] !== "")
        .sort((a, b) => Number(a[0]) - Number(b[0]));
      if (!valid.length) return NaN;
      const low = [...valid].reverse().find((candidate) => Number(candidate[0]) <= temperature) || valid[0];
      const high = valid.find((candidate) => Number(candidate[0]) >= temperature) || valid.at(-1);
      const fraction = low === high ? 0 : (temperature - Number(low[0])) / (Number(high[0]) - Number(low[0]));
      return Number(low[column]) + fraction * (Number(high[column]) - Number(low[column]));
    };
    const first = atConcentration(lower.index);
    const last = atConcentration(upper.index);
    const fraction = lower === upper ? 0 : (concentration - lower.concentration) / (upper.concentration - lower.concentration);
    return first + (last - first) * fraction;
  };
  rows.forEach((row, rowIndex) => {
    const plantName = String(row[0] ?? "").trim().toLowerCase();
    const serving = coilRows.filter(coil => requirementKey(coil.row[coil.plant]) === plantName);
    const sumOfPeaks = serving.reduce((sum, coil) => sum + requirementNumber(coil.row[coil.capacity]) * (quantities.get(requirementKey(coil.row[0])) ?? 1), 0);
    row[1] = serving.reduce((sum,coil)=>sum+(quantities.get(requirementKey(coil.row[0]))??1),0);
    row[2] = sumOfPeaks;
    const auto = new Set(); const locked = new Set(); const messages = new Map(); const muted = new Set();
    const automatic = (index, value) => {
      const key = `${plantName}::${index}`;
      if (overrides[key] && String(row[index] ?? "") === String(value)) delete overrides[key];
      if (!overrides[key] && previous[key] !== undefined && row[index] !== "" && String(row[index]) !== String(previous[key]) && String(row[index]) !== String(value)) overrides[key] = true;
      if (!overrides[key] && previous[key] === undefined && row[index] !== "" && row[index] != null && String(row[index]) !== String(value)) overrides[key] = true;
      if (!overrides[key]) { row[index] = value; auto.add(index); }
      next[key] = value;
    };
    const lock = (index, message) => { row[index] = ""; locked.add(index); messages.set(index, message); delete overrides[`${plantName}::${index}`]; };
    automatic(3, 1);
    const hasBlock = row[4] !== "" && row[4] !== null && row[4] !== undefined;
    if (hasBlock) { automatic(5, 0.1); }
    else lock(5, "Enter a Block Load to enable Safety Factor.");
    row[6] = Math.min(sumOfPeaks, sumOfPeaks * (Number(row[3]) || 0), ...(hasBlock ? [(Number(row[4]) || 0) * (1 + (Number(row[5]) || 0))] : []));
    if (row[6] === sumOfPeaks) [3,4,5].forEach(c=>muted.add(c));
    else if(hasBlock && row[6]===(Number(row[4])||0)*(1+(Number(row[5])||0))) [2,3].forEach(c=>muted.add(c));
    else [4,5].forEach(c=>muted.add(c));
    if (cooling) row[7] = row[6] / 12;
    automatic(equipmentStart, 1);
    automatic(equipmentStart + 1, 1);
    row[equipmentStart + 2] = (Number(row[equipmentStart]) || 0) > 0
      ? row[6] * (Number(row[equipmentStart + 1]) || 0) / Number(row[equipmentStart]) : 0;
    if (cooling) row[equipmentStart + 3] = row[equipmentStart + 2] / 12;
    automatic(waterStart, "TRUE");
    const waterEnabled = String(row[waterStart] ?? "").toUpperCase() === "TRUE";
    if (waterEnabled) {
      automatic(waterStart + 1, cooling ? 57 : 110);
      automatic(waterStart + 2, cooling ? 42 : 140);
      automatic(waterStart + 3, 0);
      const mean = ((Number(row[waterStart + 1]) || 0) + (Number(row[waterStart + 2]) || 0)) / 2;
      const properties = waterProperties(mean);
      const glycol = Math.max(0, Math.min(1, Number(row[waterStart + 3]) || 0));
      if (glycol > 0) {
        const cp = glycolProperty("water-propylene-specific-heat", mean, glycol * 100);
        const density = glycolProperty("water-propylene-density", mean, glycol * 100);
        if (Number.isFinite(cp)) properties.cp = cp;
        if (Number.isFinite(density)) properties.density = density / 7.48052;
      }
      row[waterStart + 4] = properties.cp;
      row[waterStart + 5] = properties.density;
      const difference = Math.abs(Number(row[waterStart + 2]) - Number(row[waterStart + 1]));
      const denominator = 60 * properties.cp * properties.density * difference;
      row[waterStart + 6] = denominator ? row[6] * 1000 / denominator : 0;
      row[waterStart + 7] = denominator ? row[equipmentStart + 2] * 1000 / denominator : 0;
    } else {
      for (let column = waterStart + 1; column <= waterStart + 3; column += 1) lock(column, "Set Water to TRUE to enable water inputs.");
      for (let column = waterStart + 4; column <= waterStart + 7; column += 1) row[column] = "";
    }
    table.autoCellStates.set(rowIndex, auto); table.lockedCellStates.set(rowIndex, locked); table.lockedCellMessages.set(rowIndex, messages); table.mutedCellStates.set(rowIndex, muted);
  });
  project.plantAutoValues[table.id] = next;
}

function requirementSourceRows(project, id) {
  const table = independentTables.find((candidate) => candidate.id === id);
  return table ? (project ? ensureProjectTableRows(project, table) : table.rows) : [];
}


function requirementKey(value) { return String(value ?? "").trim().toLowerCase(); }
function requirementNumber(value) { return numberFromTableValue(value) || 0; }
function requirementRound(value) { return Math.ceil(Math.max(0, value - 0.000001) / 5) * 5; }
function requirementScheduleValue(row, column) {
  const value = row?.[column];
  return value === "" || value === null || value === undefined ? "" : requirementNumber(value);
}

function recalculateGeneralExhaust(table, rows, project) {
  const pass=activeCalculationCache?.project===project?activeCalculationCache:null;
  if(pass){pass.completedCalculations ||= new Map();const key="recalculateGeneralExhaust::"+table.id;
    if(pass.completedCalculations.get(key)===rows)return;pass.completedCalculations.set(key,rows);}

  const zoning = new Map(requirementSourceRows(project, "calc-equipment-zoning").map((row) => [requirementKey(row[2]), row]));
  const schedules = new Map(requirementSourceRows(project, "schedule-general-exhaust").map((row) => [requirementKey(row[0]), row]));
  const people = new Map(requirementSourceRows(project, "calc-people-gains").map((row) => [requirementKey(row[0]), row]));
  const general = project?.independentTables?.["calc-general"] || globalThis.CALC_SECTION_TABLES?.find((source) => source.id === "calc-general")?.rows || [];
  const volumes = new Map(general.map((row) => [requirementKey(row[0]), row]));
  table.autoCellStates = new Map();
  table.lockedCellStates = new Map();
  table.lockedCellMessages = new Map();
  rows.forEach((row, index) => {
    const key = requirementKey(row[0]);
    const zone = zoning.get(key) || [];
    const schedule = schedules.get(requirementKey(row[4])) || [];
    const occupiedFixture = requirementScheduleValue(schedule, 1);
    const unoccupiedFixture = requirementScheduleValue(schedule, 2);
    const hasFixture = requirementNumber(occupiedFixture) > 0 || requirementNumber(unoccupiedFixture) > 0;
    const auto = new Set();
    if (!hasFixture) {
      row[5] = "";
      table.lockedCellStates.set(index, new Set([5]));
      table.lockedCellMessages.set(index, new Map([[5, "Select a requirement with an occupied or unoccupied fixture rate to set fixture quantity."]]));
    } else if (row[5] === "" || row[5] == null || Number(row[5]) === 1) {
      row[5] = 1;
      auto.add(5);
    }
    table.autoCellStates.set(index, auto);
    const quantity = requirementNumber(row[5]);
    const metadata = tabularMetadata(project, row[0]);
    row[1] = requirementNumber(metadata?.volume ?? volumes.get(key)?.[2]);
    row[2] = requirementNumber(metadata?.area ?? people.get(key)?.[2] ?? volumes.get(key)?.[3]);
    row[3] = zone[7] || "-";
    row[6] = occupiedFixture;
    row[7] = requirementScheduleValue(schedule, 3);
    row[8] = requirementScheduleValue(schedule, 5);
    row[9] = [row[6], row[7], row[8]].every((value) => value === "") ? ""
      : Math.max(requirementNumber(row[6]) * quantity, requirementNumber(row[7]) * row[2], requirementNumber(row[8]) * row[1] / 60);
    row[10] = unoccupiedFixture;
    row[11] = requirementScheduleValue(schedule, 4);
    row[12] = requirementScheduleValue(schedule, 6);
    row[13] = [row[10], row[11], row[12]].every((value) => value === "") ? ""
      : Math.max(requirementNumber(row[10]) * quantity, requirementNumber(row[11]) * row[2], requirementNumber(row[12]) * row[1] / 60);
  });
}

function recalculateEquipmentExhaust(table, rows, project) {
  const pass=activeCalculationCache?.project===project?activeCalculationCache:null;
  if(pass){pass.completedCalculations ||= new Map();const key="recalculateEquipmentExhaust::"+table.id;
    if(pass.completedCalculations.get(key)===rows)return;pass.completedCalculations.set(key,rows);}

  const zoning = new Map(requirementSourceRows(project, "calc-equipment-zoning").map((row) => [requirementKey(row[2]), row]));
  const schedules = new Map(requirementSourceRows(project, "schedule-exhaust-equipment").map((row) => [requirementKey(row[0]), row]));
  const previous = project?.exhaustEquipmentAutoValues || {};
  const next = {};
  table.autoCellStates = new Map();
  table.lockedCellStates = new Map();
  table.lockedCellMessages = new Map();
  rows.forEach((row, index) => {
    const proposed = zoning.get(requirementKey(row[0]))?.[7] || "-";
    const current = String(row[1] ?? "").trim();
    const auto = new Set();
    if (!current || current === previous[index] || (previous[index] === undefined && current === proposed)) {
      row[1] = proposed;
      auto.add(1);
    }
    if (requirementKey(row[1]) !== requirementKey(proposed)) {
      row[2] = "";
      table.lockedCellStates.set(index, new Set([2]));
      table.lockedCellMessages.set(index, new Map([[2, "Task/hood valve is only available for the zoned exhaust equipment."]]));
    }
    next[index] = proposed;
    if (row[4] === "" || row[4] == null || Number(row[4]) === 1) {
      row[4] = 1;
      auto.add(4);
    }
    table.autoCellStates.set(index, auto);
    const schedule = schedules.get(requirementKey(row[3])) || [];
    const quantity = requirementNumber(row[4]);
    const on = requirementScheduleValue(schedule, 1);
    const off = requirementScheduleValue(schedule, 2);
    row[5] = on === "" ? "" : on * quantity;
    row[6] = off === "" ? "" : off * quantity;
  });
  if (project) project.exhaustEquipmentAutoValues = next;
}

function recalculateVentilationRequirements(table, rows, project) {
  const pass=activeCalculationCache?.project===project?activeCalculationCache:null;
  if(pass){pass.completedCalculations ||= new Map();const key="recalculateVentilationRequirements::"+table.id;
    if(pass.completedCalculations.get(key)===rows)return;pass.completedCalculations.set(key,rows);}

  const zoning = new Map(requirementSourceRows(project, "calc-equipment-zoning").map((row) => [requirementKey(row[2]), row]));
  const setpoints = new Map(requirementSourceRows(project, "calc-space-condition-setpoints").map((row) => [requirementKey(row[0]), row]));
  const thermal = new Map(requirementSourceRows(project, "iesve-thermal-template").map((row) => [thermalTypeKey(row[0]), row]));
  const rates = new Map(requirementSourceRows(project, "ashrae-62-1-ventilation").map((row) => [requirementKey(row[0]), row]));
  const peopleTable = independentTables.find((candidate) => candidate.id === "calc-people-gains");
  const peopleRows = peopleTable ? requirementSourceRows(project, peopleTable.id) : [];
  if (peopleTable) recalculateGainTable(peopleTable, peopleRows, project);
  const people = new Map(peopleRows.map((row) => [requirementKey(row[0]), row]));
  const settings = new Map(requirementSourceRows(project, "airside-settings").map((row) => [requirementKey(row[0]), row]));
  project.ventilationEzAutos ||= {}; project.ventilationEzOverrides ||= {};
  table.lockedCellStates = new Map();
  const previous = project?.ventilationTypeAutos || {};
  const next = {};
  table.autoCellStates = new Map();
  rows.forEach((row, index) => {
    const space = requirementKey(row[1]);
    const zone = zoning.get(space) || [];
    row[0] = zone[3] || "-";
    const template = thermal.get(thermalTypeKey(setpoints.get(space)?.[1])) || [];
    const proposed = String(template[2] ?? "").trim();
    const current = String(row[2] ?? "").trim();
    if ((!template.length && !project?.ventilationTypeOverrides?.[space]) || !current || current === previous[space] || (previous[space] === undefined && current === proposed)) {
      row[2] = proposed;
      table.autoCellStates.set(index, new Set([2]));
    }
    next[space] = proposed;
    if (requirementKey(row[2]) === "no ventilation requirements") {
      table.lockedCellStates.set(index, new Set([10,12]));
      for (let column = 3; column < row.length; column += 1) row[column] = "-";
      return;
    }
    const rate = rates.get(requirementKey(row[2])) || [];
    row[3] = requirementNumber(rate[1]);
    row[4] = requirementNumber(rate[2]);
    row[5] = requirementNumber(people.get(space)?.[5]);
    row[6] = requirementNumber(people.get(space)?.[2]);
    row[7] = row[3] * row[5];
    row[8] = row[4] * row[6];
    row[9] = row[7] + row[8];
    const setting = settings.get(requirementKey(row[0])) || [];
    for (const [column, source] of [[10,8],[12,9]]) {
      const key = `${space}::${column}`, automatic = requirementNumber(setting[source]) || 1;
      project.ventilationEzAutos[key] = automatic;
      if (!project.ventilationEzOverrides[key]) {
        row[column] = automatic;
        table.autoCellStates.set(index, new Set([...(table.autoCellStates.get(index) || []), column]));
      }
    }
    row[11] = row[9] / row[10];
    row[13] = row[9] / row[12];
    const maximumVoz = Math.max(row[11], row[13]);
    row[14] = maximumVoz === 0 ? 0 : roundAirflowUp(Math.max(maximumVoz, airflowMinimum(project, table.id, 25)));
  });
  if (project) project.ventilationTypeAutos = next;
}

function recalculateExhaustRequirements(table, rows, project) {
  const pass=activeCalculationCache?.project===project?activeCalculationCache:null;
  if(pass){pass.completedCalculations ||= new Map();const key="recalculateExhaustRequirements::"+table.id;
    if(pass.completedCalculations.get(key)===rows)return;pass.completedCalculations.set(key,rows);}

  const zones = new Map(requirementSourceRows(project, "calc-equipment-zoning").map((row) => [requirementKey(row[2]), row]));
  const generalTable = independentTables.find((candidate) => candidate.id === "selected-general-exhaust");
  const equipmentTable = independentTables.find((candidate) => candidate.id === "selected-exhaust-equipment");
  const generalRows = generalTable ? requirementSourceRows(project, generalTable.id) : [];
  const equipmentRows = equipmentTable ? requirementSourceRows(project, equipmentTable.id) : [];
  if (generalTable) recalculateGeneralExhaust(generalTable, generalRows, project);
  if (equipmentTable) recalculateEquipmentExhaust(equipmentTable, equipmentRows, project);
  const sumFor = (source, space, column) => source.reduce((sum, candidate) =>
    requirementKey(candidate[0]) === space ? sum + requirementNumber(candidate[column]) : sum, 0);
  rows.forEach((row) => {
    const space = requirementKey(row[2]);
    const zone = zones.get(space) || [];
    row[0] = zone[7] || "-";
    row[1] = zone[8] || "-";
    const occupied = sumFor(generalRows, space, 9), unoccupied = sumFor(generalRows, space, 13);
    row[9] = occupied === 0 ? 0 : roundAirflowUp(Math.max(occupied, airflowMinimum(project, table.id, 25)));
    row[10] = unoccupied === 0 ? 0 : roundAirflowUp(unoccupied);
    const assigned = equipmentRows.filter((candidate) => requirementKey(candidate[0]) === space);
    const separate = assigned.filter((candidate) => {
      const equipment = requirementKey(candidate[1]);
      return equipment && equipment !== "-" && equipment !== requirementKey(row[0]);
    });
    const taskValves = assigned.filter((candidate) => {
      const valve = requirementKey(candidate[2]);
      return requirementKey(candidate[1]) === requirementKey(row[0]) && valve && valve !== "-"
        && valve !== requirementKey(row[1]);
    });
    row[3] = separate.reduce((total, candidate) => total + requirementNumber(candidate[5]), 0);
    row[4] = separate.reduce((total, candidate) => total + requirementNumber(candidate[6]), 0);
    row[5] = taskValves.reduce((total, candidate) => total + requirementNumber(candidate[5]), 0);
    row[6] = taskValves.reduce((total, candidate) => total + requirementNumber(candidate[6]), 0);
    const same=assigned.filter(r=>requirementKey(r[1])===requirementKey(row[0]) && requirementKey(r[2])===requirementKey(zone[8]));
    row[7]=same.reduce((sum,r)=>sum+requirementNumber(r[5]),0);row[8]=same.reduce((sum,r)=>sum+requirementNumber(r[6]),0);
    row[11]=Math.max(row[3]+row[5]+row[7],row[9]);row[12]=Math.max(row[4]+row[6]+row[8],row[9]);row[13]=Math.max(row[4]+row[6]+row[8],row[10]);
  });
}

function applyAirflowDefault(table,row,column,automatic,project,auto) {
  project.airflowAutos ||= {}; project.airflowOverrides ||= {};
  const key=`${table.id}::${requirementKey(row[0])}::${column}`;
  project.airflowAutos[key]=automatic;
  if (Object.hasOwn(project.airflowOverrides,key)) row[column]=project.airflowOverrides[key];
  else {row[column]=automatic;auto.add(column);}
}
function recalculateCombinedAirflowRequirements(table, rows, project) {
  const pass=activeCalculationCache?.project===project?activeCalculationCache:null;
  if(pass){pass.completedCalculations ||= new Map();const key="recalculateCombinedAirflowRequirements::"+table.id;
    if(pass.completedCalculations.get(key)===rows)return;pass.completedCalculations.set(key,rows);}

  table.lockedCellStates = new Map();
  const coolingTable = independentTables.find((candidate) => candidate.id === "calc-cooling-loads");
  const heatingTable = independentTables.find((candidate) => candidate.id === "calc-heating-loads");
  const coolingRows = coolingTable ? ensureProjectTableRows(project, coolingTable) : [];
  const heatingRows = heatingTable ? ensureProjectTableRows(project, heatingTable) : [];
  if (coolingTable) recalculateCoolingLoads(coolingRows, project);
  if (heatingTable) recalculateHeatingLoads(heatingRows, project);
  const coolingBySpace = new Map(coolingRows.map((row) => [requirementKey(row[0]), row]));
  const heatingBySpace = new Map(heatingRows.map((row) => [requirementKey(row[0]), row]));
  table.autoCellStates = new Map();
  rows.forEach((row, index) => {
    const cooling = coolingBySpace.get(requirementKey(row[0])) || [];
    const heating = heatingBySpace.get(requirementKey(row[0])) || [];
    for (let index = 1; index <= 5; index += 1) {
      row[index] = cooling[index] ?? "";
      row[index + 7] = heating[index] ?? "";
    }
    const minimum = airflowMinimum(project, table.id, 50);
    const auto=new Set(), locked=new Set();
    for (const [column,equipment,load,constant,roomDB,equipmentDB,output] of [[6,3,1,4,2,5,7],[13,10,8,11,9,12,14]]) {
      if (!row[equipment]) {row[column]="";row[output]="";locked.add(column);continue;}
      applyAirflowDefault(table,row,column,minimum,project,auto);
      const delta=column===6 ? Number(row[roomDB])-Number(row[equipmentDB]) : Number(row[equipmentDB])-Number(row[roomDB]);
      const calculated=Number(row[constant])>0 && delta>0 ? Number(row[load])*1000/(Number(row[constant])*delta) : 0;
      row[output]=roundAirflowUp(Math.max(calculated,Number(row[column])||0));
    }
    table.autoCellStates.set(index,auto); table.lockedCellStates.set(index,locked);
  });
}

function recordPressurizationOverride(table, row, column, value, project) {
  if (!table.pressurizationCalculation || column !== 7 || !project) return;
  project.pressurizationOverrides ||= {};
  const key = requirementKey(row[1]);
  if (String(value ?? "").toUpperCase() === "TRUE") project.pressurizationOverrides[key] = true;
  else delete project.pressurizationOverrides[key];
}

function recalculateWorkbookPressurization(table, rows, project) {
  const pass=activeCalculationCache?.project===project?activeCalculationCache:null;
  if(pass){pass.completedCalculations ||= new Map();const key="recalculateWorkbookPressurization::"+table.id;
    if(pass.completedCalculations.get(key)===rows)return;pass.completedCalculations.set(key,rows);}

  const byId = (id) => independentTables.find((candidate) => candidate.id === id);
  const source = (id) => { const table = byId(id); return table ? ensureProjectTableRows(project, table) : []; };
  const zoningTable = byId("calc-equipment-zoning"); const zones = source("calc-equipment-zoning");
  if (zoningTable) recalculateEquipmentZoning(zoningTable, zones, project);
  const settingsTable = byId("airside-settings"); const settingsRows = source("airside-settings");
  if (settingsTable) recalculateAirsideSettings(settingsTable, settingsRows, project);
  const ventilationTable = byId("calc-ventilation-exhaust"); const ventRows = source("calc-ventilation-exhaust");
  if (ventilationTable) recalculateVentilationRequirements(ventilationTable, ventRows, project);
  const exhaustTable = byId("calc-exhaust-requirements"); const exhRows = source("calc-exhaust-requirements");
  if (exhaustTable) recalculateExhaustRequirements(exhaustTable, exhRows, project);
  const airflowTable = byId("calc-airflow-requirements"); const airRows = source("calc-airflow-requirements");
  if (airflowTable) recalculateCombinedAirflowRequirements(airflowTable, airRows, project);
  const scheduleRows = source("schedule-pressurization-types");
  const lookup = (list, index) => new Map(list.map((row) => [requirementKey(row[index]), row]));
  const zoneBySpace = lookup(zones, 2), settingsByEq = lookup(settingsRows, 0);
  const ventBySpace = lookup(ventRows, 1), exhBySpace = lookup(exhRows, 2), airBySpace = lookup(airRows, 0);
  const percentByType = lookup(scheduleRows, 0);
  table.autoCellStates = new Map(); table.mutedCellStates = new Map();
  table.lockedCellStates = new Map(); table.lockedCellMessages = new Map();
  project.pressurizationOverrides ||= {};
  rows.forEach((row, index) => {
    const space = requirementKey(row[1]), zone = zoneBySpace.get(space) || [];
    row[0] = zone[0] ?? "";
    row[2] = firstAssignedEquipment(zone[3]); row[3] = firstAssignedEquipment(zone[4]);
    row[4] = firstAssignedEquipment(zone[5]); row[5] = firstAssignedEquipment(zone[6]);
    const energy = String(settingsByEq.get(requirementKey(row[2]))?.[10] ?? "").toLowerCase();
    row[6] = !row[2] ? "" : requirementKey(row[2]) !== requirementKey(row[3])
      ? "100% OA" : energy === "econ" ? "Econ RA" : "100% OSA";
    if (row[6] === "100% OSA") {
      row[7] = project.pressurizationOverrides[space] ? "TRUE" : "";
      if (!project.pressurizationOverrides[space]) table.autoCellStates.set(index, new Set([7]));
    } else {
      row[7] = ""; delete project.pressurizationOverrides[space];
      table.lockedCellStates.set(index, new Set([7]));
      table.lockedCellMessages.set(index, new Map([[7, "Only 100% OSA equipment can require the cooling and heating minimum."]]));
    }
    const vot = ventBySpace.get(space)?.[14];
    row[8] = vot === "-" || vot === undefined ? "" : vot;
    const af = airBySpace.get(space) || [];
    row[9] = row[7] === "TRUE" ? af[7] ?? "" : "";
    row[10] = row[7] === "TRUE" && row[5] ? af[14] ?? "" : "";
    if (row[6] === "Econ RA") row[11] = row[8] === "" ? "" : 1.5 * requirementNumber(row[8]);
    else if (row[6] === "100% OSA" && row[7] === "TRUE") {
      row[11] = Math.max(requirementNumber(row[8]), requirementNumber(row[9]), requirementNumber(row[10]));
      const maxFlow = row[11];
      table.mutedCellStates.set(index, new Set([8, 9, 10].filter((column) => row[column] !== "" && requirementNumber(row[column]) < maxFlow)));
    } else row[11] = row[6] ? row[8] : "";
    row[12] = exhBySpace.get(space)?.[11] ?? "";
    row[14] = percentByType.get(requirementKey(row[13]))?.[1] ?? "";
    const vent = requirementNumber(row[11]), exh = requirementNumber(row[12]), ratio = Number(row[14]);
    if (row[14] === "" || !Number.isFinite(ratio) || ratio <= 0) {
      row[15] = row[11]; row[16] = row[12];
    } else if (exh >= ratio * vent) {
      row[15] = roundAirflowUp(exh / ratio); row[16] = row[12];
    } else { row[15] = row[11]; row[16] = roundAirflowUp(ratio * vent); }
    row[19] = (row[15] === "" ? 0 : requirementNumber(row[15])) + requirementNumber(row[17]);
    row[20] = (row[16] === "" ? 0 : requirementNumber(row[16])) + requirementNumber(row[18]);
    row[21] = row[19] - row[20];
  });
}

function recalculateAirBalancingRequirements(table, rows, project) {
  const pass=activeCalculationCache?.project===project?activeCalculationCache:null;
  if(pass){pass.completedCalculations ||= new Map();const key="recalculateAirBalancingRequirements::"+table.id;
    if(pass.completedCalculations.get(key)===rows)return;pass.completedCalculations.set(key,rows);}

  const pressTable = independentTables.find((item) => item.id === "calc-pressurization");
  const pressRows = pressTable ? ensureProjectTableRows(project, pressTable) : [];
  if (pressTable) recalculateWorkbookPressurization(pressTable, pressRows, project);
  if (project.legacyManualBalances) {
    rows.forEach((row) => {
      const previous = project.legacyManualBalances[requirementKey(row[1])];
      if (row[7] === "" && previous !== undefined) row[7] = previous;
    });
    delete project.legacyManualBalances;
  }
  const transferTable = independentTables.find((item) => item.id === "selected-transfer-air");
  const transferRows = transferTable ? ensureProjectTableRows(project, transferTable) : [];
  const pressBySpace = new Map(pressRows.map((row) => [requirementKey(row[1]), row]));
  const zoneTable = independentTables.find((item) => item.id === "calc-equipment-zoning");
  const zoneBySpace = new Map((zoneTable ? ensureProjectTableRows(project, zoneTable) : []).map((row) => [requirementKey(row[2]), row[0]]));
  const transfersTo = new Map(), transfersFrom = new Map();
  transferRows.forEach((transfer) => {
    const from = requirementKey(transfer[4]), to = requirementKey(transfer[6]), amount = requirementNumber(transfer[5]);
    if (to) transfersTo.set(to, (transfersTo.get(to) || 0) + amount);
    if (from) transfersFrom.set(from, (transfersFrom.get(from) || 0) + amount);
  });
  rows.forEach((row) => {
    const space = requirementKey(row[1]), press = pressBySpace.get(space) || [];
    row[0] = zoneBySpace.get(space) ?? "";
    row[2] = press[19] ?? ""; row[3] = press[20] ?? "";
    row[4] = transfersTo.get(space) || 0; row[5] = transfersFrom.get(space) || 0;
    row[6] = requirementNumber(row[2]) - requirementNumber(row[3]) + row[4] - row[5];
    if (row[7] === "" || row[7] === undefined || row[7] === null) { row[8] = ""; row[9] = ""; }
    else { row[8] = Math.max(0, requirementNumber(row[7]) - row[6]); row[9] = Math.max(0, row[6] - requirementNumber(row[7])); }
    row[10] = requirementNumber(row[2]) + requirementNumber(row[8]);
    row[11] = requirementNumber(row[3]) + requirementNumber(row[9]);
    row[12] = row[10] - row[11];
  });
}

function recalculateTransferAir(table, rows, project) {
  const balance = independentTables.find((t) => t.id === "calc-air-balancing-requirements");
  const balanceRows = ensureProjectTableRows(project, balance);
  recalculateAirBalancingRequirements(balance, balanceRows, project);
  const bySpace = new Map(balanceRows.map((r) => [requirementKey(r[1]), r]));
  rows.forEach((row) => {
    for (const [space, pa, ta, ba, extra] of [[4,0,1,2,3],[6,10,9,8,7]]) {
      if (!row[space]) { [pa,ta,ba,extra].forEach((c) => row[c] = ""); continue; }
      const b = bySpace.get(requirementKey(row[space])) || [];
      row[pa] = requirementNumber(b[2]) - requirementNumber(b[3]);
      row[ta] = requirementNumber(b[5]) - requirementNumber(b[4]);
      row[ba] = row[pa] + row[ta]; row[extra] = requirementNumber(b[8]) - requirementNumber(b[9]);
    }
  });
}

function recalculatePeakAirflows(table, rows, project) {
  if(activeCalculationCache?.peakAirflowsCalculated===rows)return;
  const byId = (id) => independentTables.find((item) => item.id === id);
  const balanceTable = byId("calc-air-balancing-requirements");
  const balanceRows = balanceTable ? ensureProjectTableRows(project, balanceTable) : [];
  if (balanceTable) recalculateAirBalancingRequirements(balanceTable, balanceRows, project);
  const sources = (id) => { const table = byId(id); return table ? ensureProjectTableRows(project, table) : []; };
  const bySpace = (list, col = 0) => new Map(list.map((row) => [requirementKey(row[col]), row]));
  const zones = bySpace(sources("calc-equipment-zoning"), 2), air = bySpace(sources("calc-airflow-requirements"));
  const balance = bySpace(balanceRows, 1), loads = bySpace(sources("calc-room-loads")), setpoints = bySpace(sources("calc-space-condition-setpoints"));
  const settings = bySpace(sources("airside-settings"));
  const barometricPressure = modelInputCalculations({ ...modelInputDefaults, ...(project.modelInputs || {}) }).pressure;
  const coil = new Map();
  const coilContext = activeCalculationCache?.project === project && activeCalculationCache.coilContext
    ? activeCalculationCache.coilContext : coilCalculationContext(project);
  for (const id of ["airside-ventilation-cooling", "airside-room-cooling", "airside-in-unit-reheat", "airside-downstream-reheat", "airside-room-heating"]) {
    const coilTable = byId(id); if (!coilTable) continue;
    const coilRows = ensureProjectTableRows(project, coilTable, coilContext);
    coilRows.forEach((entry) => coil.set(requirementKey(entry[0]), { row: entry, cooling: id.includes("cooling") }));
  }
  const numeric = (value) => Number.isFinite(Number(value)) ? Number(value) : 0;
  table.autoCellStates=new Map();table.lockedCellStates=new Map();table.underPeakCellStates=new Map();project.peakAirflowAutos||={};
  const applyPeak=(row,index,column)=>{const key=requirementKey(row[0])+'::'+column,automatic=row[column];project.peakAirflowAutos[key]=automatic;if(automatic===''){table.lockedCellStates.get(index).add(column);return;}const override=project.peakAirflowOverrides?.[key];if(override===undefined||Number(override)===Number(automatic))table.autoCellStates.get(index).add(column);else{row[column]=override;if(Number(override)<Number(automatic))table.underPeakCellStates.get(index).add(column);}};
  rows.forEach((row, index) => {
    table.autoCellStates.set(index,new Set());table.lockedCellStates.set(index,new Set());table.underPeakCellStates.set(index,new Set());
    const space = requirementKey(row[0]), zone = zones.get(space) || [], airflow = air.get(space) || [];
    const balancing = balance.get(space) || [], load = loads.get(space) || [], setpoint = setpoints.get(space) || [];
    const central = firstAssignedEquipment(zone[4]), ventilation = firstAssignedEquipment(zone[3]);
    row[1] = firstAssignedEquipment(zone[9], zone[5], zone[4]);
    row[2] = airflow[7] ?? "";
    row[3] = row[1] && ventilation && requirementKey(ventilation) === requirementKey(central)
      ? balancing[10] ?? "" : "";
    row[4] = row[1] ? Math.max(numeric(row[2]), numeric(row[3])) : "";
    applyPeak(row,index,4);
    const cooling = coil.get(requirementKey(row[1])) || coil.get(requirementKey(central));
    const roomCoolingDB = numeric(setpoint[8]);
    row[5] = row[1] && cooling ? numeric(cooling.row[13]) * numeric(row[4]) * (roomCoolingDB - numeric(cooling.row[9])) / 1000 : "";
    const reheat = firstAssignedEquipment(zone[6]);
    row[6] = firstAssignedEquipment(reheat, zone[10]); row[7] = airflow[14] ?? "";
    row[8] = row[6] && reheat && requirementKey(row[6]) === requirementKey(reheat) && requirementKey(ventilation) === requirementKey(central)
      ? balancing[10] ?? "" : "";
    const econ = String(settings.get(requirementKey(central))?.[10] ?? "").toLowerCase() === "econ";
    row[9] = reheat && requirementKey(row[6]) === requirementKey(reheat) && econ && row[4] !== ""
      ? Math.floor(numeric(row[4]) / 10) * 5 : "";
    const demand = Math.max(numeric(row[8]), numeric(row[7]));
    row[10] = !row[6] ? "" : row[9] === "" ? demand : Math.min(demand, Math.max(numeric(row[8]), numeric(row[9])));
    applyPeak(row,index,10);
    const heating = coil.get(requirementKey(row[6]));
    const roomHeatingDB = numeric(setpoint[3]);
    row[11] = row[6] && heating ? numeric(heating.row[4]) * numeric(row[10]) * (numeric(heating.row[1]) - roomHeatingDB) / 1000 : "";
    const remaining = row[6] ? Math.max(0, numeric(load[17]) - numeric(row[11])) : "";
    row[12] = remaining === 0 ? "-" : remaining;
    row[13] = remaining > 0 ? setpoint[3] ?? "" : "";
    row[14] = remaining > 0 && reheat && requirementKey(row[6]) === requirementKey(reheat) ? firstAssignedEquipment(zone[10]) || "PFP Box" : "";
    const secondary = coil.get(requirementKey(row[14]));
    const leavingDB = row[14] === "PFP Box" ? numeric(heating?.row[1]) : numeric(secondary?.row[1]);
    row[16] = row[14] ? leavingDB || "" : "";
    const humidity = numeric(setpoint[5]);
    row[15] = row[14] === "PFP Box" && leavingDB ? airConstantsForState(leavingDB, humidity, barometricPressure).sensible
      : secondary?.row[4] ?? "";
    const delta = numeric(row[16]) - numeric(row[13]);
    row[17] = row[14] && numeric(row[15]) > 0 && delta > 0
      ? numeric(row[12]) * 1000 / (numeric(row[15]) * delta) : "";
    applyPeak(row,index,17);
    row[18] = row[17] !== "" ? numeric(row[15]) * numeric(row[17]) * delta / 1000 : "";
  });
  if(activeCalculationCache)activeCalculationCache.peakAirflowsCalculated=rows;
}

function recalculateSystemAirBalance(table, rows, project) {
  const pass=activeCalculationCache?.project===project?activeCalculationCache:null;
  if(pass){pass.completedCalculations ||= new Map();const key="recalculateSystemAirBalance::"+table.id;
    if(pass.completedCalculations.get(key)===rows)return;pass.completedCalculations.set(key,rows);}

  const byId = (id) => independentTables.find((candidate) => candidate.id === id);
  const source = (id) => {
    const table = byId(id);
    return table ? ensureProjectTableRows(project, table) : [];
  };
  const peakTable = byId("calc-peak-airflows");
  const peakRows = source("calc-peak-airflows");
  if (peakTable) recalculatePeakAirflows(peakTable, peakRows, project);
  const index = (list, column = 0) => new Map(list.map((row) => [requirementKey(row[column]), row]));
  const peakBySpace = index(peakRows);
  const balances = index(source("calc-air-balancing-requirements"), 1);
  const exhausts = index(source("calc-exhaust-requirements"), 2);
  const pressurization = index(source("calc-pressurization"), 1);
  const settings = index(source("airside-settings"));
  const taskValves = new Map();
  source("selected-exhaust-equipment").forEach((row) => {
    const space = requirementKey(row[0]);
    if (!taskValves.has(space)) taskValves.set(space, []);
    taskValves.get(space).push(firstAssignedEquipment(row[2]));
  });
  const numeric = requirementNumber;
  const next = [];
  source("calc-equipment-zoning").forEach((zone) => {
    const space = String(zone[2] ?? "").trim();
    if (!space) return;
    const key = requirementKey(space), central = firstAssignedEquipment(zone[4]), ventilation = firstAssignedEquipment(zone[3]);
    const energy = String(settings.get(requirementKey(central))?.[10] ?? "").trim().toLowerCase();
    const cooling = firstAssignedEquipment(zone[9]), heating = firstAssignedEquipment(zone[10]);
    const exhaustOnly = !ventilation && !central && !cooling && !heating
      && [zone[8], ...(taskValves.get(key) || [])].some((value) => firstAssignedEquipment(value));
    const mode = exhaustOnly ? "ahu-oa" : !central ? "doas-zone" : ventilation && requirementKey(ventilation) === requirementKey(central)
      ? energy === "econ" ? "ahu-economizing" : "ahu-oa" : "doas-ahu";
    if (mode !== table.systemAirBalanceMode) return;
    const peak = peakBySpace.get(key) || [], balance = balances.get(key) || [], exhaust = exhausts.get(key) || [];
    const primaryEquipment = mode === "doas-zone" ? cooling : central;
    const separateHeating = heating && !(mode === "doas-zone" && firstAssignedEquipment(zone[6])) && requirementKey(heating) !== requirementKey(primaryEquipment)
      && (mode === "doas-zone" || requirementKey(heating) !== requirementKey(zone[6])) ? heating : "";
    const equipmentPeak = (equipment, includeSecondary = true) => {
      if (!equipment) return "";
      const id = requirementKey(equipment);
      return Math.max(requirementKey(peak[1]) === id ? numeric(peak[4]) : 0,
        requirementKey(peak[6]) === id ? numeric(peak[10]) : 0,
        includeSecondary && requirementKey(peak[14]) === id ? numeric(peak[17]) : 0);
    };
    const centralHeating = firstAssignedEquipment(peak[6]) && [central, zone[6]].some((equipment) =>
      firstAssignedEquipment(equipment) && requirementKey(equipment) === requirementKey(peak[6])) ? numeric(peak[10]) : 0;
    const centralSupply = central ? Math.max(numeric(peak[4]), centralHeating) : "";
    const occupiedVentilation = numeric(balance[10]), occupiedExhaust = numeric(balance[11]);
    let pressure = occupiedVentilation - occupiedExhaust;
    const transferIn = numeric(balance[4]), transferOut = numeric(balance[5]);
    const maximumSupply = mode === "ahu-oa" ? Math.max(numeric(peak[4]), numeric(peak[10])) : Math.max(numeric(centralSupply), occupiedVentilation);
    if (mode === "ahu-oa") pressure = maximumSupply - occupiedExhaust;
    const minimumOccupiedSupply = mode === "ahu-oa"
      ? Math.max(numeric(pressurization.get(key)?.[11]), pressure + numeric(exhaust[12]), 0) : occupiedVentilation;
    const minimumUnoccupiedSupply = Math.max(0, pressure + numeric(exhaust[13]));
    const valves = [...new Map([zone[8], ...(taskValves.get(key) || [])].map((value) => firstAssignedEquipment(value))
      .filter((value) => value && requirementKey(value) !== requirementKey(zone[7]))
      .map((value) => [requirementKey(value), value])).values()].sort((a, b) => a.localeCompare(b));
    const values = {
      space, ventilationEquipment: ventilation, occupiedVentilation,
      exhaustEquipment: firstAssignedEquipment(zone[7]), occupiedExhaust,
      occupiedPressure: pressure, pressure, occupiedTransferIn: transferIn, transferIn,
      occupiedTransferOut: transferOut, transferOut,
      occupiedBalanced: pressure + transferIn - transferOut, balanced: pressure + transferIn - transferOut,
      coolingEquipment: cooling, coolingSupply: equipmentPeak(cooling, false), coolingReturn: equipmentPeak(cooling, false),
      heatingEquipment: separateHeating, heatingSupply: mode === "doas-zone" ? separateHeating ? numeric(peak[10]) : "" : equipmentPeak(separateHeating),
      heatingReturn: mode === "doas-zone" ? separateHeating ? numeric(peak[10]) : "" : equipmentPeak(separateHeating),
      centralEquipment: central, supplyValve: firstAssignedEquipment(zone[5]), centralSupply, centralReturn: centralSupply,
      maximumSupply, minimumOccupiedSupply, minimumUnoccupiedSupply,
      exhaustValves: valves.join(", "), maximumExhaust: occupiedExhaust,
      minimumOccupiedExhaust: minimumOccupiedSupply - pressure,
      minimumUnoccupiedExhaust: minimumUnoccupiedSupply - pressure,
      requiredVentilation: occupiedVentilation,
      returnToCentral: Math.max(0, maximumSupply - occupiedExhaust),
      returnToValve: Math.max(0, maximumSupply - occupiedVentilation),
    };
    next.push(table.balanceFields.map((field) => values[field] ?? ""));
  });
  rows.splice(0, rows.length, ...next);
}

function equipmentReturnEquation(column) {
  const dz="[DOAS & Zone Recirculation Air Balance]",ahu="[AHU with 100% OA Air Balance]",req="[Exhaust Equipment Requirements]",ex="[Exhaust Airflow Requirements]",z="[Equipment Zoning]";
  const sum=(table,key,flow)=>`SUMIF(${table}@${key},@Tag,${table}@${flow})`;
  const maximum=column===6, unoccupied=column===8, flow=maximum?"Maximum":"Minimum";
  const direct=`${sum(req,"Exhaust Equipment",flow)}+${sum(req,"Same Exhaust Valve",flow)}`;
  const doas=unoccupied ? `SUM(SUMIF(${ex}@Space,FILTER(${dz}@Space,${dz}@Exhaust Equipment=@Tag,""),${ex}@Unoccupied Minimum))` : sum(dz,"Exhaust Equipment","Occupied Exhaust Airflow");
  const label=maximum?"Maximum Exhaust Airflow":unoccupied?"Minimum Unoccupied Exhaust Airflow":"Minimum Occupied Exhaust Airflow";
  const subtract=maximum?"Minimum":"Maximum";
  const equipment=`${doas}+${sum(ahu,"Exhaust Equipment",label)}-${sum(ex,"Exhaust Equipment",`Separate Equipment ${subtract}`)}`;
  const valveSum=`SUMPRODUCT(--ISNUMBER(SEARCH(","&@Tag&",",","&SUBSTITUTE(${ahu}@Exhaust Air Valves,", ",",")&",")),${ahu}@${label})`;
  const valve=`${valveSum}-${sum(ex,"General Exhaust Valve",`Separate Equipment ${subtract}`)}-${sum(ex,"General Exhaust Valve",`Different Valve ${subtract}`)}`;
  const wrap=(x,key)=>maximum?x:`MAX(0,${sum(ex,key,"Same Valve/Equipment Minimum")},${x})`;
  const core=`IF(COUNTIF(${z}@Exhaust Equipment,@Tag)+COUNTIF(${z}@General Exhaust Valve,@Tag)=0,${direct},IF(COUNTIF(${z}@Exhaust Equipment,@Tag)>0,${wrap(equipment,"Exhaust Equipment")},IF(COUNTIF(${z}@General Exhaust Valve,@Tag)>0,${wrap(valve,"General Exhaust Valve")},0)))`;
  return maximum ? `=IF(COUNTIF(${dz}@Zone Recirculation Equipment (1),@Tag)+COUNTIF(${dz}@Zone Recirculation Equipment (2),@Tag)>0,${sum(dz,"Zone Recirculation Equipment (1)","Maximum Return Airflow (1)")}+${sum(dz,"Zone Recirculation Equipment (2)","Maximum Return Airflow (2)")},\n${core})` : `=${core}`;
}
function equipmentReturnValue(tag,column,zoning,details,exhaust,sources) {
  const dz=sources["calc-doas-zone-air-balance"]||[],ahu=sources["calc-ahu-oa-air-balance"]||[];
  const sum=(rows,key,flow,split=false)=>rows.reduce((n,r)=>n+(String(r[key]??"").split(split?",":"\u0000").some(v=>requirementKey(v)===tag)?requirementNumber(r[flow]):0),0);
  const maximum=column===6, unoccupied=column===8;
  if(maximum && dz.some(r=>[r.coolingEquipment,r.heatingEquipment].some(v=>requirementKey(v)===tag)))return sum(dz,"coolingEquipment","coolingReturn")+sum(dz,"heatingEquipment","heatingReturn");
  const isEquipment=zoning.some(r=>requirementKey(r[7])===tag),isValve=zoning.some(r=>requirementKey(r[8])===tag);
  if(!isEquipment&&!isValve)return sum(details,1,maximum?5:6)+sum(details,2,maximum?5:6);
  const field=maximum?"maximumExhaust":unoccupied?"minimumUnoccupiedExhaust":"minimumOccupiedExhaust";
  const separate=maximum?4:3,different=maximum?6:5;
  if(isEquipment) {
    const doas=unoccupied ? dz.filter(r=>requirementKey(r.exhaustEquipment)===tag).reduce((n,r)=>n+exhaust.filter(e=>requirementKey(e[2])===requirementKey(r.space)).reduce((v,e)=>v+requirementNumber(e[13]),0),0) : sum(dz,"exhaustEquipment","occupiedExhaust");
    const result=doas+sum(ahu,"exhaustEquipment",field)-sum(exhaust,0,separate);
    return maximum?result:Math.max(0,sum(exhaust,0,8),result);
  }
  const result=sum(ahu,"exhaustValves",field,true)-sum(exhaust,1,separate)-sum(exhaust,1,different);
  return maximum?result:Math.max(0,sum(exhaust,1,8),result);
}

function equipmentAirflowRules(column) {
  const dz="calc-doas-zone-air-balance", ahu="calc-ahu-oa-air-balance";
  const supplyMax=[[dz,"ventilationEquipment","occupiedVentilation"],[dz,"coolingEquipment","coolingSupply"],[dz,"heatingEquipment","heatingSupply"],[ahu,"centralEquipment","maximumSupply"],[ahu,"supplyValve","maximumSupply"]];
  const supplyOcc=[[dz,"ventilationEquipment","occupiedVentilation"],[ahu,"centralEquipment","minimumOccupiedSupply"],[ahu,"supplyValve","minimumOccupiedSupply"]];
  const supplyUnocc=[[ahu,"centralEquipment","minimumUnoccupiedSupply"],[ahu,"supplyValve","minimumUnoccupiedSupply"]];
  const returnMax=[[dz,"exhaustEquipment","occupiedExhaust"],[dz,"coolingEquipment","coolingReturn"],[dz,"heatingEquipment","heatingReturn"],[ahu,"exhaustEquipment","maximumExhaust"],[ahu,"exhaustValves","maximumExhaust"]];
  const returnOcc=[[dz,"exhaustEquipment","occupiedExhaust"],[ahu,"exhaustEquipment","minimumOccupiedExhaust"],[ahu,"exhaustValves","minimumOccupiedExhaust"]];
  const returnUnocc=[[ahu,"exhaustEquipment","minimumUnoccupiedExhaust"],[ahu,"exhaustValves","minimumUnoccupiedExhaust"]];
  return ({1:supplyMax,2:supplyOcc,3:supplyUnocc,6:returnMax,7:returnOcc,8:returnUnocc})[column] || [];
}
function equipmentAirflowEquation(column) {
  const association=column<=3 ? 'IF(COUNTIF([Equipment Zoning]@Reheat Coil,@Tag)>0,XLOOKUP(@Tag,[Equipment Zoning]@Reheat Coil,[Equipment Zoning]@Supply Air Valve),@Tag)'
    : column===5 ? 'IF(COUNTIF([Equipment Zoning]@Supply Air Valve,@Tag)>0,XLOOKUP(@Tag,[Equipment Zoning]@Supply Air Valve,[Equipment Zoning]@Reheat Coil),@Tag)' : '@Tag';
  let terms;
  if(column===4)terms=['SUMIF([Peak Airflows]@Primary Cooling Equipment,equipment,[Peak Airflows]@Primary Cooling Peak)'];
  else if(column===5)terms=['SUMIF([Peak Airflows]@Primary Heating Equipment,equipment,[Peak Airflows]@Primary Heating Peak)','SUMIF([Peak Airflows]@Secondary Equipment,equipment,[Peak Airflows]@Secondary Heating Peak)'];
  else terms=equipmentAirflowRules(column).map(([id,tag,flow])=>{
    const t=independentTables.find(t=>t.id===id), label=f=>spaceFilterColumnLabel(t,t.balanceFields.indexOf(f));
    const tags=`[${t.name}]@[${label(tag)}]`, flows=`[${t.name}]@[${label(flow)}]`;
    return tag==='exhaustValves' ? `SUMPRODUCT(--ISNUMBER(SEARCH(","&equipment&",",","&SUBSTITUTE(${tags},", ",",")&",")),${flows})` : `SUMIF(${tags},equipment,${flows})`;
  });
  return `=LET(equipment,${association},\n${terms.join(" +\n")})`;
}
const equipmentFlowCache = new WeakMap();
function equipmentFlowSignature(project) {
  const inputs=independentTables.filter(t=>!t.plantCalculation && !t.equipmentAirflowsCalculation && !t.equipmentScheduleCalculation && !t.psychCalculation).map(t=>{
    const columns=t.headers.map((_,i)=>i).filter(i=>!(t.calculatedColumns||[]).includes(i)&&!(t.lockedColumns||[]).includes(i));
    const rows=project.independentTables?.[t.id]||t.rows;
    return [t.id,rows.map(r=>[r[0],...columns.map(c=>r[c])])];
  });
  return JSON.stringify([inputs,project.modelInputs,project.calcSettings,project.clipboardImports,project.excelImports,project.zoningOverrides,project.coilOverrides,project.airsideOverrides,project.airflowOverrides,project.pressurizationOverrides,project.ventilationEzOverrides,project.ventilationTypeOverrides,project.spaceLoadFactorOverrides]);
}
function equipmentAirflowMap(project) {
  if(activeCalculationCache?.buildingEquipmentAirflows)return null;
  if(activeCalculationCache?.equipmentAirflows)return activeCalculationCache.equipmentAirflows;
  const cached=equipmentFlowCache.get(project);
  if(cached?.signature===equipmentFlowSignature(project)){
    if(activeCalculationCache)activeCalculationCache.equipmentAirflows=cached.rows;
    return cached.rows;
  }
  const owns=!activeCalculationCache;
  if(owns)activeCalculationCache={project};
  try {
    const table=independentTables.find(t=>t.equipmentAirflowsCalculation);
    const rows=ensureProjectTableRows(project,table);
    recalculateEquipmentAirflows(table,rows,project);
    return new Map(rows.map(r=>[requirementKey(r[0]),r]));
  } finally {if(owns)activeCalculationCache=null;}
}
function recalculateEquipmentAirflows(table, rows, project) {
  const owns=!activeCalculationCache;
  if(owns)activeCalculationCache={project};
  const pass=activeCalculationCache;
  if(pass.buildingEquipmentAirflows)return;
  pass.buildingEquipmentAirflows=true;
  try {
    const source=id=>{const t=independentTables.find(t=>t.id===id);return ensureProjectTableRows(project,t);};
    const zoning=source("calc-equipment-zoning");
    const peakTable=independentTables.find(t=>t.peakAirflowCalculation),peaks=source(peakTable.id);
    recalculatePeakAirflows(peakTable,peaks,project);
    const sources={};
    for(const id of ["calc-doas-zone-air-balance","calc-ahu-oa-air-balance"]) {
      const t=independentTables.find(t=>t.id===id),r=source(id);recalculateSystemAirBalance(t,r,project);
      sources[id]=r.map(row=>Object.fromEntries(t.balanceFields.map((f,i)=>[f,row[i]])));
    }
    const settingsTable=independentTables.find(t=>t.airsideSettingsCalculation),settings=source(settingsTable.id);recalculateAirsideSettings(settingsTable,settings,project);
    const percentages=new Map(settings.map(r=>[requirementKey(r[0]),r[5]===""?1:Number(r[5])]));
    const details=source("selected-exhaust-equipment"),exhaust=source("calc-exhaust-requirements");
    table.autoCellStates=new Map();table.cellDisplayEquations=new Map();
    rows.forEach((row,index)=>{
      const tag=requirementKey(row[0]),reheat=zoning.find(z=>requirementKey(z[6])===tag),valve=zoning.find(z=>requirementKey(z[5])===tag);
      const loadPercentage=percentages.get(tag)??1;
      const supplyTag=reheat ? requirementKey(reheat[5]) : tag;
      const designTag=valve ? requirementKey(valve[6]) : tag;
      const auto=new Set();
      for(const c of [1,2,3,6,7,8]) {
        const key=c<=3?supplyTag:tag;
        const total=c>=6 ? equipmentReturnValue(tag,c,zoning,details,exhaust,sources) : key ? equipmentAirflowRules(c).reduce((sum,[id,tagField,flow])=>sum+sources[id].reduce((n,r)=>n+(String(r[tagField]??"").split(tagField==='exhaustValves'?",":"\u0000").some(v=>requirementKey(v)===key)?requirementNumber(r[flow]):0),0),0):0;
        if([1,6].includes(c))applyAirflowDefault(table,row,c,total*loadPercentage,project,auto);else row[c]=total*loadPercentage;
      }
      const cooling=tag?peaks.filter(r=>requirementKey(r[1])===tag):[];
      const heating=designTag?peaks.filter(r=>requirementKey(r[6])===designTag||requirementKey(r[14])===designTag):[];
      row[4]=cooling.length?cooling.reduce((sum,r)=>sum+requirementNumber(r[4]),0):"";
      row[5]=heating.length?heating.reduce((sum,r)=>sum+(requirementKey(r[6])===designTag?requirementNumber(r[10]):0)+(requirementKey(r[14])===designTag?requirementNumber(r[17]):0),0):"";
      for(const c of [4,5])if(row[c]!=="")row[c]*=loadPercentage;
      table.autoCellStates.set(index,auto);
    });
    pass.equipmentAirflows=new Map(rows.map(r=>[requirementKey(r[0]),r]));
    equipmentFlowCache.set(project,{signature:equipmentFlowSignature(project),rows:new Map(rows.map(r=>[requirementKey(r[0]),[...r]]))});
    pass.coilContext?.calculatedCoils?.clear();
  } finally {pass.buildingEquipmentAirflows=false;if(owns)activeCalculationCache=null;}
}

function refreshLatentLoads(project, sharedContext = null) {
  const owns=!activeCalculationCache;if(owns)activeCalculationCache={project};
  const pass=activeCalculationCache;
  if(pass.buildingLatentLoads || pass.buildingEquipmentAirflows){if(owns)activeCalculationCache=null;return;}
  pass.buildingLatentLoads=true;
  try {
    const table=independentTables.find(t=>t.latentLoadCalculation),rows=ensureProjectTableRows(project,table);
    const get=id=>{const t=independentTables.find(t=>t.id===id);return [t,ensureProjectTableRows(project,t)];};
    const context=sharedContext||coilCalculationContext(project);
    const [ventTable,vents]=get('airside-ventilation-cooling'),[roomTable,rooms]=get('airside-room-cooling');
    if(!context.calculatedCoils?.has(ventTable.id))recalculateCoilTable(ventTable,vents,project,context);
    if(!context.calculatedCoils?.has(roomTable.id))recalculateCoilTable(roomTable,rooms,project,context);
    const [loadTable,loads]=get('calc-room-loads');recalculateRoomLoadTable(loads,project);
    const [conditionTable,conditions]=get('calc-space-condition-setpoints');recalculateConditionSchedules(conditionTable,conditions,project);
    const [peakTable,peaks]=get('calc-peak-airflows');recalculatePeakAirflows(peakTable,peaks,project);
    const [balanceTable,balances]=get('calc-air-balancing-requirements');recalculateAirBalancingRequirements(balanceTable,balances,project);
    const [,zones]=get('calc-equipment-zoning');
    calculateLatentRows(table,rows,{loads,conditions,peaks,balances,zones,vents,rooms,pressure:context.pressure});
    vents.forEach(r=>{
      const related=rows.filter(x=>requirementKey(x[3])===requirementKey(r[0]));
      r[1]=related.reduce((n,x)=>n+requirementNumber(x[15]),0);
      const temperatures=related.map(x=>x[16]).filter(v=>typeof v==='number'&&Number.isFinite(v));
      r[2]=temperatures.length?Math.min(...temperatures):'';
    });
  } finally {pass.buildingLatentLoads=false;if(owns)activeCalculationCache=null;}
}
function calculateLatentRows(table,rows,sources) {
  const map=(rs,col=0)=>new Map(rs.map(r=>[requirementKey(r[col]),r]));
  const loads=map(sources.loads),conditions=map(sources.conditions),peaks=map(sources.peaks),balances=map(sources.balances,1),zones=map(sources.zones,2),vents=map(sources.vents),rooms=map(sources.rooms);
  table.validationCellStates=new Map();
  rows.forEach((r,index)=>{
    const key=requirementKey(r[0]),zone=zones.get(key)||[],peak=peaks.get(key)||[],condition=conditions.get(key)||[];
    const vent=vents.get(requirementKey(zone[3]));
    r.fill('',1);r[1]=requirementNumber(loads.get(key)?.[13]);r[2]=condition[10]??'';
    r[3]=vent?zone[3]:'-';
    if(vent){r[4]=vent[3];r[5]=vent[5];r[6]=vent[8];r[7]=requirementKey(zone[3])===requirementKey(zone[4])?requirementNumber(peak[4]):requirementNumber(balances.get(key)?.[10]);r[8]=requirementNumber(r[6])*r[7]*(requirementNumber(r[2])-requirementNumber(r[5]))/1000;}
    r[9]=vent&&requirementKey(r[3])===requirementKey(zone[4])?'-':firstAssignedEquipment(zone[9],zone[5],zone[4])||'-';
    const primary=rooms.get(requirementKey(r[9]));
    if(r[9]!=='-')r[13]=requirementNumber(peak[4]);
    if(primary){r[10]=primary[9];r[11]=primary[11];r[12]=primary[14];r[14]=requirementNumber(r[12])*requirementNumber(r[13])*(requirementNumber(r[2])-requirementNumber(r[11]))/1000;}
    r[15]=Math.max(0,r[1]-requirementNumber(r[8])-requirementNumber(r[14]));
    if(r[15]>0 && vent && r[7]>0 && r[6]>0) {
      const hr=requirementNumber(r[2])-(requirementNumber(r[8])+r[15])*1000/(r[6]*r[7]);
      const vp=hr*sources.pressure/(0.621945+hr),sat=vp/requirementNumber(vent[4]);
      const alpha=Math.log(sat/(0.145038*0.61094)),db=243.04*alpha/(17.625-alpha)*9/5+32;
      if(hr>0&&sat>0&&Number.isFinite(db))r[16]=Math.trunc(db*10)/10;
      else table.validationCellStates.set(index,new Map([[16,'The required humidity ratio is not positive. More airflow or another source of dehumidification is needed.']]));
    }
  });
}

function recalculateTable(table, rows, project = activeProject()) {
  if(table.psychCalculation)return;
  if(table.equipmentScheduleCalculation){recalculateEquipmentSchedule(table,rows,project);return;}
  const ownsPass = !activeCalculationCache;
  if (ownsPass) activeCalculationCache = { project };
  try { return calculateTableCore(table, rows, project); }
  finally { if (ownsPass) activeCalculationCache = null; }
}

function calculateTableCore(table, rows, project) {
  if(table.energySimulation)return;
  if(table.energySummary){recalculateEnergySummary(table,rows,project);return;}
  if(table.conditionBaselineCalculation){recalculateConditionBaseline(table,rows,project);return;}
  if(table.latentLoadCalculation){refreshLatentLoads(project);return;}
  if (table.equipmentAirflowsCalculation) { recalculateEquipmentAirflows(table, rows, project); return; }
  if (table.transferAirCalculation) { recalculateTransferAir(table, rows, project); return; }
  if (table.tabularCalculation) { recalculateTabularSpaceData(table, rows, project); return; }
  if (table.conditionScheduleCalculation) { recalculateConditionSchedules(table, rows, project); return; }
  if (table.scheduleCalculation) { recalculateConsumptionSchedules(table, rows, project); return; }
  if (table.thermalTemplateCalculation) { recalculateThermalTemplates(table, rows, project); return; }
  if (table.systemAirBalanceMode) { recalculateSystemAirBalance(table, rows, project); return; }
  if (table.peakAirflowCalculation) { recalculatePeakAirflows(table, rows, project); return; }
  if (table.airBalancingCalculation) { recalculateAirBalancingRequirements(table, rows, project); return; }
  if (table.pressurizationCalculation) { recalculateWorkbookPressurization(table, rows, project); return; }
  if (table.combinedAirflowCalculation) { recalculateCombinedAirflowRequirements(table, rows, project); return; }
  if (table.exhaustRequirementsCalculation) { recalculateExhaustRequirements(table, rows, project); return; }
  if (table.ventilationRequirementsCalculation) { recalculateVentilationRequirements(table, rows, project); return; }
  if (table.generalExhaustCalculation) { recalculateGeneralExhaust(table, rows, project); return; }
  if (table.equipmentExhaustCalculation) { recalculateEquipmentExhaust(table, rows, project); return; }
  if (table.airsideSettingsCalculation) {
    recalculateAirsideSettings(table, rows, project);
    return;
  }
  if (table.coilCalculation) {
    recalculateCoilTable(table, rows, project);
    return;
  }
  if (table.plantCalculation) {
    recalculatePlantTable(table, rows, project);
    return;
  }
  if (table.equipmentZoningCalculation) {
    recalculateEquipmentZoning(table, rows, project);
    return;
  }
  if (table.zoningNetworkTableCalculation) {
    recalculateNetworkZoningTable(project);
    return;
  }
  if (table.roomLoadCalculation) {
    recalculateRoomLoadTable(rows, project);
    return;
  }
  if (table.heatingLoadCalculation) {
    recalculateHeatingLoads(rows, project);
    return;
  }
  if (table.coolingLoadCalculation) {
    recalculateCoolingLoads(rows, project);
    return;
  }
  if (table.miscLoadCalculation) {
    recalculateMiscLoadTable(table, rows, project);
    return;
  }
  if (table.gainCalculation) {
    recalculateGainTable(table, rows, project);
    return;
  }
  if (table.preserveImportedValues) return;
  if (table.calculation === "grouped-equipment-schedule") {
    const equipmentTable = independentTables.find((candidate) => candidate.id === "schedule-equipment-sensible-gain");
    if (equipmentTable) recalculateTable(equipmentTable, ensureProjectTableRows(project, equipmentTable), project);
  }

  const equations = tableEquations(table);
  (table.calculatedColumns || []).slice().sort((left, right) => left - right).forEach((column) => {
    rows.forEach((row) => {
      if (row[0] === "" || row[0] === null || row[0] === undefined) {
        row[column] = "";
      } else {
        row[column] = evaluateProjectEquation(equations[column] || "=0", table, row, rows, project);
      }
    });
  });
}

function recalculateDependentTables(table, project = activeProject()) {
  if (table.id !== "schedule-equipment-sensible-gain") return;
  const groupedTable = independentTables.find((candidate) => candidate.id === "schedule-grouped-equipment-sensible-gain");
  if (groupedTable) recalculateTable(groupedTable, ensureProjectTableRows(project, groupedTable), project);
}

function saveEquationEdit() {
  return;

  if (!selectedEquationContext) return;
  const { table, column } = selectedEquationContext;
  const equation = selectedEquation.value.trim();
  if (!equation.startsWith("=")) {
    formulaError.textContent = "Equations must begin with =";
    formulaError.hidden = false;
    return;
  }

  const previous = equationOverrides[table.id]?.[column];
  equationOverrides[table.id] ||= {};
  equationOverrides[table.id][column] = equation;
  try {
    if (projects.length) {
      projects.forEach((project) => {
        recalculateTable(table, ensureProjectTableRows(project, table), project);
        recalculateDependentTables(table, project);
      });
    } else {
      recalculateTable(table, table.rows, null);
      recalculateDependentTables(table, null);
    }
  } catch (error) {
    if (previous === undefined) delete equationOverrides[table.id][column];
    else equationOverrides[table.id][column] = previous;
    formulaError.textContent = error.message || "This equation could not be calculated.";
    formulaError.hidden = false;
    return;
  }

  localStorage.setItem(EQUATION_OVERRIDES_KEY, JSON.stringify(equationOverrides));
  saveProjects();
  selectedEquation.readOnly = true;
  displayFormulaFunctions(selectedEquation.value);
  editEquationButton.hidden = true;
  saveEquationButton.hidden = true;
  cancelEquationButton.hidden = true;
  formulaError.hidden = true;
  refreshRenderedTableValues(table, projectTableRows(table));
}

function numberFromTableValue(value) {
  const number = Number(String(value ?? "").replace(/,/g, ""));
  return Number.isFinite(number) ? number : 0;
}

function compareTableValues(left, right) {
  const leftBlank = left === null || left === undefined || left === "";
  const rightBlank = right === null || right === undefined || right === "";
  if (leftBlank !== rightBlank) return leftBlank ? 1 : -1;
  if (typeof left === "number" && typeof right === "number") return left - right;
  return String(left ?? "").localeCompare(String(right ?? ""), undefined, { numeric: true, sensitivity: "base" });
}

function calculateColumnWidths(table, headers, rows, dropdownOptionsByColumn = null) {
  const context = document.createElement("canvas").getContext("2d");
  return headers.map((header, index) => {
    if (table.hiddenColumns?.includes(index)) return 0;
    context.font = '11px Aptos, "Segoe UI", Arial, sans-serif';
    const contentWidth = rows.reduce((maximum, row) => Math.max(maximum, ...String(formatTableValue(row[index], table, index)).split("\n").map(line=>context.measureText(line).width)), index===0&&table.summaryLabel?context.measureText(table.summaryLabel).width:0);
    const dropdownWidth = table.dropdownColumns?.[index]
      ? (dropdownOptionsByColumn?.get(index) || tableDropdownOptions(table, index))
        .reduce((maximum, option) => Math.max(maximum, context.measureText(option).width), 0)
      : 0;
    context.font = '700 12px Aptos, "Segoe UI", Arial, sans-serif';
    const labelWidth = Math.max(0, ...String(`${header.label || ""}${header.subscript || ""}`).split(/[\s-]+/).map((word) => context.measureText(word).width)) + 46;
    context.font = '650 10px Aptos, "Segoe UI", Arial, sans-serif';
    const unitWidth = Math.max(0, ...String(header.unit || "").split(/[\s-]+/).map((word) => context.measureText(word).width)) + 42;
    const numericColumn = table.columnTypes[index] === "number";
    const minimumWidth = table.dropdownColumns?.[index] ? 96 : numericColumn ? 68 : 78;
    return Math.ceil(Math.max(minimumWidth, contentWidth + (table.dropdownColumns?.[index] ? 68 : 24), dropdownWidth + (table.dropdownColumns?.[index] ? 68 : 0), labelWidth, unitWidth));
  });
}

function autoFitRenderedTable(table, headers, rows) {
  const widths = calculateColumnWidths(table, headers, rows);
  referenceTable.querySelectorAll("col").forEach((column, index) => {
    column.style.width = `${widths[index]}px`;
  });
  referenceTable.style.width = `${widths.reduce((total, width) => total + width, 0)}px`;
  referenceTable.style.setProperty("--first-column-width", `${widths[0] || 0}px`);
  referenceTable.style.setProperty("--second-column-width", `${widths[1] || 0}px`);
  referenceTable.style.setProperty("--third-column-width", `${widths[2] || 0}px`);
  [3, 4].forEach((index) => referenceTable.style.setProperty(`--frozen-left-${index + 1}`, `${widths.slice(0, index + 1).reduce((total, width) => total + width, 0)}px`));
  applyTableFreezeLayout(table, widths);
}

function applyTableFreezeLayout(table, widths) {
  const frozen = table.frozenColumns ?? 1;
  const left = (column) => widths.slice(0, column).reduce((sum, width, index) => sum + (table.hiddenColumns?.includes(index)?0:width), 0);
  const groupHeight = referenceTable.querySelector("thead .group-header-row")?.getBoundingClientRect().height || 0;
  referenceTable.querySelectorAll("thead tr").forEach((row) => {
    const grouped = row.classList.contains("group-header-row");
    [...row.cells].forEach((cell, index) => {
      const start = grouped ? Number(cell.dataset.groupStart) : index;
      const span = grouped ? Number(cell.dataset.groupSpan) : 1;
      const horizontal = start < frozen && start + span <= frozen;
      cell.classList.toggle("frozen-edge", horizontal && start + span === frozen);
      cell.classList.toggle("after-frozen", start === frozen && frozen > 0);
      cell.style.position = "sticky";
      cell.style.top = `${grouped ? 0 : groupHeight}px`;
      cell.style.left = horizontal ? `${left(start)}px` : "auto";
      cell.style.zIndex = String(grouped ? horizontal ? 9 : 7 : horizontal ? 8 : 6);
    });
  });
  referenceTable.querySelectorAll("tbody tr, tfoot tr").forEach((row) => {
    const footer = row.parentElement.tagName === "TFOOT";
    let column = 0;
    [...row.cells].forEach((cell) => {
      const horizontal = column < frozen;
      cell.classList.toggle("frozen-edge", horizontal && column + (cell.colSpan || 1) === frozen);
      cell.classList.toggle("after-frozen", column === frozen && frozen > 0);
      cell.style.position = horizontal || footer ? "sticky" : "relative";
      cell.style.left = horizontal ? `${left(column)}px` : "auto";
      cell.style.top = "auto";
      cell.style.bottom = footer ? "0px" : "auto";
      cell.style.zIndex = String(footer ? horizontal ? 5 : 4 : horizontal ? 3 : 1);
      column += cell.colSpan || 1;
    });
  });
}

function moveToAdjacentCell(cell, key, extendSelection = false) {
  let targetRow = cell.closest("tr");
  let columnIndex = cell.cellIndex;
  const rowStep = key === "ArrowUp" ? -1 : key === "ArrowDown" ? 1 : 0;
  const columnStep = key === "ArrowLeft" ? -1 : key === "ArrowRight" ? 1 : 0;

  while (true) {
    if (rowStep) targetRow = rowStep > 0 ? targetRow?.nextElementSibling : targetRow?.previousElementSibling;
    columnIndex += columnStep;
    if (!targetRow || columnIndex < 0 || columnIndex >= targetRow.cells.length) return;
    let target = targetRow.cells[columnIndex];
    if (target.style.display === "none") {
      if (columnStep) continue;
      return;
    }
    if (target.classList.contains("editable-cell") || target.classList.contains("calculated-cell")) {
      const targetSourceIndex = Number(targetRow.dataset.sourceIndex);
      if (cell.isContentEditable && document.activeElement === cell) {
        cell.blur();
        const refreshedRow = referenceTable.querySelector(`tbody tr[data-source-index="${targetSourceIndex}"]`);
        target = refreshedRow?.cells[columnIndex] || target;
      }
      selectTableCell(activeTableId, targetSourceIndex, target.cellIndex, {
        shiftKey: extendSelection,
        ctrlKey: false,
        metaKey: false,
      });
      const focusTarget = target.querySelector("select, input.table-cell-suggest") || target;
      focusTarget.focus({ preventScroll: true });
      if (target.classList.contains("calculated-cell")) clearFillHandle();
      if (target.isContentEditable) {
        const selection = window.getSelection();
        const range = document.createRange();
        const textNode = [...target.childNodes].find((node) => node.nodeType === Node.TEXT_NODE);
        range.selectNodeContents(textNode || target);
        range.collapse(false);
        selection.removeAllRanges();
        selection.addRange(range);
      }
      alignCellInTableViewport(target);
      scheduleFillHandlePosition();
      return;
    }
  }
}

function alignCellInTableViewport(cell) {
  const scroll = cell.closest(".table-scroll"), row = cell.closest("tr");
  if (!scroll || !row) return;
  const viewport = scroll.getBoundingClientRect(), cellRect = cell.getBoundingClientRect();
  const activeTable = independentTables.find((table) => table.id === activeTableId);
  const frozen = activeTable?.frozenColumns ?? 1;
  const frozenRect = row.cells[frozen - 1]?.getBoundingClientRect();
  const left = viewport.left + scroll.clientLeft, top = viewport.top + scroll.clientTop;
  const visibleLeft = cell.cellIndex >= frozen && frozenRect ? Math.max(left, frozenRect.right) : left;
  const visibleRight = left + scroll.clientWidth;
  if (cellRect.left < visibleLeft) scroll.scrollLeft = Math.max(0, scroll.scrollLeft + cellRect.left - visibleLeft);
  else if (cellRect.right > visibleRight) scroll.scrollLeft += cellRect.right - visibleRight;
  const headerHeight = referenceTable.tHead?.getBoundingClientRect().height || 0;
  const footerHeight = referenceTable.tFoot?.getBoundingClientRect().height || 0;
  const visibleTop = top + headerHeight;
  const visibleBottom = top + scroll.clientHeight - footerHeight;
  if (cellRect.top < visibleTop) scroll.scrollTop = Math.max(0, scroll.scrollTop + cellRect.top - visibleTop);
  else if (cellRect.bottom > visibleBottom) scroll.scrollTop += cellRect.bottom - visibleBottom;
}

function sortReferenceTable(tableId, column) {
  const targetTable=independentTables.find(t=>t.id===tableId);if(targetTable?.energySimulation||targetTable?.energySummary)return;
  tableSort = tableSort.tableId === tableId && tableSort.column === column
    ? { tableId, column, direction: tableSort.direction === "asc" ? "desc" : "asc" }
    : { tableId, column, direction: "asc" };
  const project=activeProject();if(project){project.tableViewOrders ||= {};project.tableViewOrders[tableId]={...project.tableViewOrders[tableId],column:tableSort.column,direction:tableSort.direction,order:project.tableViewOrders[tableId]?.order||[]};saveProjects();}
  renderReferenceTable(tableId, tableSearch.value, { skipRecalculation: true });
  tableScroll.scrollTop = 0;
  scheduleFillHandlePosition();
}

function refreshSelectedTableCells() {
  referenceTable.querySelectorAll("tbody td.multi-cell-selected").forEach((cell) => cell.classList.remove("multi-cell-selected"));
  referenceTable.querySelectorAll("tbody tr.selected-cell-row").forEach((row) => row.classList.remove("selected-cell-row"));
  selectedTableCells.forEach((key) => {
    const [rowIndex, columnIndex] = key.split(":").map(Number);
    const row = referenceTable.querySelector(`tbody tr[data-source-index="${rowIndex}"]`);
    row?.cells[columnIndex]?.classList.add("multi-cell-selected");
  });
}

function selectTableCell(tableId, sourceIndex, columnIndex, event = {}) {
  if (!event.shiftKey && !event.ctrlKey && !event.metaKey && activeCellSelection?.tableId === tableId
    && activeCellSelection.sourceIndex === sourceIndex && activeCellSelection.columnIndex === columnIndex
    && selectedTableCells.size === 1 && selectedTableCells.has(`${sourceIndex}:${columnIndex}`)) return;
  clearSelectedEquation();
  referenceTable.querySelectorAll("tbody td.table-cell-selected").forEach((cell) => cell.classList.remove("table-cell-selected"));
  referenceTable.querySelectorAll("tbody tr.selected-cell-row").forEach((row) => row.classList.remove("selected-cell-row"));
  referenceTable.querySelector(`tbody tr[data-source-index="${sourceIndex}"]`)?.classList.add("selected-cell-row");
  const key = `${sourceIndex}:${columnIndex}`;
  if (selectedTableId !== tableId) selectedTableCells.clear();
  selectedTableId = tableId;
  activeCellSelection = { tableId, sourceIndex, columnIndex };
  selectedTableRowIndexes.clear();
  selectionAnchorIndex = -1;
  referenceTable.querySelectorAll("tbody tr.selected-row").forEach((row) => {
    row.classList.remove("selected-row");
    row.setAttribute("aria-selected", "false");
  });
  removeTableRowButton.disabled = false;
  if (event.shiftKey && cellSelectionAnchor) {
    const visibleRows = [...referenceTable.querySelectorAll("tbody tr")];
    const anchorPosition = visibleRows.findIndex((row) => Number(row.dataset.sourceIndex) === cellSelectionAnchor.sourceIndex);
    const targetPosition = visibleRows.findIndex((row) => Number(row.dataset.sourceIndex) === sourceIndex);
    if (anchorPosition >= 0 && targetPosition >= 0) {
      selectedTableCells.clear();
      const [rowStart, rowEnd] = [Math.min(anchorPosition, targetPosition), Math.max(anchorPosition, targetPosition)];
      const [columnStart, columnEnd] = [Math.min(cellSelectionAnchor.columnIndex, columnIndex), Math.max(cellSelectionAnchor.columnIndex, columnIndex)];
      visibleRows.slice(rowStart, rowEnd + 1).forEach((row) => {
        for (let column = columnStart; column <= columnEnd; column += 1) {
          if (row.cells[column]?.classList.contains("editable-cell") || row.cells[column]?.classList.contains("calculated-cell")) selectedTableCells.add(`${row.dataset.sourceIndex}:${column}`);
        }
      });
    }
  } else if (event.ctrlKey || event.metaKey) {
    if (selectedTableCells.has(key)) selectedTableCells.delete(key); else selectedTableCells.add(key);
    cellSelectionAnchor = { sourceIndex, columnIndex };
  } else {
    selectedTableCells = new Set([key]);
    cellSelectionAnchor = { sourceIndex, columnIndex };
  }
  refreshSelectedTableCells();
  referenceTable.querySelector(`tbody tr[data-source-index="${sourceIndex}"]`)?.classList.add("selected-cell-row");
}

function clearSelectedTableCellValues() {
  if (document.activeElement?.isContentEditable) document.activeElement.blur();
  const table = independentTables.find((candidate) => candidate.id === activeTableId);
  if (!table || !selectedTableCells.size) return false;
  const dropdownSnapshots=snapshotDropdownReferences(table.id,[...selectedTableCells].map(key=>Number(key.split(":")[1])));
  const rows = projectTableRows(table);
  const focusedCell = document.activeElement?.closest?.("td[data-source-index]");
  const location = focusedCell ? { sourceIndex: Number(focusedCell.dataset.sourceIndex), columnIndex: Number(focusedCell.dataset.columnIndex) }
    : activeCellSelection || (() => { const [sourceIndex, columnIndex] = [...selectedTableCells][0].split(":").map(Number); return { sourceIndex, columnIndex }; })();
  const selection = new Set(selectedTableCells), anchor = cellSelectionAnchor;
  let changed = false;
  selectedTableCells.forEach((key) => {
    const [rowIndex, columnIndex] = key.split(":").map(Number);
    const row = rows[rowIndex];
    if (!row || (table.lockedColumns || []).includes(columnIndex) || (table.calculatedColumns || []).includes(columnIndex)
      || table.lockedCellStates?.get(rowIndex)?.has(columnIndex)) return;
    recordZoningOverride(table, row, columnIndex, "", activeProject());
    recordNetworkZoningOverride(table, row, columnIndex, "", activeProject());
    recordAirsideOverride(table, row, columnIndex, "", activeProject());
    recordCoilOverride(table, row, columnIndex, "", activeProject());
    recordSpaceLoadFactorOverride(table, row, columnIndex, "", activeProject());
    recordPlantOverride(table, row, columnIndex, "", activeProject());
    recordPressurizationOverride(table, row, columnIndex, "", activeProject());
    recordScheduleOverride(table, row, columnIndex, "", activeProject());
    row[columnIndex] = "";
    changed = true;
  });
  if (!changed) return false;
  recalculateTable(table, rows);
  reconcileRemovedDropdownValues(dropdownSnapshots,activeProject());
  recalculateDependentTables(table);
  saveProjects();
  selectedTableCells = selection;
  cellSelectionAnchor = anchor;
  selectedTableId = table.id;
  activeCellSelection = { tableId: table.id, ...location };
  renderReferenceTable(table.id, tableSearch.value, { skipRecalculation: true });
  const cell = referenceTable.querySelector(`tbody tr[data-source-index="${location.sourceIndex}"]`)?.cells[location.columnIndex];
  if (cell) {
    (cell.querySelector("select, input.table-cell-suggest") || cell).focus({ preventScroll: true });
    // Focus handlers select one cell; keep the original multi-cell range after clearing it.
    selectedTableCells = selection; cellSelectionAnchor = anchor; refreshSelectedTableCells();
    cell.closest("tr")?.classList.add("selected-cell-row");
    alignCellInTableViewport(cell);
  }
  return true;
}

function selectedCellBounds() {
  const positions = [...selectedTableCells].map((key) => key.split(":").map(Number));
  if (!positions.length && activeCellSelection?.tableId === activeTableId) positions.push([activeCellSelection.sourceIndex, activeCellSelection.columnIndex]);
  if (!positions.length) return null;
  // Selections are made in the currently displayed grid. Translate source row IDs
  // back to displayed positions so filtering or sorting cannot shift the copied range.
  const visibleRows = [...referenceTable.querySelectorAll("tbody tr:not(.table-summary-row)")];
  const rowPosition = new Map(visibleRows.map((row, index) => [Number(row.dataset.sourceIndex), index]));
  const displayed = positions
    .map(([row, column]) => [rowPosition.get(row), column])
    .filter(([row]) => row !== undefined);
  if (!displayed.length) return null;
  return {
    row: Math.min(...displayed.map(([row]) => row)),
    column: Math.min(...displayed.map(([, column]) => column)),
    maxRow: Math.max(...displayed.map(([row]) => row)),
    maxColumn: Math.max(...displayed.map(([, column]) => column)),
    visibleRows,
  };
}

function selectedCellsToTsv() {
  const table = independentTables.find((candidate) => candidate.id === activeTableId);
  const bounds = selectedCellBounds();
  if (!table || !bounds) return "";
  const rows = projectTableRows(table);
  const grid = Array.from({ length: bounds.maxRow - bounds.row + 1 }, (_, rowOffset) => {
    const sourceIndex = Number(bounds.visibleRows[bounds.row + rowOffset]?.dataset.sourceIndex);
    return Array.from({ length: bounds.maxColumn - bounds.column + 1 }, (_, columnOffset) =>
      formatTableValue(rows[sourceIndex]?.[bounds.column + columnOffset], table, bounds.column + columnOffset),
    );
  });
  return CsvTools.stringifyClipboard(grid);
}

function pasteSelectedCells(text) {
  const table = independentTables.find((candidate) => candidate.id === activeTableId);
  const bounds = selectedCellBounds();
  if (!table || !bounds || !text.trim()) return false;
  // Spreadsheet cell clips are TSV even when a single value contains commas.
  const grid = CsvTools.parse(text, "\t");
  if (!grid.length) return false;
  const dropdownSnapshots=snapshotDropdownReferences(table.id,grid[0].map((_,c)=>bounds.column+c));
  const rows = projectTableRows(table);
  const invalid = [];
  grid.forEach((pastedRow, rowOffset) => pastedRow.forEach((_, columnOffset) => {
    const rowIndex = Number(bounds.visibleRows[bounds.row + rowOffset]?.dataset.sourceIndex);
    const columnIndex = bounds.column + columnOffset;
    if (!rows[rowIndex] || columnIndex >= table.headers.length || (table.calculatedColumns || []).includes(columnIndex)
      || (table.lockedColumns || []).includes(columnIndex) || table.lockedCellStates?.get(rowIndex)?.has(columnIndex)) invalid.push(`${rowIndex + 1}:${columnIndex + 1}`);
  }));
  if (invalid.length) {
    setCsvFileStatus(`Selected range is not valid: ${invalid.length} calculated or locked cell${invalid.length === 1 ? "" : "s"} cannot be changed.`, true);
    return true;
  }
  grid.forEach((pastedRow, rowOffset) => pastedRow.forEach((value, columnOffset) => {
    const rowIndex = Number(bounds.visibleRows[bounds.row + rowOffset]?.dataset.sourceIndex);
    const columnIndex = bounds.column + columnOffset;
    const row = rows[rowIndex];
    const parsed = normalizedTableInput(table, columnIndex, value);
    recordZoningOverride(table, row, columnIndex, parsed, activeProject());
    recordNetworkZoningOverride(table, row, columnIndex, parsed, activeProject());
    recordAirsideOverride(table, row, columnIndex, parsed, activeProject());
    recordCoilOverride(table, row, columnIndex, parsed, activeProject());
    recordPlantOverride(table, row, columnIndex, parsed, activeProject());
    recordSpaceLoadFactorOverride(table, row, columnIndex, parsed, activeProject());
    recordPressurizationOverride(table, row, columnIndex, parsed, activeProject());
    recordScheduleOverride(table, row, columnIndex, parsed, activeProject());
    row[columnIndex] = parsed;
  }));
  recalculateTable(table, rows);
  reconcileRemovedDropdownValues(dropdownSnapshots,activeProject());
  recalculateDependentTables(table);
  saveProjects();
  selectedTableCells = new Set(grid.flatMap((pastedRow, rowOffset) => pastedRow.map((_, columnOffset) => {
    const sourceIndex = Number(bounds.visibleRows[bounds.row + rowOffset]?.dataset.sourceIndex);
    return `${sourceIndex}:${bounds.column + columnOffset}`;
  })));
  const firstSourceIndex = Number(bounds.visibleRows[bounds.row]?.dataset.sourceIndex);
  renderReferenceTable(table.id, tableSearch.value, { skipRecalculation: true });
  const firstCell = referenceTable.querySelector(`tbody tr[data-source-index="${firstSourceIndex}"]`)?.cells[bounds.column];
  (firstCell?.querySelector("select") || firstCell)?.focus({ preventScroll: true });
  return true;
}

function selectTableRow(tableId, tableRow, sourceIndex, event = {}) {
  if (selectedTableId !== tableId) {
    selectedTableRowIndexes.clear();
    selectionAnchorIndex = -1;
  }
  selectedTableId = tableId;
  const toggle = Boolean(event.ctrlKey || event.metaKey);
  if (event.shiftKey && selectionAnchorIndex >= 0) {
    const visibleRows = [...referenceTable.querySelectorAll("tbody tr")];
    const anchorPosition = visibleRows.findIndex((row) => Number(row.dataset.sourceIndex) === selectionAnchorIndex);
    const targetPosition = visibleRows.indexOf(tableRow);
    if (anchorPosition >= 0 && targetPosition >= 0) {
      selectedTableRowIndexes = new Set(visibleRows
        .slice(Math.min(anchorPosition, targetPosition), Math.max(anchorPosition, targetPosition) + 1)
        .map((row) => Number(row.dataset.sourceIndex)));
    }
  } else if (toggle) {
    if (selectedTableRowIndexes.has(sourceIndex)) selectedTableRowIndexes.delete(sourceIndex);
    else selectedTableRowIndexes.add(sourceIndex);
    selectionAnchorIndex = sourceIndex;
  } else {
    selectedTableRowIndexes = new Set([sourceIndex]);
    selectionAnchorIndex = sourceIndex;
  }
  referenceTable.querySelectorAll("tbody tr").forEach((row) => {
    const selected = selectedTableRowIndexes.has(Number(row.dataset.sourceIndex));
    row.classList.toggle("selected-row", selected);
    row.setAttribute("aria-selected", String(selected));
  });
  removeTableRowButton.disabled = selectedTableRowIndexes.size === 0 && selectedTableCells.size === 0;
}

let pendingTableRow = null;

function addTableRow() {
  const table = independentTables.find((candidate) => candidate.id === activeTableId);
  if (!table) return;
  const rows = projectTableRows(table);
  const row = Array(table.columns.length).fill("");
  rows.push(row);
  pendingTableRow = { tableId: table.id, row };
  recalculateTable(table, rows);
  recalculateDependentTables(table);
  selectedTableId = table.id;
  selectedTableRowIndexes = new Set([rows.length - 1]);
  selectionAnchorIndex = rows.length - 1;
  saveProjects();
  tableSearch.value = "";
  tableSort = { tableId: table.id, column: -1, direction: "asc" };
  renderReferenceTable(table.id);
  requestAnimationFrame(() => {
    const scroll = document.querySelector(".table-scroll");
    scroll.scrollTop = scroll.scrollHeight;
    referenceTable.querySelector("tbody tr:last-child .editable-cell")?.focus();
  });
}

function removeTableRow() {
  if (!activeTableId) return;
  const table = independentTables.find((candidate) => candidate.id === activeTableId);
  if (!table) return;
  if (selectedTableId !== activeTableId && selectedTableCells.size) selectedTableId = activeTableId;
  if (selectedTableRowIndexes.size === 0 && selectedTableCells.size) {
    selectedTableRowIndexes = new Set([...selectedTableCells].map((key) => Number(key.split(":")[0])));
  }
  if (selectedTableId !== activeTableId || selectedTableRowIndexes.size === 0) return;
  const snapshots=snapshotDropdownReferences(table.id);
  const rows = projectTableRows(table);
  [...selectedTableRowIndexes].sort((left, right) => right - left).forEach((index) => {
    if (table.thermalTemplateCalculation && table.lockedCellStates?.get(index)?.has(0)) return;
    rows.splice(index, 1);
    if (table.equipmentExhaustCalculation) {
      const previous = activeProject().exhaustEquipmentAutoValues || {};
      activeProject().exhaustEquipmentAutoValues = Object.fromEntries(Object.entries(previous).filter(([key]) => Number(key) !== index).map(([key,value]) => [Number(key) > index ? Number(key)-1 : key,value]));
    }
    activeProject()?.tableRowIds?.[table.id]?.splice(index, 1);
  });
  reconcileRemovedDropdownValues(snapshots,activeProject());
  recalculateTable(table, rows);
  recalculateDependentTables(table);
  saveProjects();
  selectedTableId = "";
  selectedTableRowIndexes.clear(); selectedTableCells.clear(); activeCellSelection = null; pendingTableRow = null;
  selectionAnchorIndex = -1;
  removeTableRowButton.disabled = true;
  renderReferenceTable(table.id);
}

function renderSummaryLinks(groupName) {
  summaryLinks.innerHTML = "";
  summaryLinks.hidden = !groupName;
  if (!groupName) return;

  const section = modules.find((candidate) => candidate.group === groupName);
  if (!section || !section.items.length) {
    const note = document.createElement("span");
    note.className = "summary-note";
    note.textContent = "Reference tables will be added as their calculation dependencies are migrated.";
    summaryLinks.appendChild(note);
    return;
  }

  section.items.forEach((item) => {
    const button = document.createElement("button");
    button.type = "button";
    const label = document.createElement("span"); label.textContent = item[0]; button.appendChild(label);
  const table = independentTables.find((t) => t.id === item[3]);
  if (false && table) { const count = document.createElement("span"); count.className = "item-count"; count.dataset.rowCountTable = table.id;
    count.textContent = String((activeProject()?.independentTables?.[table.id] || table.rows).length); button.appendChild(count); }
    button.addEventListener("click", () => {
      search.value = "";
      renderTree();
      const target = document.querySelector(`[data-id="${CSS.escape(slugify(item[0]))}"]`);
      if (target) selectModule(target);
    });
    summaryLinks.appendChild(button);
  });
}

function syncActiveState() {
  const aliases = {
    "air-balance": slugify("DOAS & Zone Recirculation Air Balance"),
    "non-peak-air-balance": slugify("AHU with 100% OA Air Balance"),
    "equipment-zoning-table": "equipment-zoning",
    "building-level-system": "settings",
    "building-level-exhaust-relief-systems": "settings",
  };
  const requestedId = location.hash.slice(1) || "space-condition-setpoints";
  const id = aliases[requestedId] || requestedId;
  document.querySelectorAll("[data-id]").forEach((button) => button.classList.toggle("active", button.dataset.id === id));
  const active = document.querySelector(`[data-id="${CSS.escape(id)}"]`)
    || document.querySelector('[data-id="space-condition-setpoints"]');
  if (active) updateWorkspace(active.dataset);
}

function openBrowser() {
  browser.classList.add("open");
  scrim.classList.add("open");
  document.body.style.overflow = "hidden";
}

function closeBrowser() {
  if(document.body.classList.contains("print-mode"))return;
  browser.classList.remove("open");
  scrim.classList.remove("open");
  document.body.style.overflow = "";
}

function createProjectId() {
  return globalThis.crypto?.randomUUID?.() || `project-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function defaultProject() {
  const project = { id: createProjectId() };
  projectFields.forEach((input) => {
    const field = input.dataset.projectField;
    project[field] = localStorage.getItem(`hvac-project-${field}`) ?? input.value ?? "";
  });
  project.number ||= "185021";
  project.name ||= "IESVE 2025 Energy Model";
  return project;
}

function saveProjects() {
  const next = JSON.stringify(projects);
  const previous = localStorage.getItem(PROJECTS_KEY);
  if (!applyingHistory && previous && previous !== next) {
    undoStack.push(previous);
    if (undoStack.length > 100) undoStack.shift();
    redoStack.length = 0;
  }
  localStorage.setItem(PROJECTS_KEY, next);
  localStorage.setItem(ACTIVE_PROJECT_KEY, activeProjectId);
}

function restoreProjectHistory(snapshot) {
  applyingHistory = true;
  try {
    projects = JSON.parse(snapshot);
    if (!projects.some((project) => project.id === activeProjectId)) activeProjectId = projects[0]?.id || "";
    localStorage.setItem(PROJECTS_KEY, JSON.stringify(projects));
    localStorage.setItem(ACTIVE_PROJECT_KEY, activeProjectId);
    selectedTableCells.clear();
    cellSelectionAnchor = null;
    fillProjectFields();
    renderProjectList();
    syncActiveState();
  } finally {
    applyingHistory = false;
  }
}

function undoProjectChange() {
  const snapshot = undoStack.pop();
  if (!snapshot) return;
  redoStack.push(JSON.stringify(projects));
  restoreProjectHistory(snapshot);
}

function redoProjectChange() {
  const snapshot = redoStack.pop();
  if (!snapshot) return;
  undoStack.push(JSON.stringify(projects));
  restoreProjectHistory(snapshot);
}

function loadProjects() {
  try {
    const saved = JSON.parse(localStorage.getItem(PROJECTS_KEY) || "null");
    projects = Array.isArray(saved) && saved.length ? saved : [defaultProject()];
  } catch {
    projects = [defaultProject()];
  }

  const savedActiveId = localStorage.getItem(ACTIVE_PROJECT_KEY);
  activeProjectId = projects.some((project) => project.id === savedActiveId) ? savedActiveId : projects[0].id;
  projects.forEach(synchronizeProjectSpaceReferences);
  saveProjects();
}

function activeProject() {
  return projects.find((project) => project.id === activeProjectId) || projects[0];
}

function fillProjectFields() {
  refreshTodayDates();
  const project = activeProject();
  if (!project) return;
  projectFields.forEach((input) => {
    if (input.dataset.projectField === "date" && project.dateMode === "today") project.date = localToday();
    input.value = project[input.dataset.projectField] || "";
    if (input.dataset.projectField === "date") input.readOnly = project.dateMode === "today";
  });
}

function localToday(now = new Date()) {
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
}

function refreshTodayDates() {
  const today = localToday(); let changed = false;
  projects.forEach((project) => { if (project.dateMode === "today" && project.date !== today) { project.date = today; changed = true; } });
  const project = activeProject(), input = document.querySelector('[data-project-field="date"]');
  if (project?.dateMode === "today") input.value = today;
  document.querySelector("#project-date-today").checked = project?.dateMode === "today";
  input.readOnly = project?.dateMode === "today";
  input.classList.toggle("calculated-value", input.readOnly);
  if (changed) saveProjects();
}

function renderProjectList(query = projectSearch.value) {
  const normalized = query.trim().toLowerCase();
  const matches = projects.filter((project) =>
    [project.number, project.name, project.client].some((value) => String(value || "").toLowerCase().includes(normalized)),
  );
  projectList.innerHTML = "";

  if (!matches.length) {
    const empty = document.createElement("p");
    empty.className = "project-list-empty";
    empty.textContent = "No projects match this search.";
    projectList.appendChild(empty);
    return;
  }

  matches.forEach((project) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "project-list-item";
    button.classList.toggle("active", project.id === activeProjectId);
    if (project.id === activeProjectId) button.setAttribute("aria-current", "true");

    const number = document.createElement("strong");
    number.textContent = project.number;
    const name = document.createElement("span");
    name.textContent = project.name || "Untitled project";
    button.append(number, name);
    button.addEventListener("click", () => selectProject(project.id));
    projectList.appendChild(button);
  });
}

function selectProject(projectId) {
  if (!projects.some((project) => project.id === projectId)) return;
  activeProjectId = projectId;
  selectedTableId = "";
  selectedTableRowIndexes.clear();
  selectionAnchorIndex = -1;
  synchronizeProjectSpaceReferences(activeProject());
  saveProjects();
  fillProjectFields();
  renderProjectList();
  syncActiveState();
}

function setProjectSwitcher(open) {
  shell.classList.toggle("projects-open", open);
  projectSwitcherToggle.setAttribute("aria-expanded", String(open));
  projectSwitcherToggle.setAttribute("aria-label", `${open ? "Close" : "Open"} project list`);
  projectSwitcherToggle.title = `${open ? "Close" : "Open"} project list`;
  if (open) {
    renderProjectList();
    projectSearch.focus();
  }
}

function openProjectDialog() {
  projectForm.reset();
  projectDialogError.textContent = "";
  projectDialog.showModal();
  requestAnimationFrame(() => newProjectNumber.focus());
}

function addProject(event) {
  event.preventDefault();
  const number = newProjectNumber.value.trim();
  if (!number) {
    projectDialogError.textContent = "Enter a project number.";
    newProjectNumber.focus();
    return;
  }
  if (projects.some((project) => String(project.number).toLowerCase() === number.toLowerCase())) {
    projectDialogError.textContent = "That project number already exists.";
    newProjectNumber.focus();
    return;
  }

  const project = {
    id: createProjectId(),
    number,
    client: "",
    name: "",
    date: "",
    made_by: "",
    checked_by: "",
    submittal: "",
  };
  projects.push(project);
  projectSearch.value = "";
  projectDialog.close();
  selectProject(project.id);
}

function initializeProjects() {
  loadProjects();
  fillProjectFields();
  renderProjectList();

  projectFields.forEach((input) => {
    if (input.readOnly && input.dataset.projectField !== "date") return;
    input.addEventListener("input", () => {
      const project = activeProject();
      if (!project) return;
      project[input.dataset.projectField] = input.value;
      if (input.dataset.projectField === "date") { project.dateMode = "fixed"; input.classList.remove("calculated-value"); document.querySelector("#project-date-today").checked = false; }
      saveProjects();
      renderProjectList();
    });
  });
}

search.addEventListener("input", (event) => renderTree(event.target.value));
projectSearch.addEventListener("input", (event) => renderProjectList(event.target.value));
document.querySelector("#project-date-today").addEventListener("change", (event) => {
  const project = activeProject(); if (!project) return;
  project.dateMode = event.target.checked ? "today" : "fixed";
  refreshTodayDates(); saveProjects();
});
document.addEventListener("visibilitychange", () => { if (!document.hidden) refreshTodayDates(); });
setInterval(refreshTodayDates, 60000);
[minimumInput, twoValueSchedule, sensibleLoadFactor, latentLoadFactor, heatingLoadFactor].forEach((input) => {
  const show = () => showTopAutomaticEquation(input);
  input.addEventListener("focus", show); input.addEventListener("click", show);
});
sharedSpaceSearch.addEventListener("input", () => {
  const project = activeProject(); if (!project) return;
  project[spaceFilterContext?.equipment ? "equipmentSearch" : spaceFilterContext?.thermal ? "thermalTableSearch" : "sharedSpaceSearch"] = sharedSpaceSearch.value;
  applySharedFilterChange();
});
spaceFilterField.addEventListener("change", () => {
  const project = activeProject(); if (!project) return;
  project[spaceFilterContext?.equipment ? "equipmentFilter" : spaceFilterContext?.thermal ? "thermalTableFilter" : "sharedSpaceFilter"] = { field: spaceFilterField.value, values: null };
  applySharedFilterChange();
});
spaceFilterToggle.addEventListener("click", () => {
  if (!spaceFilterContext) return;
  if (!spaceFilterPopover.hidden) { closeSharedFilter(); return; }
  spaceFilterDraft = new Set(spaceFilterContext.state.values ?? spaceFilterContext.options.map((option) => option.value));
  spaceFilterSearch.value = ""; renderSharedFilterOptions();
  spaceFilterPopover.hidden = false; spaceFilterToggle.setAttribute("aria-expanded", "true"); spaceFilterSearch.focus();
});
spaceFilterSearch.addEventListener("input", renderSharedFilterOptions);
spaceFilterAll.addEventListener("change", () => {
  shownFilterOptions().forEach((option) => { if (spaceFilterAll.checked) spaceFilterDraft.add(option.value); else spaceFilterDraft.delete(option.value); });
  renderSharedFilterOptions();
});
document.querySelector("#space-filter-apply").addEventListener("click", () => {
  if (!spaceFilterContext) return;
  const values = spaceFilterContext.options.map((option) => option.value).filter((value) => spaceFilterDraft.has(value));
  spaceFilterContext.state.values = values.length === spaceFilterContext.options.length ? null : values;
  applySharedFilterChange(); spaceFilterToggle.focus();
});
document.querySelector("#space-filter-cancel").addEventListener("click", () => { closeSharedFilter(); spaceFilterToggle.focus(); });
spaceFilterClear.addEventListener("click", () => { if (spaceFilterContext) { spaceFilterContext.state.values = null; activeProject()[spaceFilterContext.equipment ? "equipmentSearch" : spaceFilterContext.thermal ? "thermalTableSearch" : "sharedSpaceSearch"] = ""; if (!spaceFilterContext.thermal) activeProject()[spaceFilterContext.equipment?"excludedEquipment":"excludedSpaces"] = []; applySharedFilterChange(); } });
document.addEventListener("pointerdown", (event) => {
  if(event.target.closest?.(".formula-evaluator"))return; if (!spaceFilter.contains(event.target)) closeSharedFilter(); });
spaceFilter.addEventListener("keydown", (event) => { if (event.key === "Escape") { closeSharedFilter(); spaceFilterToggle.focus(); event.stopPropagation(); } });
tableSearch.addEventListener("input", (event) => {
  if (activeTableId) renderReferenceTable(activeTableId, event.target.value, { skipRecalculation: true });
});
twoValueSchedule.addEventListener("change", () => {
  const project = activeProject();
  if (!project || activeTableId !== "calc-space-condition-setpoints") return;
  project.calcSettings ||= {};
  project.calcSettings.twoValueSchedule = twoValueSchedule.value.trim() || "System extended hours";
  twoValueSchedule.value = project.calcSettings.twoValueSchedule;
  twoValueSchedule.classList.toggle("auto-default", twoValueSchedule.value === "System extended hours");
  renderReferenceTable(activeTableId, tableSearch.value);
  saveProjects();
});
minimumInput.addEventListener("change", () => {
  const project = activeProject();
  const table = independentTables.find((candidate) => candidate.id === minimumInput.dataset.tableId);
  if (!project || !table) return;
  const fallback = table.ventilationMinimumDefault ?? table.exhaustMinimumDefault ?? table.supplyMinimumDefault;
  const input = minimumInput.value.trim();
  const parsed = Number(input);
  if (input && (!Number.isFinite(parsed) || parsed < 0)) { updateTableSettings(table); return; }
  project.calcSettings ||= {};
  project.calcSettings.airflowMinimums ||= {};
  if (!input || parsed === fallback) delete project.calcSettings.airflowMinimums[table.id];
  else project.calcSettings.airflowMinimums[table.id] = parsed;
  updateTableSettings(table);
  const rows = projectTableRows(table);
  recalculateTable(table, rows, project);
  saveProjects();
  if (activeTableId === table.id) renderReferenceTable(table.id, tableSearch.value, { skipRecalculation: true });
});
document.querySelector("#cancel-space-reconcile").addEventListener("click", () => {
  pendingSpaceReconciliation = null;
  spaceReconcileDialog.close();
});
document.querySelector("#apply-space-reconcile").addEventListener("click", () => {
  if (!pendingSpaceReconciliation) return;
  const { table, importedRows, state, newSpaces, oldSpaces } = pendingSpaceReconciliation;
  try {
    applyCalculationSpaceChanges(newSpaces, oldSpaces);
    commitTabularImport(table, importedRows, state);
    pendingSpaceReconciliation = null;
    spaceReconcileDialog.close();
  } catch (error) {
    spaceReconcileError.textContent = error.message || "The space changes could not be applied.";
  }
});
[
  [sensibleLoadFactor, "sensible"],
  [latentLoadFactor, "latent"],
  [heatingLoadFactor, "heating"],
].forEach(([input, key]) => input.addEventListener("change", () => {
  const project = activeProject();
  const table = independentTables.find((candidate) => candidate.id === "calc-room-loads");
  if (!project || !table) return;
  const parsed = Number(String(input.value).replace(/,/g, "").replace(/%$/, ""));
  if (!Number.isFinite(parsed) || parsed < 0) {
    updateTableSettings(table);
    return;
  }
  project.calcSettings ||= {};
  project.calcSettings.spaceLoadFactors ||= { sensible: 0.1, latent: 0.1, heating: 0.1 };
  project.calcSettings.spaceLoadFactors[key] = parsed / 100;
  recalculateTable(table, ensureProjectTableRows(project, table), project);
  saveProjects();
  if (activeTableId === table.id) renderReferenceTable(table.id, tableSearch.value);
}));
document.addEventListener("keydown", (event) => {
  if(event.target.closest?.(".formula-evaluator"))return;
  if (event.target.closest?.(".cell-dropdown-popup, .cell-note-editor")) return;
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "z") {
    event.preventDefault();
    if (event.shiftKey) redoProjectChange(); else undoProjectChange();
    return;
  }
  if (event.key === "Delete" && selectedTableCells.size) {
    if (document.activeElement?.isContentEditable || document.activeElement?.matches(".dropdown-inline-editor,.table-inline-editor")) return;
    if (clearSelectedTableCellValues()) event.preventDefault();
    return;
  }
  if (!["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(event.key)) return;
  const cell = event.composedPath().find((node) => node instanceof HTMLTableCellElement && referenceTable.contains(node));
  if (!cell || cell.isContentEditable || event.target.closest?.(".dropdown-inline-editor,.table-inline-editor") || event.altKey || event.ctrlKey || event.metaKey) return;
  event.preventDefault();
  event.stopImmediatePropagation();
  moveToAdjacentCell(cell, event.key, event.shiftKey);
}, true);

// First click selects; a subsequent click edits the selected input cell.
referenceTable.addEventListener("pointerdown", (event) => {
  if (event.button !== 0) return;
  const cell = event.target.closest("td");
  if (!cell?.closest("tbody") || (!cell.classList.contains("editable-cell") && !cell.classList.contains("calculated-cell"))) return;
  if (cell.isContentEditable || event.target.closest(".dropdown-inline-editor,.table-inline-editor")) return;
  cell.editOnClick = selectedTableCells.size===1 && activeCellSelection?.tableId===activeTableId && activeCellSelection?.sourceIndex===Number(cell.dataset.sourceIndex) && activeCellSelection?.columnIndex===Number(cell.dataset.columnIndex) && !event.shiftKey && !event.ctrlKey && !event.metaKey && !event.target.closest('button,.cell-note-flag');
  if(cell.editOnClick&&cell.startCellEdit){event.preventDefault();event.stopPropagation();cell.editOnClick=false;cellDragSelection=false;cell.startCellEdit();return;}
  selectTableCell(activeTableId, Number(cell.dataset.sourceIndex), Number(cell.dataset.columnIndex), event);
  cellDragSelection = !event.shiftKey && !event.ctrlKey && !event.metaKey && !cell.querySelector("select");
  if (!cell.querySelector("select, input.table-cell-suggest")) {
    event.preventDefault();
    cell.focus({ preventScroll: true });
  }
}, true);

referenceTable.addEventListener('click',event=>{
  const cell=event.target.closest('td');if(!cell)return;
  if(cell.editOnClick&&selectedTableCells.size===1&&!event.target.closest('button,.cell-note-flag'))cell.startCellEdit?.();
  cell.editOnClick=false;
});
referenceTable.addEventListener("pointerover", (event) => {
  if (!cellDragSelection || !(event.buttons & 1)) return;
  const cell = event.target.closest("td");
  if (!cell || (!cell.classList.contains("editable-cell") && !cell.classList.contains("calculated-cell"))) return;
  selectTableCell(activeTableId, Number(cell.dataset.sourceIndex), Number(cell.dataset.columnIndex), { shiftKey: true });
});
document.addEventListener("pointerup", () => { cellDragSelection = false; });
document.addEventListener("pointercancel", () => { cellDragSelection = false; });

document.addEventListener("copy", (event) => {
  if (document.activeElement?.isContentEditable || document.activeElement?.matches(".table-inline-editor,.dropdown-inline-editor") || (!referenceTable.contains(document.activeElement) && !referenceTable.contains(event.target))) return;
  if (!selectedTableCells.size && activeCellSelection?.tableId !== activeTableId) return;
  const text = selectedCellsToTsv();
  if (!text) return;
  event.clipboardData?.setData("text/plain", text);
  event.preventDefault();
  event.stopImmediatePropagation();
}, true);

document.addEventListener("cut", (event) => {
  if (document.activeElement?.isContentEditable || document.activeElement?.matches(".table-inline-editor,.dropdown-inline-editor") || (!referenceTable.contains(document.activeElement) && !referenceTable.contains(event.target))) return;
  if (!selectedTableCells.size && activeCellSelection?.tableId !== activeTableId) return;
  const text = selectedCellsToTsv();
  if (!text) return;
  event.clipboardData?.setData("text/plain", text);
  event.preventDefault();
  clearSelectedTableCellValues();
});

document.addEventListener('paste',event=>{
  const table=independentTables.find(t=>t.id===activeTableId);if(!table?.energySimulation)return;
  if(event.target.closest?.('input,textarea,[contenteditable="true"]'))return;
  const text=event.clipboardData?.getData('text/plain');if(!text)return;
  event.preventDefault();event.stopImmediatePropagation();
  try{importEnergyClipboard(table,text);}catch(e){showPasteFormatError();}
},true);
document.addEventListener("paste", (event) => {
  if (document.activeElement?.isContentEditable || document.activeElement?.matches(".table-inline-editor,.dropdown-inline-editor") || (!referenceTable.contains(document.activeElement) && !referenceTable.contains(event.target))) return;
  if (!selectedTableCells.size && activeCellSelection?.tableId !== activeTableId) return;
  const text = event.clipboardData?.getData("text/plain") || "";
  if (!text) return;
  event.preventDefault();
  pasteSelectedCells(text);
}, true);

addTableRowButton.addEventListener("click", addTableRow);
removeTableRowButton.addEventListener("click", removeTableRow);
pasteDataButton.addEventListener("click", pasteDataFromClipboard);
copyDataButton.addEventListener("click", copyTabularData);
importExcelButton.addEventListener("click", () => importExcelInput.click());
importExcelInput.addEventListener("change", () => {
  importRoomZoneLoads(importExcelInput.files?.[0]);
});
editEquationButton.addEventListener("click", beginEquationEdit);
saveEquationButton.addEventListener("click", saveEquationEdit);
cancelEquationButton.addEventListener("click", cancelEquationEdit);
selectedEquation.addEventListener("keydown", (event) => {
  if (selectedEquation.readOnly) return;
  if (event.key === "Enter") {
    event.preventDefault();
    saveEquationEdit();
  } else if (event.key === "Escape") {
    event.preventDefault();
    event.stopPropagation();
    cancelEquationEdit();
  }
});
projectSwitcherToggle.addEventListener("click", () => setProjectSwitcher(!shell.classList.contains("projects-open")));
document.addEventListener("click", (event) => {
  if (!shell.classList.contains("projects-open") || event.target.closest?.("#project-switcher, #project-switcher-toggle, dialog")) return;
  if (event.target.closest?.(".workspace, .topbar, #project-browser")) setProjectSwitcher(false);
});
document.querySelector("#add-project").addEventListener("click", openProjectDialog);
document.querySelector("#cancel-project").addEventListener("click", () => projectDialog.close());
projectForm.addEventListener("submit", addProject);
document.querySelector("#open-browser").addEventListener("click", openBrowser);
document.querySelector("#close-browser").addEventListener("click", closeBrowser);
scrim.addEventListener("click", closeBrowser);
window.addEventListener("hashchange", syncActiveState);
document.addEventListener("pointermove", (event) => updateFillPreview(event.clientX, event.clientY));
document.addEventListener("pointerup", finishFillDrag);
document.addEventListener("pointercancel", finishFillDrag);
restoreAutoButton.addEventListener("click", () => { if(selectedAutoRestore)selectedAutoRestore();else openFormulaEvaluator(); });
document.addEventListener("pointerdown", (event) => {
  if(event.target.closest?.(".formula-evaluator"))return;
  if (!event.target.closest?.("#reference-table td, .fill-handle, #formula-bar, .cell-dropdown-popup, .cell-note-editor, .cell-note-flag, #remove-table-row, #add-table-row")) clearTableSelection();
});
document.addEventListener("pointerdown", (event) => {
  if(event.target.closest?.(".formula-evaluator"))return;
  if (event.target.closest?.(".fill-handle") || event.target.closest?.("td.editable-cell")) return;
  clearFillHandle();
});
tableScroll.addEventListener("scroll", scheduleFillHandlePosition, { passive: true });
modelInputsView.addEventListener("pointerdown", (event) => {
  if (!event.target.closest("input.calculated-value, .model-input-formula")) hideModelInputEquation();
});
window.addEventListener("paste", (event) => {
  if (activeTableId !== "iesve-tabular-space-data") return;
  if (event.defaultPrevented || referenceTable.contains(document.activeElement) || referenceTable.contains(event.target)) return;
  if (event.target instanceof HTMLInputElement || event.target instanceof HTMLTextAreaElement || event.target.isContentEditable) return;
  const text = event.clipboardData?.getData("text/plain") || "";
  if (!text.trim()) return;
  event.preventDefault();
  try {
    pasteTabularData(text);
  } catch (error) {
    showPasteFormatError();
  }
});
window.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && !projectDialog.open) {
    closeBrowser();
    setProjectSwitcher(false);
  }
});


let spaceChoiceExcluded = new Set();
document.querySelector('#space-choice-toggle').addEventListener('click', () => {
  const popup=document.querySelector('#space-choice-popover'); popup.hidden=!popup.hidden;
  document.querySelector('#space-choice-toggle').setAttribute('aria-expanded',String(!popup.hidden));
  if (!popup.hidden) { closeSharedFilter(); spaceChoiceExcluded=new Set(currentFilterExclusions()); document.querySelector('#space-choice-search').value=''; renderSpaceChoices(); document.querySelector('#space-choice-search').focus(); }
});
document.querySelector('#space-choice-search').addEventListener('input',renderSpaceChoices);
document.querySelector('#space-choice-all').addEventListener('change',(event) => {
  const search=document.querySelector('#space-choice-search').value.toLowerCase();
  (spaceFilterContext?.spaceOptions || []).filter((o) => o.label.toLowerCase().includes(search)).forEach((o) => { if (event.target.checked) spaceChoiceExcluded.delete(o.value); else spaceChoiceExcluded.add(o.value); }); renderSpaceChoices();
});
document.querySelector('#space-choice-apply').addEventListener('click',()=> { activeProject()[spaceFilterContext?.equipment?"excludedEquipment":"excludedSpaces"]=[...spaceChoiceExcluded]; applySharedFilterChange(); });
document.querySelector('#space-choice-cancel').addEventListener('click',()=> { document.querySelector('#space-choice-popover').hidden=true; });
document.addEventListener('pointerdown',(event) => {
  if (!event.target.closest('.cell-dropdown-popup, .cell-dropdown-arrow')) closeCellDropdown();
  if (!event.target.closest('.cell-note-editor, .cell-note-flag')) document.querySelector('.cell-note-editor')?.remove();
  if (!event.target.closest('#space-choice-control')) document.querySelector('#space-choice-popover').hidden=true;
});
tableScroll.addEventListener('scroll',()=> { closeCellDropdown(); document.querySelector('.cell-note-tooltip')?.remove(); document.querySelector('.cell-note-editor')?.remove(); }, {passive:true});
window.addEventListener('resize',closeCellDropdown);
referenceTable.addEventListener("pointerover",hoverTableCell);
referenceTable.addEventListener("pointerleave",clearTableHover);
window.addEventListener("scroll",scheduleFillHandlePosition,{capture:true,passive:true});
initializeProjects();
renderTree();

let loadedVersion = null;
async function checkForUpdates() {
  if (document.visibilityState !== "visible") return;
  try {
    const isLocal = location.hostname === "127.0.0.1" || location.hostname === "localhost";
    const versionUrl = isLocal ? `/version?t=${Date.now()}` : `./version.json?t=${Date.now()}`;
    const response = await fetch(versionUrl, { cache: "no-store" });
    if (!response.ok) return;
    const { version } = await response.json();
    if (loadedVersion !== null && version !== loadedVersion) location.reload();
    loadedVersion = version;
  } catch {
    // The local server may be restarting; the next poll will reconnect.
  }
}

checkForUpdates();
setInterval(checkForUpdates, 1200);
