const modules = [
  {
    group: "IESVE",
    source: "IES Data → IES Loads",
    summary: "Import, normalize, export, and review the IESVE space and room-load datasets used by the design workbook.",
    items: [
      ["IES Tabular Space Data Output", "IES Data", "Review imported tabular space data before it enters the calculation model."],
      ["IES Tabular Space Data Export", "IES Data", "Prepare the normalized tabular space dataset used by downstream calculations."],
      ["IES Room/Zone Loads Report", "IES Loads", "Review room and zone heating and cooling load results from the IES export."],
    ],
  },
  {
    group: "Space Calculations",
    source: "Inputs → IES Loads → Calc",
    summary: "Review space conditions, loads, zoning, ventilation, air balance, latent performance, baseline systems, and monitoring criteria.",
    items: [
      ["Space Condition Setpoints", "Inputs → Calc", "Define occupied heating, cooling, humidity, and setback criteria for each space condition."],
      ["Internal Gains", "Calc", "Calculate people, lighting, equipment, and process gains by space."],
      ["Room Loads", "IES Loads → Calc", "Consolidate the sensible and latent room load components used for system sizing."],
      ["Equipment Zoning", "Calc", "Assign spaces to equipment zones and evaluate shared operating criteria."],
      ["Heating Load", "IES Loads → Calc", "Calculate design heating requirements while preserving workbook sizing and rounding rules."],
      ["Cooling Load", "IES Loads → Calc", "Calculate design sensible, latent, and total cooling requirements."],
      ["Required Ventilation and Exhaust Rates", "Calc → Exhaust", "Determine required outdoor air and exhaust quantities for each applicable space."],
      ["Pressurization", "Calc", "Evaluate supply, return, exhaust, and transfer relationships for space pressure intent."],
      ["Non-Peak Air Balance", "Calc", "Review airflow balance away from coincident peak load conditions."],
      ["Latent Load Calculations", "Calc", "Trace latent gains and moisture loads through the space calculation path."],
      ["Space Condition Type and Baseline System", "Inputs → Calc", "Map space condition types to the workbook baseline system logic."],
      ["CO₂ Monitoring", "Calc", "Identify spaces subject to carbon dioxide monitoring criteria."],
    ],
  },
  {
    group: "Selected Space Requirements",
    source: "Lighting → Misc → Exhaust → Transfer",
    summary: "Manage supplemental fixture, equipment, exhaust, and transfer-air requirements for the selected spaces that need added detail.",
    items: [
      ["Lighting Loads", "Lighting", "Add detailed lighting loads for selected spaces where fixture-level inputs are required."],
      ["Miscellaneous Sensible Loads", "Misc", "Add detailed plug, process, and equipment sensible loads for selected spaces."],
      ["General Exhaust Requirements", "Exhaust", "Apply general exhaust criteria to selected spaces."],
      ["Exhaust Equipment Requirements", "Exhaust", "Define equipment-specific exhaust demands and operating relationships."],
      ["Transfer Air", "Transfer", "Define transfer-air paths and quantities for selected spaces."],
    ],
  },
  {
    group: "Airside Equipment",
    source: "Airside → Psych",
    summary: "Review airside design settings, coil duties, and psychrometric processes for the project systems.",
    items: [
      ["Settings", "Airside", "Configure shared airside design conditions and equipment assumptions."],
      ["Preheat Coils", "Airside", "Size and review preheat coil performance at workbook design conditions."],
      ["Cooling Coils", "Airside", "Size and review cooling coil sensible, latent, and total performance."],
      ["Reheat / Heating Coils", "Airside", "Size and review reheat and heating coil performance."],
      ["Psychrometric Charts", "Psych", "Visualize air-state processes used in the airside calculations."],
    ],
  },
  {
    group: "Plantside Equipment",
    source: "Plantside",
    summary: "Review the calculated cooling and heating plant design duties and equipment selections.",
    items: [
      ["Cooling Plant Equipment", "Plantside", "Review cooling plant equipment selections and calculated design duties."],
      ["Heating Plant Equipment", "Plantside", "Review heating plant equipment selections and calculated design duties."],
    ],
  },
  {
    group: "Energy",
    source: "Energy",
    summary: "Compare proposed energy performance with the four baseline building rotations used by the workbook.",
    items: [
      ["Proposed", "Energy", "Review the proposed building energy-model results."],
      ["Baseline 000deg", "Energy", "Review the baseline energy-model results at the 000-degree rotation."],
      ["Baseline 090deg", "Energy", "Review the baseline energy-model results at the 090-degree rotation."],
      ["Baseline 180deg", "Energy", "Review the baseline energy-model results at the 180-degree rotation."],
      ["Baseline 270deg", "Energy", "Review the baseline energy-model results at the 270-degree rotation."],
    ],
  },
  {
    group: "Independent Tables",
    source: "ASHRAE",
    summary: "Browse the independent ASHRAE reference tables used by the workbook calculations.",
    items: [
      ["Ventilation Rates", "ASHRAE · B4:E83", "Outdoor-air rates and default occupant density by occupancy category.", "ashrae-62-1-ventilation"],
      ["Baseline Lighting Power Density", "ASHRAE · G4:H108", "Baseline lighting power density by common space type.", "ashrae-90-1-baseline-lighting"],
      ["Proposed Lighting Power Density", "ASHRAE · J4:K103", "Lighting power allowances by common space type.", "ashrae-90-1-proposed-lighting"],
      ["Occupant Heat Gain", "ASHRAE · M4:O17", "Sensible and latent heat gain per person by activity level.", "ashrae-fundamentals-people-heat"],
      ["Climate Zones and Baseline Systems", "ASHRAE · T4:AD23", "Climate-zone descriptions and baseline system assignments by building type and size.", "ashrae-climate-zones"],
      ["Baseline System Descriptions", "ASHRAE · AL4:AR18", "Baseline HVAC system types, fan control, cooling source, and heating source.", "ashrae-90-1-baseline-systems"],
    ],
  },
];

const ashraeTables = globalThis.ASHRAE_TABLES || [];

const tree = document.querySelector("#project-tree");
const search = document.querySelector("#browser-search");
const browser = document.querySelector("#project-browser");
const scrim = document.querySelector("#drawer-scrim");
const moduleContent = document.querySelector("#module-content");
const summaryLinks = document.querySelector("#summary-links");
const shell = document.querySelector(".app-shell");
const projectList = document.querySelector("#project-list");
const projectSearch = document.querySelector("#project-search");
const projectDialog = document.querySelector("#project-dialog");
const projectForm = document.querySelector("#project-form");
const newProjectNumber = document.querySelector("#new-project-number");
const projectDialogError = document.querySelector("#project-dialog-error");
const projectSwitcherToggle = document.querySelector("#project-switcher-toggle");
const tableView = document.querySelector("#table-view");
const referenceTable = document.querySelector("#reference-table");
const tableSearch = document.querySelector("#table-search");
const tableCount = document.querySelector("#table-count");
const tableStandard = document.querySelector("#table-standard");
const addTableRowButton = document.querySelector("#add-table-row");
let activeTableId = "";
let tableSort = { tableId: "", column: -1, direction: "asc" };

const PROJECTS_KEY = "hvac-projects-v1";
const ACTIVE_PROJECT_KEY = "hvac-active-project-v1";
const projectFields = [...document.querySelectorAll("[data-project-field]")];
let projects = [];
let activeProjectId = "";

const slugify = (text) => text.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");

function renderTree(query = "") {
  const normalized = query.trim().toLowerCase();
  tree.innerHTML = "";
  let resultCount = 0;

  modules.forEach((section) => {
    const groupMatch = section.group.toLowerCase().includes(normalized);
    const visibleItems = section.items.filter((item) => !normalized || groupMatch || item[0].toLowerCase().includes(normalized));
    if (normalized && !groupMatch && !visibleItems.length) return;
    resultCount += visibleItems.length + 1;

    const wrapper = document.createElement("section");
    wrapper.className = "tree-group";

    const row = document.createElement("div");
    row.className = "group-row";

    if (section.items.length) {
      const expander = document.createElement("button");
      expander.className = "group-expander";
      expander.type = "button";
      expander.setAttribute("aria-label", `Collapse ${section.group}`);
      expander.setAttribute("aria-expanded", "true");
      expander.innerHTML = '<span class="chevron" aria-hidden="true">›</span>';
      expander.addEventListener("click", () => {
        wrapper.classList.toggle("collapsed");
        const expanded = !wrapper.classList.contains("collapsed");
        expander.setAttribute("aria-expanded", String(expanded));
        expander.setAttribute("aria-label", `${expanded ? "Collapse" : "Expand"} ${section.group}`);
      });
      row.appendChild(expander);
    } else {
      const spacer = document.createElement("span");
      spacer.className = "group-spacer";
      row.appendChild(spacer);
    }

    const groupLink = document.createElement("button");
    groupLink.className = "group-link";
    groupLink.type = "button";
    groupLink.dataset.id = `section-${slugify(section.group)}`;
    groupLink.dataset.title = section.group;
    groupLink.dataset.group = "Project Browser";
    groupLink.dataset.source = section.source;
    groupLink.dataset.description = section.summary;
    groupLink.dataset.summary = "true";
    groupLink.textContent = section.group;
    groupLink.addEventListener("click", () => selectModule(groupLink));
    row.appendChild(groupLink);

    if (section.items.length) {
      const count = document.createElement("span");
      count.className = "item-count";
      count.textContent = String(section.items.length);
      row.appendChild(count);
    }

    wrapper.appendChild(row);

    if (visibleItems.length) {
      const children = document.createElement("div");
      children.className = "tree-children";
      visibleItems.forEach((item) => children.appendChild(createLeaf(item, section.group)));
      wrapper.appendChild(children);
    }
    tree.appendChild(wrapper);
  });

  if (!resultCount) {
    const empty = document.createElement("p");
    empty.className = "no-results";
    empty.textContent = "No calculations match this search.";
    tree.appendChild(empty);
  }

  syncActiveState();
}

function createLeaf(item, group) {
  const button = document.createElement("button");
  button.type = "button";
  button.className = "tree-leaf";
  button.dataset.id = slugify(item[0]);
  button.dataset.title = item[0];
  button.dataset.group = group;
  button.dataset.source = item[1];
  button.dataset.description = item[2];
  if (item[3]) button.dataset.table = item[3];
  button.textContent = item[0];
  button.addEventListener("click", () => selectModule(button));
  return button;
}

function selectModule(button) {
  history.replaceState(null, "", `#${button.dataset.id}`);
  updateWorkspace(button.dataset);
  syncActiveState();
  closeBrowser();
}

function updateWorkspace(data) {
  const isSummary = data.summary === "true";
  const isTable = Boolean(data.table);
  document.querySelector("#crumb-group").textContent = data.group;
  document.querySelector("#crumb-page").textContent = data.title;
  document.querySelector("#page-kicker").textContent = isSummary ? "SECTION SUMMARY" : data.group.toUpperCase();
  document.querySelector("#page-title").textContent = data.title;
  document.querySelector("#page-description").textContent = data.description;
  document.querySelector("#source-sheet").textContent = data.source;
  document.querySelector("#module-heading").textContent = isSummary ? "Section overview" : data.title;
  document.querySelector("#module-status").textContent = isTable ? "Table migrated" : "Structure ready";
  document.querySelector("#parity-status").textContent = isTable ? "Workbook data matched" : "Not tested";
  document.querySelector("#revision-status").textContent = isTable ? "ASHRAE source preserved" : "Source preserved";
  document.querySelector("#module-action").textContent = isTable ? "Editable table" : "Calculation pending";
  document.querySelector("#empty-title").textContent = isSummary ? `${data.title} summary` : "Ready for workbook logic";
  document.querySelector("#empty-copy").textContent = isSummary
    ? data.description
    : "The navigation and source mapping are in place. Inputs, equations, units, validation, and Excel parity tests will be added in the next migration increment.";
  moduleContent.classList.toggle("is-summary", isSummary);
  shell.classList.toggle("table-mode", isTable);
  moduleContent.hidden = isTable || !isSummary;
  tableView.hidden = !isTable;
  if (isTable) {
    tableSearch.value = "";
    renderReferenceTable(data.table);
  } else {
    activeTableId = "";
    renderSummaryLinks(isSummary ? data.title : null);
  }
  document.title = `${data.title} · HVAC Design Workbook`;
}

function renderReferenceTable(tableId, query = tableSearch.value) {
  const table = ashraeTables.find((candidate) => candidate.id === tableId);
  if (!table) return;
  activeTableId = tableId;
  tableStandard.textContent = table.standard;
  const normalized = query.trim().toLowerCase();
  const sourceRows = projectTableRows(table);
  const rows = sourceRows
    .map((row, sourceIndex) => ({ row, sourceIndex }))
    .filter(({ row }) => !normalized || row.some((value) => String(value ?? "").toLowerCase().includes(normalized)));

  if (tableSort.tableId === tableId && tableSort.column >= 0) {
    const { column, direction } = tableSort;
    rows.sort((left, right) => compareTableValues(left.row[column], right.row[column]) * (direction === "asc" ? 1 : -1));
  }

  referenceTable.innerHTML = "";
  const head = document.createElement("thead");
  const headerRow = document.createElement("tr");
  table.headers.forEach((header, columnIndex) => {
    const cell = document.createElement("th");
    cell.scope = "col";
    const button = document.createElement("button");
    button.type = "button";
    button.className = "table-sort-button";
    button.title = `Sort by ${header.label}`;
    button.setAttribute("aria-label", `Sort by ${header.label}`);

    const label = document.createElement("span");
    label.className = "column-label";
    appendFormattedText(label, header.label);
    if (header.subscript) {
      const subscript = document.createElement("sub");
      subscript.textContent = header.subscript;
      label.appendChild(subscript);
    }
    button.appendChild(label);

    if (header.unit) {
      const unit = document.createElement("span");
      unit.className = "column-unit";
      appendFormattedText(unit, header.unit);
      button.appendChild(unit);
    }

    const indicator = document.createElement("span");
    indicator.className = "sort-indicator";
    if (tableSort.tableId === tableId && tableSort.column === columnIndex) {
      indicator.textContent = tableSort.direction === "asc" ? "↑" : "↓";
      cell.setAttribute("aria-sort", tableSort.direction === "asc" ? "ascending" : "descending");
    } else {
      indicator.textContent = "↕";
    }
    button.appendChild(indicator);
    button.addEventListener("click", () => sortReferenceTable(tableId, columnIndex));
    cell.appendChild(button);
    headerRow.appendChild(cell);
  });
  head.appendChild(headerRow);

  const body = document.createElement("tbody");
  rows.forEach(({ row, sourceIndex }) => {
    const tableRow = document.createElement("tr");
    row.forEach((value, index) => {
      const cell = document.createElement("td");
      cell.textContent = value ?? "";
      if (typeof value === "number") cell.classList.add("numeric-cell");
      if ((table.calculatedColumns || []).includes(index)) {
        cell.classList.add("calculated-cell");
        cell.title = "Calculated from other cells in this row";
      } else {
        cell.classList.add("editable-cell");
        cell.contentEditable = "true";
        cell.spellcheck = false;
        cell.setAttribute("aria-label", `Edit ${table.headers[index].label}, row ${sourceIndex + 1}`);
        cell.addEventListener("keydown", (event) => {
          if (event.key === "Enter") {
            event.preventDefault();
            cell.blur();
          } else if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(event.key)) {
            event.preventDefault();
            moveToAdjacentCell(cell, event.key);
          }
        });
        cell.addEventListener("blur", () => updateTableCell(table, sourceRows, sourceIndex, index, cell.textContent, tableRow));
      }
      tableRow.appendChild(cell);
    });
    body.appendChild(tableRow);
  });

  const widths = calculateColumnWidths(table, sourceRows);
  const columnGroup = document.createElement("colgroup");
  widths.forEach((width) => {
    const column = document.createElement("col");
    column.style.width = `${width}px`;
    columnGroup.appendChild(column);
  });
  referenceTable.append(columnGroup, head, body);
  referenceTable.style.width = `${widths.reduce((total, width) => total + width, 0)}px`;
  tableCount.textContent = `${rows.length} of ${sourceRows.length} rows`;
}

function appendFormattedText(element, text) {
  String(text).split(/(ft2)/gi).forEach((part) => {
    if (part.toLowerCase() === "ft2") {
      element.append("ft");
      const superscript = document.createElement("sup");
      superscript.textContent = "2";
      element.appendChild(superscript);
    } else {
      element.append(part);
    }
  });
}

function projectTableRows(table) {
  const project = activeProject();
  if (!project) return table.rows;
  project.independentTables ||= {};
  if (!Array.isArray(project.independentTables[table.id])) {
    project.independentTables[table.id] = table.rows.map((row) => [...row]);
    saveProjects();
  }
  return project.independentTables[table.id];
}

function updateTableCell(table, rows, rowIndex, columnIndex, rawValue, tableRow) {
  const value = rawValue.trim();
  rows[rowIndex][columnIndex] = table.columnTypes[columnIndex] === "number" && value !== "" && Number.isFinite(Number(value))
    ? Number(value)
    : value;
  recalculateTableRow(table, rows[rowIndex]);
  (table.calculatedColumns || []).forEach((index) => {
    const cell = tableRow.cells[index];
    if (cell) cell.textContent = rows[rowIndex][index] ?? "";
  });
  saveProjects();
  autoFitRenderedTable(table, rows);
}

function recalculateTableRow(table, row) {
  if (table.calculation === "baseline-system-list") row[2] = `${row[0] ?? ""} - ${row[1] ?? ""}`;
}

function compareTableValues(left, right) {
  const leftBlank = left === null || left === undefined || left === "";
  const rightBlank = right === null || right === undefined || right === "";
  if (leftBlank !== rightBlank) return leftBlank ? 1 : -1;
  if (typeof left === "number" && typeof right === "number") return left - right;
  return String(left ?? "").localeCompare(String(right ?? ""), undefined, { numeric: true, sensitivity: "base" });
}

function calculateColumnWidths(table, rows) {
  const context = document.createElement("canvas").getContext("2d");
  context.font = '11px Aptos, "Segoe UI", Arial, sans-serif';
  return table.headers.map((header, index) => {
    const headerText = `${header.label || ""} ${header.unit || ""}`.trim();
    const contentWidth = rows.reduce((maximum, row) => Math.max(maximum, context.measureText(String(row[index] ?? "")).width), 0);
    const headerWidth = context.measureText(headerText).width + 26;
    return Math.ceil(Math.min(420, Math.max(110, contentWidth + 24, headerWidth)));
  });
}

function autoFitRenderedTable(table, rows) {
  const widths = calculateColumnWidths(table, rows);
  referenceTable.querySelectorAll("col").forEach((column, index) => {
    column.style.width = `${widths[index]}px`;
  });
  referenceTable.style.width = `${widths.reduce((total, width) => total + width, 0)}px`;
}

function moveToAdjacentCell(cell, key) {
  const row = cell.closest("tr");
  const body = row.parentElement;
  const rows = [...body.rows];
  let rowIndex = rows.indexOf(row);
  let columnIndex = cell.cellIndex;
  const rowStep = key === "ArrowUp" ? -1 : key === "ArrowDown" ? 1 : 0;
  const columnStep = key === "ArrowLeft" ? -1 : key === "ArrowRight" ? 1 : 0;

  while (true) {
    rowIndex += rowStep;
    columnIndex += columnStep;
    const targetRow = rows[rowIndex];
    if (!targetRow || columnIndex < 0 || columnIndex >= targetRow.cells.length) return;
    const target = targetRow.cells[columnIndex];
    if (target.classList.contains("editable-cell")) {
      target.focus();
      const selection = window.getSelection();
      const range = document.createRange();
      range.selectNodeContents(target);
      selection.removeAllRanges();
      selection.addRange(range);
      return;
    }
  }
}

function sortReferenceTable(tableId, column) {
  tableSort = tableSort.tableId === tableId && tableSort.column === column
    ? { tableId, column, direction: tableSort.direction === "asc" ? "desc" : "asc" }
    : { tableId, column, direction: "asc" };
  renderReferenceTable(tableId);
}

function addTableRow() {
  const table = ashraeTables.find((candidate) => candidate.id === activeTableId);
  if (!table) return;
  const rows = projectTableRows(table);
  const row = Array(table.columns.length).fill("");
  recalculateTableRow(table, row);
  rows.push(row);
  saveProjects();
  tableSearch.value = "";
  tableSort = { tableId: table.id, column: -1, direction: "asc" };
  renderReferenceTable(table.id);
  requestAnimationFrame(() => {
    const scroll = document.querySelector(".table-scroll");
    scroll.scrollTop = scroll.scrollHeight;
    referenceTable.querySelector("tbody tr:last-child .editable-cell")?.focus();
  });
}

function renderSummaryLinks(groupName) {
  summaryLinks.innerHTML = "";
  summaryLinks.hidden = !groupName;
  if (!groupName) return;

  const section = modules.find((candidate) => candidate.group === groupName);
  if (!section || !section.items.length) {
    const note = document.createElement("span");
    note.className = "summary-note";
    note.textContent = "Reference tables will be added as their calculation dependencies are migrated.";
    summaryLinks.appendChild(note);
    return;
  }

  section.items.forEach((item) => {
    const button = document.createElement("button");
    button.type = "button";
    button.textContent = item[0];
    button.addEventListener("click", () => {
      search.value = "";
      renderTree();
      const target = document.querySelector(`[data-id="${CSS.escape(slugify(item[0]))}"]`);
      if (target) selectModule(target);
    });
    summaryLinks.appendChild(button);
  });
}

function syncActiveState() {
  const id = location.hash.slice(1) || "space-condition-setpoints";
  document.querySelectorAll("[data-id]").forEach((button) => button.classList.toggle("active", button.dataset.id === id));
  const active = document.querySelector(`[data-id="${CSS.escape(id)}"]`);
  if (active) updateWorkspace(active.dataset);
}

function openBrowser() {
  browser.classList.add("open");
  scrim.classList.add("open");
  document.body.style.overflow = "hidden";
}

function closeBrowser() {
  browser.classList.remove("open");
  scrim.classList.remove("open");
  document.body.style.overflow = "";
}

function createProjectId() {
  return globalThis.crypto?.randomUUID?.() || `project-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function defaultProject() {
  const project = { id: createProjectId() };
  projectFields.forEach((input) => {
    const field = input.dataset.projectField;
    project[field] = localStorage.getItem(`hvac-project-${field}`) ?? input.value ?? "";
  });
  project.number ||= "185021";
  project.name ||= "IESVE Energy Model";
  return project;
}

function saveProjects() {
  localStorage.setItem(PROJECTS_KEY, JSON.stringify(projects));
  localStorage.setItem(ACTIVE_PROJECT_KEY, activeProjectId);
}

function loadProjects() {
  try {
    const saved = JSON.parse(localStorage.getItem(PROJECTS_KEY) || "null");
    projects = Array.isArray(saved) && saved.length ? saved : [defaultProject()];
  } catch {
    projects = [defaultProject()];
  }

  const savedActiveId = localStorage.getItem(ACTIVE_PROJECT_KEY);
  activeProjectId = projects.some((project) => project.id === savedActiveId) ? savedActiveId : projects[0].id;
  saveProjects();
}

function activeProject() {
  return projects.find((project) => project.id === activeProjectId) || projects[0];
}

function fillProjectFields() {
  const project = activeProject();
  if (!project) return;
  projectFields.forEach((input) => {
    input.value = project[input.dataset.projectField] || "";
  });
}

function renderProjectList(query = projectSearch.value) {
  const normalized = query.trim().toLowerCase();
  const matches = projects.filter((project) =>
    [project.number, project.name, project.client].some((value) => String(value || "").toLowerCase().includes(normalized)),
  );
  projectList.innerHTML = "";

  if (!matches.length) {
    const empty = document.createElement("p");
    empty.className = "project-list-empty";
    empty.textContent = "No projects match this search.";
    projectList.appendChild(empty);
    return;
  }

  matches.forEach((project) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "project-list-item";
    button.classList.toggle("active", project.id === activeProjectId);
    if (project.id === activeProjectId) button.setAttribute("aria-current", "true");

    const number = document.createElement("strong");
    number.textContent = project.number;
    const name = document.createElement("span");
    name.textContent = project.name || "Untitled project";
    button.append(number, name);
    button.addEventListener("click", () => selectProject(project.id));
    projectList.appendChild(button);
  });
}

function selectProject(projectId) {
  if (!projects.some((project) => project.id === projectId)) return;
  activeProjectId = projectId;
  saveProjects();
  fillProjectFields();
  renderProjectList();
  syncActiveState();
}

function setProjectSwitcher(open) {
  shell.classList.toggle("projects-open", open);
  projectSwitcherToggle.setAttribute("aria-expanded", String(open));
  projectSwitcherToggle.setAttribute("aria-label", `${open ? "Close" : "Open"} project list`);
  projectSwitcherToggle.title = `${open ? "Close" : "Open"} project list`;
  if (open) {
    renderProjectList();
    projectSearch.focus();
  }
}

function openProjectDialog() {
  projectForm.reset();
  projectDialogError.textContent = "";
  projectDialog.showModal();
  requestAnimationFrame(() => newProjectNumber.focus());
}

function addProject(event) {
  event.preventDefault();
  const number = newProjectNumber.value.trim();
  if (!number) {
    projectDialogError.textContent = "Enter a project number.";
    newProjectNumber.focus();
    return;
  }
  if (projects.some((project) => String(project.number).toLowerCase() === number.toLowerCase())) {
    projectDialogError.textContent = "That project number already exists.";
    newProjectNumber.focus();
    return;
  }

  const project = {
    id: createProjectId(),
    number,
    client: "",
    name: "",
    date: "",
    made_by: "",
    checked_by: "",
    submittal: "",
  };
  projects.push(project);
  projectSearch.value = "";
  projectDialog.close();
  selectProject(project.id);
}

function initializeProjects() {
  loadProjects();
  fillProjectFields();
  renderProjectList();

  projectFields.forEach((input) => {
    if (input.readOnly) return;
    input.addEventListener("input", () => {
      const project = activeProject();
      if (!project) return;
      project[input.dataset.projectField] = input.value;
      saveProjects();
      renderProjectList();
    });
  });
}

search.addEventListener("input", (event) => renderTree(event.target.value));
projectSearch.addEventListener("input", (event) => renderProjectList(event.target.value));
tableSearch.addEventListener("input", (event) => {
  if (activeTableId) renderReferenceTable(activeTableId, event.target.value);
});
addTableRowButton.addEventListener("click", addTableRow);
projectSwitcherToggle.addEventListener("click", () => setProjectSwitcher(!shell.classList.contains("projects-open")));
document.querySelector("#add-project").addEventListener("click", openProjectDialog);
document.querySelector("#cancel-project").addEventListener("click", () => projectDialog.close());
projectForm.addEventListener("submit", addProject);
document.querySelector("#open-browser").addEventListener("click", openBrowser);
document.querySelector("#close-browser").addEventListener("click", closeBrowser);
scrim.addEventListener("click", closeBrowser);
window.addEventListener("hashchange", syncActiveState);
window.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && !projectDialog.open) {
    closeBrowser();
    setProjectSwitcher(false);
  }
});

initializeProjects();
renderTree();

let loadedVersion = null;
async function checkForUpdates() {
  if (document.visibilityState !== "visible") return;
  try {
    const isLocal = location.hostname === "127.0.0.1" || location.hostname === "localhost";
    const versionUrl = isLocal ? `/version?t=${Date.now()}` : `./version.json?t=${Date.now()}`;
    const response = await fetch(versionUrl, { cache: "no-store" });
    if (!response.ok) return;
    const { version } = await response.json();
    if (loadedVersion !== null && version !== loadedVersion) location.reload();
    loadedVersion = version;
  } catch {
    // The local server may be restarting; the next poll will reconnect.
  }
}

checkForUpdates();
setInterval(checkForUpdates, 1200);
