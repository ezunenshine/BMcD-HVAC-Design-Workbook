const modules = [
  {
    group: "Model Inputs",
    source: "Inputs",
    summary: "Project, site, climate, weather, and building inputs used throughout the workbook.",
    directView: "model-inputs",
    items: [],
  },
  {
    group: "IESVE 2025",
    source: "IES Data → IES Loads",
    summary: "Import, normalize, export, and review the IESVE 2025 space and room-load datasets used by the design workbook.",
    items: [
      ["Thermal Templates", "Thermal · B3:O115", "Map thermal space types to ventilation, occupant heat-gain, and lighting criteria.", "iesve-thermal-template"],
      ["Tabular Space Data", "IES Data · D3:AL201", "Review and edit the IESVE tabular space dataset used by downstream calculations.", "iesve-tabular-space-data"],
      ["Room/Zone Loads Report", "Room/Zone Loads · A10:U149", "Review imported room and zone sensible cooling, latent cooling, and heating loads.", "room-zone-loads-report"],
    ],
  },
  {
    group: "Space Calculations",
    source: "Inputs → IES Loads → Calc",
    summary: "Review space conditions, loads, zoning, ventilation, air balance, latent performance, baseline systems, and monitoring criteria.",
    items: [
      ["Space Condition Setpoints", "Calc · F:N", "Define heating, cooling, humidity, setback, and ventilated temperature-rise criteria.", "calc-space-condition-setpoints"],
      ["DHW", "Calc · O:V", "Calculate occupancy-driven domestic hot-water demand and schedule values.", "calc-dhw"],
      ["Lighting Gains", "Calc · W:AC", "Calculate recommended, manual, proposed, and baseline lighting gains by space.", "calc-lighting-gains"],
      ["People Gains", "Calc · AD:AK", "Calculate recommended occupancy and sensible and latent people gains by space.", "calc-people-gains"],
      ["Miscellaneous Sensible Gains", "Calc · AL:AP", "Calculate recommended, manual, and summarized miscellaneous sensible gains by space.", "calc-misc-gains"],
      ["Space Loads", "Calc · AQ:BC", "Consolidate sensible cooling, latent cooling, and heating space loads used for sizing.", "calc-room-loads"],
      ["Equipment Zoning", "Calc · BD:BQ", "Assign spaces to equipment zones and evaluate shared operating criteria.", "calc-equipment-zoning"],
      ["Heating Load Calculations", "Calc · BR:BZ", "Calculate design heating requirements while preserving workbook sizing and rounding logic.", "calc-heating-loads"],
      ["Cooling Load Calculations", "Calc · CA:CO", "Calculate design sensible, latent, and total cooling requirements.", "calc-cooling-loads"],
      ["Required Ventilation and Exhaust Rate Calculations", "Calc · CP:DH", "Determine required outdoor-air and exhaust quantities for each applicable space.", "calc-ventilation-exhaust"],
      ["Pressurization Calculations", "Calc · DI:DY", "Evaluate supply, return, exhaust, and transfer relationships for space pressure intent.", "calc-pressurization"],
      ["Non-Peak Air Balance", "Calc · DZ:EG", "Review airflow balance away from coincident peak-load conditions.", "calc-non-peak-air-balance"],
      ["Air Balance", "Calc · EH:EU", "Review the space supply, return, exhaust, transfer, and balance relationships.", "calc-air-balance"],
      ["Latent Load Calculations", "Calc · EV:FE", "Trace latent gains and moisture loads through the space calculation path.", "calc-latent-loads"],
      ["Space Condition Type and Baseline System", "Calc · FF:FQ", "Map space condition types to the workbook baseline-system logic.", "calc-condition-baseline"],
      ["CO₂ Monitoring Calculation", "Calc · FR:FY", "Identify spaces subject to carbon-dioxide monitoring criteria.", "calc-co2-monitoring"],
    ],
  },
  {
    group: "Selected Space Requirements",
    source: "Lighting → Misc → Exhaust → Transfer",
    summary: "Manage supplemental fixture, equipment, exhaust, and transfer-air requirements for the selected spaces that need added detail.",
    items: [
      ["Lighting Loads", "Lighting · E13:M235", "Add detailed lighting loads for selected spaces where fixture-level inputs are required.", "selected-lighting-loads"],
      ["Miscellaneous Sensible Loads", "Misc · E9:R72", "Add detailed plug, process, and equipment sensible loads for selected spaces.", "selected-misc-loads"],
      ["General Exhaust Requirements", "Exhaust · T9:AI89", "Apply general exhaust criteria to selected spaces.", "selected-general-exhaust"],
      ["Exhaust Equipment Requirements", "Exhaust · AK9:AT84", "Define equipment-specific exhaust demands and operating relationships.", "selected-exhaust-equipment"],
      ["Transfer Air", "Transfer · L9:V110", "Define transfer-air paths and quantities for selected spaces.", "selected-transfer-air"],
    ],
  },
  {
    group: "Airside Equipment",
    source: "Airside → Psych",
    summary: "Review airside design settings, coil duties, and psychrometric processes for the project systems.",
    items: [
      ["Settings", "Airside · B:AG", "Configure shared airside design conditions and equipment assumptions.", "airside-settings"],
      ["Preheat Coils", "Airside · AH:AT", "Size and review preheat coil performance at workbook design conditions.", "airside-preheat"],
      ["Cooling Coils", "Airside · AU:CM", "Size and review cooling coil sensible, latent, and total performance.", "airside-cooling"],
      ["Reheat / Heating Coils", "Airside · CN:DG", "Size and review reheat and heating coil performance.", "airside-heating"],
      ["Psychrometric Charts", "Psych", "Visualize air-state processes used in the airside calculations."],
    ],
  },
  {
    group: "Plantside Equipment",
    source: "Plantside",
    summary: "Review the calculated cooling and heating plant design duties and equipment selections.",
    items: [
      ["Plantside Equipment", "Plantside · B9:U12", "Review plant equipment selections and calculated design duties.", "plantside-equipment"],
    ],
  },
  {
    group: "Energy",
    source: "Energy",
    summary: "Compare proposed energy performance with the four baseline building rotations used by the workbook.",
    items: [
      ["Proposed", "Energy", "Review the proposed building energy-model results."],
      ["Baseline 000deg", "Energy", "Review the baseline energy-model results at the 000-degree rotation."],
      ["Baseline 090deg", "Energy", "Review the baseline energy-model results at the 090-degree rotation."],
      ["Baseline 180deg", "Energy", "Review the baseline energy-model results at the 180-degree rotation."],
      ["Baseline 270deg", "Energy", "Review the baseline energy-model results at the 270-degree rotation."],
    ],
  },
  {
    group: "Independent Tables",
    source: "Lighting → Misc → Exhaust → ASHRAE → Water",
    summary: "Browse project schedules and the independent ASHRAE and water-property reference tables used by the workbook calculations.",
    items: [
      ["Lighting Schedule", "Lighting · O13:Q62", "Lighting fixture types, wattages, and calculated project quantities.", "schedule-lighting"],
      ["Equipment Sensible Gain Schedule", "Misc · T9:Z56", "Equipment load inputs in Btu/h and kW with efficiency, space allocation, calculated heat gain, and project quantities.", "schedule-equipment-sensible-gain"],
      ["Grouped Equipment Sensible Gain Schedule", "Misc · AA9:AE11", "Reusable equipment groups with calculated row heat gain and group heat-gain totals.", "schedule-grouped-equipment-sensible-gain"],
      ["General Exhaust Schedule", "Exhaust · AV9:BE40", "General exhaust criteria by fixture, area, and occupied or unoccupied air-change basis.", "schedule-general-exhaust"],
      ["Exhaust Equipment Schedule", "Exhaust · AV9:BE40", "Equipment-specific exhaust airflow for on and off operating conditions.", "schedule-exhaust-equipment"],
      ["Ventilation Rates", "ASHRAE · B4:E83", "Outdoor-air rates and default occupant density by occupancy category.", "ashrae-62-1-ventilation"],
      ["Baseline Lighting Power Density", "ASHRAE · G4:H108", "Baseline lighting power density by common space type.", "ashrae-90-1-baseline-lighting"],
      ["Proposed Lighting Power Density", "ASHRAE · J4:K103", "Lighting power allowances by common space type.", "ashrae-90-1-proposed-lighting"],
      ["Occupant Heat Gain", "ASHRAE · M4:O17", "Sensible and latent heat gain per person by activity level.", "ashrae-fundamentals-people-heat"],
      ["Climate Zones and Baseline Systems", "ASHRAE · T4:AD23", "Climate-zone descriptions and baseline system assignments by building type and size.", "ashrae-climate-zones"],
      ["Baseline System Descriptions", "ASHRAE · AL4:AR18", "Baseline HVAC system types, fan control, cooling source, and heating source.", "ashrae-90-1-baseline-systems"],
      ["FEMP SHW Calculator Table", "ASHRAE · AT4:AU11", "Estimated service hot-water use by building type for domestic hot-water calculations.", "femp-shw-calculator"],
      ["Ethylene Glycol Density", "Water · B9:L38", "Density of aqueous ethylene glycol solutions by temperature and volume concentration.", "water-ethylene-density"],
      ["Propylene Glycol Density", "Water · O9:Y38", "Density of inhibited aqueous propylene glycol solutions by temperature and volume concentration.", "water-propylene-density"],
      ["Ethylene Glycol Specific Heat", "Water · B44:L73", "Specific heat of aqueous ethylene glycol solutions by temperature and volume concentration.", "water-ethylene-specific-heat"],
      ["Propylene Glycol Specific Heat", "Water · O44:Y73", "Specific heat of aqueous propylene glycol solutions by temperature and volume concentration.", "water-propylene-specific-heat"],
      ["Water Properties at 14.700 psia", "Water · B89:O113", "Thermophysical properties of water at atmospheric pressure.", "water-nist-properties"],
    ],
  },
];

const independentTables = [
  ...(globalThis.INDEPENDENT_TABLES || []),
  ...(globalThis.CALC_SECTION_TABLES || []),
  ...(globalThis.SELECTED_REQUIREMENT_TABLES || []),
  ...(globalThis.AIRSIDE_PLANTSIDE_TABLES || []),
].filter((table) => table.id !== "calc-general");

if (!independentTables.some((table) => table.id === "femp-shw-calculator")) {
  independentTables.push({
    id: "femp-shw-calculator",
    name: "FEMP SHW Calculator Table",
    standard: "FEMP SHW Calculator Table",
    description: "Estimated hot-water use from the workbook FEMP SHW Calculator table.",
    sheet: "ASHRAE",
    range: "AT4:AU11",
    headers: [
      { label: "Building Type" },
      { label: "Estimated Hot Water Use", unit: "gal/person-day" },
    ],
    columns: ["Building Type", "Estimated Hot Water Use (gal/person-day)"],
    columnTypes: ["text", "number"],
    lockedColumns: [0, 1],
    identityColumns: [0],
    rows: [
      ["House", 15.8],
      ["Hotel/Motel", 20],
      ["Hospital", 52],
      ["Office", 1.1],
      ["Restaurant", 2.4],
      ["School", 0.5],
      ["School with Showers", 1.9],
    ],
  });
}

if (!independentTables.some((table) => table.id === "project-inputs")) {
  independentTables.unshift({
    id: "project-inputs",
    name: "Model Inputs",
    standard: "Model Inputs",
    description: "Project site, climate, weather, and building inputs from the workbook Inputs sheet.",
    sheet: "Inputs",
    range: "B19:I54",
    headers: [
      { label: "Category" }, { label: "Input" }, { label: "Value" }, { label: "Unit" },
    ],
    columns: ["Category", "Input", "Value", "Unit"],
    columnTypes: ["text", "text", "text", "text"],
    lockedColumns: [0, 1, 3],
    cellDropdownRows: { 16: { 2: ["TRUE"] } },
    frozenColumns: 2,
    identityColumns: [0, 1],
    schemaVersion: 2,
    rows: [
      ["Site", "Location", "Forest Park, Georgia", ""],
      ["Site", "Country / State", "Curry County, NM", ""],
      ["Site", "Latitude", "33.63 N", "degrees"],
      ["Site", "Longitude", "84.442 W", "degrees"],
      ["Site", "Climate Zone", "3A", ""],
      ["Site", "Elevation", 1011, "ft"],
      ["Site", "Simulation Weather Data", "USA_GA_Atlanta-Hartsfield-Jackson_Intl.AP_722190_TMY3.epw", ""],
      ["Cooling Design", "Percentile", 0.01, "%"],
      ["Cooling Design", "Dry Bulb", 91.6, "°F"],
      ["Cooling Design", "Wet Bulb", 73.6, "°F"],
      ["Dehumidification", "Dry Bulb", 80.4, "°F"],
      ["Dehumidification", "Humidity Ratio", 128.5, "gr/lb"],
      ["Heating Design", "Percentile", 0.99, "%"],
      ["Heating Design", "Dry Bulb", 27.1, "°F"],
      ["Humidification", "Dry Bulb", 32.1, "°F"],
      ["Humidification", "Humidity Ratio", 9.2, "gr/lb"],
      ["Building", "UFC", "TRUE", ""],
      ["Building", "Infiltration at 0.3 in. pressure differential", 0.25, "CFM/ft2"],
    ],
  });
}

configureCalcSectionTables();
configureSelectedRequirementTables();
configureThermalTemplate();
configureAirsideTables();
independentTables.filter((table) => table.id.startsWith("calc-")).forEach((table) => {
  table.fixedRows = true;
  table.spaceColumn = table.id === "calc-equipment-zoning" ? 2 : 0;
});

function configureAirsideTables() {
  const settings = independentTables.find((table) => table.id === "airside-settings");
  if (!settings) return;
  const sourceIndexes = [0, 1, 2, 3, 4, 6, 8, 9, 29, 31, 10, 12, 17, 18, 19, 20, 21, 22, 23, 24, 26, 27];
  settings.sourceRows = Object.fromEntries(Object.entries(settings.sourceRows || {}).map(([equipment, row]) => {
    const migrated = sourceIndexes.map((index) => row[index] ?? "");
    [4, 5, 6, 7, 8, 9, 10].forEach((index) => { migrated[index] = ""; });
    return [equipment, migrated];
  }));
  settings.headers = [
    { label: "Equipment" },
    { label: "Rooms Served" },
    { label: "Design Airflow", unit: "CFM" },
    { label: "Unit Type" },
    { label: "Quantity" },
    { label: "Load Percentage", unit: "%" },
    { label: "Preheat Coil" },
    { label: "Ventilation Cooling Coil" },
    { label: "Ez, Cool" },
    { label: "Ez, Heat" },
    { label: "Energy Recovery" },
    { label: "Associated Equipment" },
    { label: "Ventilation Unocc Minimum", unit: "CFM" },
    { label: "Ventilation Occ Minimum", unit: "CFM" },
    { label: "Cooling Peak", unit: "CFM" },
    { label: "IESVE Cooling Block", unit: "CFM" },
    { label: "Cooling Design", unit: "CFM" },
    { label: "Heating Peak", unit: "CFM" },
    { label: "IESVE Heating Block", unit: "CFM" },
    { label: "Heating Design", unit: "CFM" },
    { label: "Exhaust Minimum", unit: "CFM" },
    { label: "Exhaust Airflow", unit: "CFM" },
  ];
  settings.columns = settings.headers.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`);
  settings.columnTypes = ["text", "number", "number", "text", "number", "number", "number", "number", "text", "text", "text", "text", ...Array(10).fill("number")];
  settings.calculatedColumns = [1, 2, 11, 12, 13, 14, 16, 17, 19, 20, 21];
  settings.lockedColumns = [0, 1, 2];
  settings.identityColumns = [0, 1, 2];
  settings.frozenColumns = 3;
  settings.dropdownColumns = {
    6: { options: ["TRUE", "FALSE"] },
    7: { options: ["TRUE", "FALSE"] },
    10: { options: ["TRUE", "FALSE"] },
  };
  settings.autoColumns = [4, 5, 6, 7, 8, 9, 10];
  settings.zeroDecimalColumns = [1, 2, 4, 5, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21];
  settings.oneDecimalColumns = [8, 9];
  settings.columnWidthOverrides = { 6: 96, 7: 112, 8: 76, 9: 76, 10: 96 };
  settings.headerClasses = { 6: "heating-load-header", 7: "sensible-cooling-header" };
  settings.displayEquations = {
    1: '=COUNTA(UNIQUE(FILTER([Equipment Zoning]@Space, EQUIPMENTMATCH(@Equipment))))',
    2: '=IF(@Cooling Design<>0, @Cooling Design, @Exhaust Airflow)',
    5: '=1 / @Quantity',
    8: '=IF(@Ventilation Cooling Coil="TRUE", 1.0, "")',
    9: '=IF(@Ventilation Cooling Coil="TRUE", 1.0, "")',
    11: '=EQUIPMENTASSOCIATION(@Equipment, [Equipment Zoning])',
    12: '=SUMIF([Equipment Zoning]@Equipment, @Equipment, [Space Calculations]@Ventilation Unocc Minimum)',
    13: '=SUMIF([Equipment Zoning]@Equipment, @Equipment, [Space Calculations]@Ventilation Occ Minimum)',
    14: '=SUMIF([Equipment Zoning]@Cooling Equipment, @Equipment, [Space Calculations]@Cooling Airflow)',
    15: '=[IESVE Room Loads]@Cooling Block Airflow',
    16: '=IF(@IESVE Cooling Block="", @Cooling Peak * @Load Percentage, @IESVE Cooling Block * @Load Percentage)',
    17: '=SUMIF([Equipment Zoning]@Heating Equipment, @Equipment, [Space Calculations]@Heating Airflow)',
    18: '=[IESVE Room Loads]@Heating Block Airflow',
    19: '=IF(@IESVE Heating Block="", @Heating Peak * @Load Percentage, @IESVE Heating Block * @Load Percentage)',
    20: '=XLOOKUP(@Equipment, [Exhaust Requirements]@Equipment, [Exhaust Requirements]@Minimum Airflow) * @Load Percentage',
    21: '=XLOOKUP(@Equipment, [Exhaust Requirements]@Equipment, [Exhaust Requirements]@Airflow) * @Load Percentage',
  };
  settings.airsideSettingsCalculation = true;
  settings.preserveImportedValues = true;
  settings.readonlyEquations = true;

  const configureCoil = (id, colorClass, groups, renamedHeaders = {}) => {
    const table = independentTables.find((candidate) => candidate.id === id);
    if (!table) return;
    Object.entries(renamedHeaders).forEach(([column, label]) => { table.headers[Number(column)].label = label; });
    table.headers.forEach((header) => {
      header.label = header.label
        .replace(/^Outside Air Heating - /, "")
        .replace(/^Outside Air Cooling - /, "")
        .replace(/^Outside Air Dehumidification - /, "")
        .replace(/^Room Air Cooling - /, "")
        .replace(/^Preheat Coil Air Leaving - /, "")
        .replace(/^Room Air Heating - /, "");
    });
    table.columns = table.headers.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`);
    table.headerGroups = [{ label: "General", start: 0, span: 1, className: "space-group-header" }, ...groups.map((group) => ({ ...group, className: colorClass }))];
    table.headerClasses = Object.fromEntries(table.headers.map((_, index) => [index, index === 0 ? "space-group-header" : colorClass]));
    table.sectionStartColumns = groups.slice(1).map((group) => group.start);
    table.zeroDecimalColumns = table.headers.map((header, index) => header.unit === "CFM" || /Latent Constant/i.test(header.label) ? index : -1).filter((index) => index >= 0);
    table.oneDecimalColumns = table.headers.map((header, index) => header.unit === "°F" ? index : -1).filter((index) => index >= 0);
    table.threeDecimalColumns = table.headers.map((header, index) => /Sensible Constant/i.test(header.label) ? index : -1).filter((index) => index >= 0);
    table.fiveDecimalColumns = table.headers.map((header, index) => header.unit === "lb/lb" ? index : -1).filter((index) => index >= 0);
    table.decimalColumns = table.headers.map((header, index) => ["MBH", "GPM"].includes(header.unit) ? index : -1).filter((index) => index >= 0);
  };
  configureCoil("airside-preheat", "heating-load-header", [
    { label: "Leaving Conditions", start: 1, span: 5 },
    { label: "Outside Air Heating", start: 6, span: 6 },
    { label: "Plant", start: 12, span: 2 },
  ], { 6: "Sensible Constant" });
  configureCoil("airside-cooling", "sensible-cooling-header", [
    { label: "Leaving Conditions", start: 1, span: 13 },
    { label: "Outside Air Cooling", start: 14, span: 9 },
    { label: "Outside Air Dehumidification", start: 23, span: 9 },
    { label: "Room Air Cooling", start: 32, span: 9 },
    { label: "Capacity and Plant", start: 41, span: 5 },
  ], { 14: "Sensible Constant", 15: "Latent Constant", 23: "Sensible Constant", 24: "Latent Constant", 32: "Sensible Constant", 33: "Latent Constant" });
  configureCoil("airside-heating", "heating-load-header", [
    { label: "Leaving Conditions", start: 1, span: 5 },
    { label: "Preheat Coil Air Leaving", start: 6, span: 6 },
    { label: "Room Air Heating", start: 12, span: 6 },
    { label: "Capacity and Plant", start: 18, span: 3 },
  ], { 6: "Sensible Constant", 12: "Sensible Constant" });
  configureDetailedCoilTables();
}

function configureDetailedCoilTables() {
  const configure = ({ id, headers, transform, calculatedColumns, groups, colorClass, autoColumns = [], editableColumns = [] }) => {
    const table = independentTables.find((candidate) => candidate.id === id);
    if (!table) return;
    table.sourceRows = Object.fromEntries(Object.entries(table.sourceRows || {}).map(([equipment, row]) => [equipment, transform(row)]));
    table.headers = headers;
    table.columns = headers.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`);
    table.columnTypes = headers.map((header, index) => index === 0 || ["Equipment", "Plant Serving Coil"].includes(header.label) ? "text" : "number");
    table.calculatedColumns = calculatedColumns;
    table.lockedColumns = [0];
    table.identityColumns = [0];
    table.frozenColumns = 1;
    table.headerGroups = [{ label: "General", start: 0, span: 1, className: "space-group-header" }, ...groups.map((group) => ({ ...group, className: colorClass }))];
    table.headerClasses = Object.fromEntries(headers.map((_, index) => [index, index ? colorClass : "space-group-header"]));
    table.sectionStartColumns = groups.slice(1).map((group) => group.start);
    table.autoColumns = autoColumns;
    table.zeroDecimalColumns = headers.map((header, index) => header.unit === "CFM" || /Latent Constant/i.test(header.label) ? index : -1).filter((index) => index >= 0);
    table.oneDecimalColumns = headers.map((header, index) => header.unit === "°F" ? index : -1).filter((index) => index >= 0);
    table.threeDecimalColumns = headers.map((header, index) => /Sensible Constant/i.test(header.label) ? index : -1).filter((index) => index >= 0);
    table.fiveDecimalColumns = headers.map((header, index) => header.unit === "lb/lb" ? index : -1).filter((index) => index >= 0);
    table.decimalColumns = headers.map((header, index) => ["MBH", "GPM"].includes(header.unit) ? index : -1).filter((index) => index >= 0);
    table.preserveImportedValues = false;
    table.readonlyEquations = true;
    table.coilCalculation = id.replace("airside-", "");
    table.schemaVersion = undefined;
  };

  configure({
    id: "airside-preheat",
    headers: [
      { label: "Equipment" },
      { label: "Dry-Bulb", unit: "°F" }, { label: "Hum-Ratio", unit: "lb/lb" }, { label: "Wet-Bulb", unit: "°F" }, { label: "Sensible Constant" },
      { label: "Dry-Bulb", unit: "°F" }, { label: "Hum-Ratio", unit: "lb/lb" }, { label: "Wet-Bulb", unit: "°F" }, { label: "Sensible Constant" },
      { label: "Airflow", unit: "CFM" }, { label: "Capacity", unit: "MBH" }, { label: "Plant Serving Coil" }, { label: "Flow Rate", unit: "GPM" },
    ],
    transform: (row) => [row[0], "", row[3], row[4], row[5], row[7], row[8], row[9], row[6], row[10], row[11], row[12], row[13]],
    calculatedColumns: [2, 3, 4, 5, 6, 7, 8, 10],
    autoColumns: [1],
    editableColumns: [1, 9, 11, 12],
    colorClass: "heating-load-header",
    groups: [
      { label: "Leaving Conditions", start: 1, span: 4 },
      { label: "Entering Conditions - Heating Design Day", start: 5, span: 6 },
      { label: "Plant", start: 11, span: 2 },
    ],
  });

  configure({
    id: "airside-cooling",
    headers: [
      { label: "Equipment" },
      { label: "Unaccounted Latent", unit: "MBH" }, { label: "Required Dry-Bulb", unit: "°F" }, { label: "Min Dry-Bulb", unit: "°F" }, { label: "Rel-Hum", unit: "%" }, { label: "Hum-Ratio", unit: "lb/lb" }, { label: "Wet-Bulb", unit: "°F" }, { label: "Sensible Constant" }, { label: "Latent Constant" },
      { label: "Max Dry-Bulb", unit: "°F" }, { label: "Rel-Hum", unit: "%" }, { label: "Hum-Ratio", unit: "lb/lb" }, { label: "Wet-Bulb", unit: "°F" }, { label: "Sensible Constant" }, { label: "Latent Constant" },
      { label: "Dry-Bulb", unit: "°F" }, { label: "Hum-Ratio", unit: "lb/lb" }, { label: "Wet-Bulb", unit: "°F" }, { label: "Sensible Constant" }, { label: "Latent Constant" }, { label: "Airflow", unit: "CFM" }, { label: "Sensible", unit: "MBH" }, { label: "Latent", unit: "MBH" }, { label: "Capacity", unit: "MBH" },
      { label: "Dry-Bulb", unit: "°F" }, { label: "Hum-Ratio", unit: "lb/lb" }, { label: "Wet-Bulb", unit: "°F" }, { label: "Sensible Constant" }, { label: "Latent Constant" }, { label: "Airflow", unit: "CFM" }, { label: "Sensible", unit: "MBH" }, { label: "Latent", unit: "MBH" }, { label: "Capacity", unit: "MBH" },
      { label: "Dry-Bulb", unit: "°F" }, { label: "Hum-Ratio", unit: "lb/lb" }, { label: "Wet-Bulb", unit: "°F" }, { label: "Sensible Constant" }, { label: "Latent Constant" }, { label: "Airflow", unit: "CFM" }, { label: "Sensible", unit: "MBH" }, { label: "Latent", unit: "MBH" }, { label: "Capacity", unit: "MBH" },
      { label: "Sensible Capacity", unit: "MBH" }, { label: "Latent Capacity", unit: "MBH" }, { label: "Total Capacity", unit: "MBH" }, { label: "Plant Serving Coil" }, { label: "Flow Rate", unit: "GPM" },
    ],
    transform: (row) => [
      row[0], row[3], row[4], "", "", "", "", "", "", "", "", "", "", "", "",
      row[16], row[17], row[18], row[14], row[15], row[19], row[20], row[21], row[22],
      row[25], row[26], row[27], row[23], row[24], row[28], row[29], row[30], row[31],
      row[34], row[35], row[36], row[32], row[33], row[37], row[38], row[39], row[40],
      row[41], row[42], row[43], row[44], row[45],
    ],
    calculatedColumns: [5, 6, 7, 8, 11, 12, 13, 14, ...Array.from({ length: 30 }, (_, index) => index + 15).filter((index) => ![20, 29, 38, 45].includes(index)), 46],
    autoColumns: [3, 4, 9, 10],
    editableColumns: [1, 2, 3, 4, 9, 10, 20, 29, 38, 45],
    colorClass: "sensible-cooling-header",
    groups: [
      { label: "Leaving Conditions - Dehumidification Mode", start: 1, span: 8 },
      { label: "Leaving Conditions - Normal Operation", start: 9, span: 6 },
      { label: "Entering Conditions - Cooling Design Day", start: 15, span: 9 },
      { label: "Entering Conditions - Dehumidification Design Day", start: 24, span: 9 },
      { label: "Entering Conditions - Cooling Room Air", start: 33, span: 9 },
      { label: "Capacity and Plant", start: 42, span: 5 },
    ],
  });

  configure({
    id: "airside-heating",
    headers: [
      { label: "Equipment" },
      { label: "Dry-Bulb", unit: "°F" }, { label: "Hum-Ratio", unit: "lb/lb" }, { label: "Wet-Bulb", unit: "°F" }, { label: "Sensible Constant" },
      { label: "Dry-Bulb", unit: "°F" }, { label: "Hum-Ratio", unit: "lb/lb" }, { label: "Wet-Bulb", unit: "°F" }, { label: "Sensible Constant" }, { label: "Airflow", unit: "CFM" }, { label: "Capacity", unit: "MBH" },
      { label: "Dry-Bulb", unit: "°F" }, { label: "Hum-Ratio", unit: "lb/lb" }, { label: "Wet-Bulb", unit: "°F" }, { label: "Sensible Constant" }, { label: "Airflow", unit: "CFM" }, { label: "Capacity", unit: "MBH" },
      { label: "Total Capacity", unit: "MBH" }, { label: "Plant Serving Coil" }, { label: "Flow Rate", unit: "GPM" },
    ],
    transform: (row) => [row[0], "", row[3], row[4], row[5], row[7], row[8], row[9], row[6], row[10], row[11], row[13], row[14], row[15], row[12], row[16], row[17], row[18], row[19], row[20]],
    calculatedColumns: [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 19],
    autoColumns: [1],
    editableColumns: [1, 18],
    colorClass: "heating-load-header",
    groups: [
      { label: "Leaving Conditions", start: 1, span: 4 },
      { label: "Entering Air Condition - Preheat Coil Air Leaving", start: 5, span: 6 },
      { label: "Entering Air Condition - Room Air", start: 11, span: 6 },
      { label: "Capacity and Plant", start: 17, span: 3 },
    ],
  });

  const preheat = independentTables.find((table) => table.id === "airside-preheat");
  if (preheat) preheat.displayEquations = {
    2: '=[Entering Conditions - Heating Design Day]@Hum-Ratio',
    3: '=WETBULB(@Dry-Bulb, @Hum-Ratio, [Model Inputs]@Barometric Pressure)',
    4: '=SENSIBLECONSTANT(@Dry-Bulb, @Hum-Ratio, [Model Inputs]@Barometric Pressure)',
    5: '=[Model Inputs]@Heating Design Dry-Bulb', 6: '=[Model Inputs]@Heating Design Hum-Ratio',
    7: '=WETBULB(@Dry-Bulb, @Hum-Ratio, [Model Inputs]@Barometric Pressure)',
    8: '=SENSIBLECONSTANT(@Dry-Bulb, @Hum-Ratio, [Model Inputs]@Barometric Pressure)',
    10: '=@Sensible Constant * @Airflow * ([Leaving Conditions]@Dry-Bulb - [Entering Conditions]@Dry-Bulb) / 1000',
  };
  const cooling = independentTables.find((table) => table.id === "airside-cooling");
  if (cooling) cooling.displayEquations = {
    5: '=HUMIDITYRATIO(@Dry-Bulb, @Rel-Hum, [Model Inputs]@Barometric Pressure)', 6: '=WETBULB(@Dry-Bulb, @Hum-Ratio)',
    7: '=SENSIBLECONSTANT(@Dry-Bulb, @Hum-Ratio)', 8: '=LATENTCONSTANT(@Dry-Bulb, @Hum-Ratio)',
    11: '=HUMIDITYRATIO(@Dry-Bulb, @Rel-Hum, [Model Inputs]@Barometric Pressure)', 12: '=WETBULB(@Dry-Bulb, @Hum-Ratio)',
    13: '=SENSIBLECONSTANT(@Dry-Bulb, @Hum-Ratio)', 14: '=LATENTCONSTANT(@Dry-Bulb, @Hum-Ratio)',
    15: '=[Model Inputs]@Cooling Design Dry-Bulb', 16: '=[Model Inputs]@Cooling Design Hum-Ratio',
    24: '=[Model Inputs]@Dehumidification Design Dry-Bulb', 25: '=[Model Inputs]@Dehumidification Design Hum-Ratio',
    33: '=AVERAGE([Space Condition Setpoints]@Cooling Setpoint for rooms served)',
    34: '=AVERAGE([Space Condition Setpoints]@Cooling Hum-Ratio for rooms served)',
    42: '=SUM(@Sensible across entering conditions)', 43: '=SUM(@Latent across entering conditions)', 44: '=@Sensible Capacity + @Latent Capacity',
  };
  [17, 26, 35].forEach((column) => { if (cooling) cooling.displayEquations[column] = '=WETBULB(@Dry-Bulb, @Hum-Ratio)'; });
  [18, 27, 36].forEach((column) => { if (cooling) cooling.displayEquations[column] = '=SENSIBLECONSTANT(@Dry-Bulb, @Hum-Ratio)'; });
  [19, 28, 37].forEach((column) => { if (cooling) cooling.displayEquations[column] = '=LATENTCONSTANT(@Dry-Bulb, @Hum-Ratio)'; });
  [[21, "Sensible"], [22, "Latent"], [23, "Capacity"], [30, "Sensible"], [31, "Latent"], [32, "Capacity"], [39, "Sensible"], [40, "Latent"], [41, "Capacity"]].forEach(([column, name]) => {
    if (cooling) cooling.displayEquations[column] = name === "Capacity" ? '=@Sensible + @Latent' : `=AIR${String(name).toUpperCase()}LOAD(@Entering, @Leaving, @Airflow)`;
  });
  const heating = independentTables.find((table) => table.id === "airside-heating");
  if (heating) heating.displayEquations = {
    2: '=AVERAGE([Space Condition Setpoints]@Heating Hum-Ratio for rooms served)', 3: '=WETBULB(@Dry-Bulb, @Hum-Ratio)',
    4: '=SENSIBLECONSTANT(@Dry-Bulb, @Hum-Ratio)',
    5: '=XLOOKUP(@Upstream Ventilation Equipment, [Preheat Coils]@Equipment, [Preheat Coils]@Leaving Dry-Bulb)',
    6: '=[Preheat Coils]@Leaving Hum-Ratio', 7: '=[Preheat Coils]@Leaving Wet-Bulb', 8: '=[Preheat Coils]@Leaving Sensible Constant',
    11: '=AVERAGE([Space Condition Setpoints]@Heating Setpoint for rooms served)',
    12: '=AVERAGE([Space Condition Setpoints]@Heating Hum-Ratio for rooms served)', 13: '=WETBULB(@Dry-Bulb, @Hum-Ratio)',
    14: '=SENSIBLECONSTANT(@Dry-Bulb, @Hum-Ratio)', 16: '=@Sensible Constant * @Airflow * ([Leaving Conditions]@Dry-Bulb - @Dry-Bulb) / 1000',
    17: '=SUM(@Capacity)', 19: '=PLANTFLOW(@Total Capacity, @Plant Serving Coil)',
  };
}

function configureThermalTemplate() {
  const thermal = independentTables.find((table) => table.id === "iesve-thermal-template");
  if (!thermal) return;
  thermal.name = "Thermal Templates";
  thermal.standard = "Thermal Templates";
  thermal.headers[10] = { ...thermal.headers[10], label: "Baseline LPD" };
  thermal.headers[12] = { ...thermal.headers[12], label: "Proposed LPD" };
  thermal.columns[10] = "Baseline LPD (W/ft2)";
  thermal.columns[12] = "Proposed LPD (W/ft2)";
  thermal.headerLinks = {
    2: "ashrae-62-1-ventilation",
    6: "ashrae-fundamentals-people-heat",
    9: "ashrae-90-1-baseline-lighting",
    11: "ashrae-90-1-proposed-lighting",
  };
  thermal.equations ||= {};
  thermal.displayEquations ||= {};
  thermal.equations[1] = "=COUNTIF([Space Condition Setpoints]@Type,@Type)";
  thermal.displayEquations[1] = "=COUNTIF([Space Condition Setpoints]@Type, @Type)";
}

function configureSelectedRequirementTables() {
  const lighting = independentTables.find((table) => table.id === "selected-lighting-loads");
  if (lighting) {
    const retained = [0, 1, 2, 3, 6, 7];
    lighting.headers = [
      { label: "Space Name" }, { label: "Light" }, { label: "Quantity" },
      { label: "Wattage", unit: "W" }, { label: "Gain", unit: "W" }, { label: "Notes/Identifier" },
    ];
    lighting.columns = lighting.headers.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`);
    lighting.columnTypes = ["text", "text", "number", "number", "number", "text"];
    lighting.rows = lighting.rows.map((row) => retained.map((index) => row[index]));
    lighting.calculatedColumns = [3, 4];
    lighting.displayEquations = {
      3: "=XLOOKUP(@Light, [Lighting Schedule]@Light, [Lighting Schedule]@Wattage)",
      4: "=@Quantity * @Wattage",
    };
    lighting.equations = {
      3: "=XLOOKUP(@Light, [Lighting Schedule]@Light, [Lighting Schedule]@Wattage)",
      4: "=@Quantity*@Wattage",
    };
    lighting.preserveImportedValues = false;
    lighting.readonlyEquations = false;
    lighting.dropdownColumns = {
      0: { sourceTableId: "calc-space-condition-setpoints", sourceColumn: 0 },
      1: { sourceTableId: "schedule-lighting", sourceColumn: 0 },
    };
    lighting.headerLinks = { 1: "schedule-lighting" };
    lighting.schemaVersion = 3;
  }
  const misc = independentTables.find((table) => table.id === "selected-misc-loads");
  if (misc) {
    const retained = [0, 1, 2, 3, 4, 5, 6, 9, 10, 11, 12];
    misc.headers = [
      { label: "Space Name" }, { label: "Equipment" }, { label: ">1 Items" },
      { label: "Per Person" }, { label: "People" }, { label: "Quantity" },
      { label: "Sens Heat Gain", unit: "Btu/h" }, { label: "Misc", unit: "kW" },
      { label: "Misc", unit: "Btu/h" }, { label: "Gain", unit: "Btu/h" }, { label: "Notes/Identifier" },
    ];
    misc.columns = misc.headers.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`);
    misc.columnTypes = ["text", "text", "number", "text", "text", "number", "number", "number", "number", "number", "text"];
    misc.rows = misc.rows.map((row) => retained.map((index) => row[index])).map((row) => {
      row[3] = row[3] === true || String(row[3]).toUpperCase() === "TRUE" ? "TRUE" : "";
      return row;
    });
    misc.calculatedColumns = [4, 5, 6, 9];
    misc.displayEquations = {
      4: '=IF(@Per Person="TRUE", XLOOKUP(@Space Name, [People Gains]@Space, [People Gains]@Actual People), "-")',
      5: '=IF(@>1 Items="", 1, @>1 Items)',
      6: '=XLOOKUP(@Equipment, [Equipment Sensible Gain Schedule + Grouped Equipment Sensible Gain Schedule]@Equipment, @Heat Gain)',
      9: '=IF(@People="-", 1, @People) * @Quantity * @Sens Heat Gain + 3412.142 * @Misc kW + @Misc Btu/h',
    };
    misc.dropdownColumns = {
      0: { sourceTableId: "calc-space-condition-setpoints", sourceColumn: 0 },
      1: { sources: [
        { sourceTableId: "schedule-equipment-sensible-gain", sourceColumn: 0 },
        { sourceTableId: "schedule-grouped-equipment-sensible-gain", sourceColumn: 0 },
      ] },
      3: { options: ["TRUE"] },
    };
    misc.headerLinks = { 1: "schedule-equipment-sensible-gain" };
    misc.columnWidthOverrides = { 3: 94, 4: 96, 5: 96 };
    misc.miscLoadCalculation = true;
    misc.preserveImportedValues = false;
    misc.readonlyEquations = true;
    misc.schemaVersion = 3;
  }
}

function configureCalcSectionTables() {
  const general = globalThis.CALC_SECTION_TABLES?.find((table) => table.id === "calc-general");
  const generalRows = general?.rows || [];
  const bySpace = new Map(generalRows.map((row) => [String(row[0]), row]));

  const setpoints = independentTables.find((table) => table.id === "calc-space-condition-setpoints");
  if (setpoints) {
    setpoints.headers = [
      { label: "Space" },
      { label: "Type" },
      { label: "Relative Humidity", unit: "%" },
      { label: "Heating Main Setpoint", unit: "°F" },
      { label: "Heating Temperature Setback", unit: "°F" },
      { label: "Heating Humidity Ratio", unit: "lb/lb" },
      { label: "Ventilated Temperature Rise", unit: "°F" },
      { label: "Cooling Main Setpoint", unit: "°F" },
      { label: "Cooling Temperature Setback", unit: "°F" },
      { label: "Cooling Humidity Ratio", unit: "lb/lb" },
    ];
    setpoints.columns = setpoints.headers.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`);
    setpoints.columnTypes = ["text", "text", "number", "number", "number", "number", "number", "number", "number", "number"];
    setpoints.rows = setpoints.rows.map((row) => [row[0], bySpace.get(String(row[0]))?.[1] ?? "", row[1], row[2], row[3], row[4], row[5], row[7], row[8], row[9]]);
    setpoints.calculatedColumns = [5, 9];
    setpoints.lockedColumns = [0, 1];
    setpoints.identityColumns = [0, 1];
    setpoints.frozenColumns = 2;
    setpoints.fiveDecimalColumns = [5, 9];
    setpoints.conditionalCalculatedColumns = { 7: { whenColumn: 6, baseValue: 91.6 } };
    setpoints.displayEquations = {
      5: "=HUMIDITY_RATIO(@Heating Main Setpoint, @Relative Humidity, [Inputs]@Barometric Pressure)",
      7: "=[Inputs]@Cooling Design Dry Bulb + @Ventilated Temperature Rise",
      9: "=HUMIDITY_RATIO(@Cooling Main Setpoint, @Relative Humidity, [Inputs]@Barometric Pressure)",
    };
    setpoints.twoValueScheduleDefault = "System extended hours";
    setpoints.schemaVersion = 2;
  }

  const dhw = independentTables.find((table) => table.id === "calc-dhw");
  if (dhw) {
    dhw.headers = [
      { label: "Space" },
      { label: "Building Type" },
      { label: "Total People" },
      { label: "DHW Consumption", unit: "GPH" },
    ];
    dhw.columns = ["Space", "Building Type", "Total People", "DHW Consumption (GPH)"];
    dhw.columnTypes = ["text", "text", "number", "number"];
    dhw.rows = dhw.rows.map((row) => row.slice(0, 4));
    dhw.calculatedColumns = [3];
    dhw.lockedColumns = [0];
    dhw.identityColumns = [0];
    dhw.fiveDecimalColumns = [3];
    dhw.summaryColumns = [1, 2, 3];
    dhw.summaryAggregations = { 1: "count", 2: "sum", 3: "sum" };
    dhw.preserveImportedValues = false;
    dhw.readonlyEquations = false;
    dhw.dropdownColumns = { 1: { sourceTableId: "femp-shw-calculator", sourceColumn: 0 } };
    dhw.headerLinks = { 1: "femp-shw-calculator" };
    dhw.equations = { 3: "=@TotalPeople*XLOOKUP(@BuildingType, [FEMP SHW Calculator Table]@BuildingType, [FEMP SHW Calculator Table]@EstimatedHotWaterUse)/24" };
    dhw.displayEquations = { 3: "=@Total People * XLOOKUP(@Building Type, [FEMP SHW Calculator Table]@Building Type, [FEMP SHW Calculator Table]@Estimated Hot Water Use) / 24" };
    dhw.schemaVersion = 2;
  }

  const roomLoads = independentTables.find((table) => table.id === "calc-room-loads");
  if (roomLoads) {
    roomLoads.name = "Space Loads";
    roomLoads.standard = "Space Loads";
    roomLoads.headers = [
      { label: "Space" }, { label: "Type" },
      { label: "IESVE", unit: "MBH" }, { label: "Internal Gains", unit: "MBH" }, { label: "Size per IGs" },
      { label: "Add/Subtract", unit: "MBH" }, { label: "Oversizing Factor", unit: "%" }, { label: "Load", unit: "MBH" },
      { label: "IESVE", unit: "MBH" }, { label: "People", unit: "MBH" }, { label: "Size per IESVE" },
      { label: "Add/Subtract", unit: "MBH" }, { label: "Oversizing Factor", unit: "%" }, { label: "Load", unit: "MBH" },
      { label: "IESVE", unit: "MBH" }, { label: "Add/Subtract", unit: "MBH" }, { label: "Oversizing Factor", unit: "%" }, { label: "Load", unit: "MBH" },
    ];
    roomLoads.columns = roomLoads.headers.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`);
    roomLoads.rows = roomLoads.rows.map((row) => {
      const migrated = [row[0], bySpace.get(String(row[0]))?.[1] ?? "", ...row.slice(1)];
      return [...migrated.slice(0, 6), 0.1, migrated[6], ...migrated.slice(7, 11), 0.1, migrated[11], ...migrated.slice(12, 14), 0.1, migrated[14]];
    });
    roomLoads.rows.forEach((row) => { row[4] = String(row[4]).toUpperCase() === "TRUE" ? "TRUE" : ""; row[10] = String(row[10]).toUpperCase() === "TRUE" ? "TRUE" : ""; });
    roomLoads.columnTypes = ["text", "text", "number", "number", "text", "number", "number", "number", "number", "number", "text", "number", "number", "number", "number", "number", "number", "number"];
    roomLoads.calculatedColumns = [2, 3, 7, 8, 9, 13, 14, 17];
    roomLoads.lockedColumns = [0, 1]; roomLoads.identityColumns = [0, 1]; roomLoads.frozenColumns = 2;
    roomLoads.dropdownColumns = { 4: { options: ["TRUE"] }, 10: { options: ["TRUE"] } };
    roomLoads.autoColumns = [6, 12, 16];
    roomLoads.columnWidthOverrides = { 4: 94, 6: 170, 10: 94, 12: 170, 16: 170 };
    roomLoads.decimalColumns = [2, 3, 5, 7, 8, 9, 11, 13, 14, 15, 17];
    roomLoads.summaryColumns = [2, 3, 5, 7, 8, 9, 11, 13, 14, 15, 17];
    roomLoads.headerGroups = [
      { label: "General", start: 0, span: 2, className: "space-group-header" },
      { label: "Cooling Sensible", start: 2, span: 6, className: "sensible-cooling-header" },
      { label: "Cooling Latent", start: 8, span: 6, className: "latent-cooling-header" },
      { label: "Heating", start: 14, span: 4, className: "heating-load-header" },
    ];
    roomLoads.headerClasses = Object.fromEntries([
      ...[2, 3, 4, 5, 6, 7].map((index) => [index, "sensible-cooling-header"]),
      ...[8, 9, 10, 11, 12, 13].map((index) => [index, "latent-cooling-header"]),
      ...[14, 15, 16, 17].map((index) => [index, "heating-load-header"]),
    ]);
    roomLoads.sectionStartColumns = [8, 14];
    roomLoads.headerLinks = { 2: "room-zone-loads-report", 8: "room-zone-loads-report", 14: "room-zone-loads-report" };
    roomLoads.displayEquations = {
      2: '=XLOOKUP(@Space, [Room/Zone Loads Report]@Room, [Room/Zone Loads Report]@Sensible Cooling)',
      3: '=([Lighting Gains]@Proposed Lighting Gain + [People Gains]@Sensible Load + [Miscellaneous Sensible Gains]@Miscellaneous Sensible Load) / 1000',
      7: '=MAX((1 + [Cooling Sensible]@Oversizing Factor) * (IF([Cooling Sensible]@Size per IGs="TRUE", [Cooling Sensible]@Internal Gains, [Cooling Sensible]@IESVE) + [Cooling Sensible]@Add/Subtract), 0)',
      8: '=XLOOKUP(@Space, [Room/Zone Loads Report]@Room, [Room/Zone Loads Report]@Latent Cooling)',
      9: '=[People Gains]@Latent Load / 1000',
      13: '=MAX((1 + [Cooling Latent]@Oversizing Factor) * (IF([Cooling Latent]@Size per IESVE="TRUE", [Cooling Latent]@IESVE, [Cooling Latent]@People) + [Cooling Latent]@Add/Subtract), 0)',
      14: '=XLOOKUP(@Space, [Room/Zone Loads Report]@Room, [Room/Zone Loads Report]@Heating)',
      17: '=MAX((1 + [Heating]@Oversizing Factor) * ([Heating]@IESVE + [Heating]@Add/Subtract), 0)',
    };
    roomLoads.roomLoadCalculation = true;
    roomLoads.preserveImportedValues = false;
    roomLoads.readonlyEquations = true;
  }

  const heatingLoads = independentTables.find((table) => table.id === "calc-heating-loads");
  if (heatingLoads) {
    heatingLoads.headers = [
      { label: "Space" }, { label: "Equipment" }, { label: "AHU Reheat" },
      { label: "Load", unit: "MBH" }, { label: "Leaving DB", unit: "°F" },
      { label: "Sensible Constant" }, { label: "Required Airflow", unit: "CFM" },
      { label: "Ventilation Minimum", unit: "CFM" }, { label: "Total Airflow", unit: "CFM" },
      { label: "Sensible Contribution", unit: "MBH" },
    ];
    heatingLoads.columns = heatingLoads.headers.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`);
    heatingLoads.headerClasses = Object.fromEntries(heatingLoads.headers.map((_, index) => [index, index ? "heating-load-header" : "space-group-header"]));
    heatingLoads.zeroDecimalColumns = [6, 7, 8];
    heatingLoads.decimalColumns = [3, 9];
    heatingLoads.oneDecimalColumns = [4];
    heatingLoads.threeDecimalColumns = [5];
    heatingLoads.heatingLoadCalculation = true;
    heatingLoads.preserveImportedValues = false;
    heatingLoads.displayEquations = {
      1: '=[Equipment Zoning]@Heating Equipment',
      2: '=IF([Equipment Zoning]@Reheat Coil<>"", TRUE, "")',
      3: '=[Space Loads]@Heating Load',
      4: '=XLOOKUP(@Equipment, [Reheat / Heating Coils]@Equipment, [Reheat / Heating Coils]@Leaving Dry-Bulb)',
      5: '=XLOOKUP(@Equipment, [Reheat / Heating Coils]@Equipment, [Reheat / Heating Coils]@Leaving Sensible Constant)',
      6: '=CEILING(MAX(50, 1000 * @Load / (@Sensible Constant * (@Leaving DB - [Space Condition Setpoints]@Heating Setpoint))), 5)',
      8: '=MAX(@Required Airflow, @Ventilation Minimum)',
      9: '=@Sensible Constant * @Total Airflow * (@Leaving DB - [Space Condition Setpoints]@Heating Setpoint) / 1000',
    };
  }

  const coolingLoads = independentTables.find((table) => table.id === "calc-cooling-loads");
  if (coolingLoads) {
    coolingLoads.headers = [
      { label: "Space" }, { label: "Equipment" }, { label: "Sized for Ventilation?" },
      { label: "Sensible Load", unit: "MBH" }, { label: "Minimum LDB", unit: "°F" },
      { label: "Cooling LDB", unit: "°F" }, { label: "Leaving HR", unit: "lb/lb" },
      { label: "Leaving RH", unit: "%" }, { label: "Sensible Constant" }, { label: "Latent Constant" },
      { label: "Required Airflow", unit: "CFM" }, { label: "2x Heating Minimum", unit: "CFM" },
      { label: "Ventilation Minimum", unit: "CFM" }, { label: "Total Airflow", unit: "CFM" },
      { label: "Sensible Contribution", unit: "MBH" }, { label: "Remaining Latent", unit: "MBH" },
    ];
    coolingLoads.columns = coolingLoads.headers.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`);
    coolingLoads.headerClasses = Object.fromEntries(coolingLoads.headers.map((_, index) => [index, index ? "sensible-cooling-header" : "space-group-header"]));
    coolingLoads.zeroDecimalColumns = [9, 10, 11, 12, 13];
    coolingLoads.decimalColumns = [3, 14, 15];
    coolingLoads.oneDecimalColumns = [4, 5];
    coolingLoads.threeDecimalColumns = [8];
    coolingLoads.fiveDecimalColumns = [6];
    coolingLoads.coolingLoadCalculation = true;
    coolingLoads.preserveImportedValues = false;
    coolingLoads.displayEquations = {
      1: '=[Equipment Zoning]@Cooling Equipment',
      2: '=IF([Equipment Zoning]@Ventilation Equipment=@Equipment, TRUE, "")',
      3: '=[Space Loads]@Cooling Sensible Load',
      4: '=XLOOKUP(@Equipment, [Cooling Coils]@Equipment, [Cooling Coils]@Required Minimum LDB)',
      5: '=XLOOKUP(@Equipment, [Cooling Coils]@Equipment, [Cooling Coils]@Leaving Dry-Bulb)',
      6: '=XLOOKUP(@Equipment, [Cooling Coils]@Equipment, [Cooling Coils]@Leaving Humidity Ratio)',
      7: '=XLOOKUP(@Equipment, [Cooling Coils]@Equipment, [Cooling Coils]@Leaving Relative Humidity)',
      8: '=XLOOKUP(@Equipment, [Cooling Coils]@Equipment, [Cooling Coils]@Leaving Sensible Constant)',
      9: '=XLOOKUP(@Equipment, [Cooling Coils]@Equipment, [Cooling Coils]@Leaving Latent Constant)',
      10: '=CEILING(MAX(50, 1000 * @Sensible Load / (@Sensible Constant * ([Space Condition Setpoints]@Cooling Setpoint - @Cooling LDB))), 5)',
      13: '=MAX(@Required Airflow, @2x Heating Minimum, @Ventilation Minimum)',
      14: '=@Sensible Constant * @Total Airflow * ([Space Condition Setpoints]@Cooling Setpoint - @Cooling LDB) / 1000',
      15: '=@Latent Constant * @Total Airflow * ([Space Condition Setpoints]@Cooling HR - @Leaving HR) / 1000',
    };
  }

  const equipmentZoning = independentTables.find((table) => table.id === "calc-equipment-zoning");
  if (equipmentZoning) {
    equipmentZoning.headers = [
      { label: "Zone Group" }, { label: "Zone" }, { label: "Space" },
      { label: "Equipment" },
      { label: "Central Equipment" }, { label: "Valve" }, { label: "Reheat Coil" },
      { label: "Cooling Equipment" }, { label: "Heating Equipment" },
      { label: "Equipment" }, { label: "General Valve" },
    ];
    equipmentZoning.columns = equipmentZoning.headers.map((header) => header.label);
    equipmentZoning.columnTypes = Array(equipmentZoning.headers.length).fill("text");
    equipmentZoning.rows = equipmentZoning.rows.map((row) => [
      row[1] ?? "", "", row[0] ?? "", row[2] ?? "", "", "", row[14] === "-" ? "" : row[14] ?? "",
      row[9] === "-" ? "" : row[9] ?? "", "", row[5] === "-" ? "" : row[5] ?? "", row[4] ?? "",
    ]);
    equipmentZoning.calculatedColumns = [];
    equipmentZoning.lockedColumns = [0, 1, 2];
    equipmentZoning.identityColumns = [0, 1, 2];
    equipmentZoning.frozenColumns = 3;
    equipmentZoning.headerGroups = [
      { label: "General", start: 0, span: 3, className: "space-group-header", linkTableId: "room-zone-loads-report" },
      { label: "Ventilation", start: 3, span: 1, className: "ventilation-header" },
      { label: "Building Level Circulation", start: 4, span: 3, className: "building-circulation-header" },
      { label: "Zone Level Circulation", start: 7, span: 2, className: "zone-circulation-header" },
      { label: "Exhaust", start: 9, span: 2, className: "exhaust-header" },
    ];
    equipmentZoning.headerClasses = {
      3: "ventilation-header", 4: "sensible-cooling-header", 5: "valve-header", 6: "heating-load-header",
      7: "sensible-cooling-header", 8: "heating-load-header", 9: "exhaust-header", 10: "exhaust-header",
    };
    equipmentZoning.sectionStartColumns = [4, 7, 9];
    equipmentZoning.autoColumns = [3, 4, 5, 6, 7, 8, 9];
    equipmentZoning.summaryColumns = equipmentZoning.headers.map((_, index) => index).filter((index) => index >= 3);
    equipmentZoning.summaryAggregations = Object.fromEntries(equipmentZoning.summaryColumns.map((index) => [index, "unique-count"]));
    equipmentZoning.equipmentZoningCalculation = true;
    equipmentZoning.preserveImportedValues = false;
    equipmentZoning.readonlyEquations = true;
    equipmentZoning.schemaVersion = 2;
  }

  const gains = independentTables.find((table) => table.id === "calc-internal-gains");
  if (gains) {
    const oldCalculated = new Set(gains.calculatedColumns || []);
    const oldDisplayEquations = { ...(gains.displayEquations || {}) };
    const buildGainTable = ({ id, name, range, activeSourceIndex, sourceIndexes, headers, summarySourceIndexes = [], oneDecimalSourceIndexes = [] }) => {
      const tableHeaders = [{ label: "Space" }, { label: "Type" }, { label: "Area", unit: "ft2" }, ...headers, { label: "Active" }];
      const table = {
        id, name, standard: name, description: `${name} split from the workbook Calc table.`, sheet: "Calc", range,
        headers: tableHeaders,
        columns: tableHeaders.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`),
        columnTypes: tableHeaders.map((_, index) => index < 2 || index === tableHeaders.length - 1 ? "text" : "number"),
        rows: gains.rows.map((row) => {
          const source = bySpace.get(String(row[0])) || [];
          const active = row[activeSourceIndex] === true || String(row[activeSourceIndex]).toLowerCase() === "true";
          return [row[0], source[1] ?? "", source[3] ?? "", ...sourceIndexes.map((index) => row[index]), active ? "Yes" : "No"];
        }),
        calculatedColumns: [...sourceIndexes.map((sourceIndex, index) => oldCalculated.has(sourceIndex) ? index + 3 : -1).filter((index) => index >= 0), tableHeaders.length - 1],
        lockedColumns: [0, 1, 2], identityColumns: [0, 1, 2], frozenColumns: 3,
        summaryColumns: summarySourceIndexes.map((sourceIndex) => sourceIndexes.indexOf(sourceIndex) + 3).filter((index) => index >= 3),
        oneDecimalColumns: oneDecimalSourceIndexes.map((sourceIndex) => sourceIndexes.indexOf(sourceIndex) + 3).filter((index) => index >= 3),
        displayEquations: {}, preserveImportedValues: true, readonlyEquations: true, schemaVersion: 1,
      };
      sourceIndexes.forEach((sourceIndex, index) => {
        if (oldDisplayEquations[sourceIndex]) table.displayEquations[index + 3] = oldDisplayEquations[sourceIndex];
      });
      if (oldDisplayEquations[activeSourceIndex]) table.displayEquations[tableHeaders.length - 1] = oldDisplayEquations[activeSourceIndex];
      independentTables.push(table);
    };

    buildGainTable({
      id: "calc-lighting-gains", name: "Lighting Gains", range: "W:AC", activeSourceIndex: 1,
      sourceIndexes: [2, 3, 4, 5, 6, 7], summarySourceIndexes: [6, 7], oneDecimalSourceIndexes: [2, 3, 5],
      headers: [
        { label: "Thermal Template Lighting Power Density", unit: "W/ft2" },
        { label: "Recommended Lighting Power Density", unit: "W/ft2" },
        { label: "Detailed Lighting Load", unit: "W" },
        { label: "Manual Lighting Power Density", unit: "W/ft2" },
        { label: "Proposed Lighting Load", unit: "Btu/h" },
        { label: "Baseline Lighting Load", unit: "Btu/h" },
      ],
    });
    buildGainTable({
      id: "calc-people-gains", name: "People Gains", range: "AD:AK", activeSourceIndex: 8,
      sourceIndexes: [9, 10, 11, 12, 13, 14, 15], summarySourceIndexes: [12, 13, 14, 15],
      headers: [
        { label: "Thermal Template Sensible Heat", unit: "Btu/h-person" },
        { label: "Thermal Template Latent Heat", unit: "Btu/h-person" },
        { label: "Recommended Area per Person", unit: "ft2/person" },
        { label: "Manual People" }, { label: "People Count", unit: "people" },
        { label: "Sensible People Load", unit: "Btu/h" }, { label: "Latent People Load", unit: "Btu/h" },
      ],
    });
    buildGainTable({
      id: "calc-misc-gains", name: "Miscellaneous Sensible Gains", range: "AL:AP", activeSourceIndex: 16,
      sourceIndexes: [17, 18, 19, 20], summarySourceIndexes: [20], oneDecimalSourceIndexes: [17, 19],
      headers: [
        { label: "Thermal Template Sensible Gain Density", unit: "W/ft2" },
        { label: "Detailed Equipment Load", unit: "Btu/h" },
        { label: "Manual Sensible Gain Density", unit: "W/ft2" },
        { label: "Calculated Miscellaneous Load", unit: "Btu/h" },
      ],
    });

    const thermal = independentTables.find((table) => table.id === "iesve-thermal-template");
    const thermalByType = new Map((thermal?.rows || []).map((row) => [String(row[0]), row]));
    const activityMap = (sourceIndex) => Object.fromEntries(gains.rows.map((row) => [String(row[0]), row[sourceIndex] === true || String(row[sourceIndex]).toLowerCase() === "true"]));

    const lighting = independentTables.find((table) => table.id === "calc-lighting-gains");
    if (lighting) {
      lighting.headers = [
        { label: "Space" }, { label: "Type" }, { label: "Area", unit: "ft2" },
        { label: "Proposed LPD", unit: "W/ft2" }, { label: "Baseline LPD", unit: "W/ft2" },
        { label: "Manual Lighting Gain", unit: "W" }, { label: "Detailed Lighting Gain", unit: "W" },
        { label: "Proposed Lighting Gain", unit: "Btu/h" }, { label: "Baseline Lighting Gain", unit: "Btu/h" },
      ];
      lighting.columns = lighting.headers.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`);
      lighting.columnTypes = ["text", "text", "number", "number", "number", "number", "number", "number", "number"];
      lighting.rows = gains.rows.map((row) => {
        const source = bySpace.get(String(row[0])) || [];
        return [row[0], source[1] ?? "", source[3] ?? "", "", "", "", "", row[6], row[7]];
      });
      lighting.calculatedColumns = [3, 4, 6, 7, 8];
      lighting.lockedColumns = [0, 1, 2]; lighting.identityColumns = [0, 1, 2]; lighting.frozenColumns = 3;
      lighting.summaryColumns = [2, 7, 8]; lighting.oneDecimalColumns = [3, 4]; lighting.zeroDecimalColumns = [2];
      lighting.activityBySpace = activityMap(1);
      lighting.volumeBySpace = Object.fromEntries(generalRows.map((row) => [String(row[0]), row[2]]));
      lighting.gainCalculation = "lighting";
      lighting.headerLinks = { 3: "iesve-thermal-template", 4: "iesve-thermal-template", 6: "selected-lighting-loads" };
      lighting.preserveImportedValues = true; lighting.readonlyEquations = true; lighting.schemaVersion = 3;
      lighting.displayEquations = {
        3: '=IFGAINACTIVE("Lighting", XLOOKUP(@Type, [Thermal Templates]@Space Type, [Thermal Templates]@Proposed LPD))',
        4: '=IFGAINACTIVE("Lighting", XLOOKUP(@Type, [Thermal Templates]@Space Type, [Thermal Templates]@Baseline LPD))',
        6: '=IFGAINACTIVE("Lighting", SUMIF([Lighting Loads]@Space Name, @Space, [Lighting Loads]@Gain))',
        7: '=IFGAINACTIVE("Lighting", 3.412 * COALESCE(@Detailed Lighting Gain, @Manual Lighting Gain, @Proposed LPD * @Area))',
        8: '=IFGAINACTIVE("Lighting", 3.412 * @Baseline LPD * @Area)',
      };
    }

    const people = independentTables.find((table) => table.id === "calc-people-gains");
    if (people) {
      people.headers = [
        { label: "Space" }, { label: "Type" }, { label: "Area", unit: "ft2" },
        { label: "Occupant Density", unit: "people/ft2" }, { label: "Manual People", unit: "people" },
        { label: "Actual People", unit: "people" }, { label: "Sensible Heat", unit: "Btu/h-person" },
        { label: "Latent Heat", unit: "Btu/h-person" }, { label: "Sensible Load", unit: "Btu/h" },
        { label: "Latent Load", unit: "Btu/h" },
      ];
      people.columns = people.headers.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`);
      people.columnTypes = ["text", "text", "number", "number", "number", "number", "number", "number", "number", "number"];
      people.rows = gains.rows.map((row) => {
        const source = bySpace.get(String(row[0])) || [];
        return [row[0], source[1] ?? "", source[3] ?? "", "", row[12], row[13], "", "", row[14], row[15]];
      });
      people.calculatedColumns = [3, 5, 6, 7, 8, 9];
      people.lockedColumns = [0, 1, 2]; people.identityColumns = [0, 1, 2]; people.frozenColumns = 3;
      people.summaryColumns = [2, 4, 5, 8, 9]; people.zeroDecimalColumns = [2, 5];
      people.activityBySpace = activityMap(8); people.gainCalculation = "people";
      people.headerLinks = { 3: "iesve-thermal-template", 6: "iesve-thermal-template", 7: "iesve-thermal-template" };
      people.preserveImportedValues = true; people.readonlyEquations = true; people.schemaVersion = 3;
      people.displayEquations = {
        3: '=IFGAINACTIVE("People", XLOOKUP(@Type, [Thermal Templates]@Space Type, [Thermal Templates]@Occupant Density) / 1000)',
        5: '=IFGAINACTIVE("People", IF(@Manual People="", ROUND(@Occupant Density * @Area, 0), @Manual People))',
        6: '=IFGAINACTIVE("People", XLOOKUP(@Type, [Thermal Templates]@Space Type, [Thermal Templates]@Sensible Heat))',
        7: '=IFGAINACTIVE("People", XLOOKUP(@Type, [Thermal Templates]@Space Type, [Thermal Templates]@Latent Heat))',
        8: '=IFGAINACTIVE("People", @Actual People * @Sensible Heat)',
        9: '=IFGAINACTIVE("People", @Actual People * @Latent Heat)',
      };
    }

    const misc = independentTables.find((table) => table.id === "calc-misc-gains");
    if (misc) {
      misc.headers = [
        { label: "Space" }, { label: "Type" }, { label: "Area", unit: "ft2" },
        { label: "Sensible Heat Gain Density", unit: "W/ft2" },
        { label: "Detailed Equipment Load", unit: "Btu/h" }, { label: "Miscellaneous Sensible Load", unit: "Btu/h" },
      ];
      misc.columns = misc.headers.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`);
      misc.columnTypes = ["text", "text", "number", "number", "number", "number"];
      misc.rows = gains.rows.map((row) => {
        const source = bySpace.get(String(row[0])) || [];
        return [row[0], source[1] ?? "", source[3] ?? "", "", row[18], row[20]];
      });
      misc.calculatedColumns = [3, 4, 5];
      misc.lockedColumns = [0, 1, 2]; misc.identityColumns = [0, 1, 2]; misc.frozenColumns = 3;
      misc.summaryColumns = [2, 5]; misc.oneDecimalColumns = [3]; misc.zeroDecimalColumns = [2];
      misc.activityBySpace = activityMap(16); misc.gainCalculation = "misc";
      misc.headerLinks = { 3: "iesve-thermal-template", 4: "selected-misc-loads" };
      misc.preserveImportedValues = true; misc.readonlyEquations = true; misc.schemaVersion = 3;
      misc.displayEquations = {
        3: '=IFGAINACTIVE("Computers", XLOOKUP(@Type, [Thermal Templates]@Space Type, [Thermal Templates]@Sensible Heat Gain Density))',
        4: '=IFGAINACTIVE("Computers", SUMIF([Miscellaneous Sensible Loads]@Space Name, @Space, [Miscellaneous Sensible Loads]@Gain))',
        5: '=IFGAINACTIVE("Computers", COALESCE(@Detailed Equipment Load, 3.412 * @Sensible Heat Gain Density * @Area))',
      };
    }
  }
}

const tabularSpaceHeaders = [
  { label: "Space ID" },
  { label: "Space Name" },
  { label: "Heating Design Supply Air Temperature", unit: "°F" },
  { label: "Cooling Design Supply Air Temperature", unit: "°F" },
  { label: "DHW Consumption Room-level Setting" },
  { label: "DHW Consumption", unit: "US gal/h" },
  { label: "DHW Consumption Pattern" },
  { label: "DHW Pattern Of Use Profile" },
  { label: "Heating Setpoint", unit: "°F" },
  { label: "Cooling Setpoint", unit: "°F" },
  { label: "Saturation Upper Limit", unit: "%" },
  { label: "Gain 1 Input Mode" },
  { label: "Gain 1 Occupancy", unit: "people" },
  { label: "Gain 1 Max. Sensible Gain", unit: "Btu/h" },
  { label: "Gain 1 Max. Sensible Gain", unit: "Btu/h·person" },
  { label: "Gain 1 Max. Latent Gain", unit: "Btu/h·person" },
  { label: "Gain 1 Max. Power Consumption", unit: "Btu/h" },
  { label: "Gain 2 Input Mode" },
  { label: "Gain 2 Occupancy", unit: "people" },
  { label: "Gain 2 Max. Sensible Gain", unit: "Btu/h" },
  { label: "Gain 2 Max. Sensible Gain", unit: "Btu/h·person" },
  { label: "Gain 2 Max. Latent Gain", unit: "Btu/h·person" },
  { label: "Gain 2 Max. Power Consumption", unit: "Btu/h" },
  { label: "Gain 3 Input Mode" },
  { label: "Gain 3 Occupancy", unit: "people" },
  { label: "Gain 3 Max. Sensible Gain", unit: "Btu/h" },
  { label: "Gain 3 Max. Sensible Gain", unit: "Btu/h·person" },
  { label: "Gain 3 Max. Latent Gain", unit: "Btu/h·person" },
  { label: "Gain 3 Max. Power Consumption", unit: "Btu/h" },
  { label: "Basis for OA Requirement" },
  { label: "Outdoor Air Req. Type" },
  { label: "Outdoor Air Req.", unit: "cfm" },
  { label: "Use Exhaust Air Change Req?" },
  { label: "Exhaust Air Change Req." },
  { label: "Exhaust Air Change Req. Unit" },
];

const tabularSpaceCsvHeaders = [
  "Space ID",
  "Space Name (Real)",
  "Heating Design Supply Air Temperature (°F) (Real)",
  "Cooling Design Supply Air Temperature (°F) (Real)",
  "DHW Consumption Room-level Setting (Real)",
  "DHW Consumption (Real)",
  "DHW Consumption Pattern (Real)",
  "DHW Pattern Of Use Profile (Real)",
  "Heating Setpoint (°F) (Real)",
  "Cooling Setpoint (°F) (Real)",
  "% Saturation Upper Limit (Real)",
  "Gain 1 Input Mode (Real)",
  "Gain 1 Occupancy (People) (Real)",
  "Gain 1 Max. Sensible Gain (Btu/h) (Real)",
  "Gain 1 Max. Sensible Gain (Btu/h·person) (Real)",
  "Gain 1 Max. Latent Gain (Btu/h·person) (Real)",
  "Gain 1 Max. Power Consumption (Btu/h) (Real)",
  "Gain 2 Input Mode (Real)",
  "Gain 2 Occupancy (People) (Real)",
  "Gain 2 Max. Sensible Gain (Btu/h) (Real)",
  "Gain 2 Max. Sensible Gain (Btu/h·person) (Real)",
  "Gain 2 Max. Latent Gain (Btu/h·person) (Real)",
  "Gain 2 Max. Power Consumption (Btu/h) (Real)",
  "Gain 3 Input Mode (Real)",
  "Gain 3 Occupancy (People) (Real)",
  "Gain 3 Max. Sensible Gain (Btu/h) (Real)",
  "Gain 3 Max. Sensible Gain (Btu/h·person) (Real)",
  "Gain 3 Max. Latent Gain (Btu/h·person) (Real)",
  "Gain 3 Max. Power Consumption (Btu/h) (Real)",
  "Basis for OA Requirement (Real)",
  "Outdoor Air Req. Type (Real)",
  "Outdoor Air Req. (cfm) (Real)",
  "Use Exhaust Air Change Req? (Real)",
  "Exhaust Air Change Req. (Real)",
  "Exhaust Air Change Req. Unit (Real)",
];

if (!independentTables.some((table) => table.id === "iesve-tabular-space-data")) {
  const numericColumns = new Set([2, 3, 5, 10, 12, 13, 14, 15, 16, 18, 19, 20, 21, 22, 24, 25, 26, 27, 28, 31, 33]);
  independentTables.unshift({
    id: "iesve-tabular-space-data",
    name: "Tabular Space Data",
    standard: "Tabular Space Data",
    description: "IESVE tabular space data structure populated from pasted source data.",
    sheet: "IES Data",
    range: "D3:AL201",
    headers: tabularSpaceHeaders,
    columns: tabularSpaceHeaders.map((header) => `${header.label}${header.unit ? ` (${header.unit})` : ""}`),
    columnTypes: tabularSpaceHeaders.map((_, index) => numericColumns.has(index) ? "number" : "text"),
    percentageColumns: [10],
    csvHeaders: tabularSpaceCsvHeaders,
    lockedColumns: tabularSpaceHeaders.map((_, index) => index),
    frozenColumns: 2,
    rows: [],
  });
}

if (!independentTables.some((table) => table.id === "room-zone-loads-report")) {
  const headers = [
    { label: "Zone Group" },
    { label: "Zone" },
    { label: "Room" },
    { label: "Sensible Cooling (without oversizing)", unit: "MBH" },
    { label: "Latent Cooling (without oversizing)", unit: "MBH" },
    { label: "Heating (without oversizing)", unit: "MBH" },
  ];
  independentTables.unshift({
    id: "room-zone-loads-report",
    name: "Room/Zone Loads Report",
    standard: "Room/Zone Loads Report",
    description: "Room and zone loads imported from the workbook report beginning at row 10.",
    sheet: "IES Loads",
    range: "A10:U149",
    headers,
    columns: [
      "Zone Group",
      "Zone",
      "Room",
      "Sensible Cooling Load without Oversizing (MBH)",
      "Latent Cooling Load without Oversizing (MBH)",
      "Heating Load without Oversizing (MBH)",
    ],
    columnTypes: ["text", "text", "text", "number", "number", "number"],
    lockedColumns: headers.map((_, index) => index),
    decimalColumns: [3, 4, 5],
    excelImport: true,
    frozenColumns: 3,
    identityColumns: [0, 1, 2],
    headerClasses: {
      3: "sensible-cooling-header",
      4: "latent-cooling-header",
      5: "heating-load-header",
    },
    rows: [],
  });
}

const tree = document.querySelector("#project-tree");
const search = document.querySelector("#browser-search");
const browser = document.querySelector("#project-browser");
const scrim = document.querySelector("#drawer-scrim");
const moduleContent = document.querySelector("#module-content");
const summaryLinks = document.querySelector("#summary-links");
const shell = document.querySelector(".app-shell");
const projectList = document.querySelector("#project-list");
const projectSearch = document.querySelector("#project-search");
const projectDialog = document.querySelector("#project-dialog");
const projectForm = document.querySelector("#project-form");
const newProjectNumber = document.querySelector("#new-project-number");
const projectDialogError = document.querySelector("#project-dialog-error");
const projectSwitcherToggle = document.querySelector("#project-switcher-toggle");
const tableView = document.querySelector("#table-view");
const modelInputsView = document.querySelector("#model-inputs-view");
const equipmentZoningView = document.querySelector("#equipment-zoning-view");
const tableScroll = document.querySelector(".table-scroll");
const referenceTable = document.querySelector("#reference-table");
const tableSearch = document.querySelector("#table-search");
const tableCount = document.querySelector("#table-count");
const tableStandard = document.querySelector("#table-standard");
const tableSettings = document.querySelector("#table-settings");
const twoValueSetting = document.querySelector("#two-value-setting");
const twoValueSchedule = document.querySelector("#two-value-schedule");
const loadFactorSettings = document.querySelector("#load-factor-settings");
const sensibleLoadFactor = document.querySelector("#sensible-load-factor");
const latentLoadFactor = document.querySelector("#latent-load-factor");
const heatingLoadFactor = document.querySelector("#heating-load-factor");
const spaceReconcileDialog = document.querySelector("#space-reconcile-dialog");
const newSpaceList = document.querySelector("#new-space-list");
const oldSpaceList = document.querySelector("#old-space-list");
const spaceActionList = document.querySelector("#space-action-list");
const spaceReconcileError = document.querySelector("#space-reconcile-error");
const addTableRowButton = document.querySelector("#add-table-row");
const removeTableRowButton = document.querySelector("#remove-table-row");
const editableKey = document.querySelector(".editable-key");
const calculatedKey = document.querySelector(".calculated-key");
const autoKey = document.querySelector(".auto-key");
const matchKey = document.querySelector(".match-key");
const differentKey = document.querySelector(".different-key");
const formulaBar = document.querySelector("#formula-bar");
const selectedEquation = document.querySelector("#selected-equation");
const editEquationButton = document.querySelector("#edit-equation");
const saveEquationButton = document.querySelector("#save-equation");
const cancelEquationButton = document.querySelector("#cancel-equation");
const formulaError = document.querySelector("#formula-error");
const clipboardActions = document.querySelector("#clipboard-actions");
const excelActions = document.querySelector("#excel-actions");
const importExcelButton = document.querySelector("#import-excel");
const importExcelInput = document.querySelector("#import-excel-input");
const pasteDataButton = document.querySelector("#paste-table-data");
const copyDataButton = document.querySelector("#copy-table-data");
const csvFileStatus = document.querySelector("#csv-file-status");
const templateStatus = document.querySelector("#template-status");
const rowActions = document.querySelector("#row-actions");
const csvComparisonBar = document.querySelector("#csv-comparison-bar");
const csvComparisonColumn = document.querySelector("#csv-comparison-column");
const csvComparisonValue = document.querySelector("#csv-comparison-value");
const csvComparisonStatus = document.querySelector("#csv-comparison-status");
let activeTableId = "";
let tableSort = { tableId: "", column: -1, direction: "asc" };
let selectedTableId = "";
let selectedTableRowIndexes = new Set();
let selectionAnchorIndex = -1;
let selectedTableCells = new Set();
let cellSelectionAnchor = null;
let fillDrag = null;
let suppressFillHandleOnce = false;
const undoStack = [];
const redoStack = [];
let applyingHistory = false;
let pendingSpaceReconciliation = null;

const PROJECTS_KEY = "hvac-projects-v1";
const ACTIVE_PROJECT_KEY = "hvac-active-project-v1";
const EQUATION_OVERRIDES_KEY = "hvac-equation-overrides-v1";
const EQUIPMENT_EQUATION_SCHEMA_KEY = "hvac-equipment-equation-schema-v1";
const tableNumberFormatter = new Intl.NumberFormat("en-US", { maximumFractionDigits: 20 });
const zeroDecimalFormatter = new Intl.NumberFormat("en-US", { maximumFractionDigits: 0 });
const oneDecimalFormatter = new Intl.NumberFormat("en-US", { minimumFractionDigits: 1, maximumFractionDigits: 1 });
const twoDecimalFormatter = new Intl.NumberFormat("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const threeDecimalFormatter = new Intl.NumberFormat("en-US", { minimumFractionDigits: 3, maximumFractionDigits: 3 });
const fiveDecimalFormatter = new Intl.NumberFormat("en-US", { minimumFractionDigits: 5, maximumFractionDigits: 5 });
const calculatedBtuNumberFormatter = new Intl.NumberFormat("en-US", { maximumFractionDigits: 0 });
const projectFields = [...document.querySelectorAll("[data-project-field]")];
let projects = [];
let activeProjectId = "";
let selectedEquationContext = null;
let equationOverrides = {};
const csvImportsByProject = new Map();
const excelImportsByProject = new Map();
let selectedCsvComparisonContext = null;
try {
  equationOverrides = JSON.parse(localStorage.getItem(EQUATION_OVERRIDES_KEY) || "{}");
  if (localStorage.getItem(EQUIPMENT_EQUATION_SCHEMA_KEY) !== "4") {
    if (equationOverrides["schedule-equipment-sensible-gain"]) delete equationOverrides["schedule-equipment-sensible-gain"][5];
    if (equationOverrides["schedule-grouped-equipment-sensible-gain"]) delete equationOverrides["schedule-grouped-equipment-sensible-gain"][4];
    localStorage.setItem(EQUATION_OVERRIDES_KEY, JSON.stringify(equationOverrides));
    localStorage.setItem(EQUIPMENT_EQUATION_SCHEMA_KEY, "4");
  }
} catch {
  equationOverrides = {};
}

const slugify = (text) => text.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");

function renderTree(query = "") {
  const normalized = query.trim().toLowerCase();
  tree.innerHTML = "";
  let resultCount = 0;

  modules.forEach((section) => {
    const groupMatch = section.group.toLowerCase().includes(normalized);
    const visibleItems = section.items.filter((item) => !normalized || groupMatch || item[0].toLowerCase().includes(normalized));
    if (normalized && !groupMatch && !visibleItems.length) return;
    resultCount += visibleItems.length + 1;

    const wrapper = document.createElement("section");
    wrapper.className = "tree-group";

    const row = document.createElement("div");
    row.className = "group-row";

    if (section.items.length) {
      const expander = document.createElement("button");
      expander.className = "group-expander";
      expander.type = "button";
      expander.setAttribute("aria-label", `Collapse ${section.group}`);
      expander.setAttribute("aria-expanded", "true");
      expander.innerHTML = '<span class="chevron" aria-hidden="true">▶</span>';
      expander.addEventListener("click", () => {
        wrapper.classList.toggle("collapsed");
        const expanded = !wrapper.classList.contains("collapsed");
        expander.setAttribute("aria-expanded", String(expanded));
        expander.setAttribute("aria-label", `${expanded ? "Collapse" : "Expand"} ${section.group}`);
      });
      row.appendChild(expander);
    } else {
      const spacer = document.createElement("span");
      spacer.className = "group-spacer";
      row.appendChild(spacer);
    }

    const groupLink = document.createElement(section.noSummary ? "span" : "button");
    groupLink.className = "group-link";
    if (section.directView) groupLink.classList.add("featured-group-link");
    if (section.noSummary) groupLink.classList.add("is-static");
    else {
      groupLink.type = "button";
      groupLink.dataset.id = `section-${slugify(section.group)}`;
      groupLink.dataset.title = section.group;
      groupLink.dataset.group = "Project Browser";
      groupLink.dataset.source = section.source;
      groupLink.dataset.description = section.summary;
      if (section.directTable) groupLink.dataset.table = section.directTable;
      else if (section.directView) groupLink.dataset.view = section.directView;
      else groupLink.dataset.summary = "true";
      groupLink.addEventListener("click", () => selectModule(groupLink));
    }
    groupLink.textContent = section.group;
    row.appendChild(groupLink);

    if (section.items.length) {
      const count = document.createElement("span");
      count.className = "item-count";
      count.textContent = String(section.items.length);
      row.appendChild(count);
    }

    wrapper.appendChild(row);

    if (visibleItems.length) {
      const children = document.createElement("div");
      children.className = "tree-children";
      visibleItems.forEach((item) => children.appendChild(createLeaf(item, section.group)));
      wrapper.appendChild(children);
    }
    tree.appendChild(wrapper);
  });

  if (!resultCount) {
    const empty = document.createElement("p");
    empty.className = "no-results";
    empty.textContent = "No calculations match this search.";
    tree.appendChild(empty);
  }

  syncActiveState();
}

function createLeaf(item, group) {
  const button = document.createElement("button");
  button.type = "button";
  button.className = "tree-leaf";
  button.dataset.id = slugify(item[0]);
  button.dataset.title = item[0];
  button.dataset.group = group;
  button.dataset.source = item[1];
  button.dataset.description = item[2];
  if (item[3]) button.dataset.table = item[3];
  button.textContent = item[0];
  button.addEventListener("click", () => selectModule(button));
  return button;
}

function selectModule(button) {
  history.replaceState(null, "", `#${button.dataset.id}`);
  updateWorkspace(button.dataset);
  syncActiveState();
  closeBrowser();
}

function openLinkedTable(tableId) {
  const target = [...document.querySelectorAll("[data-table]")].find((button) => button.dataset.table === tableId);
  if (target) selectModule(target);
}

const modelInputDefaults = {
  location: "Forest Park, Georgia", countryState: "Curry County, NM", latitude: "33.63 N", longitude: "84.442 W",
  climateZone: "3A", elevation: 1011, weatherFile: "USA_GA_Atlanta-Hartsfield-Jackson_Intl.AP_722190_TMY3.epw",
  coolingPercentile: 1, coolingDb: 91.6, coolingWb: 73.6,
  dehumidificationPercentile: 1, dehumidificationDb: 80.4, dehumidificationHrGr: 128.5,
  heatingPercentile: 99, heatingDb: 27.1, heatingHrGr: 0,
  humidificationPercentile: 99, humidificationDb: 32.1, humidificationHrGr: 9.2,
  ufc: "TRUE",
  proposedWallPrescriptive: "U-", proposedWall: "U-", proposedRoofPrescriptive: "U-", proposedRoof: "U-",
  proposedSwingingDoorPrescriptive: "U-", proposedSwingingDoor: "U-", proposedNonSwingingDoorPrescriptive: "U-", proposedNonSwingingDoor: "U-",
  proposedFenestrationUPrescriptive: "U-", proposedFenestrationShgcPrescriptive: "SHGC-", proposedFenestrationVtPrescriptive: "VT-",
  proposedFenestrationU: "U-", proposedFenestrationShgc: "SHGC-", proposedFenestrationVt: "VT-",
  proposedGroundFloorPrescriptive: "F-", proposedGroundFloor: "F-",
  baselineWall: "U-", baselineRoof: "U-", baselineSwingingDoor: "U-", baselineNonSwingingDoor: "U-",
  baselineFenestrationU: "U-", baselineFenestrationShgc: "SHGC-", baselineFenestrationVt: "VT-", baselineGroundFloor: "F-",
  baselineBuildingType: "Other Nonresidential 4-5 Floors or 25,000-150,000 ft2",
};

function modelInputCalculations(values) {
  const elevation = Number(values.elevation) || 0;
  const pressure = 14.696 * Math.pow(1 - 6.8754e-6 * elevation, 5.2559);
  const weatherValues = (dryBulb, humidityRatio) => {
    const db = Number(dryBulb) || 0;
    const hr = Number(humidityRatio) || 0;
    const absoluteTemperature = db + 459.67;
    const density = 0.075 * (pressure / 14.696) * (530 / absoluteTemperature) / (1 + 1.6078 * hr);
    return {
      sensible: 60 * density * (0.241 + 0.444 * hr),
      latent: 60 * density * (1093 - 0.556 * db),
    };
  };
  const coolingDbC = ((Number(values.coolingDb) || 0) - 32) * 5 / 9;
  const coolingWbC = ((Number(values.coolingWb) || 0) - 32) * 5 / 9;
  const saturationPressureKpa = 0.61094 * Math.exp((17.625 * coolingWbC) / (coolingWbC + 243.04));
  const saturationPressurePsia = saturationPressureKpa / 6.89476;
  const saturatedHumidityRatio = 0.621945 * saturationPressurePsia / (pressure - saturationPressurePsia);
  const coolingHr = ((2501 - 2.326 * coolingWbC) * saturatedHumidityRatio - 1.006 * (coolingDbC - coolingWbC))
    / (2501 + 1.86 * coolingDbC - 4.186 * coolingWbC);
  const dehumidificationHr = (Number(values.dehumidificationHrGr) || 0) / 7000;
  const heatingHr = (Number(values.heatingHrGr) || 0) / 7000;
  const humidificationHr = (Number(values.humidificationHrGr) || 0) / 7000;
  return {
    pressure,
    coolingHr, dehumidificationHr, heatingHr, humidificationHr,
    cooling: weatherValues(values.coolingDb, coolingHr),
    dehumidification: weatherValues(values.dehumidificationDb, dehumidificationHr),
    heating: weatherValues(values.heatingDb, heatingHr),
    humidification: weatherValues(values.humidificationDb, humidificationHr),
    infiltration: String(values.ufc).toUpperCase() === "TRUE" ? 0.25 : 0.6,
  };
}

function syncModelInputsToSourceTable(project) {
  const values = project.modelInputs;
  const sourceTable = independentTables.find((table) => table.id === "project-inputs");
  if (!sourceTable) return;
  project.independentTables ||= {};
  const rows = project.independentTables[sourceTable.id] || sourceTable.rows.map((row) => [...row]);
  const assignments = [
    [0, values.location], [1, values.countryState], [2, values.latitude], [3, values.longitude], [4, values.climateZone],
    [5, values.elevation], [6, values.weatherFile], [7, (Number(values.coolingPercentile) || 0) / 100],
    [8, values.coolingDb], [9, values.coolingWb], [10, values.dehumidificationDb], [11, values.dehumidificationHrGr],
    [12, (Number(values.heatingPercentile) || 0) / 100], [13, values.heatingDb], [14, values.humidificationDb],
    [15, values.humidificationHrGr], [16, values.ufc], [17, Number.isFinite(Number(values.proposedInfiltrationOverride))
      ? Number(values.proposedInfiltrationOverride)
      : String(values.ufc).toUpperCase() === "TRUE" ? 0.25 : 0.6],
  ];
  assignments.forEach(([index, value]) => { if (rows[index]) rows[index][2] = value; });
  project.independentTables[sourceTable.id] = rows;
  project.independentTableSchemaVersions ||= {};
  project.independentTableSchemaVersions[sourceTable.id] = sourceTable.schemaVersion;
}

function renderModelInputs() {
  const project = activeProject();
  if (!project) return;
  if (!project.modelInputs) {
    const sourceRows = project.independentTables?.["project-inputs"];
    if (Array.isArray(sourceRows) && sourceRows.length >= 18) {
      project.modelInputs = {
        ...modelInputDefaults,
        location: sourceRows[0]?.[2], countryState: sourceRows[1]?.[2], latitude: sourceRows[2]?.[2], longitude: sourceRows[3]?.[2],
        climateZone: sourceRows[4]?.[2], elevation: sourceRows[5]?.[2], weatherFile: sourceRows[6]?.[2],
        coolingPercentile: (Number(sourceRows[7]?.[2]) || 0) * 100, coolingDb: sourceRows[8]?.[2], coolingWb: sourceRows[9]?.[2],
        dehumidificationDb: sourceRows[10]?.[2], dehumidificationHrGr: sourceRows[11]?.[2],
        heatingPercentile: (Number(sourceRows[12]?.[2]) || 0) * 100, heatingDb: sourceRows[13]?.[2],
        humidificationDb: sourceRows[14]?.[2], humidificationHrGr: sourceRows[15]?.[2], ufc: sourceRows[16]?.[2],
      };
    }
  }
  project.modelInputs = { ...modelInputDefaults, ...(project.modelInputs || {}) };
  const values = project.modelInputs;
  const calculated = modelInputCalculations(values);
  modelInputsView.innerHTML = "";

  const addSection = (title, className = "") => {
    const section = document.createElement("section");
    section.className = `model-input-section ${className}`.trim();
    const heading = document.createElement("h3");
    heading.textContent = title;
    section.appendChild(heading);
    modelInputsView.appendChild(section);
    return section;
  };
  const addField = (parent, label, key, options = {}) => {
    const field = document.createElement("label");
    if (options.wide) field.classList.add("wide-field");
    if (options.className) field.classList.add(options.className);
    const caption = document.createElement("span");
    appendFormattedText(caption, label);
    const input = document.createElement(options.select ? "select" : "input");
    input.dataset.modelInput = key;
    if (options.select) {
      options.select.forEach((optionValue) => {
        const option = document.createElement("option"); option.value = optionValue; option.textContent = optionValue; input.appendChild(option);
      });
    }
    input.value = values[key] ?? "";
    input.addEventListener("change", () => {
      values[key] = options.number && input.value !== "" ? Number(input.value) : input.value;
      syncModelInputsToSourceTable(project); saveProjects(); renderModelInputs();
    });
    field.append(caption, input); parent.appendChild(field); return input;
  };
  const addCalculated = (parent, label, value, digits = 5, equation = "") => {
    const field = document.createElement("label");
    const caption = document.createElement("span"); appendFormattedText(caption, label);
    const input = document.createElement("input"); input.className = "calculated-value"; input.readOnly = true;
    input.value = typeof value === "number" && Number.isFinite(value) ? Number(value).toFixed(digits) : value ?? "";
    input.dataset.equation = equation;
    input.addEventListener("click", () => showModelInputEquation(equation));
    field.append(caption, input); parent.appendChild(field); return field;
  };
  const addAutofill = (parent, label, automaticValue, overrideKey, digits, equation) => {
    const field = document.createElement("label");
    const caption = document.createElement("span"); appendFormattedText(caption, label);
    const input = document.createElement("input");
    const overridden = values[overrideKey] !== "" && values[overrideKey] !== null && values[overrideKey] !== undefined
      && Number.isFinite(Number(values[overrideKey])) && Number(values[overrideKey]) !== Number(automaticValue);
    input.value = Number(overridden ? values[overrideKey] : automaticValue).toFixed(digits);
    input.title = `Autopopulated value: ${Number(automaticValue).toFixed(digits)}`;
    if (!overridden) input.classList.add("auto-populated-input");
    input.addEventListener("focus", () => showModelInputEquation(equation));
    input.addEventListener("change", () => {
      const parsed = Number(input.value);
      if (!Number.isFinite(parsed) || parsed === Number(automaticValue)) delete values[overrideKey];
      else values[overrideKey] = parsed;
      syncModelInputsToSourceTable(project); saveProjects(); renderModelInputs();
    });
    field.append(caption, input); parent.appendChild(field); return field;
  };

  const climateOptionsTable = independentTables.find((table) => table.id === "ashrae-climate-zones");
  const climateZoneOptions = (climateOptionsTable?.rows || []).map((row) => String(row[0] ?? "")).filter(Boolean);
  const site = addSection("Site, Location, and Climate", "site-inputs");
  addField(site, "Location & Site Data", "location", { className: "half-field" }); addField(site, "Country, State", "countryState", { className: "half-field" });
  addField(site, "Latitude", "latitude", { className: "third-field" }); addField(site, "Longitude", "longitude", { className: "third-field" }); addField(site, "Climate Zone", "climateZone", { className: "third-field", select: climateZoneOptions });
  addField(site, "Elevation [ft]", "elevation", { number: true, className: "half-field" }); addCalculated(site, "Barometric Pressure [psia]", calculated.pressure, 3, "=14.696 * (1 - 6.8754E-6 * @Elevation)^5.2559");
  addField(site, "Simulation Weather Data", "weatherFile", { wide: true });

  const design = addSection("Design Weather Data", "design-weather-inputs");
  const designHeader = document.createElement("div"); designHeader.className = "design-weather-row design-weather-header";
  ["Condition", "Percentile [%]", "DB [°F]", "WB [°F]", "HR [gr/lb]", "HR [lb/lb]", "Sensible Constant", "Latent Constant"].forEach((text) => { const span = document.createElement("span"); span.textContent = text; designHeader.appendChild(span); });
  design.appendChild(designHeader);
  const weatherRows = [
    ["Cooling", "cooling", "coolingPercentile", "coolingDb", "coolingWb", null, calculated.coolingHr],
    ["Dehumidification", "dehumidification", "dehumidificationPercentile", "dehumidificationDb", null, "dehumidificationHrGr", calculated.dehumidificationHr],
    ["Heating", "heating", "heatingPercentile", "heatingDb", null, "heatingHrGr", calculated.heatingHr],
    ["Humidification", "humidification", "humidificationPercentile", "humidificationDb", null, "humidificationHrGr", calculated.humidificationHr],
  ];
  weatherRows.forEach(([label, calcKey, percentileKey, dbKey, wbKey, grKey, hrValue]) => {
    const row = document.createElement("div"); row.className = "design-weather-row";
    const name = document.createElement("strong"); name.textContent = label; row.appendChild(name);
    [percentileKey, dbKey, wbKey, grKey].forEach((key) => {
      const input = document.createElement("input"); input.type = "text"; input.value = key ? values[key] ?? "" : ""; input.disabled = !key;
      if (key === "heatingHrGr") {
        input.title = "Autopopulated value: 0";
        if (Number(input.value) === 0) input.classList.add("auto-populated-input");
      }
      if (key) input.addEventListener("change", () => { values[key] = input.value === "" ? "" : Number(input.value); syncModelInputsToSourceTable(project); saveProjects(); renderModelInputs(); });
      row.appendChild(input);
    });
    [hrValue, calculated[calcKey].sensible, calculated[calcKey].latent].forEach((value, index) => {
      const equations = [
        calcKey === "cooling" ? "=PSYCHROMETRIC_HR(@DB, @WB, @Barometric Pressure)" : "=@HR [gr/lb] / 7000",
        "=60 * @Air Density * (0.241 + 0.444 * @HR)",
        "=60 * @Air Density * (1093 - 0.556 * @DB)",
      ];
      const input = document.createElement("input"); input.readOnly = true; input.className = "calculated-value"; input.value = Number(value).toFixed(index ? 3 : 5);
      input.addEventListener("click", () => showModelInputEquation(equations[index])); row.appendChild(input);
    });
    design.appendChild(row);
  });

  const building = addSection("Proposed Building Construction", "building-inputs");
  const generalTable = independentTables.find((table) => table.id === "calc-general");
  const conditionTable = independentTables.find((table) => table.id === "calc-condition-baseline");
  const generalRows = generalTable ? projectTableRows(generalTable) : [];
  const conditionRows = conditionTable ? projectTableRows(conditionTable) : [];
  const areaBySpace = new Map(generalRows.map((row) => [String(row[0] ?? ""), Number(row[3]) || 0]));
  const areas = conditionRows.reduce((totals, row) => {
    const condition = String(row[10] ?? "Unconditioned");
    const area = areaBySpace.get(String(row[0] ?? "")) || 0;
    if (condition === "Conditioned") totals.conditioned += area;
    else if (condition === "Semiheated") totals.semiheated += area;
    else totals.unconditioned += area;
    totals.total += area;
    return totals;
  }, { conditioned: 0, semiheated: 0, unconditioned: 0, total: 0 });
  addCalculated(building, "Conditioned [ft2]", areas.conditioned, 1, '=SUMIF([Space Condition and Baseline]@Condition, "Conditioned", @Area)');
  addCalculated(building, "Semiheated [ft2]", areas.semiheated, 1, '=SUMIF([Space Condition and Baseline]@Condition, "Semiheated", @Area)');
  addCalculated(building, "Unconditioned [ft2]", areas.unconditioned, 1, '=SUMIF([Space Condition and Baseline]@Condition, "Unconditioned", @Area)');
  addCalculated(building, "Total Area [ft2]", areas.total, 1, '=SUM([Space Calculations]@Area)');
  values.ufc = String(values.ufc).toUpperCase() === "TRUE" ? "TRUE" : "FALSE";
  addField(building, "UFC", "ufc", { select: ["TRUE", "FALSE"] });
  const proposedInfiltration = addAutofill(building, "Infiltration at 0.3 in. Pressure Differential [CFM/ft2]", calculated.infiltration, "proposedInfiltrationOverride", 2, '=IF(@UFC="TRUE", 0.25, 0.60)');
  proposedInfiltration.classList.add("infiltration-field");

  const cleanConstructionValue = (value) => String(value ?? "").replace(/^(?:SHGC|VT|U|F)-/, "");
  values.proposedAssemblies ||= [
    ["External Walls", values.proposedWallPrescriptive, "", "", values.proposedWall, "", ""],
    ["Roof", values.proposedRoofPrescriptive, "", "", values.proposedRoof, "", ""],
    ["Swinging Doors", values.proposedSwingingDoorPrescriptive, "", "", values.proposedSwingingDoor, "", ""],
    ["Non-Swinging Doors", values.proposedNonSwingingDoorPrescriptive, "", "", values.proposedNonSwingingDoor, "", ""],
    ["Fenestrations", values.proposedFenestrationUPrescriptive, values.proposedFenestrationShgcPrescriptive, values.proposedFenestrationVtPrescriptive, values.proposedFenestrationU, values.proposedFenestrationShgc, values.proposedFenestrationVt],
    ["Perimeter Room Ground Floors", values.proposedGroundFloorPrescriptive, "", "", values.proposedGroundFloor, "", ""],
  ].map(([name, ...entries]) => ({ name, prescriptiveUF: cleanConstructionValue(entries[0]), prescriptiveSHGC: cleanConstructionValue(entries[1]), prescriptiveVT: cleanConstructionValue(entries[2]), proposedUF: cleanConstructionValue(entries[3]), proposedSHGC: cleanConstructionValue(entries[4]), proposedVT: cleanConstructionValue(entries[5]) }));
  values.baselineAssemblies ||= [
    ["External Walls", values.baselineWall, "", ""], ["Roof", values.baselineRoof, "", ""],
    ["Swinging Doors", values.baselineSwingingDoor, "", ""], ["Non-Swinging Doors", values.baselineNonSwingingDoor, "", ""],
    ["Fenestrations", values.baselineFenestrationU, values.baselineFenestrationShgc, values.baselineFenestrationVt],
    ["Perimeter Room Ground Floors", values.baselineGroundFloor, "", ""],
  ].map(([name, ...entries]) => ({ name, uf: cleanConstructionValue(entries[0]), shgc: cleanConstructionValue(entries[1]), vt: cleanConstructionValue(entries[2]) }));

  const addConstructionGrid = (parent, collectionKey, baseline = false) => {
    const rows = values[collectionKey];
    const grid = document.createElement("div"); grid.className = `construction-grid ${baseline ? "baseline-grid" : "proposed-grid"}`;
    const addButton = document.createElement("button"); addButton.type = "button"; addButton.className = "construction-add"; addButton.textContent = "+"; addButton.title = "Add line item";
    addButton.addEventListener("click", () => {
      rows.push(baseline ? { name: "", uf: "", shgc: "", vt: "" } : { name: "", prescriptiveUF: "", prescriptiveSHGC: "", prescriptiveVT: "", proposedUF: "", proposedSHGC: "", proposedVT: "" });
      saveProjects(); renderModelInputs();
    });
    grid.appendChild(addButton);
    const headings = baseline ? ["Assembly", "U/F", "SHGC", "VT"] : ["Assembly", "Prescriptive U/F", "Prescriptive SHGC", "Prescriptive VT", "Proposed U/F", "Proposed SHGC", "Proposed VT"];
    headings.forEach((heading) => { const span = document.createElement("span"); span.className = "construction-heading"; span.textContent = heading; grid.appendChild(span); });
    const fields = baseline ? ["name", "uf", "shgc", "vt"] : ["name", "prescriptiveUF", "prescriptiveSHGC", "prescriptiveVT", "proposedUF", "proposedSHGC", "proposedVT"];
    rows.forEach((row, rowIndex) => {
      const removeButton = document.createElement("button"); removeButton.type = "button"; removeButton.className = "construction-remove"; removeButton.textContent = "←"; removeButton.title = "Remove line item";
      removeButton.addEventListener("click", () => { rows.splice(rowIndex, 1); saveProjects(); renderModelInputs(); });
      grid.appendChild(removeButton);
      fields.forEach((field) => {
        const input = document.createElement("input"); input.value = row[field] ?? "";
        const updateState = () => input.classList.toggle("has-value", input.value.trim() !== "");
        updateState();
        input.addEventListener("input", () => { row[field] = input.value; updateState(); saveProjects(); });
        grid.appendChild(input);
      });
    });
    parent.appendChild(grid);
  };
  addConstructionGrid(building, "proposedAssemblies");

  const baseline = addSection("ASHRAE Baseline Building Construction", "baseline-building-inputs");
  addAutofill(baseline, "Infiltration at 0.3 in. Pressure Differential [CFM/ft2]", 1, "baselineInfiltrationOverride", 2, "=1.00");
  addConstructionGrid(baseline, "baselineAssemblies", true);
  const climateTable = independentTables.find((table) => table.id === "ashrae-climate-zones");
  const systemTable = independentTables.find((table) => table.id === "ashrae-90-1-baseline-systems");
  const buildingTypes = (climateTable?.headers || []).slice(2, 10).map((header) => header.label);
  if (!buildingTypes.includes(values.baselineBuildingType)) values.baselineBuildingType = buildingTypes[6] || values.baselineBuildingType;
  addField(baseline, "Building Type - Area Based on Conditioned Area", "baselineBuildingType", { select: buildingTypes, wide: true });
  const climateRow = (climateTable?.rows || []).find((row) => String(row[0]) === String(values.climateZone));
  const buildingTypeIndex = (climateTable?.headers || []).findIndex((header) => header.label === values.baselineBuildingType);
  const systemNumber = climateRow?.[buildingTypeIndex] || "";
  const system = (systemTable?.rows || []).find((row) => String(row[0]) === String(systemNumber)) || [];
  [
    ["Number", systemNumber, '=XLOOKUP(@Climate Zone, [Climate Zones]@Climate Zone, [Climate Zones]@Building Type)'],
    ["System", system[1] ?? "", '=XLOOKUP(@Number, [Baseline System Descriptions]@Number, @System)'],
    ["System Type", system[2] ?? "", '=XLOOKUP(@Number, [Baseline System Descriptions]@Number, @System Type)'],
    ["Fan Control", system[3] ?? "", '=XLOOKUP(@Number, [Baseline System Descriptions]@Number, @Fan Control)'],
    ["Cooling Type", system[4] ?? "", '=XLOOKUP(@Number, [Baseline System Descriptions]@Number, @Cooling Type)'],
    ["Heating Type", system[5] ?? "", '=XLOOKUP(@Number, [Baseline System Descriptions]@Number, @Heating Type)'],
  ].forEach(([label, value, equation]) => addCalculated(baseline, label, value, 0, equation));

  const formula = document.createElement("div"); formula.className = "model-input-formula"; formula.hidden = true;
  const symbol = document.createElement("span"); symbol.textContent = "fx";
  const output = document.createElement("output");
  formula.append(symbol, output); modelInputsView.appendChild(formula);
}

function showModelInputEquation(equation) {
  const bar = modelInputsView.querySelector(".model-input-formula");
  const output = modelInputsView.querySelector(".model-input-formula output");
  if (!bar || !output) return;
  if (!equation) { bar.hidden = true; return; }
  output.textContent = equation;
  bar.hidden = false;
}

function hideModelInputEquation() {
  const bar = modelInputsView.querySelector(".model-input-formula");
  if (bar) bar.hidden = true;
}

function updateWorkspace(data) {
  const isSummary = data.summary === "true";
  const isEquipmentZoning = data.table === "calc-equipment-zoning";
  const isTable = Boolean(data.table) && !isEquipmentZoning;
  const isModelInputs = data.view === "model-inputs";
  document.querySelector("#crumb-group").textContent = data.group;
  document.querySelector("#crumb-page").textContent = data.title;
  document.querySelector("#page-kicker").textContent = isSummary ? "SECTION SUMMARY" : data.group.toUpperCase();
  document.querySelector("#page-title").textContent = data.title;
  document.querySelector("#page-description").textContent = data.description;
  document.querySelector("#source-sheet").textContent = data.source;
  document.querySelector(".section-label").textContent = isSummary ? "TABLE CONTENTS" : "CURRENT MODULE";
  document.querySelector("#module-heading").textContent = data.title;
  document.querySelector("#module-status").textContent = isTable || isModelInputs || isEquipmentZoning ? "Migrated" : "Structure ready";
  document.querySelector("#parity-status").textContent = isTable || isModelInputs || isEquipmentZoning ? "Workbook data matched" : "Not tested";
  document.querySelector("#revision-status").textContent = isTable || isModelInputs || isEquipmentZoning ? "Workbook source preserved" : "Source preserved";
  document.querySelector("#module-action").textContent = isEquipmentZoning ? "Interactive zoning" : isModelInputs ? "Project inputs" : isTable ? "Editable table" : "Calculation pending";
  document.querySelector("#empty-title").textContent = isSummary ? `${data.title} summary` : "Ready for workbook logic";
  document.querySelector("#empty-copy").textContent = isSummary
    ? data.description
    : "The navigation and source mapping are in place. Inputs, equations, units, validation, and Excel parity tests will be added in the next migration increment.";
  moduleContent.classList.toggle("is-summary", isSummary);
  shell.classList.toggle("summary-mode", isSummary);
  shell.classList.toggle("table-mode", isTable);
  shell.classList.toggle("model-inputs-mode", isModelInputs);
  shell.classList.toggle("equipment-zoning-mode", isEquipmentZoning);
  moduleContent.hidden = isTable || isModelInputs || isEquipmentZoning || !isSummary;
  tableView.hidden = !isTable;
  modelInputsView.hidden = !isModelInputs;
  equipmentZoningView.hidden = !isEquipmentZoning;
  if (isTable) {
    tableSearch.value = "";
    renderReferenceTable(data.table);
  } else if (isModelInputs) {
    activeTableId = "";
    renderModelInputs();
  } else if (isEquipmentZoning) {
    activeTableId = "calc-equipment-zoning";
    renderEquipmentZoningTool();
  } else {
    activeTableId = "";
    renderSummaryLinks(isSummary ? data.title : null);
  }
  document.title = `${data.title} · HVAC Design Workbook`;
}

const ZONING_SYMBOLS = [
  { id: "oa", label: "Entering OA", kind: "node", node: "oa", short: "OA" },
  { id: "ea", label: "Leaving EA", kind: "node", node: "ea", short: "EA" },
  { id: "louver", label: "Louver", kind: "accessory", short: "LVR" },
  { id: "heating-coil", label: "Heating Coil", kind: "device", slots: 1, heating: true, short: "HC" },
  { id: "preheat-cooling", label: "Preheat + Cooling", kind: "device", slots: 2, heating: true, cooling: true, short: "PH+C" },
  { id: "preheat-cooling-reheat", label: "Preheat + Cooling + Reheat", kind: "device", slots: 2, heating: true, cooling: true, short: "PH+C+RH" },
  { id: "cooling-heating", label: "Cooling FCU + Heating FCU", kind: "device", slots: 2, heating: true, cooling: true, short: "C+H" },
  { id: "valve", label: "Valve", kind: "device", slots: 1, cooling: true, short: "V" },
];

const zoningSymbol = (id) => ZONING_SYMBOLS.find((symbol) => symbol.id === id);
const cloneZoningConfiguration = (assignment) => ({
  buildingId: assignment.buildingId || "",
  devices: [...(assignment.devices || [])],
  louver: Boolean(assignment.louver),
  nodeOverrides: { ...(assignment.nodeOverrides || {}) },
});

function zoningSourceSpaces(project) {
  const table = independentTables.find((candidate) => candidate.id === "calc-equipment-zoning");
  if (!table) return [];
  return ensureProjectTableRows(project, table).map((row) => ({
    group: String(row[0] ?? "").trim() || "UNGROUPED",
    zone: String(row[1] ?? "").trim(),
    space: String(row[2] ?? "").trim(),
    legacy: row,
  })).filter((item) => item.space);
}

function inferBuildingEquipmentType(id) {
  const value = String(id).toUpperCase();
  if (value.includes("DOAS")) return "DOAS";
  if (value.includes("VALVE") || value.includes("VLV")) return "Central Valve";
  return "Central AHU";
}

function equipmentZoningState(project) {
  const spaces = zoningSourceSpaces(project);
  project.equipmentZoningTool ||= { library: [], assignments: {}, templates: {}, selectedGroup: "", selectedSpace: "", pendingSymbol: "" };
  const state = project.equipmentZoningTool;
  state.library ||= []; state.assignments ||= {}; state.templates ||= {};
  if (!state.initialized) {
    const libraryIds = new Set();
    spaces.forEach(({ legacy }) => [legacy[3], legacy[4], legacy[9]].forEach((value) => {
      const id = String(value ?? "").trim();
      if (!id || id === "-" || libraryIds.has(id.toLowerCase())) return;
      libraryIds.add(id.toLowerCase()); state.library.push({ id, type: inferBuildingEquipmentType(id) });
    }));
    state.initialized = true;
  }
  const validSpaces = new Set(spaces.map((item) => item.space));
  Object.keys(state.assignments).forEach((space) => { if (!validSpaces.has(space)) delete state.assignments[space]; });
  spaces.forEach(({ group, zone, space, legacy }) => {
    if (!state.assignments[space]) {
      const devices = [];
      if (legacy[5]) devices.push("valve");
      if (legacy[6]) devices.push("heating-coil");
      if (!devices.length && legacy[7] && legacy[8]) devices.push("cooling-heating");
      state.assignments[space] = {
        group, zone, space,
        buildingId: String(legacy[4] || legacy[3] || legacy[9] || ""),
        devices: devices.slice(0, 2), louver: false, nodeOverrides: {},
      };
    }
    state.assignments[space].group = group;
    state.assignments[space].zone = zone;
  });
  const groups = [...new Set(spaces.map((item) => item.group))];
  if (!groups.includes(state.selectedGroup)) state.selectedGroup = groups[0] || "";
  if (!validSpaces.has(state.selectedSpace)) state.selectedSpace = "";
  return { state, spaces, groups };
}

function automaticZoningNodes(assignment, library) {
  const equipment = library.find((item) => item.id === assignment.buildingId);
  const automatic = { oa: false, sa: false, ra: false, ea: false };
  if (equipment?.type === "DOAS") { automatic.oa = true; automatic.sa = true; }
  if (equipment?.type === "Central AHU") { automatic.oa = true; automatic.sa = true; automatic.ra = true; }
  if (equipment?.type === "Central Valve") automatic.sa = true;
  if ((assignment.devices || []).length) { automatic.sa = true; automatic.ra = true; }
  if (assignment.louver) automatic.oa = true;
  const nodes = {};
  Object.keys(automatic).forEach((node) => {
    const override = assignment.nodeOverrides?.[node];
    nodes[node] = typeof override === "boolean" ? override : automatic[node];
  });
  return nodes;
}

function zoningConfigurationMatches(left, right) {
  if (!right) return false;
  return JSON.stringify(cloneZoningConfiguration(left)) === JSON.stringify(cloneZoningConfiguration(right));
}

function syncZoningToolToCalc(project, state) {
  const table = independentTables.find((candidate) => candidate.id === "calc-equipment-zoning");
  if (!table) return;
  const rows = ensureProjectTableRows(project, table);
  const libraryById = new Map(state.library.map((item) => [item.id, item]));
  rows.forEach((row) => {
    const assignment = state.assignments[String(row[2] ?? "")];
    if (!assignment) return;
    row[0] = assignment.group; row[1] = assignment.zone;
    [3, 4, 5, 6, 7, 8, 9, 10].forEach((column) => { row[column] = ""; });
    const building = libraryById.get(assignment.buildingId);
    if (building?.type === "DOAS") row[3] = building.id;
    else if (building?.type === "Central AHU") row[4] = building.id;
    else if (building?.type === "Central Valve") row[5] = building.id;
    const equipmentBase = assignment.space.replace(/\s+/g, "-").replace(/[^A-Za-z0-9-]/g, "");
    (assignment.devices || []).forEach((device) => {
      if (device === "valve") row[5] = `${equipmentBase}-VLV`;
      if (device === "heating-coil") row[6] = `${equipmentBase}-RHC`;
      if (["preheat-cooling", "preheat-cooling-reheat", "cooling-heating"].includes(device)) {
        row[7] = `${equipmentBase}-FCU`; row[8] = `${equipmentBase}-FCU`;
        if (device === "preheat-cooling-reheat") row[6] = `${equipmentBase}-RHC`;
      }
    });
  });
}

function saveEquipmentZoning(project, state, rerender = true) {
  syncZoningToolToCalc(project, state);
  saveProjects();
  if (rerender) renderEquipmentZoningTool();
}

function validateZoningSymbol(assignment, symbolId) {
  const symbol = zoningSymbol(symbolId);
  if (!symbol) return "Unknown equipment symbol.";
  if (symbol.kind !== "device") return "";
  const devices = assignment.devices || [];
  if (devices.includes(symbolId)) return `${symbol.label} is already assigned to this space.`;
  const existingSymbols = devices.map(zoningSymbol).filter(Boolean);
  if (existingSymbols.some((item) => item.slots === 2)) return "This space already contains a two-slot equipment assembly.";
  if (symbol.slots === 2 && devices.length) return "A two-slot assembly requires both equipment slots to be empty.";
  const usedSlots = existingSymbols.reduce((sum, item) => sum + (item.slots || 0), 0);
  if (usedSlots + symbol.slots > 2) return "A space cannot contain more than two zone-equipment slots.";
  if (symbol.heating && existingSymbols.some((item) => item.heating)) return "A space cannot contain more than one heating-type device.";
  if (symbol.cooling && existingSymbols.some((item) => item.cooling)) return "A space cannot contain more than one cooling-type device.";
  return "";
}

function applyZoningSymbol(project, state, assignment, symbolId) {
  const symbol = zoningSymbol(symbolId);
  if (!symbol) return "Unknown equipment symbol.";
  if (symbol.kind === "node") {
    assignment.nodeOverrides ||= {}; assignment.nodeOverrides[symbol.node] = true;
  } else if (symbol.kind === "accessory") {
    assignment.louver = true;
  } else {
    const error = validateZoningSymbol(assignment, symbolId);
    if (error) return error;
    assignment.devices ||= []; assignment.devices.push(symbolId);
  }
  state.selectedSpace = assignment.space;
  state.notice = `${symbol.label} added to ${assignment.space}.`;
  saveEquipmentZoning(project, state);
  return "";
}

function zoningSymbolElement(symbol, compact = false) {
  const element = document.createElement("span");
  element.className = `zoning-symbol symbol-${symbol.id}${compact ? " compact" : ""}`;
  const icon = document.createElement("i"); icon.setAttribute("aria-hidden", "true"); icon.textContent = symbol.short;
  const label = document.createElement("span"); label.textContent = symbol.label;
  element.append(icon, label);
  return element;
}

function renderEquipmentZoningTool() {
  const project = activeProject();
  if (!project) return;
  const { state, spaces, groups } = equipmentZoningState(project);
  equipmentZoningView.innerHTML = "";
  const status = document.createElement("div"); status.className = "zoning-status"; status.setAttribute("role", "status"); status.setAttribute("aria-live", "polite");
  const setStatus = (message, error = false) => { status.textContent = message; status.classList.toggle("is-error", error); };
  if (state.notice) setStatus(state.notice);

  const librarySection = document.createElement("section"); librarySection.className = "zoning-library-section";
  const libraryHeading = document.createElement("div"); libraryHeading.className = "zoning-section-heading";
  libraryHeading.innerHTML = "<div><span>Shared equipment</span><h3>Building-level equipment</h3></div>";
  const addForm = document.createElement("form"); addForm.className = "building-equipment-form";
  const idInput = document.createElement("input"); idInput.required = true; idInput.placeholder = "Equipment ID"; idInput.setAttribute("aria-label", "New building equipment ID");
  const typeSelect = document.createElement("select"); typeSelect.setAttribute("aria-label", "New building equipment type");
  ["DOAS", "Central AHU", "Central Valve"].forEach((type) => { const option = document.createElement("option"); option.value = type; option.textContent = type; typeSelect.appendChild(option); });
  const addButton = document.createElement("button"); addButton.type = "submit"; addButton.textContent = "Add equipment";
  addForm.append(idInput, typeSelect, addButton); libraryHeading.appendChild(addForm); librarySection.appendChild(libraryHeading);
  addForm.addEventListener("submit", (event) => {
    event.preventDefault(); const id = idInput.value.trim();
    if (!id) return;
    if (state.library.some((item) => item.id.toLowerCase() === id.toLowerCase())) { setStatus("That building equipment ID already exists.", true); return; }
    state.library.push({ id, type: typeSelect.value }); saveEquipmentZoning(project, state);
  });
  const libraryList = document.createElement("div"); libraryList.className = "building-equipment-list";
  state.library.forEach((item, index) => {
    const row = document.createElement("div"); row.className = `building-equipment-item type-${slugify(item.type)}`;
    const mark = document.createElement("i"); mark.textContent = item.type === "DOAS" ? "D" : item.type === "Central AHU" ? "A" : "V";
    const id = document.createElement("input"); id.value = item.id; id.setAttribute("aria-label", `${item.type} equipment ID`);
    const type = typeSelect.cloneNode(true); type.value = item.type; type.setAttribute("aria-label", `${item.id} equipment type`);
    const remove = document.createElement("button"); remove.type = "button"; remove.className = "zoning-icon-button danger"; remove.textContent = "×"; remove.title = `Remove ${item.id}`;
    id.addEventListener("change", () => {
      const nextId = id.value.trim(); if (!nextId) { id.value = item.id; return; }
      if (state.library.some((candidate, candidateIndex) => candidateIndex !== index && candidate.id.toLowerCase() === nextId.toLowerCase())) { id.value = item.id; setStatus("That building equipment ID already exists.", true); return; }
      const previous = item.id; item.id = nextId;
      Object.values(state.assignments).forEach((assignment) => { if (assignment.buildingId === previous) assignment.buildingId = nextId; });
      saveEquipmentZoning(project, state);
    });
    type.addEventListener("change", () => { item.type = type.value; saveEquipmentZoning(project, state); });
    remove.addEventListener("click", () => {
      state.library.splice(index, 1); Object.values(state.assignments).forEach((assignment) => { if (assignment.buildingId === item.id) assignment.buildingId = ""; });
      saveEquipmentZoning(project, state);
    });
    row.append(mark, id, type, remove); libraryList.appendChild(row);
  });
  if (!state.library.length) { const empty = document.createElement("p"); empty.className = "zoning-empty-copy"; empty.textContent = "Add a DOAS, central AHU, or central valve to make it available to spaces."; libraryList.appendChild(empty); }
  librarySection.appendChild(libraryList);

  const designSection = document.createElement("section"); designSection.className = "zoning-design-section";
  const controls = document.createElement("div"); controls.className = "zoning-controls";
  const groupLabel = document.createElement("label"); groupLabel.innerHTML = "<span>Zone group</span>";
  const groupSelect = document.createElement("select"); groups.forEach((group) => { const option = document.createElement("option"); option.value = group; option.textContent = group; groupSelect.appendChild(option); }); groupSelect.value = state.selectedGroup;
  groupSelect.addEventListener("change", () => { state.selectedGroup = groupSelect.value; state.selectedSpace = ""; saveEquipmentZoning(project, state); }); groupLabel.appendChild(groupSelect);
  const applyButton = document.createElement("button"); applyButton.type = "button"; applyButton.className = "apply-template-button"; applyButton.textContent = "Apply selected space to group"; applyButton.disabled = !state.selectedSpace;
  applyButton.addEventListener("click", () => {
    const source = state.assignments[state.selectedSpace]; if (!source) return;
    const configuration = cloneZoningConfiguration(source); state.templates[source.group] = configuration;
    Object.values(state.assignments).filter((assignment) => assignment.group === source.group).forEach((assignment) => Object.assign(assignment, cloneZoningConfiguration(configuration)));
    saveEquipmentZoning(project, state);
  });
  const exportButton = document.createElement("button"); exportButton.type = "button"; exportButton.className = "zoning-export-button"; exportButton.textContent = "Export CSV"; exportButton.addEventListener("click", () => exportEquipmentZoningCsv(project));
  controls.append(groupLabel, applyButton, exportButton); designSection.appendChild(controls);

  const palette = document.createElement("div"); palette.className = "zoning-palette"; palette.setAttribute("aria-label", "Equipment symbol palette");
  const paletteHeading = document.createElement("div"); paletteHeading.className = "zoning-palette-heading"; paletteHeading.innerHTML = "<span>Symbol palette and legend</span><strong>Drag onto a space, or select a symbol and then select a space</strong>";
  ZONING_SYMBOLS.forEach((symbol) => {
    const button = document.createElement("button"); button.type = "button"; button.draggable = true; button.className = "zoning-palette-item"; button.title = `Drag ${symbol.label} onto a space`;
    button.appendChild(zoningSymbolElement(symbol)); button.classList.toggle("is-active", state.pendingSymbol === symbol.id);
    button.addEventListener("dragstart", (event) => { event.dataTransfer.setData("text/plain", symbol.id); event.dataTransfer.effectAllowed = "copy"; });
    button.addEventListener("click", () => { state.pendingSymbol = state.pendingSymbol === symbol.id ? "" : symbol.id; saveEquipmentZoning(project, state); });
    palette.appendChild(button);
  });
  designSection.append(paletteHeading, palette, status);

  const cards = document.createElement("div"); cards.className = "space-card-grid";
  spaces.filter((item) => item.group === state.selectedGroup).forEach(({ space }) => cards.appendChild(renderZoningSpaceCard(project, state, state.assignments[space], setStatus)));
  if (!cards.children.length) { const empty = document.createElement("p"); empty.className = "zoning-empty-copy"; empty.textContent = "No spaces are available in this zone group."; cards.appendChild(empty); }
  designSection.appendChild(cards);

  const tableSection = document.createElement("section"); tableSection.className = "zoning-data-section";
  const tableHeading = document.createElement("div"); tableHeading.className = "zoning-section-heading"; tableHeading.innerHTML = `<div><span>Zone-level data</span><h3>Space equipment assignments</h3></div><strong>${spaces.length} spaces</strong>`;
  tableSection.append(tableHeading, renderZoningAssignmentTable(state, spaces));
  equipmentZoningView.append(librarySection, designSection, tableSection);
}

function renderZoningSpaceCard(project, state, assignment, setStatus) {
  const card = document.createElement("article"); card.className = "zoning-space-card"; card.dataset.space = assignment.space;
  card.classList.toggle("is-selected", state.selectedSpace === assignment.space);
  card.classList.toggle("is-drop-target", Boolean(state.pendingSymbol));
  const template = state.templates[assignment.group];
  const badge = document.createElement("span"); badge.className = `space-template-state ${template && !zoningConfigurationMatches(assignment, template) ? "override" : "match"}`; badge.textContent = template ? (zoningConfigurationMatches(assignment, template) ? "Template" : "Override") : "Individual";
  const header = document.createElement("header");
  const title = document.createElement("div"); const zone = document.createElement("span"); zone.textContent = assignment.zone || "No zone"; const name = document.createElement("h4"); name.textContent = assignment.space; title.append(zone, name); header.append(title, badge);

  const equipmentLabel = document.createElement("label"); equipmentLabel.className = "building-equipment-tag"; equipmentLabel.innerHTML = "<span>Building equipment</span>";
  const equipmentSelect = document.createElement("select"); const blank = document.createElement("option"); blank.value = ""; blank.textContent = "None"; equipmentSelect.appendChild(blank);
  state.library.forEach((item) => { const option = document.createElement("option"); option.value = item.id; option.textContent = `${item.id} · ${item.type}`; equipmentSelect.appendChild(option); }); equipmentSelect.value = assignment.buildingId || "";
  equipmentSelect.addEventListener("change", () => { assignment.buildingId = equipmentSelect.value; state.selectedSpace = assignment.space; saveEquipmentZoning(project, state); }); equipmentLabel.appendChild(equipmentSelect);

  const box = document.createElement("div"); box.className = "space-box";
  const nodes = automaticZoningNodes(assignment, state.library);
  Object.entries(nodes).forEach(([node, active]) => { if (!active) return; const marker = document.createElement("span"); marker.className = `connection-node node-${node}`; marker.textContent = node.toUpperCase(); box.appendChild(marker); });
  const slots = document.createElement("div"); slots.className = "zone-equipment-slots";
  (assignment.devices || []).forEach((deviceId) => {
    const symbol = zoningSymbol(deviceId); if (!symbol) return;
    const chip = document.createElement("div"); chip.className = `zone-device-chip slots-${symbol.slots}`; chip.appendChild(zoningSymbolElement(symbol, true));
    const remove = document.createElement("button"); remove.type = "button"; remove.textContent = "×"; remove.title = `Remove ${symbol.label}`; remove.addEventListener("click", (event) => { event.stopPropagation(); assignment.devices = assignment.devices.filter((id) => id !== deviceId); saveEquipmentZoning(project, state); });
    chip.appendChild(remove); slots.appendChild(chip);
  });
  const usedSlots = (assignment.devices || []).map(zoningSymbol).filter(Boolean).reduce((sum, item) => sum + (item.slots || 0), 0);
  for (let slot = usedSlots; slot < 2; slot += 1) { const empty = document.createElement("div"); empty.className = "zone-device-empty"; empty.textContent = `Slot ${slot + 1}`; slots.appendChild(empty); }
  if (assignment.louver) { const louver = document.createElement("div"); louver.className = "space-louver"; louver.appendChild(zoningSymbolElement(zoningSymbol("louver"), true)); const remove = document.createElement("button"); remove.type = "button"; remove.textContent = "×"; remove.title = "Remove louver"; remove.addEventListener("click", (event) => { event.stopPropagation(); assignment.louver = false; saveEquipmentZoning(project, state); }); louver.appendChild(remove); box.appendChild(louver); }
  box.appendChild(slots);

  const nodeControls = document.createElement("div"); nodeControls.className = "node-controls";
  ["oa", "sa", "ra", "ea"].forEach((node) => {
    const label = document.createElement("label"); const input = document.createElement("input"); input.type = "checkbox"; input.checked = nodes[node];
    input.addEventListener("change", () => { assignment.nodeOverrides ||= {}; assignment.nodeOverrides[node] = input.checked; state.selectedSpace = assignment.space; saveEquipmentZoning(project, state); });
    label.append(input, document.createTextNode(node.toUpperCase())); nodeControls.appendChild(label);
  });
  const autoNodes = document.createElement("button"); autoNodes.type = "button"; autoNodes.textContent = "Auto"; autoNodes.title = "Reset connection nodes to automatic"; autoNodes.addEventListener("click", () => { assignment.nodeOverrides = {}; saveEquipmentZoning(project, state); }); nodeControls.appendChild(autoNodes);
  card.append(header, equipmentLabel, box, nodeControls);
  const applySymbol = (symbolId) => {
    const error = applyZoningSymbol(project, state, assignment, symbolId);
    if (error) setStatus(error, true); else setStatus(`${zoningSymbol(symbolId)?.label || "Symbol"} added to ${assignment.space}.`);
  };
  card.addEventListener("dragover", (event) => { event.preventDefault(); card.classList.add("drag-over"); event.dataTransfer.dropEffect = "copy"; });
  card.addEventListener("dragleave", () => card.classList.remove("drag-over"));
  card.addEventListener("drop", (event) => { event.preventDefault(); card.classList.remove("drag-over"); applySymbol(event.dataTransfer.getData("text/plain")); });
  card.addEventListener("click", (event) => {
    if (event.target.closest("button, select, input, label")) return;
    if (state.pendingSymbol) {
      const symbol = state.pendingSymbol;
      const validation = validateZoningSymbol(assignment, symbol);
      if (validation) { setStatus(validation, true); return; }
      state.pendingSymbol = ""; applySymbol(symbol);
    }
    else { state.selectedSpace = assignment.space; saveEquipmentZoning(project, state); }
  });
  return card;
}

function renderZoningAssignmentTable(state, spaces) {
  const wrap = document.createElement("div"); wrap.className = "zoning-table-wrap";
  const table = document.createElement("table"); table.className = "zoning-assignment-table";
  const headers = ["Space", "Zone Group", "Zone", "Slot 1", "Slot 2", "Building Equipment", "OA", "SA", "RA", "EA", "Louver"];
  const head = document.createElement("thead"); const headRow = document.createElement("tr"); headers.forEach((text) => { const th = document.createElement("th"); th.textContent = text; headRow.appendChild(th); }); head.appendChild(headRow); table.appendChild(head);
  const body = document.createElement("tbody");
  spaces.forEach(({ space }) => {
    const assignment = state.assignments[space]; const nodes = automaticZoningNodes(assignment, state.library); const devices = assignment.devices.map((id) => zoningSymbol(id)?.label || id);
    const values = [space, assignment.group, assignment.zone, devices[0] || "", devices[1] || (zoningSymbol(assignment.devices[0])?.slots === 2 ? "Occupied by assembly" : ""), assignment.buildingId || "", nodes.oa ? "TRUE" : "", nodes.sa ? "TRUE" : "", nodes.ra ? "TRUE" : "", nodes.ea ? "TRUE" : "", assignment.louver ? "TRUE" : ""];
    const row = document.createElement("tr"); values.forEach((value) => { const td = document.createElement("td"); td.textContent = value; row.appendChild(td); }); body.appendChild(row);
  });
  table.appendChild(body); wrap.appendChild(table); return wrap;
}

function exportEquipmentZoningCsv(project) {
  const { state, spaces } = equipmentZoningState(project);
  const rows = [["Space", "Zone Group", "Zone", "Zone Equipment Slot 1", "Zone Equipment Slot 2", "Building Equipment", "OA", "SA", "RA", "EA", "Louver"]];
  spaces.forEach(({ space }) => {
    const assignment = state.assignments[space]; const nodes = automaticZoningNodes(assignment, state.library); const devices = assignment.devices.map((id) => zoningSymbol(id)?.label || id);
    rows.push([space, assignment.group, assignment.zone, devices[0] || "", devices[1] || (zoningSymbol(assignment.devices[0])?.slots === 2 ? "Occupied by assembly" : ""), assignment.buildingId || "", nodes.oa ? "TRUE" : "", nodes.sa ? "TRUE" : "", nodes.ra ? "TRUE" : "", nodes.ea ? "TRUE" : "", assignment.louver ? "TRUE" : ""]);
  });
  const csv = rows.map((row) => row.map((value) => `"${String(value ?? "").replace(/"/g, '""')}"`).join(",")).join("\r\n");
  const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
  const link = document.createElement("a"); link.href = url; link.download = `equipment-zoning-${project.number || "project"}.csv`; document.body.appendChild(link); link.click(); link.remove(); URL.revokeObjectURL(url);
}

function updateTableSettings(table) {
  const scheduleVisible = Boolean(table.twoValueScheduleDefault);
  const factorsVisible = Boolean(table.roomLoadCalculation);
  tableSettings.hidden = !scheduleVisible && !factorsVisible;
  twoValueSetting.hidden = !scheduleVisible;
  loadFactorSettings.hidden = !factorsVisible;
  if (!scheduleVisible && !factorsVisible) return;
  const project = activeProject();
  if (!project && scheduleVisible) {
    twoValueSchedule.value = table.twoValueScheduleDefault;
    return;
  }
  project.calcSettings ||= {};
  if (scheduleVisible) twoValueSchedule.value = project.calcSettings.twoValueSchedule || table.twoValueScheduleDefault;
  if (factorsVisible) {
    project.calcSettings.spaceLoadFactors ||= { sensible: 0.1, latent: 0.1, heating: 0.1 };
    sensibleLoadFactor.value = tableNumberFormatter.format(project.calcSettings.spaceLoadFactors.sensible * 100);
    latentLoadFactor.value = tableNumberFormatter.format(project.calcSettings.spaceLoadFactors.latent * 100);
    heatingLoadFactor.value = tableNumberFormatter.format(project.calcSettings.spaceLoadFactors.heating * 100);
  }
}

function isConditionalCalculatedCell(table, row, columnIndex) {
  const config = table.conditionalCalculatedColumns?.[columnIndex];
  if (!config) return false;
  const value = row[config.whenColumn];
  return value !== "" && value !== null && value !== undefined;
}

function isUnusedGainCell(table, row, columnIndex) {
  const populated = (value) => value !== "" && value !== null && value !== undefined;
  if (table.id === "calc-lighting-gains") {
    if (columnIndex === 3) return populated(row[6]) || populated(row[5]);
    if (columnIndex === 5) return populated(row[6]);
  }
  if (table.id === "calc-people-gains" && columnIndex === 3) return populated(row[4]);
  if (table.id === "calc-misc-gains" && columnIndex === 3) return populated(row[4]);
  return false;
}

function humidityRatio(dryBulbF, relativeHumidity) {
  const dryBulb = Number(dryBulbF);
  const humidity = Number(relativeHumidity);
  if (!Number.isFinite(dryBulb) || !Number.isFinite(humidity)) return "";
  const dryBulbC = (dryBulb - 32) * 5 / 9;
  const saturationPressure = 0.145038 * 0.61094 * Math.exp((17.625 * dryBulbC) / (dryBulbC + 243.04));
  const vaporPressure = saturationPressure * humidity;
  return 0.621945 * vaporPressure / (14.166979464192584 - vaporPressure);
}

function recalculateSpecialTableRow(table, row) {
  if (table.id !== "calc-space-condition-setpoints") return;
  if (isConditionalCalculatedCell(table, row, 7)) {
    const rise = Number(row[6]);
    row[7] = Number.isFinite(rise) ? 91.6 + rise : "";
  }
  row[5] = humidityRatio(row[3], row[2]);
  row[9] = humidityRatio(row[7], row[2]);
}

function clearFillPreview() {
  referenceTable.querySelectorAll(".fill-preview").forEach((cell) => cell.classList.remove("fill-preview"));
}

function clearFillHandle() {
  document.querySelectorAll("body > .fill-handle").forEach((handle) => handle.remove());
  referenceTable.querySelectorAll(".fill-source").forEach((source) => source.classList.remove("fill-source"));
}

function showFillHandle(cell, table, rows, sourceIndex, columnIndex) {
  clearFillHandle();
  if (!cell.classList.contains("editable-cell")) return;
  cell.classList.add("fill-source");
  const cellRect = cell.getBoundingClientRect();
  const handle = document.createElement("span");
  handle.className = "fill-handle";
  handle.style.left = `${cellRect.right - 7}px`;
  handle.style.top = `${cellRect.bottom - 7}px`;
  handle.setAttribute("role", "button");
  handle.setAttribute("aria-label", "Drag to fill cells below");
  handle.addEventListener("pointerdown", (event) => {
    event.preventDefault();
    event.stopPropagation();
    handle.setPointerCapture?.(event.pointerId);
    fillDrag = { table, rows, sourceIndex, columnIndex, sourceValue: rows[sourceIndex][columnIndex], targetIndexes: [] };
  });
  document.body.appendChild(handle);
}

function updateFillPreview(clientX, clientY) {
  if (!fillDrag) return;
  const target = document.elementFromPoint(clientX, clientY)?.closest?.("td");
  if (!target || Number(target.dataset.columnIndex) !== fillDrag.columnIndex) return;
  const bodyRows = [...referenceTable.querySelectorAll("tbody tr:not(.table-summary-row)")];
  const originRow = bodyRows.findIndex((row) => Number(row.dataset.sourceIndex) === fillDrag.sourceIndex);
  const targetRow = bodyRows.indexOf(target.parentElement);
  if (originRow < 0 || targetRow < 0) return;
  const [start, end] = originRow <= targetRow ? [originRow, targetRow] : [targetRow, originRow];
  fillDrag.targetIndexes = bodyRows.slice(start, end + 1).map((row) => Number(row.dataset.sourceIndex));
  clearFillPreview();
  bodyRows.slice(start, end + 1).forEach((row) => row.cells[fillDrag.columnIndex]?.classList.add("fill-preview"));
}

function finishFillDrag() {
  if (!fillDrag) return;
  const { table, rows, sourceIndex, columnIndex, sourceValue, targetIndexes } = fillDrag;
  targetIndexes.filter((index) => index !== sourceIndex).forEach((index) => {
    rows[index][columnIndex] = sourceValue;
    recalculateSpecialTableRow(table, rows[index]);
  });
  clearFillPreview();
  fillDrag = null;
  recalculateTable(table, rows);
  recalculateDependentTables(table);
  saveProjects();
  renderReferenceTable(table.id, tableSearch.value);
}

function renderReferenceTable(tableId, query = tableSearch.value) {
  const table = independentTables.find((candidate) => candidate.id === tableId);
  if (!table) return;
  clearFillHandle();
  activeTableId = tableId;
  tableStandard.textContent = table.standard;
  updateTableSettings(table);
  referenceTable.classList.toggle("two-frozen-columns", table.frozenColumns === 2);
  referenceTable.classList.toggle("three-frozen-columns", table.frozenColumns === 3);
  calculatedKey.hidden = ![...(table.calculatedColumns || []), ...(table.lockedColumns || [])].length;
  updateCsvToolbar(table);
  clearCsvComparison();
  clearSelectedEquation();
  const normalized = query.trim().toLowerCase();
  const sourceRows = projectTableRows(table);
  recalculateTable(table, sourceRows);
  const headers = displayedTableHeaders(table);
  if (selectedTableId !== tableId) {
    selectedTableId = "";
    selectedTableRowIndexes.clear();
    selectionAnchorIndex = -1;
    selectedTableCells.clear();
    cellSelectionAnchor = null;
  } else {
    selectedTableRowIndexes = new Set([...selectedTableRowIndexes].filter((index) => index < sourceRows.length));
  }
  removeTableRowButton.disabled = selectedTableRowIndexes.size === 0;
  const rows = sourceRows
    .map((row, sourceIndex) => ({ row, sourceIndex }))
    .filter(({ row }) => !normalized || row.some((value) => String(value ?? "").toLowerCase().includes(normalized)));

  if (tableSort.tableId === tableId && tableSort.column >= 0) {
    const { column, direction } = tableSort;
    rows.sort((left, right) => compareTableValues(left.row[column], right.row[column]) * (direction === "asc" ? 1 : -1));
  }

  referenceTable.innerHTML = "";
  referenceTable.setAttribute("aria-multiselectable", "true");
  const head = document.createElement("thead");
  if (table.headerGroups?.length) {
    const groupRow = document.createElement("tr");
    groupRow.className = "group-header-row";
    table.headerGroups.forEach((group) => {
      const cell = document.createElement("th");
      cell.colSpan = group.span;
      cell.scope = "colgroup";
      if (group.linkTableId) {
        const link = document.createElement("button"); link.type = "button"; link.className = "header-link group-header-link"; link.textContent = group.label;
        link.title = `Open ${independentTables.find((candidate) => candidate.id === group.linkTableId)?.name || "source table"}`;
        link.addEventListener("click", () => openLinkedTable(group.linkTableId)); cell.appendChild(link);
      } else {
        cell.textContent = group.label;
      }
      if (group.className) cell.classList.add(group.className);
      if ((table.sectionStartColumns || []).includes(group.start)) cell.classList.add("section-divider");
      groupRow.appendChild(cell);
    });
    head.appendChild(groupRow);
  }
  const headerRow = document.createElement("tr");
  headers.forEach((header, columnIndex) => {
    const cell = document.createElement("th");
    cell.scope = "col";
    if ((table.calculatedColumns || []).includes(columnIndex)) cell.classList.add("calculated-header");
    if (table.headerClasses?.[columnIndex]) cell.classList.add(table.headerClasses[columnIndex]);
    if ((table.sectionStartColumns || []).includes(columnIndex)) cell.classList.add("section-divider");
    const content = document.createElement("div");
    content.className = "table-header-content";

    const linkedTableId = table.headerLinks?.[columnIndex];
    const label = document.createElement(linkedTableId ? "button" : "span");
    label.className = linkedTableId ? "column-label header-link" : "column-label";
    if (linkedTableId) {
      label.type = "button";
      label.title = `Open ${independentTables.find((candidate) => candidate.id === linkedTableId)?.name || "source table"}`;
      label.addEventListener("click", () => openLinkedTable(linkedTableId));
    }
    appendFormattedText(label, header.label);
    if (header.subscript) {
      const subscript = document.createElement("sub");
      subscript.textContent = header.subscript;
      label.appendChild(subscript);
    }
    content.appendChild(label);

    if (header.unit) {
      const unit = document.createElement("span");
      unit.className = "column-unit";
      appendFormattedText(unit, header.unit);
      content.appendChild(unit);
    }

    const sortButton = document.createElement("button");
    sortButton.type = "button";
    sortButton.className = "column-sort-control";
    sortButton.title = `Sort by ${header.label}`;
    sortButton.setAttribute("aria-label", `Sort by ${header.label}`);
    if (tableSort.tableId === tableId && tableSort.column === columnIndex) {
      sortButton.textContent = tableSort.direction === "asc" ? "↑" : "↓";
      cell.setAttribute("aria-sort", tableSort.direction === "asc" ? "ascending" : "descending");
    } else {
      sortButton.textContent = "↕";
    }
    sortButton.addEventListener("click", () => sortReferenceTable(tableId, columnIndex));
    content.appendChild(sortButton);
    cell.appendChild(content);
    headerRow.appendChild(cell);
  });
  head.appendChild(headerRow);

  const dropdownOptionsByColumn = new Map(
    Object.keys(table.dropdownColumns || {}).map((columnIndex) => {
      const index = Number(columnIndex);
      return [index, tableDropdownOptions(table, index)];
    }),
  );

  const body = document.createElement("tbody");
  rows.forEach(({ row, sourceIndex }) => {
    const tableRow = document.createElement("tr");
    tableRow.dataset.sourceIndex = String(sourceIndex);
    tableRow.classList.toggle("selected-row", selectedTableId === tableId && selectedTableRowIndexes.has(sourceIndex));
    tableRow.setAttribute("aria-selected", String(selectedTableId === tableId && selectedTableRowIndexes.has(sourceIndex)));
    tableRow.addEventListener("click", (event) => {
      if (event.target.closest("td.editable-cell")) return;
      selectTableRow(tableId, tableRow, sourceIndex, event);
    });
    row.forEach((value, index) => {
      const cell = document.createElement("td");
      cell.dataset.sourceIndex = String(sourceIndex);
      cell.dataset.columnIndex = String(index);
      if (typeof value === "number") cell.classList.add("numeric-cell");
      if ((table.sectionStartColumns || []).includes(index)) cell.classList.add("section-divider");
      if (isUnusedGainCell(table, row, index)) cell.classList.add("inactive-gain-cell");
      if ((table.id === "iesve-tabular-space-data" && index < 2) || (table.identityColumns || []).includes(index)) {
        cell.classList.add("identity-cell");
      }
      const conditionalCalculated = isConditionalCalculatedCell(table, row, index);
      const calculated = (table.calculatedColumns || []).includes(index) || conditionalCalculated;
      const dynamicLocked = table.lockedCellStates?.get(sourceIndex)?.has(index);
      const locked = (table.lockedColumns || []).includes(index) || conditionalCalculated || dynamicLocked;
      if (table.autoCellStates?.get(sourceIndex)?.has(index) && !dynamicLocked) cell.classList.add("auto-populated-cell");
      if (dynamicLocked) cell.classList.add("dynamically-locked-cell");
      if (calculated || locked) {
        cell.textContent = formatTableValue(value, table, index);
        cell.classList.add("calculated-cell");
        if (locked) cell.classList.add("locked-cell");
        cell.tabIndex = 0;
        const imported = Boolean(table.excelImport);
        cell.title = imported ? "Imported value" : dynamicLocked
          ? table.lockedCellMessages?.get(sourceIndex)?.get(index) || "Locked by the active equipment path"
          : calculated ? "Calculated value; select to view the equation" : "Calculated value";
        cell.setAttribute("aria-label", `${imported ? "Imported" : "Calculated"} ${table.headers[index].label}, row ${sourceIndex + 1}`);
        if (calculated) {
          cell.addEventListener("click", () => showSelectedEquation(table, cell, index));
          cell.addEventListener("focus", () => showSelectedEquation(table, cell, index));
        } else {
          cell.addEventListener("focus", clearSelectedEquation);
        }
        cell.addEventListener("keydown", (event) => {
          if (event.key === "Enter" || ["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(event.key)) {
            event.preventDefault();
            moveToAdjacentCell(cell, event.key === "Enter" ? "ArrowDown" : event.key, event.shiftKey);
          }
        });
      } else if (table.dropdownColumns?.[index] || table.cellDropdownRows?.[sourceIndex]?.[index]) {
        cell.classList.add("editable-cell", "dropdown-cell");
        const select = document.createElement("select");
        select.className = "table-cell-select";
        select.setAttribute("aria-label", `Select ${table.headers[index].label}, row ${sourceIndex + 1}`);
        const options = table.cellDropdownRows?.[sourceIndex]?.[index] || dropdownOptionsByColumn.get(index) || [];
        const rawCurrentValue = String(value ?? "");
        const normalizedOption = options.find((option) => option.localeCompare(rawCurrentValue, undefined, { sensitivity: "base" }) === 0);
        const currentValue = normalizedOption || rawCurrentValue;
        const addOption = (optionValue) => {
          const option = document.createElement("option");
          option.value = optionValue;
          option.textContent = optionValue;
          select.appendChild(option);
        };
        addOption("");
        if (currentValue !== "") addOption(currentValue);
        select.value = currentValue;
        select.title = select.value;
        const populateDropdownOptions = () => {
          if (select.dataset.optionsLoaded === "true") return;
          const selectedValue = select.value;
          const optionValues = selectedValue !== "" && !options.includes(selectedValue)
            ? [selectedValue, ...options]
            : options;
          select.replaceChildren();
          addOption("");
          optionValues.forEach(addOption);
          select.value = selectedValue;
          select.dataset.optionsLoaded = "true";
        };
        select.addEventListener("pointerdown", populateDropdownOptions);
        select.addEventListener("focus", () => {
          populateDropdownOptions();
          clearSelectedEquation();
          if (!suppressFillHandleOnce) showFillHandle(cell, table, sourceRows, sourceIndex, index);
          suppressFillHandleOnce = false;
        });
        select.addEventListener("change", () => {
          select.title = select.value;
          updateTableCell(table, sourceRows, sourceIndex, index, select.value);
        });
        select.addEventListener("keydown", (event) => {
          if (event.key === "Enter" || ["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(event.key)) {
            event.preventDefault();
            moveToAdjacentCell(cell, event.key === "Enter" ? "ArrowDown" : event.key, event.shiftKey);
          }
        });
        cell.appendChild(select);
      } else {
        cell.textContent = formatTableValue(value, table, index);
        cell.classList.add("editable-cell");
        cell.contentEditable = "true";
        cell.spellcheck = false;
        cell.setAttribute("aria-label", `Edit ${table.headers[index].label}, row ${sourceIndex + 1}`);
        cell.addEventListener("focus", () => {
          clearSelectedEquation();
          if (!suppressFillHandleOnce) showFillHandle(cell, table, sourceRows, sourceIndex, index);
          suppressFillHandleOnce = false;
        });
        cell.addEventListener("keydown", (event) => {
          if (event.key === "Enter") {
            event.preventDefault();
            moveToAdjacentCell(cell, "ArrowDown");
          } else if (!event.shiftKey && ["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(event.key)) {
            event.preventDefault();
            moveToAdjacentCell(cell, event.key, event.shiftKey);
          }
        });
        cell.addEventListener("blur", () => {
          const nextValue = normalizedTableInput(table, index, cell.textContent);
          const currentValue = row[index] ?? "";
          const unchanged = typeof nextValue === "number" && typeof currentValue === "number"
            ? Math.abs(nextValue - currentValue) < 1e-12
            : String(nextValue) === String(currentValue);
          if (!unchanged) updateTableCell(table, sourceRows, sourceIndex, index, cell.textContent);
        });
      }
      if (table.equipmentZoningCalculation && (table.autoColumns || []).includes(index) && !dynamicLocked) {
        const autoValue = activeProject()?.zoningAutoValues?.[table.id]?.[zoningCellKey(row, index)] ?? "";
        cell.title = `Autopopulated value: ${autoValue || "(blank)"}`;
      }
      if (table.roomLoadCalculation && (table.autoColumns || []).includes(index)) {
        const autoValue = activeProject()?.spaceLoadFactorAutos?.[`${String(row[0] ?? "")}::${index}`] ?? 0;
        cell.title = `Autopopulated value: ${tableNumberFormatter.format(Number(autoValue) * 100)}%`;
      }
      if (table.airsideSettingsCalculation && (table.autoColumns || []).includes(index) && !dynamicLocked) {
        const autoValue = activeProject()?.airsideAutoValues?.[airsideCellKey(row, index)] ?? "";
        cell.title = `Autopopulated value: ${isPercentageColumn(table, index) ? `${zeroDecimalFormatter.format(Number(autoValue) * 100)}%` : autoValue || "(blank)"}`;
      }
      if (table.coilCalculation && (table.autoColumns || []).includes(index) && !dynamicLocked) {
        const autoValue = activeProject()?.coilAutoValues?.[table.id]?.[airsideCellKey(row, index)] ?? "";
        cell.title = `Autopopulated value: ${isPercentageColumn(table, index) ? `${oneDecimalFormatter.format(Number(autoValue) * 100)}%` : oneDecimalFormatter.format(Number(autoValue))}`;
      }
      if (table.roomLoadCalculation && table.missingRoomLoadSpaces?.has(String(row[0] ?? "")) && [0, 2, 8, 14].includes(index)) {
        cell.classList.add("missing-source-cell");
        cell.title = "Space not in Room/Zone Loads Report.";
      }
      decorateCsvComparisonCell(table, cell, row, sourceIndex, index);
      decorateRoomValidationCell(table, cell, value, index);
      cell.addEventListener("pointerdown", (event) => {
        if (event.button !== 0 || !(table.lockedColumns || []).includes(index)) return;
        cell.focus({ preventScroll: true });
        markSelectedTableCell(cell);
      });
      cell.addEventListener("focusin", () => {
        if ((table.lockedColumns || []).includes(index)) markSelectedTableCell(cell);
        showCsvComparison(table, sourceRows, sourceIndex, index);
      });
      cell.addEventListener("click", () => {
        if ((table.lockedColumns || []).includes(index)) {
          cell.focus({ preventScroll: true });
          markSelectedTableCell(cell);
        }
        showCsvComparison(table, sourceRows, sourceIndex, index);
      });
      cell.addEventListener("pointerdown", (event) => {
        if (event.button !== 0 || !cell.classList.contains("editable-cell")) return;
        selectTableCell(tableId, sourceIndex, index, event);
      });
      if (selectedTableCells.has(`${sourceIndex}:${index}`)) cell.classList.add("multi-cell-selected");
      tableRow.appendChild(cell);
    });
    body.appendChild(tableRow);
  });

  let foot = null;
  if ((table.summaryColumns || []).length) {
    foot = document.createElement("tfoot");
    const summaryRow = document.createElement("tr");
    summaryRow.className = "table-summary-row";
    headers.forEach((_, columnIndex) => {
      const cell = document.createElement("td");
      if (columnIndex === 0) cell.textContent = "Total";
      if ((table.summaryColumns || []).includes(columnIndex)) {
        const aggregation = table.summaryAggregations?.[columnIndex] || "sum";
        const total = aggregation === "count"
          ? sourceRows.filter((row) => row[columnIndex] !== "" && row[columnIndex] !== null && row[columnIndex] !== undefined).length
          : aggregation === "unique-count"
            ? new Set(sourceRows.map((row) => String(row[columnIndex] ?? "").trim()).filter(Boolean)).size
          : sourceRows.reduce((sum, row) => sum + (Number(row[columnIndex]) || 0), 0);
        cell.textContent = columnIndex === 0 && aggregation === "unique-count" ? `Total: ${total}` : formatTableValue(total, table, columnIndex);
        cell.classList.add("numeric-cell");
      }
      if ((table.identityColumns || []).includes(columnIndex)) cell.classList.add("identity-cell");
      summaryRow.appendChild(cell);
    });
    foot.appendChild(summaryRow);
  }

  const widths = calculateColumnWidths(table, headers, sourceRows);
  const columnGroup = document.createElement("colgroup");
  widths.forEach((width) => {
    const column = document.createElement("col");
    column.style.width = `${width}px`;
    columnGroup.appendChild(column);
  });
  referenceTable.append(columnGroup, head, body, ...(foot ? [foot] : []));
  referenceTable.style.width = `${widths.reduce((total, width) => total + width, 0)}px`;
  referenceTable.style.setProperty("--first-column-width", `${widths[0]}px`);
  referenceTable.style.setProperty("--second-column-width", `${widths[1] || 0}px`);
  tableCount.textContent = rows.length === sourceRows.length
    ? `${sourceRows.length} rows`
    : `${rows.length} of ${sourceRows.length} rows`;
}

function appendFormattedText(element, text) {
  String(text).split(/(ft[23])/gi).forEach((part) => {
    if (/^ft[23]$/i.test(part)) {
      element.append("ft");
      const superscript = document.createElement("sup");
      superscript.textContent = part.slice(-1);
      element.appendChild(superscript);
    } else {
      element.append(part);
    }
  });
}

function ensureProjectTableRows(project, table) {
  if (!project) return table.rows;
  project.independentTables ||= {};
  project.independentTableSchemaVersions ||= {};
  let savedRows = project.independentTables[table.id];
  if (table.airsideSection) {
    const zoning = independentTables.find((candidate) => candidate.id === "calc-equipment-zoning");
    const zoningRows = zoning ? ensureProjectTableRows(project, zoning) : [];
    if (zoning) recalculateEquipmentZoning(zoning, zoningRows, project);
    let equipment = [];
    const seen = new Set();
    zoningRows.forEach((row) => [3, 4, 5, 6, 7, 8, 9, 10].forEach((column) => {
      const value = String(row[column] ?? "").trim();
      const key = value.toLowerCase();
      if (!value || value === "-" || seen.has(key)) return;
      seen.add(key); equipment.push(value);
    }));
    if (table.coilCalculation) {
      const settingsTable = independentTables.find((candidate) => candidate.id === "airside-settings");
      const settingsRows = settingsTable ? ensureProjectTableRows(project, settingsTable) : [];
      if (settingsTable) recalculateAirsideSettings(settingsTable, settingsRows, project);
      const settingsByEquipment = new Map(settingsRows.map((row) => [String(row[0] ?? "").toLowerCase(), row]));
      if (table.coilCalculation === "preheat") {
        equipment = equipment.filter((name) => String(settingsByEquipment.get(name.toLowerCase())?.[6] ?? "").toUpperCase() === "TRUE");
      } else if (table.coilCalculation === "cooling") {
        const central = new Set(zoningRows.map((row) => String(row[4] ?? "").toLowerCase()).filter(Boolean));
        const cooling = new Set(zoningRows.map((row) => String(row[7] ?? "").toLowerCase()).filter(Boolean));
        equipment = equipment.filter((name) => {
          const key = name.toLowerCase();
          const settingsRow = settingsByEquipment.get(key);
          return central.has(key) || cooling.has(key) || String(settingsRow?.[7] ?? "").toUpperCase() === "TRUE";
        });
      } else if (table.coilCalculation === "heating") {
        const heating = new Set(zoningRows.map((row) => String(row[8] ?? "").toLowerCase()).filter(Boolean));
        const reheat = new Set(zoningRows.map((row) => String(row[6] ?? "").toLowerCase()).filter(Boolean));
        equipment = equipment.filter((name) => {
          const key = name.toLowerCase();
          return heating.has(key) || reheat.has(key) || settingsByEquipment.get(key)?.[11] === "In Unit RHC";
        });
      }
    }
    const existing = new Map((Array.isArray(savedRows) ? savedRows : [])
      .filter((row) => row.length === table.columns.length)
      .map((row) => [String(row[0] ?? "").toLowerCase(), row]));
    table.sourceRowsLookup ||= new Map(Object.entries(table.sourceRows || {}).map(([key, row]) => [key.toLowerCase(), row]));
    const source = table.sourceRowsLookup;
    savedRows = equipment.map((name) => {
      const row = existing.get(name.toLowerCase()) || source.get(name.toLowerCase()) || Array(table.columns.length).fill("");
      const copy = [...row]; copy[0] = name; return copy;
    });
    project.independentTables[table.id] = savedRows;
    return savedRows;
  }
  if (table.schemaVersion && project.independentTableSchemaVersions[table.id] !== table.schemaVersion) {
    project.independentTables[table.id] = table.rows.map((row) => [...row]);
    project.independentTableSchemaVersions[table.id] = table.schemaVersion;
    savedRows = project.independentTables[table.id];
    saveProjects();
  }
  if (!Array.isArray(savedRows) && table.sourceTableId && Array.isArray(project.independentTables[table.sourceTableId])) {
    const sourceRows = project.independentTables[table.sourceTableId];
    if (sourceRows.every((row) => row.length >= Math.max(...table.sourceColumnIndexes) + 1)) {
      savedRows = sourceRows.map((row) => table.sourceColumnIndexes.map((index) => row[index]));
      project.independentTables[table.id] = savedRows;
      saveProjects();
    }
  }
  if (table.id === "schedule-equipment-sensible-gain" && project.independentTableSchemaVersions[table.id] !== 3) {
    if (Array.isArray(savedRows)) {
      project.independentTables[table.id] = savedRows.map((row) => {
        if (row.length === 6) return [row[0], row[1], row[2] ?? "", row[3] ?? "", "", row[4], row[5]];
        const kilowatts = row[2] !== "" && row[2] !== null && row[2] !== undefined
          ? numberFromTableValue(row[2]) / 1000
          : row[3] ?? "";
        return [row[0], row[1], kilowatts, row[4] ?? "", "", row[5], row[6]];
      });
    } else {
      project.independentTables[table.id] = table.rows.map((row) => [...row]);
    }
    project.independentTableSchemaVersions[table.id] = 3;
    savedRows = project.independentTables[table.id];
    saveProjects();
  }
  if (table.id === "iesve-tabular-space-data" && project.independentTableSchemaVersions[table.id] !== 2) {
    project.independentTables[table.id] = [];
    project.clipboardImports ||= {};
    delete project.clipboardImports[table.id];
    project.independentTableSchemaVersions[table.id] = 2;
    savedRows = project.independentTables[table.id];
    saveProjects();
  }
  if (table.id === "room-zone-loads-report" && project.independentTableSchemaVersions[table.id] !== 1) {
    project.independentTables[table.id] = [];
    project.excelImports ||= {};
    delete project.excelImports[table.id];
    project.independentTableSchemaVersions[table.id] = 1;
    savedRows = project.independentTables[table.id];
    saveProjects();
  }
  if (table.id === "calc-room-loads" && Array.isArray(savedRows)) {
    const typeBySpace = new Map(table.rows.map((row) => [String(row[0] ?? ""), row[1] ?? ""]));
    if (savedRows.some((row) => row.length === 14)) {
      savedRows = savedRows.map((row) => [row[0], typeBySpace.get(String(row[0] ?? "")) || "", ...row.slice(1)]);
    }
    if (savedRows.some((row) => row.length === 15)) {
      savedRows = savedRows.map((row) => [
        ...row.slice(0, 6), 0.1, row[6],
        ...row.slice(7, 11), 0.1, row[11],
        ...row.slice(12, 14), 0.1, row[14],
      ]);
    }
    savedRows.forEach((row) => {
      row[4] = String(row[4] ?? "").toUpperCase() === "TRUE" ? "TRUE" : "";
      row[10] = String(row[10] ?? "").toUpperCase() === "TRUE" ? "TRUE" : "";
    });
    project.independentTables[table.id] = savedRows;
  }
  if (table.id === "ashrae-90-1-baseline-systems" && Array.isArray(savedRows) && savedRows.some((row) => row.length === 7)) {
    project.independentTables[table.id] = savedRows.map((row) => row.length === 7 ? row.filter((_, index) => index !== 2) : row);
    saveProjects();
  } else if (!Array.isArray(savedRows) || savedRows.some((row) => row.length !== table.columns.length)) {
    project.independentTables[table.id] = table.rows.map((row) => [...row]);
    saveProjects();
  }
  return project.independentTables[table.id];
}

function projectTableRows(table) {
  return ensureProjectTableRows(activeProject(), table);
}

function ensureProjectTableHeaders(project, table) {
  if (!project) return table.headers;
  project.independentTableHeaders ||= {};
  let savedHeaders = project.independentTableHeaders[table.id];
  if (!Array.isArray(savedHeaders) && table.sourceTableId && Array.isArray(project.independentTableHeaders[table.sourceTableId])) {
    const sourceHeaders = project.independentTableHeaders[table.sourceTableId];
    if (sourceHeaders.length >= Math.max(...table.sourceColumnIndexes) + 1) {
      savedHeaders = table.sourceColumnIndexes.map((index) => ({ ...sourceHeaders[index] }));
      project.independentTableHeaders[table.id] = savedHeaders;
      saveProjects();
    }
  }
  if (table.id === "ashrae-90-1-baseline-systems" && Array.isArray(savedHeaders) && savedHeaders.length === 7) {
    project.independentTableHeaders[table.id] = savedHeaders.filter((_, index) => index !== 2);
    saveProjects();
  } else if (!Array.isArray(savedHeaders) || savedHeaders.length !== table.headers.length) {
    project.independentTableHeaders[table.id] = table.headers.map((header) => ({ ...header }));
    saveProjects();
  }
  return project.independentTableHeaders[table.id];
}

function projectTableHeaders(table) {
  return table.headers;
}

function displayedTableHeaders(table) {
  return projectTableHeaders(table);
}

function isPercentageColumn(table, columnIndex) {
  return table.headers[columnIndex]?.unit === "%";
}

function formatTableValue(value, table, columnIndex) {
  if (typeof value === "boolean") return value ? "TRUE" : "";
  if (typeof value === "number" && Number.isFinite(value) && table && Number.isInteger(columnIndex)) {
    if ((table.zeroDecimalColumns || []).includes(columnIndex)) {
      return isPercentageColumn(table, columnIndex)
        ? `${zeroDecimalFormatter.format(value * 100)}%`
        : zeroDecimalFormatter.format(value);
    }
    if ((table.oneDecimalColumns || []).includes(columnIndex)) return oneDecimalFormatter.format(value);
    if ((table.threeDecimalColumns || []).includes(columnIndex)) return threeDecimalFormatter.format(value);
    if ((table.fiveDecimalColumns || []).includes(columnIndex)) return fiveDecimalFormatter.format(value);
    if ((table.decimalColumns || []).includes(columnIndex)) return twoDecimalFormatter.format(value);
    if (isPercentageColumn(table, columnIndex)) return `${tableNumberFormatter.format(value * 100)}%`;
    if ([...(table.calculatedColumns || []), ...(table.lockedColumns || [])].includes(columnIndex)
      && String(table.headers[columnIndex]?.unit || "").startsWith("Btu/h")) {
      return calculatedBtuNumberFormatter.format(value);
    }
  }
  return typeof value === "number" && Number.isFinite(value) ? tableNumberFormatter.format(value) : value ?? "";
}

function normalizedTableInput(table, columnIndex, rawValue) {
  const value = String(rawValue ?? "").trim();
  const percentage = isPercentageColumn(table, columnIndex);
  const normalizedNumber = value.replace(/,/g, "").replace(/\s*%$/, "");
  return table.columnTypes[columnIndex] === "number" && normalizedNumber !== "" && Number.isFinite(Number(normalizedNumber))
    ? Number(normalizedNumber) / (percentage ? 100 : 1)
    : value;
}

function updateTableCell(table, rows, rowIndex, columnIndex, rawValue) {
  const value = String(rawValue ?? "").trim();
  recordZoningOverride(table, rows[rowIndex], columnIndex, value, activeProject());
  recordAirsideOverride(table, rows[rowIndex], columnIndex, value, activeProject());
  recordCoilOverride(table, rows[rowIndex], columnIndex, value, activeProject());
  recordSpaceLoadFactorOverride(table, rows[rowIndex], columnIndex, value, activeProject());
  rows[rowIndex][columnIndex] = normalizedTableInput(table, columnIndex, value);
  recalculateSpecialTableRow(table, rows[rowIndex]);
  recalculateTable(table, rows);
  recalculateDependentTables(table);
  saveProjects();
  if (table.conditionalCalculatedColumns || table.equipmentZoningCalculation || table.roomLoadCalculation || table.airsideSettingsCalculation || table.coilCalculation) renderReferenceTable(table.id, tableSearch.value);
  else {
    refreshRenderedTableValues(table, rows);
    refreshTableSummary(table, rows);
  }
  updateCsvComparisonDecorations(table, rows);
  if (selectedCsvComparisonContext?.tableId === table.id) {
    const { rowIndex: selectedRow, columnIndex: selectedColumn } = selectedCsvComparisonContext;
    showCsvComparison(table, rows, selectedRow, selectedColumn);
  }
}

function refreshTableSummary(table, rows) {
  const summaryRow = referenceTable.querySelector("tfoot .table-summary-row");
  if (!summaryRow) return;
  (table.summaryColumns || []).forEach((columnIndex) => {
    const aggregation = table.summaryAggregations?.[columnIndex] || "sum";
    const total = aggregation === "count"
      ? rows.filter((row) => row[columnIndex] !== "" && row[columnIndex] !== null && row[columnIndex] !== undefined).length
      : aggregation === "unique-count"
        ? new Set(rows.map((row) => String(row[columnIndex] ?? "").trim()).filter(Boolean)).size
      : rows.reduce((sum, row) => sum + (Number(row[columnIndex]) || 0), 0);
    const cell = summaryRow.cells[columnIndex];
    if (cell) cell.textContent = columnIndex === 0 && aggregation === "unique-count" ? `Total: ${total}` : formatTableValue(total, table, columnIndex);
  });
}

function refreshRenderedTableValues(table, rows) {
  referenceTable.querySelectorAll("tbody tr").forEach((tableRow) => {
    const row = rows[Number(tableRow.dataset.sourceIndex)];
    if (!row) return;
    table.headers.forEach((_, columnIndex) => {
      if (!(table.calculatedColumns || []).includes(columnIndex) && !isPercentageColumn(table, columnIndex)) return;
      const cell = tableRow.cells[columnIndex];
      if (!cell) return;
      cell.textContent = formatTableValue(row[columnIndex], table, columnIndex);
      cell.classList.toggle("numeric-cell", typeof row[columnIndex] === "number");
    });
  });
  autoFitRenderedTable(table, displayedTableHeaders(table), rows);
}

function csvImportKey(table) {
  return `${activeProject()?.id || "default"}::${table.id}`;
}

function csvImportState(table) {
  if (!table?.csvHeaders) return null;
  const key = csvImportKey(table);
  if (csvImportsByProject.has(key)) return csvImportsByProject.get(key);
  const saved = activeProject()?.clipboardImports?.[table.id];
  if (!saved || !Array.isArray(saved.sourceRows) || !Array.isArray(saved.mappedColumns) || !saved.importedAt || !saved.templateType) return null;
  const state = {
    importedAt: saved.importedAt,
    mappedColumns: saved.mappedColumns,
    sourceRows: saved.sourceRows,
    templateType: saved.templateType,
  };
  csvImportsByProject.set(key, state);
  return state;
}

function excelImportState(table) {
  if (!table?.excelImport) return null;
  const key = csvImportKey(table);
  if (excelImportsByProject.has(key)) return excelImportsByProject.get(key);
  const saved = activeProject()?.excelImports?.[table.id];
  if (!saved?.importedAt || !saved?.fileName) return null;
  const state = {
    importedAt: saved.importedAt,
    fileName: saved.fileName,
    simulationRunAt: saved.simulationRunAt || "",
    simulationRunPrecision: saved.simulationRunPrecision || "time",
  };
  excelImportsByProject.set(key, state);
  return state;
}

function setCsvFileStatus(message, isError = false) {
  csvFileStatus.textContent = message;
  csvFileStatus.title = message;
  csvFileStatus.classList.toggle("is-error", isError);
}

function updateCsvToolbar(table) {
  const supportsCsv = Array.isArray(table.csvHeaders);
  const supportsExcel = Boolean(table.excelImport);
  templateStatus.classList.toggle("simulation-status", supportsExcel);
  clipboardActions.hidden = !supportsCsv;
  excelActions.hidden = !supportsExcel;
  rowActions.hidden = supportsCsv || supportsExcel || table.fixedRows;
  csvFileStatus.hidden = !supportsCsv && !supportsExcel;
  templateStatus.hidden = !supportsCsv && !supportsExcel;
  editableKey.hidden = supportsCsv || supportsExcel;
  autoKey.hidden = !table.equipmentZoningCalculation && !table.roomLoadCalculation && !table.airsideSettingsCalculation && !table.coilCalculation;
  matchKey.hidden = !supportsCsv;
  differentKey.hidden = !supportsCsv;
  editableKey.lastChild.textContent = table.equipmentZoningCalculation || table.roomLoadCalculation || table.airsideSettingsCalculation || table.coilCalculation ? "Override" : "Editable";
  calculatedKey.lastChild.textContent = table.equipmentZoningCalculation ? "Locked" : supportsCsv ? "Not in source" : supportsExcel ? "Imported" : "Calculated";
  if (!supportsCsv && !supportsExcel) {
    copyDataButton.disabled = true;
    setCsvFileStatus("");
    templateStatus.textContent = "";
    return;
  }
  if (supportsExcel) {
    copyDataButton.disabled = true;
    const state = excelImportState(table);
    const importedAt = state ? new Date(state.importedAt) : null;
    const dateText = importedAt && Number.isFinite(importedAt.getTime())
      ? new Intl.DateTimeFormat(undefined, { dateStyle: "medium", timeStyle: "short" }).format(importedAt)
      : "";
    setCsvFileStatus(state ? `Last upload: ${dateText}` : "No Excel imported");
    const simulationRunAt = state?.simulationRunAt ? new Date(state.simulationRunAt) : null;
    const simulationText = simulationRunAt && Number.isFinite(simulationRunAt.getTime())
      ? new Intl.DateTimeFormat(undefined, state.simulationRunPrecision === "date"
        ? { dateStyle: "medium" }
        : { dateStyle: "medium", timeStyle: "short" }).format(simulationRunAt)
      : "";
    templateStatus.textContent = state ? `Simulation run: ${simulationText || "Not available"}` : "";
    templateStatus.title = state?.fileName || "";
    templateStatus.hidden = !state;
    return;
  }
  const state = csvImportState(table);
  copyDataButton.disabled = !state || !projectTableRows(table).length;
  const importedAt = state ? new Date(state.importedAt) : null;
  const dateText = importedAt && Number.isFinite(importedAt.getTime())
    ? new Intl.DateTimeFormat(undefined, { dateStyle: "medium", timeStyle: "short" }).format(importedAt)
    : "";
  setCsvFileStatus(state ? `Last upload: ${dateText}` : "No data pasted");
  templateStatus.textContent = state ? `${state.templateType} Template` : "";
  templateStatus.hidden = !state;
}

function clearCsvComparison() {
  selectedCsvComparisonContext = null;
  csvComparisonBar.hidden = true;
  csvComparisonBar.classList.remove("is-different", "is-unmapped");
  csvComparisonColumn.textContent = "";
  csvComparisonValue.textContent = "";
  csvComparisonStatus.textContent = "";
}

function tableValueForCsv(table, value, columnIndex) {
  if (isPercentageColumn(table, columnIndex) && typeof value === "number") return value * 100;
  return value ?? "";
}

function csvValuesMatch(table, tableValue, csvValue, columnIndex) {
  const current = tableValueForCsv(table, tableValue, columnIndex);
  const left = String(current ?? "").trim();
  const right = String(csvValue ?? "").trim();
  const leftNumber = Number(left.replace(/,/g, ""));
  const rightNumber = Number(right.replace(/,/g, ""));
  if (left !== "" && right !== "" && Number.isFinite(leftNumber) && Number.isFinite(rightNumber)) {
    return Math.abs(leftNumber - rightNumber) <= 0.001;
  }
  return left.localeCompare(right, undefined, { sensitivity: "base" }) === 0;
}

function csvComparisonForCell(table, row, sourceIndex, columnIndex) {
  const state = csvImportState(table);
  if (!state) return null;
  if (!state.mappedColumns[columnIndex]) {
    return { mapped: false, matches: false, csvValue: "" };
  }
  const csvRow = state.sourceRows[sourceIndex];
  const csvValue = csvRow?.[columnIndex] ?? "";
  return {
    mapped: true,
    linked: Boolean(csvRow),
    matches: Boolean(csvRow) && csvValuesMatch(table, row[columnIndex], csvValue, columnIndex),
    csvValue,
  };
}

function decorateCsvComparisonCell(table, cell, row, sourceIndex, columnIndex) {
  cell.classList.remove("csv-match", "csv-different");
  if (table.id === "iesve-tabular-space-data" && columnIndex < 2) return;
  const comparison = csvComparisonForCell(table, row, sourceIndex, columnIndex);
  if (!comparison?.mapped) return;
  cell.classList.add(comparison.matches ? "csv-match" : "csv-different");
}

function markSelectedTableCell(cell) {
  referenceTable.querySelectorAll(".table-cell-selected").forEach((candidate) => {
    candidate.classList.remove("table-cell-selected");
    candidate.removeAttribute("aria-current");
  });
  cell.classList.add("table-cell-selected");
  cell.setAttribute("aria-current", "true");
}

function decorateRoomValidationCell(table, cell, value, columnIndex) {
  if (table.id !== "room-zone-loads-report" || columnIndex !== 2) return;
  const tabularTable = independentTables.find((candidate) => candidate.id === "iesve-tabular-space-data");
  const tabularRows = tabularTable ? projectTableRows(tabularTable) : [];
  const room = String(value ?? "").trim();
  const exists = tabularRows.some((row) => String(row[1] ?? "").trim().localeCompare(room, undefined, { sensitivity: "base" }) === 0);
  if (exists) return;
  cell.classList.add("room-not-in-tabular");
  cell.title = "Room not in Tabular Space Data";
  cell.setAttribute("aria-label", `${cell.getAttribute("aria-label")}. Room not in Tabular Space Data`);
}

function updateCsvComparisonDecorations(table, rows) {
  if (!table.csvHeaders) return;
  referenceTable.querySelectorAll("tbody tr").forEach((tableRow) => {
    const sourceIndex = Number(tableRow.dataset.sourceIndex);
    const row = rows[sourceIndex];
    if (!row) return;
    [...tableRow.cells].forEach((cell, columnIndex) => {
      decorateCsvComparisonCell(table, cell, row, sourceIndex, columnIndex);
    });
  });
}

function showCsvComparison(table, rows, sourceIndex, columnIndex) {
  const state = csvImportState(table);
  if (!state) {
    clearCsvComparison();
    return;
  }
  const row = rows[sourceIndex];
  if (!row) return;
  selectedCsvComparisonContext = { tableId: table.id, rowIndex: sourceIndex, columnIndex };
  const header = table.headers[columnIndex];
  csvComparisonColumn.textContent = `${header.label}${header.unit ? ` (${header.unit})` : ""}`;
  const comparison = csvComparisonForCell(table, row, sourceIndex, columnIndex);
  csvComparisonBar.hidden = false;
  csvComparisonBar.classList.toggle("is-unmapped", !comparison?.mapped);
  csvComparisonBar.classList.toggle("is-different", Boolean(comparison?.mapped && !comparison.matches));
  if (!comparison?.mapped) {
    csvComparisonValue.textContent = "Not included in the pasted source data";
    csvComparisonStatus.textContent = "Not in source";
  } else {
    csvComparisonValue.textContent = comparison.linked
      ? (String(comparison.csvValue) || "(blank)")
      : "No source row";
    csvComparisonStatus.textContent = comparison.matches ? "Matches source" : "Differs from source";
  }
}

function csvHeaderForTemplate(header, templateType) {
  if (!header || header === "Space ID") return header;
  return header.replace(/ \(Real\)$/, ` (${templateType})`);
}

function detectTemplateType(headers) {
  if (CsvTools.normalizeHeader(headers[0]) !== "space id") {
    throw new Error("The first pasted column must be Space ID.");
  }
  const spaceName = String(headers[1] ?? "").trim();
  const match = spaceName.match(/^Space Name \((Real|Proposed|Baseline)\)$/i);
  if (!match) throw new Error("The second pasted column must be Space Name (Real), Space Name (Proposed), or Space Name (Baseline).");
  const templateType = match[1][0].toUpperCase() + match[1].slice(1).toLowerCase();
  const suffix = ` (${templateType})`.toLowerCase();
  const invalidHeader = headers.slice(1).find((header) => {
    const value = String(header ?? "").trim();
    return value !== "" && !value.toLowerCase().endsWith(suffix);
  });
  if (invalidHeader !== undefined) {
    throw new Error(`Every pasted header after Space ID must end with (${templateType}). Check: ${invalidHeader}`);
  }
  return templateType;
}

function csvColumnMap(table, headers, templateType) {
  const headerIndexes = new Map();
  headers.forEach((header, index) => {
    const normalized = CsvTools.normalizeHeader(header);
    if (normalized && !headerIndexes.has(normalized)) headerIndexes.set(normalized, index);
  });
  return table.csvHeaders.map((header) => header === null
    ? -1
    : (headerIndexes.get(CsvTools.normalizeHeader(csvHeaderForTemplate(header, templateType))) ?? -1));
}

function saveClipboardImport(table, state) {
  const project = activeProject();
  if (!project) return;
  project.clipboardImports ||= {};
  project.clipboardImports[table.id] = {
    importedAt: state.importedAt,
    mappedColumns: state.mappedColumns,
    sourceRows: state.sourceRows,
    templateType: state.templateType,
  };
  saveProjects();
}

function calculationSpaceTables() {
  return independentTables.filter((table) => table.id.startsWith("calc-") && Number.isInteger(table.spaceColumn));
}

function blankCalculationRow(table, space) {
  const source = table.rows.find((row) => String(row[table.spaceColumn] ?? "") === space);
  const row = source ? [...source] : Array(table.columns.length).fill("");
  row[table.spaceColumn] = space;
  return row;
}

function moveSpaceMetadata(table, oldSpace, newSpace) {
  ["activityBySpace", "volumeBySpace"].forEach((property) => {
    if (!table[property] || !Object.hasOwn(table[property], oldSpace)) return;
    table[property][newSpace] = table[property][oldSpace];
    delete table[property][oldSpace];
  });
}

function setInitialCalculationSpaces(spaces) {
  const project = activeProject();
  calculationSpaceTables().forEach((table) => {
    const rows = ensureProjectTableRows(project, table);
    const existing = new Map(rows.map((row) => [String(row[table.spaceColumn] ?? ""), row]));
    project.independentTables[table.id] = spaces.map((space) => existing.has(space) ? [...existing.get(space)] : blankCalculationRow(table, space));
  });
  calculationSpaceTables().forEach((table) => recalculateTable(table, project.independentTables[table.id], project));
}

function remapProjectSpaceKeys(project, oldSpace, newSpace = "") {
  const remap = (record) => {
    if (!record) return;
    Object.keys(record).forEach((key) => {
      if (!key.startsWith(`${oldSpace}::`)) return;
      if (newSpace) record[`${newSpace}${key.slice(oldSpace.length)}`] = record[key];
      delete record[key];
    });
  };
  Object.values(project.zoningOverrides || {}).forEach(remap);
  Object.values(project.zoningAutoValues || {}).forEach(remap);
  remap(project.spaceLoadFactorOverrides);
  remap(project.spaceLoadFactorAutos);
}

function applyCalculationSpaceChanges(newSpaces, oldSpaces) {
  const project = activeProject();
  calculationSpaceTables().forEach((table) => {
    let rows = ensureProjectTableRows(project, table);
    const pairCount = Math.min(newSpaces.length, oldSpaces.length);
    for (let index = 0; index < pairCount; index += 1) {
      const oldSpace = oldSpaces[index];
      const newSpace = newSpaces[index];
      const row = rows.find((candidate) => String(candidate[table.spaceColumn] ?? "") === oldSpace);
      if (row) row[table.spaceColumn] = newSpace;
      else rows.push(blankCalculationRow(table, newSpace));
      moveSpaceMetadata(table, oldSpace, newSpace);
    }
    newSpaces.slice(pairCount).forEach((space) => rows.push(blankCalculationRow(table, space)));
    const removed = new Set(oldSpaces.slice(pairCount));
    if (removed.size) rows = rows.filter((row) => !removed.has(String(row[table.spaceColumn] ?? "")));
    project.independentTables[table.id] = rows;
  });
  const pairCount = Math.min(newSpaces.length, oldSpaces.length);
  for (let index = 0; index < pairCount; index += 1) remapProjectSpaceKeys(project, oldSpaces[index], newSpaces[index]);
  oldSpaces.slice(pairCount).forEach((space) => remapProjectSpaceKeys(project, space));
  calculationSpaceTables().forEach((table) => recalculateTable(table, project.independentTables[table.id], project));
}

function commitTabularImport(table, importedRows, state) {
  const rows = projectTableRows(table);
  rows.splice(0, rows.length, ...importedRows);
  csvImportsByProject.set(csvImportKey(table), state);
  saveClipboardImport(table, state);
  selectedTableId = "";
  selectedTableRowIndexes.clear();
  selectionAnchorIndex = -1;
  tableSearch.value = "";
  tableSort = { tableId: table.id, column: -1, direction: "asc" };
  renderReferenceTable(table.id);
}

function renderSpaceReconciliation() {
  if (!pendingSpaceReconciliation) return;
  const { newSpaces, oldSpaces } = pendingSpaceReconciliation;
  const renderList = (container, values, side) => {
    container.innerHTML = "";
    values.forEach((value, index) => {
      const row = document.createElement("div"); row.className = "space-change-row";
      const label = document.createElement("span"); label.textContent = value; label.title = value;
      const controls = document.createElement("span"); controls.className = "space-change-controls";
      [["↑", -1], ["↓", 1]].forEach(([symbol, direction]) => {
        const button = document.createElement("button"); button.type = "button"; button.textContent = symbol;
        button.title = `${direction < 0 ? "Move up" : "Move down"} ${value}`;
        button.disabled = direction < 0 ? index === 0 : index === values.length - 1;
        button.addEventListener("click", () => {
          const nextIndex = index + direction;
          [values[index], values[nextIndex]] = [values[nextIndex], values[index]];
          renderSpaceReconciliation();
        });
        controls.appendChild(button);
      });
      row.append(label, controls); container.appendChild(row);
    });
  };
  renderList(newSpaceList, newSpaces, "new");
  renderList(oldSpaceList, oldSpaces, "old");
  spaceActionList.innerHTML = "";
  const count = Math.max(newSpaces.length, oldSpaces.length);
  for (let index = 0; index < count; index += 1) {
    const action = newSpaces[index] && oldSpaces[index] ? "REPLACE" : newSpaces[index] ? "ADD" : "REMOVE";
    const row = document.createElement("div"); row.className = `space-action-row ${action.toLowerCase()}`;
    row.textContent = action === "REPLACE" ? "← REPLACE" : action === "ADD" ? "+ ADD" : "− REMOVE";
    spaceActionList.appendChild(row);
  }
}

function openSpaceReconciliation(payload) {
  pendingSpaceReconciliation = payload;
  spaceReconcileError.textContent = "";
  renderSpaceReconciliation();
  spaceReconcileDialog.showModal();
}

function pasteTabularData(text) {
  const table = independentTables.find((candidate) => candidate.id === activeTableId);
  if (!table?.csvHeaders) return;
  const grid = CsvTools.parseClipboard(text);
  const headerRowIndex = grid.findIndex((row) => CsvTools.normalizeHeader(row[0]) === "space id");
  if (headerRowIndex < 0) throw new Error("The pasted header row must begin with Space ID and Space Name.");
  const headers = grid[headerRowIndex];
  const templateType = detectTemplateType(headers);
  const columnMap = csvColumnMap(table, headers, templateType);
  if (columnMap[0] < 0 || columnMap[1] < 0) throw new Error("Space ID or Space Name is missing from the pasted data.");

  const pastedRows = grid.slice(headerRowIndex + 1)
    .filter((row) => row.some((value) => String(value ?? "").trim() !== ""))
    .map((row) => Array.from({ length: headers.length }, (_, index) => row[index] ?? ""))
    .filter((row) => row[columnMap[0]].trim() !== "" || row[columnMap[1]].trim() !== "");
  if (!pastedRows.length) throw new Error("The pasted data does not contain any space rows.");

  const previousImport = csvImportState(table);
  const rows = projectTableRows(table);
  const existingBySpaceId = new Map(rows.map((row) => [String(row[0] ?? "").trim().toLowerCase(), row]));
  const sourceRows = pastedRows.map((pastedRow) => table.csvHeaders.map((header, columnIndex) => {
    const pastedColumnIndex = columnMap[columnIndex];
    return header && pastedColumnIndex >= 0 ? pastedRow[pastedColumnIndex] : null;
  }));
  const importedRows = sourceRows.map((sourceRow) => {
    const spaceId = String(sourceRow[0] ?? "").trim();
    const existing = existingBySpaceId.get(spaceId.toLowerCase());
    const row = existing ? [...existing] : Array(table.columns.length).fill("");
    row[0] = spaceId;
    row[1] = String(sourceRow[1] ?? "").trim();
    return row;
  });
  const state = {
    importedAt: new Date().toISOString(),
    mappedColumns: columnMap.map((columnIndex) => columnIndex >= 0),
    sourceRows,
    templateType,
  };
  const nextSpaces = [...new Set(importedRows.map((row) => String(row[1] ?? "").trim()).filter(Boolean))];
  if (!previousImport) {
    setInitialCalculationSpaces(nextSpaces);
    commitTabularImport(table, importedRows, state);
    return;
  }
  const currentSpaces = [...new Set(calculationSpaceTables()[0]
    ? ensureProjectTableRows(activeProject(), calculationSpaceTables()[0]).map((row) => String(row[calculationSpaceTables()[0].spaceColumn] ?? "").trim()).filter(Boolean)
    : [])];
  const currentSet = new Set(currentSpaces);
  const nextSet = new Set(nextSpaces);
  const newSpaces = nextSpaces.filter((space) => !currentSet.has(space));
  const oldSpaces = currentSpaces.filter((space) => !nextSet.has(space));
  if (newSpaces.length || oldSpaces.length) {
    openSpaceReconciliation({ table, importedRows, state, newSpaces, oldSpaces });
    return;
  }
  commitTabularImport(table, importedRows, state);
}

async function pasteDataFromClipboard() {
  pasteDataButton.disabled = true;
  try {
    if (!navigator.clipboard?.readText || !window.isSecureContext) {
      throw new Error("Direct clipboard access is unavailable. Press Ctrl+V while this table is open.");
    }
    const text = await navigator.clipboard.readText();
    if (!text.trim()) throw new Error("The clipboard does not contain text data.");
    pasteTabularData(text);
  } catch (error) {
    setCsvFileStatus(error.message || "The clipboard data could not be used.", true);
  } finally {
    pasteDataButton.disabled = false;
  }
}

async function writeClipboardText(text) {
  if (navigator.clipboard?.writeText && window.isSecureContext) {
    await navigator.clipboard.writeText(text);
    return;
  }
  const helper = document.createElement("textarea");
  helper.value = text;
  helper.setAttribute("readonly", "");
  helper.style.position = "fixed";
  helper.style.opacity = "0";
  document.body.appendChild(helper);
  helper.select();
  const copied = document.execCommand("copy");
  helper.remove();
  if (!copied) throw new Error("Clipboard access was blocked by the browser.");
}

async function copyTabularData() {
  const table = independentTables.find((candidate) => candidate.id === activeTableId);
  const state = csvImportState(table);
  if (!table?.csvHeaders || !state) return;
  const rows = projectTableRows(table);
  const headers = table.csvHeaders.map((header) => csvHeaderForTemplate(header, state.templateType));
  const values = rows.map((row) => table.headers.map((_, columnIndex) => formatTableValue(row[columnIndex], table, columnIndex)));
  copyDataButton.disabled = true;
  try {
    await writeClipboardText(CsvTools.stringifyClipboard([headers, ...values]));
    copyDataButton.textContent = "Copied to clipboard";
    setTimeout(() => {
      copyDataButton.textContent = "Copy data to clipboard...";
      copyDataButton.disabled = false;
    }, 1200);
  } catch (error) {
    setCsvFileStatus(error.message || "The table could not be copied.", true);
    copyDataButton.disabled = false;
    setTimeout(() => updateCsvToolbar(table), 2500);
  }
}

function normalizedLoadHeader(value) {
  return String(value ?? "").replace(/\s+/g, " ").trim().toLowerCase();
}

function findRoomZoneLoadSheet(workbook) {
  for (const sheet of workbook.sheets) {
    let columns = null;
    const headerRowIndex = sheet.rows.findIndex((row, index) => {
      if (index > 30 || !row) return false;
      const zoneGroup = row.findIndex((value) => normalizedLoadHeader(value) === "zone group");
      const sensibleHeader = row.findIndex((value) => normalizedLoadHeader(value).includes("sensible cooling load"));
      const latent = row.findIndex((value) => normalizedLoadHeader(value).includes("latent cooling load"));
      const heating = row.findIndex((value) => normalizedLoadHeader(value).includes("heating load"));
      if (zoneGroup < 0 || sensibleHeader < 0 || latent < 0 || heating < 0) return false;
      if (normalizedLoadHeader(row[zoneGroup + 1]) !== "zone" || normalizedLoadHeader(row[zoneGroup + 2]) !== "room") return false;
      columns = {
        zoneGroup,
        zone: zoneGroup + 1,
        room: zoneGroup + 2,
        sensible: sensibleHeader + 1,
        latent,
        heating,
      };
      return true;
    });
    if (headerRowIndex >= 0) return { sheet, headerRowIndex, columns };
  }
  throw new Error("The workbook does not contain the expected Room/Zone Loads Report headers.");
}

function loadNumber(value, rowNumber, label) {
  if (value === "" || value === null || value === undefined) return "";
  if (typeof value === "number" && Number.isFinite(value)) return value;
  const number = Number(String(value).replace(/,/g, "").trim());
  if (!Number.isFinite(number)) throw new Error(`${label} is not numeric on Excel row ${rowNumber}.`);
  return number;
}

function roomZoneRowsFromWorkbook(workbook) {
  const { sheet, headerRowIndex, columns } = findRoomZoneLoadSheet(workbook);
  let zoneGroup = "";
  let zone = "";
  const rows = [];
  sheet.rows.slice(headerRowIndex + 2).forEach((sourceRow, offset) => {
    if (!sourceRow) return;
    const sourceGroup = String(sourceRow[columns.zoneGroup] ?? "").trim();
    const sourceZone = String(sourceRow[columns.zone] ?? "").trim();
    const room = String(sourceRow[columns.room] ?? "").trim();
    if (sourceGroup) zoneGroup = sourceGroup;
    if (sourceZone) zone = sourceZone;
    if (!room) return;
    const excelRow = headerRowIndex + 3 + offset;
    rows.push([
      zoneGroup,
      zone,
      room,
      loadNumber(sourceRow[columns.sensible], excelRow, "Sensible cooling load"),
      loadNumber(sourceRow[columns.latent], excelRow, "Latent cooling load"),
      loadNumber(sourceRow[columns.heating], excelRow, "Heating load"),
    ]);
  });
  if (!rows.length) throw new Error("The Room/Zone Loads Report does not contain any room rows beginning at row 10.");
  return rows;
}

async function importRoomZoneLoads(file) {
  const table = independentTables.find((candidate) => candidate.id === activeTableId);
  if (!table?.excelImport || !file) return;
  if (!/\.(xlsx|xlsm)$/i.test(file.name)) {
    setCsvFileStatus("Select an .xlsx or .xlsm Excel workbook.", true);
    importExcelInput.value = "";
    return;
  }
  importExcelButton.disabled = true;
  setCsvFileStatus("Importing Excel workbook...");
  try {
    const workbook = await XlsxReader.read(await file.arrayBuffer(), {
      sheetNamePattern: /ies loads|room.*zone.*loads|loads report/i,
    });
    const { simulationRunAt, simulationRunPrecision } = simulationRunTimeFromWorkbook(workbook, file);
    const importedRows = roomZoneRowsFromWorkbook(workbook);
    const rows = projectTableRows(table);
    rows.splice(0, rows.length, ...importedRows);
    const state = { importedAt: new Date().toISOString(), fileName: file.name, simulationRunAt, simulationRunPrecision };
    excelImportsByProject.set(csvImportKey(table), state);
    const project = activeProject();
    project.excelImports ||= {};
    project.excelImports[table.id] = state;
    selectedTableId = "";
    selectedTableRowIndexes.clear();
    selectionAnchorIndex = -1;
    tableSearch.value = "";
    tableSort = { tableId: table.id, column: -1, direction: "asc" };
    saveProjects();
    renderReferenceTable(table.id);
  } catch (error) {
    setCsvFileStatus(error.message || "The Excel workbook could not be imported.", true);
  } finally {
    importExcelButton.disabled = false;
    importExcelInput.value = "";
  }
}

function simulationRunTimeFromFile(file) {
  const relativePath = String(file.webkitRelativePath || "");
  const nativePath = String(file.path || "").replace(/\\/g, "/");
  const parentFolders = [relativePath, nativePath]
    .map((path) => path.split("/").filter(Boolean).slice(-2, -1)[0] || "")
    .filter(Boolean);
  const fileStem = String(file.name || "").replace(/\.(xlsx|xlsm)$/i, "");
  const match = [...parentFolders, fileStem]
    .map((value) => value.match(/(\d{8})[ _-](\d{6})$/))
    .find(Boolean);
  if (!match) return "";
  const [, date, time] = match;
  const year = Number(date.slice(0, 4));
  const month = Number(date.slice(4, 6));
  const day = Number(date.slice(6, 8));
  const hour = Number(time.slice(0, 2));
  const minute = Number(time.slice(2, 4));
  const second = Number(time.slice(4, 6));
  const value = new Date(year, month - 1, day, hour, minute, second);
  if (value.getFullYear() !== year || value.getMonth() !== month - 1 || value.getDate() !== day
    || value.getHours() !== hour || value.getMinutes() !== minute || value.getSeconds() !== second) {
    throw new Error("The simulation timestamp in the report folder name is not a valid date and time.");
  }
  return value.toISOString();
}

function simulationRunTimeFromWorkbook(workbook, file) {
  const createdAt = new Date(workbook.createdAt || "");
  if (Number.isFinite(createdAt.getTime())) {
    return { simulationRunAt: createdAt.toISOString(), simulationRunPrecision: "time" };
  }
  const reportDate = workbook.sheets?.[0]?.rows?.[3]?.[1];
  const dateMatch = String(reportDate || "").match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (dateMatch) {
    const value = new Date(Number(dateMatch[1]), Number(dateMatch[2]) - 1, Number(dateMatch[3]));
    return { simulationRunAt: value.toISOString(), simulationRunPrecision: "date" };
  }
  const fromPath = simulationRunTimeFromFile(file);
  return { simulationRunAt: fromPath, simulationRunPrecision: fromPath ? "time" : "date" };
}

function tableDropdownOptions(table, columnIndex) {
  const config = table.dropdownColumns?.[columnIndex];
  if (!config) return [];
  if (Array.isArray(config.options)) return config.options.map(String);
  const sources = config.sources || [config];
  return [...new Set(sources.flatMap((source) => {
    const sourceTable = independentTables.find((candidate) => candidate.id === source.sourceTableId);
    return sourceTable ? projectTableRows(sourceTable).map((row) => row[source.sourceColumn]) : [];
  })
    .filter((value) => value !== null && value !== undefined && value !== "")
    .map(String))];
}

function tableEquations(table) {
  return { ...(table.equations || {}), ...(equationOverrides[table.id] || {}) };
}

function equationColumnIndex(table, name) {
  const normalize = (value) => String(value || "").replace(/^@/, "").replace(/[^A-Za-z0-9]+/g, "").toLowerCase();
  const normalized = normalize(name);
  let index = table.headers.findIndex((header) => normalize(`${header.label || ""}${header.unit || ""}`) === normalized);
  if (index < 0) index = table.headers.findIndex((header) => normalize(header.label) === normalized);
  if (index < 0) index = (table.columns || []).findIndex((column) => normalize(column) === normalized);
  return index;
}

function tokenizeEquation(expression) {
  const source = String(expression || "").trim().replace(/^=/, "");
  const tokens = [];
  let index = 0;
  while (index < source.length) {
    const character = source[index];
    if (/\s/.test(character)) { index += 1; continue; }
    if (character === "@") {
      const reference = source.slice(index + 1).match(/^[A-Za-z_][A-Za-z0-9_]*/);
      if (!reference) throw new Error("Enter a column reference after @");
      tokens.push({ type: "reference", value: reference[0] });
      index += reference[0].length + 1;
      continue;
    }
    if (character === '"') {
      let value = "";
      index += 1;
      while (index < source.length && source[index] !== '"') value += source[index++];
      if (source[index] !== '"') throw new Error("Missing closing quote");
      tokens.push({ type: "string", value });
      index += 1;
      continue;
    }
    const number = source.slice(index).match(/^(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?/i);
    if (number) {
      tokens.push({ type: "number", value: Number(number[0]) });
      index += number[0].length;
      continue;
    }
    const identifier = source.slice(index).match(/^[A-Za-z_][A-Za-z0-9_]*/);
    if (identifier) {
      tokens.push({ type: "identifier", value: identifier[0].toUpperCase() });
      index += identifier[0].length;
      continue;
    }
    const pair = source.slice(index, index + 2);
    if ([">=", "<=", "<>", "!=", "=="].includes(pair)) {
      tokens.push({ type: "operator", value: pair });
      index += 2;
      continue;
    }
    if ("+-*/&=><(),".includes(character)) {
      tokens.push({ type: ["(", ")", ","].includes(character) ? character : "operator", value: character });
      index += 1;
      continue;
    }
    throw new Error(`Unsupported character: ${character}`);
  }
  tokens.push({ type: "end", value: "" });
  return tokens;
}

function evaluateEquation(expression, table, row) {
  const tokens = tokenizeEquation(expression);
  let position = 0;
  const current = () => tokens[position];
  const take = (type) => {
    if (current().type !== type) throw new Error(`Expected ${type}`);
    return tokens[position++];
  };
  const numeric = (value) => numberFromTableValue(value);
  const functions = {
    IF: (condition, yes, no) => condition ? yes : no,
    N: numeric,
    ROUND: (value, digits = 0) => {
      const factor = 10 ** numeric(digits);
      return Math.round(numeric(value) * factor) / factor;
    },
    MIN: (...values) => Math.min(...values.map(numeric)),
    MAX: (...values) => Math.max(...values.map(numeric)),
    ABS: (value) => Math.abs(numeric(value)),
    LOOKUP: (value) => value === "" || value === null || value === undefined ? "" : table.lookup?.[String(value)] ?? 0,
  };

  function primary() {
    const token = current();
    if (token.type === "number" || token.type === "string") { position += 1; return token.value; }
    if (token.type === "reference") {
      position += 1;
      const column = equationColumnIndex(table, token.value);
      if (column < 0) throw new Error(`Unknown column @${token.value}`);
      return row[column];
    }
    if (token.type === "identifier") {
      position += 1;
      if (token.value === "TRUE") return true;
      if (token.value === "FALSE") return false;
      const fn = functions[token.value];
      if (!fn) throw new Error(`Unsupported function ${token.value}`);
      take("(");
      const args = [];
      if (current().type !== ")") {
        args.push(comparison());
        while (current().type === ",") { position += 1; args.push(comparison()); }
      }
      take(")");
      return fn(...args);
    }
    if (token.type === "(") {
      position += 1;
      const value = comparison();
      take(")");
      return value;
    }
    throw new Error("Expected a value");
  }

  function unary() {
    if (current().type === "operator" && ["+", "-"].includes(current().value)) {
      const operator = tokens[position++].value;
      const value = numeric(unary());
      return operator === "-" ? -value : value;
    }
    return primary();
  }
  function multiply() {
    let value = unary();
    while (current().type === "operator" && ["*", "/"].includes(current().value)) {
      const operator = tokens[position++].value;
      const right = numeric(unary());
      value = operator === "*" ? numeric(value) * right : numeric(value) / right;
    }
    return value;
  }
  function add() {
    let value = multiply();
    while (current().type === "operator" && ["+", "-"].includes(current().value)) {
      const operator = tokens[position++].value;
      const right = numeric(multiply());
      value = operator === "+" ? numeric(value) + right : numeric(value) - right;
    }
    return value;
  }
  function concatenate() {
    let value = add();
    while (current().type === "operator" && current().value === "&") {
      position += 1;
      value = String(value ?? "") + String(add() ?? "");
    }
    return value;
  }
  function comparison() {
    let value = concatenate();
    if (current().type === "operator" && ["=", "==", "!=", "<>", ">", "<", ">=", "<="].includes(current().value)) {
      const operator = tokens[position++].value;
      const right = concatenate();
      if (["=", "=="].includes(operator)) return value == right;
      if (["!=", "<>"].includes(operator)) return value != right;
      if (operator === ">") return value > right;
      if (operator === "<") return value < right;
      if (operator === ">=") return value >= right;
      return value <= right;
    }
    return value;
  }

  const result = comparison();
  if (current().type !== "end") throw new Error("Unexpected text after formula");
  return result;
}

function clearSelectedEquation() {
  formulaBar.hidden = true;
  selectedEquation.value = "";
  selectedEquation.readOnly = true;
  selectedEquationContext = null;
  editEquationButton.hidden = false;
  saveEquationButton.hidden = true;
  cancelEquationButton.hidden = true;
  formulaError.hidden = true;
  formulaError.textContent = "";
  referenceTable.querySelectorAll(".equation-cell-selected").forEach((cell) => cell.classList.remove("equation-cell-selected"));
}

function showSelectedEquation(table, cell, column) {
  referenceTable.querySelectorAll(".equation-cell-selected").forEach((candidate) => candidate.classList.remove("equation-cell-selected"));
  cell.classList.add("equation-cell-selected");
  selectedEquationContext = { table, column };
  const equation = equationOverrides[table.id]?.[column]
    || table.displayEquations?.[column]
    || table.equations?.[column]
    || "";
  if (!equation) {
    clearSelectedEquation();
    return;
  }
  selectedEquation.value = equation;
  selectedEquation.readOnly = true;
  editEquationButton.hidden = Boolean(table.readonlyEquations);
  saveEquationButton.hidden = true;
  cancelEquationButton.hidden = true;
  formulaError.hidden = true;
  formulaBar.hidden = false;
}

function beginEquationEdit() {
  if (!selectedEquationContext) return;
  const { table, column } = selectedEquationContext;
  if (table.readonlyEquations) return;
  selectedEquation.value = tableEquations(table)[column] || "=0";
  selectedEquation.readOnly = false;
  editEquationButton.hidden = true;
  saveEquationButton.hidden = false;
  cancelEquationButton.hidden = false;
  formulaError.hidden = true;
  selectedEquation.focus();
  selectedEquation.select();
}

function cancelEquationEdit() {
  if (!selectedEquationContext) return;
  const { table, column } = selectedEquationContext;
  selectedEquation.value = equationOverrides[table.id]?.[column]
    || table.displayEquations?.[column]
    || table.equations?.[column]
    || "";
  selectedEquation.readOnly = true;
  editEquationButton.hidden = false;
  saveEquationButton.hidden = true;
  cancelEquationButton.hidden = true;
  formulaError.hidden = true;
}

function sourceTableForEquation(name) {
  const normalized = String(name).replace(/[^A-Za-z0-9]+/g, "").toLowerCase();
  return independentTables.find((table) => [table.id, table.name, table.standard]
    .some((value) => String(value || "").replace(/[^A-Za-z0-9]+/g, "").toLowerCase() === normalized));
}

function evaluateProjectEquation(expression, table, row, rows, project) {
  const qualifiedCountif = String(expression || "").trim().match(/^=COUNTIF\(\s*\[([^\]]+)\]@([A-Za-z_][A-Za-z0-9_]*)\s*,\s*@([A-Za-z_][A-Za-z0-9_]*)\s*\)$/i);
  if (qualifiedCountif) {
    const sourceTable = sourceTableForEquation(qualifiedCountif[1]);
    if (!sourceTable) throw new Error(`Unknown COUNTIF table [${qualifiedCountif[1]}]`);
    const sourceColumn = equationColumnIndex(sourceTable, qualifiedCountif[2]);
    let criteriaColumn = equationColumnIndex(table, qualifiedCountif[3]);
    if (criteriaColumn < 0 && table.id === "iesve-thermal-template" && qualifiedCountif[3].toLowerCase() === "type") criteriaColumn = 0;
    if (sourceColumn < 0 || criteriaColumn < 0) throw new Error("Unknown COUNTIF column reference");
    const criteria = String(row[criteriaColumn] ?? "");
    const sourceRows = sourceTable.id === table.id ? rows : ensureProjectTableRows(project, sourceTable);
    return sourceRows.filter((candidate) => String(candidate[sourceColumn] ?? "").localeCompare(criteria, undefined, { sensitivity: "base" }) === 0).length;
  }
  const qualifiedSumif = String(expression || "").trim().match(/^=SUMIF\(\s*\[([^\]]+)\]@([A-Za-z_][A-Za-z0-9_]*)\s*,\s*@([A-Za-z_][A-Za-z0-9_]*)\s*,\s*\[([^\]]+)\]@([A-Za-z_][A-Za-z0-9_]*)\s*\)$/i);
  if (qualifiedSumif) {
    const rangeTable = sourceTableForEquation(qualifiedSumif[1]);
    const sumTable = sourceTableForEquation(qualifiedSumif[4]);
    if (!rangeTable || rangeTable !== sumTable) throw new Error("SUMIF range and sum columns must use the same table");
    const rangeColumn = equationColumnIndex(rangeTable, qualifiedSumif[2]);
    const criteriaColumn = equationColumnIndex(table, qualifiedSumif[3]);
    const sumColumn = equationColumnIndex(sumTable, qualifiedSumif[5]);
    if ([rangeColumn, criteriaColumn, sumColumn].some((index) => index < 0)) throw new Error("Unknown SUMIF column reference");
    const sourceRows = rangeTable.id === table.id ? rows : ensureProjectTableRows(project, rangeTable);
    const criteria = row[criteriaColumn];
    return sourceRows.reduce((total, candidate) => candidate[rangeColumn] == criteria ? total + numberFromTableValue(candidate[sumColumn]) : total, 0);
  }
  const sumif = String(expression || "").trim().match(/^=SUMIF\(\s*@([A-Za-z_][A-Za-z0-9_]*)\s*,\s*@([A-Za-z_][A-Za-z0-9_]*)\s*,\s*@([A-Za-z_][A-Za-z0-9_]*)\s*\)$/i);
  if (sumif) {
    const rangeColumn = equationColumnIndex(table, sumif[1]);
    const criteriaColumn = equationColumnIndex(table, sumif[2]);
    const sumColumn = equationColumnIndex(table, sumif[3]);
    if ([rangeColumn, criteriaColumn, sumColumn].some((index) => index < 0)) throw new Error("Unknown SUMIF column reference");
    const criteria = row[criteriaColumn];
    return rows.reduce((total, candidate) => candidate[rangeColumn] == criteria ? total + numberFromTableValue(candidate[sumColumn]) : total, 0);
  }

  const withLookups = String(expression || "").replace(/XLOOKUP\(\s*@([A-Za-z_][A-Za-z0-9_]*)\s*,\s*\[([^\]]+)\]@([A-Za-z_][A-Za-z0-9_]*)\s*,\s*\[([^\]]+)\]@([A-Za-z_][A-Za-z0-9_]*)\s*\)/gi, (reference, currentColumnName, lookupTableName, lookupColumnName, resultTableName, resultColumnName) => {
    const lookupTable = sourceTableForEquation(lookupTableName);
    const resultTable = sourceTableForEquation(resultTableName);
    if (!lookupTable || lookupTable !== resultTable) throw new Error(`Unknown XLOOKUP table in ${reference}`);
    const currentColumn = equationColumnIndex(table, currentColumnName);
    const lookupColumn = equationColumnIndex(lookupTable, lookupColumnName);
    const resultColumn = equationColumnIndex(resultTable, resultColumnName);
    if ([currentColumn, lookupColumn, resultColumn].some((index) => index < 0)) throw new Error(`Unknown XLOOKUP column in ${reference}`);
    const sourceRows = ensureProjectTableRows(project, lookupTable);
    const lookupValue = String(row[currentColumn] ?? "");
    const sourceRow = sourceRows.find((candidate) => String(candidate[lookupColumn] ?? "").localeCompare(lookupValue, undefined, { sensitivity: "base" }) === 0);
    const value = sourceRow?.[resultColumn] ?? 0;
    return typeof value === "number" ? String(value) : JSON.stringify(String(value));
  });

  const resolved = withLookups.replace(/\[([^\]]+)\]@([A-Za-z_][A-Za-z0-9_]*)/g, (reference, tableName, columnName) => {
    const sourceTable = sourceTableForEquation(tableName);
    if (!sourceTable) throw new Error(`Unknown table [${tableName}]`);
    const sourceColumn = equationColumnIndex(sourceTable, columnName);
    const lookupColumn = equationColumnIndex(table, sourceTable.headers[0].label);
    if (sourceColumn < 0 || lookupColumn < 0) throw new Error(`Unknown reference ${reference}`);
    const sourceRows = ensureProjectTableRows(project, sourceTable);
    const lookupValue = String(row[lookupColumn] ?? "");
    const sourceRow = sourceRows.find((candidate) => String(candidate[0] ?? "").localeCompare(lookupValue, undefined, { sensitivity: "base" }) === 0);
    const value = sourceRow?.[sourceColumn] ?? 0;
    return typeof value === "number" ? String(value) : JSON.stringify(String(value));
  });
  return evaluateEquation(resolved, table, row);
}

function recalculateGainTable(table, rows, project) {
  const thermal = independentTables.find((candidate) => candidate.id === "iesve-thermal-template");
  const thermalRows = thermal ? (project ? ensureProjectTableRows(project, thermal) : thermal.rows) : [];
  const thermalByType = new Map(thermalRows.map((row) => [String(row[0]), row]));
  const lightingLoads = independentTables.find((candidate) => candidate.id === "selected-lighting-loads");
  const lightingRows = lightingLoads ? (project ? ensureProjectTableRows(project, lightingLoads) : lightingLoads.rows) : [];
  const miscLoads = independentTables.find((candidate) => candidate.id === "selected-misc-loads");
  const miscRows = miscLoads ? (project ? ensureProjectTableRows(project, miscLoads) : miscLoads.rows) : [];
  const lightingPowerDensity = (value, space, area) => {
    const numeric = Number(value);
    if (Number.isFinite(numeric)) return numeric;
    const height = area ? (Number(table.volumeBySpace?.[space]) || 0) / area : 0;
    const text = String(value || "");
    if (text.includes("0.050") && text.includes("0.025")) return 0.05 - 0.025 * height;
    if (text.includes("0.0375")) return 0.037 * height;
    return 0;
  };

  rows.forEach((row) => {
    const space = String(row[0] ?? "");
    const active = Boolean(table.activityBySpace?.[space]);
    const template = thermalByType.get(String(row[1] ?? "")) || [];
    const area = Number(row[2]) || 0;
    if (table.gainCalculation === "people") {
      if (!active) {
        [3, 5, 6, 7, 8, 9].forEach((index) => { row[index] = ""; });
        return;
      }
      row[3] = (Number(template[5]) || 0) / 1000;
      const manualPeople = row[4] !== "" && row[4] !== null && row[4] !== undefined ? Number(row[4]) : NaN;
      row[5] = Number.isFinite(manualPeople) ? manualPeople : Math.round((Number(row[3]) || 0) * area);
      row[6] = template[7] ?? "";
      row[7] = template[8] ?? "";
      row[8] = (Number(row[5]) || 0) * (Number(row[6]) || 0);
      row[9] = (Number(row[5]) || 0) * (Number(row[7]) || 0);
      return;
    }
    if (table.gainCalculation === "lighting") {
      if (!active) {
        [3, 4, 6, 7, 8].forEach((index) => { row[index] = ""; });
        return;
      }
      row[3] = template[12] ?? "";
      row[4] = lightingPowerDensity(template[10], space, area);
      const matches = lightingRows.filter((candidate) => String(candidate[0] ?? "") === space);
      row[6] = matches.length ? matches.reduce((sum, candidate) => sum + (Number(candidate[4]) || 0), 0) : "";
      const manual = row[5] !== "" && row[5] !== null && row[5] !== undefined ? Number(row[5]) : NaN;
      const proposedWatts = row[6] !== "" ? Number(row[6]) || 0 : Number.isFinite(manual) ? manual : (Number(row[3]) || 0) * area;
      row[7] = 3.412 * proposedWatts;
      row[8] = 3.412 * (Number(row[4]) || 0) * area;
      return;
    }
    if (table.gainCalculation === "misc") {
      if (!active) {
        [3, 4, 5].forEach((index) => { row[index] = ""; });
        return;
      }
      row[3] = template[13] ?? "";
      const matches = miscRows.filter((candidate) => String(candidate[0] ?? "") === space);
      row[4] = matches.length ? matches.reduce((sum, candidate) => sum + (Number(candidate[9]) || 0), 0) : "";
      row[5] = row[4] !== "" ? Number(row[4]) || 0 : 3.412 * (Number(row[3]) || 0) * area;
    }
  });
}

function recalculateMiscLoadTable(table, rows, project) {
  const peopleTable = independentTables.find((candidate) => candidate.id === "calc-people-gains");
  const equipmentTable = independentTables.find((candidate) => candidate.id === "schedule-equipment-sensible-gain");
  const groupedTable = independentTables.find((candidate) => candidate.id === "schedule-grouped-equipment-sensible-gain");
  const peopleRows = peopleTable ? ensureProjectTableRows(project, peopleTable) : [];
  if (peopleTable) recalculateGainTable(peopleTable, peopleRows, project);
  const peopleBySpace = new Map(peopleRows.map((row) => [String(row[0] ?? ""), row[5]]));
  const equipmentRows = equipmentTable ? ensureProjectTableRows(project, equipmentTable) : [];
  const groupedRows = groupedTable ? ensureProjectTableRows(project, groupedTable) : [];
  if (equipmentTable) recalculateTable(equipmentTable, equipmentRows, project);
  if (groupedTable) recalculateTable(groupedTable, groupedRows, project);
  const heatGainByEquipment = new Map(equipmentRows.map((row) => [String(row[0] ?? ""), Number(row[5]) || 0]));
  groupedRows.forEach((row) => heatGainByEquipment.set(String(row[0] ?? ""), Number(row[4]) || 0));

  rows.forEach((row) => {
    if (row[0] === "" || row[0] === null || row[0] === undefined) {
      [4, 5, 6, 9].forEach((index) => { row[index] = ""; });
      return;
    }
    const perPerson = String(row[3] ?? "").toUpperCase() === "TRUE";
    row[4] = perPerson ? (peopleBySpace.get(String(row[0])) ?? 0) : "-";
    row[5] = row[2] === "" || row[2] === null || row[2] === undefined ? 1 : Number(row[2]) || 0;
    row[6] = heatGainByEquipment.get(String(row[1] ?? "")) ?? 0;
    const peopleMultiplier = perPerson ? Number(row[4]) || 0 : 1;
    row[9] = peopleMultiplier * (Number(row[5]) || 0) * (Number(row[6]) || 0)
      + 3412.142 * (Number(row[7]) || 0) + (Number(row[8]) || 0);
  });
}

function recalculateRoomLoadTable(rows, project) {
  const reportTable = independentTables.find((candidate) => candidate.id === "room-zone-loads-report");
  const reportRows = reportTable ? ensureProjectTableRows(project, reportTable) : [];
  const reportByRoom = new Map(reportRows.map((row) => [String(row[2] ?? ""), row]));
  const gainTable = (id) => independentTables.find((candidate) => candidate.id === id);
  const lightingTable = gainTable("calc-lighting-gains");
  const peopleTable = gainTable("calc-people-gains");
  const miscTable = gainTable("calc-misc-gains");
  const lightingRows = lightingTable ? ensureProjectTableRows(project, lightingTable) : [];
  const peopleRows = peopleTable ? ensureProjectTableRows(project, peopleTable) : [];
  const miscRows = miscTable ? ensureProjectTableRows(project, miscTable) : [];
  if (lightingTable) recalculateGainTable(lightingTable, lightingRows, project);
  if (peopleTable) recalculateGainTable(peopleTable, peopleRows, project);
  if (miscTable) recalculateGainTable(miscTable, miscRows, project);
  const bySpace = (sourceRows) => new Map(sourceRows.map((row) => [String(row[0] ?? ""), row]));
  const lightingBySpace = bySpace(lightingRows);
  const peopleBySpace = bySpace(peopleRows);
  const miscBySpace = bySpace(miscRows);
  const enabled = (value) => value === true || String(value ?? "").toUpperCase() === "TRUE";
  project.calcSettings ||= {};
  project.calcSettings.spaceLoadFactors ||= { sensible: 0.1, latent: 0.1, heating: 0.1 };
  project.spaceLoadFactorOverrides ||= {};
  project.spaceLoadFactorAutos ||= {};
  const factors = project.calcSettings.spaceLoadFactors;
  const factorColumns = [[6, factors.sensible], [12, factors.latent], [16, factors.heating]];
  const nextAutos = {};
  const roomLoadsTable = independentTables.find((candidate) => candidate.id === "calc-room-loads");
  roomLoadsTable.autoCellStates = new Map();
  roomLoadsTable.missingRoomLoadSpaces = new Set();

  rows.forEach((row, rowIndex) => {
    const space = String(row[0] ?? "");
    if (!space) {
      [2, 3, 7, 8, 9, 13, 14, 17].forEach((index) => { row[index] = ""; });
      return;
    }
    const report = reportByRoom.get(space);
    if (!report) roomLoadsTable.missingRoomLoadSpaces.add(space);
    const lighting = lightingBySpace.get(space) || [];
    const people = peopleBySpace.get(space) || [];
    const misc = miscBySpace.get(space) || [];
    const autoCells = new Set();
    factorColumns.forEach(([column, defaultValue]) => {
      const key = `${space}::${column}`;
      const normalizedDefault = Number(defaultValue) || 0;
      if (project.spaceLoadFactorOverrides[key] && Number(row[column]) === normalizedDefault) delete project.spaceLoadFactorOverrides[key];
      if (!project.spaceLoadFactorOverrides[key]) {
        const previous = project.spaceLoadFactorAutos[key];
        if (previous !== undefined && row[column] !== "" && Number(row[column]) !== Number(previous) && Number(row[column]) !== normalizedDefault) {
          project.spaceLoadFactorOverrides[key] = true;
        }
      }
      if (!project.spaceLoadFactorOverrides[key]) {
        row[column] = normalizedDefault;
        autoCells.add(column);
      }
      nextAutos[key] = normalizedDefault;
    });
    roomLoadsTable.autoCellStates.set(rowIndex, autoCells);
    row[2] = report ? Number(report[3]) || 0 : "";
    row[3] = ((Number(lighting[7]) || 0) + (Number(people[8]) || 0) + (Number(misc[5]) || 0)) / 1000;
    const sensibleBasis = enabled(row[4]) ? row[3] : row[2];
    row[7] = sensibleBasis === "" ? "" : Math.max((1 + (Number(row[6]) || 0)) * ((Number(sensibleBasis) || 0) + (Number(row[5]) || 0)), 0);
    row[8] = report ? Number(report[4]) || 0 : "";
    row[9] = (Number(people[9]) || 0) / 1000;
    const latentBasis = enabled(row[10]) ? row[8] : row[9];
    row[13] = latentBasis === "" ? "" : Math.max((1 + (Number(row[12]) || 0)) * ((Number(latentBasis) || 0) + (Number(row[11]) || 0)), 0);
    row[14] = report ? Number(report[5]) || 0 : "";
    row[17] = row[14] === "" ? "" : Math.max((1 + (Number(row[16]) || 0)) * ((Number(row[14]) || 0) + (Number(row[15]) || 0)), 0);
  });
  project.spaceLoadFactorAutos = nextAutos;
}

function recordSpaceLoadFactorOverride(table, row, column, value, project) {
  if (!table.roomLoadCalculation || !(table.autoColumns || []).includes(column) || !project) return;
  project.spaceLoadFactorOverrides ||= {};
  const key = `${String(row[0] ?? "")}::${column}`;
  const numericValue = Number(String(value ?? "").replace(/%$/, "")) / 100;
  const autoValue = Number(project.spaceLoadFactorAutos?.[key]);
  if (Number.isFinite(numericValue) && numericValue === autoValue) delete project.spaceLoadFactorOverrides[key];
  else project.spaceLoadFactorOverrides[key] = true;
}

function loadCalculationSources(project) {
  const byId = (id) => independentTables.find((candidate) => candidate.id === id);
  const zoningTable = byId("calc-equipment-zoning");
  const spaceLoadsTable = byId("calc-room-loads");
  const setpointsTable = byId("calc-space-condition-setpoints");
  const heatingCoilsTable = byId("airside-heating");
  const coolingCoilsTable = byId("airside-cooling");
  const zoningRows = zoningTable ? ensureProjectTableRows(project, zoningTable) : [];
  if (zoningTable) recalculateEquipmentZoning(zoningTable, zoningRows, project);
  const spaceLoadRows = spaceLoadsTable ? ensureProjectTableRows(project, spaceLoadsTable) : [];
  if (spaceLoadsTable) recalculateRoomLoadTable(spaceLoadRows, project);
  const setpointRows = setpointsTable ? ensureProjectTableRows(project, setpointsTable) : [];
  const heatingCoilRows = heatingCoilsTable ? ensureProjectTableRows(project, heatingCoilsTable) : [];
  const coolingCoilRows = coolingCoilsTable ? ensureProjectTableRows(project, coolingCoilsTable) : [];
  if (heatingCoilsTable) recalculateCoilTable(heatingCoilsTable, heatingCoilRows, project);
  if (coolingCoilsTable) recalculateCoilTable(coolingCoilsTable, coolingCoilRows, project);
  const mapBy = (rows, column) => new Map(rows.map((row) => [String(row[column] ?? ""), row]));
  return {
    zoningBySpace: mapBy(zoningRows, 2),
    loadsBySpace: mapBy(spaceLoadRows, 0),
    setpointsBySpace: mapBy(setpointRows, 0),
    heatingCoilsByEquipment: mapBy(heatingCoilRows, 0),
    coolingCoilsByEquipment: mapBy(coolingCoilRows, 0),
  };
}

const ceilingFive = (value) => Math.ceil(Math.max(Number(value) || 0, 0) / 5) * 5;

function recalculateHeatingLoads(rows, project) {
  const sources = loadCalculationSources(project);
  rows.forEach((row) => {
    const space = String(row[0] ?? "");
    if (!space) { row.fill("", 1); return; }
    const zoning = sources.zoningBySpace.get(space) || [];
    const loads = sources.loadsBySpace.get(space) || [];
    const setpoints = sources.setpointsBySpace.get(space) || [];
    const equipment = String(zoning[8] ?? "");
    const coil = sources.heatingCoilsByEquipment.get(equipment) || [];
    row[1] = equipment;
    row[2] = zoning[6] ? true : "";
    row[3] = loads[17] ?? "";
    row[4] = coil[1] ?? 0;
    row[5] = coil[4] ?? 0;
    const deltaT = (Number(row[4]) || 0) - (Number(setpoints[3]) || 0);
    row[6] = row[5] && deltaT > 0 ? ceilingFive(Math.max(50, (Number(row[3]) || 0) * 1000 / ((Number(row[5]) || 0) * deltaT))) : 0;
    row[7] = Number(row[7]) || 0;
    row[8] = Math.max(Number(row[6]) || 0, Number(row[7]) || 0);
    row[9] = row[2] ? (Number(row[5]) || 0) * (Number(row[8]) || 0) * deltaT / 1000 : 0;
  });
}

function recalculateCoolingLoads(rows, project) {
  const sources = loadCalculationSources(project);
  const heatingTable = independentTables.find((candidate) => candidate.id === "calc-heating-loads");
  const heatingRows = heatingTable ? ensureProjectTableRows(project, heatingTable) : [];
  if (heatingTable) recalculateHeatingLoads(heatingRows, project);
  const heatingBySpace = new Map(heatingRows.map((row) => [String(row[0] ?? ""), row]));
  rows.forEach((row) => {
    const space = String(row[0] ?? "");
    if (!space) { row.fill("", 1); return; }
    const zoning = sources.zoningBySpace.get(space) || [];
    const loads = sources.loadsBySpace.get(space) || [];
    const setpoints = sources.setpointsBySpace.get(space) || [];
    const equipment = String(zoning[7] ?? "");
    const coil = sources.coolingCoilsByEquipment.get(equipment) || [];
    const heating = heatingBySpace.get(space) || [];
    row[1] = equipment;
    row[2] = equipment && String(zoning[3] ?? "") === equipment ? true : "";
    row[3] = loads[7] ?? "";
    row[4] = coil[2] ?? 0;
    row[5] = coil[9] ?? 0;
    row[6] = coil[11] ?? 0;
    row[7] = coil[10] ?? "";
    row[8] = coil[13] ?? 0;
    row[9] = coil[14] ?? 0;
    const deltaT = (Number(setpoints[7]) || 0) - (Number(row[5]) || 0);
    row[10] = row[8] && deltaT > 0 ? ceilingFive(Math.max(50, (Number(row[3]) || 0) * 1000 / ((Number(row[8]) || 0) * deltaT))) : 0;
    row[11] = row[2] || !zoning[6] ? 0 : 2 * (Number(heating[8]) || 0);
    row[12] = Number(row[12]) || 0;
    row[13] = Math.max(Number(row[10]) || 0, Number(row[11]) || 0, Number(row[12]) || 0);
    row[14] = (Number(row[8]) || 0) * (Number(row[13]) || 0) * deltaT / 1000;
    row[15] = (Number(row[9]) || 0) * (Number(row[13]) || 0) * ((Number(setpoints[9]) || 0) - (Number(row[6]) || 0)) / 1000;
  });
}

function zoningCellKey(row, column) {
  return `${String(row[2] ?? "")}::${column}`;
}

function recordZoningOverride(table, row, column, value, project) {
  if (!table.equipmentZoningCalculation || !(table.autoColumns || []).includes(column)) return;
  project.zoningOverrides ||= {};
  project.zoningOverrides[table.id] ||= {};
  const defaults = project.zoningAutoValues?.[table.id] || {};
  const key = zoningCellKey(row, column);
  if (String(value ?? "") === String(defaults[key] ?? "")) delete project.zoningOverrides[table.id][key];
  else project.zoningOverrides[table.id][key] = true;
}

function airsideCellKey(row, column) {
  return `${String(row[0] ?? "")}::${column}`;
}

function recordAirsideOverride(table, row, column, value, project) {
  if (!table.airsideSettingsCalculation || !(table.autoColumns || []).includes(column) || !project) return;
  project.airsideOverrides ||= {};
  const key = airsideCellKey(row, column);
  const defaultValue = project.airsideAutoValues?.[key] ?? "";
  const normalized = isPercentageColumn(table, column)
    ? Number(String(value ?? "").replace(/%$/, "")) / 100
    : value;
  if (String(normalized ?? "") === String(defaultValue ?? "")) delete project.airsideOverrides[key];
  else project.airsideOverrides[key] = true;
}

function recordCoilOverride(table, row, column, value, project) {
  if (!table.coilCalculation || !(table.autoColumns || []).includes(column) || !project) return;
  project.coilOverrides ||= {};
  project.coilOverrides[table.id] ||= {};
  const key = airsideCellKey(row, column);
  const automatic = project.coilAutoValues?.[table.id]?.[key] ?? "";
  const normalized = isPercentageColumn(table, column) ? Number(String(value).replace(/%$/, "")) / 100 : Number(value);
  if (Number.isFinite(normalized) && Number(normalized) === Number(automatic)) delete project.coilOverrides[table.id][key];
  else project.coilOverrides[table.id][key] = true;
}

function humidityRatioForPressure(dryBulbF, relativeHumidity, pressure) {
  const dryBulbC = (Number(dryBulbF) - 32) * 5 / 9;
  const saturationPressure = 0.145038 * 0.61094 * Math.exp((17.625 * dryBulbC) / (dryBulbC + 243.04));
  const vaporPressure = saturationPressure * Math.max(0, Math.min(1, Number(relativeHumidity) || 0));
  return 0.621945 * vaporPressure / (pressure - vaporPressure);
}

function relativeHumidityForRatio(dryBulbF, humidityRatioValue, pressure) {
  const dryBulbC = (Number(dryBulbF) - 32) * 5 / 9;
  const saturationPressure = 0.145038 * 0.61094 * Math.exp((17.625 * dryBulbC) / (dryBulbC + 243.04));
  const vaporPressure = Number(humidityRatioValue) * pressure / (0.621945 + Number(humidityRatioValue));
  return Math.max(0, Math.min(1, vaporPressure / saturationPressure));
}

function wetBulbFromState(dryBulbF, humidityRatioValue, pressure) {
  const dryBulbC = (Number(dryBulbF) - 32) * 5 / 9;
  const rh = relativeHumidityForRatio(dryBulbF, humidityRatioValue, pressure) * 100;
  const wetBulbC = dryBulbC * Math.atan(0.151977 * Math.sqrt(rh + 8.313659))
    + Math.atan(dryBulbC + rh) - Math.atan(rh - 1.676331)
    + 0.00391838 * Math.pow(rh, 1.5) * Math.atan(0.023101 * rh) - 4.686035;
  return wetBulbC * 9 / 5 + 32;
}

function airConstantsForState(dryBulbF, humidityRatioValue, pressure) {
  const db = Number(dryBulbF) || 0;
  const hr = Number(humidityRatioValue) || 0;
  const density = 0.075 * (pressure / 14.696) * (530 / (db + 459.67)) / (1 + 1.6078 * hr);
  return {
    sensible: 60 * density * (0.241 + 0.444 * hr),
    latent: 60 * density * (1093 - 0.556 * db),
  };
}

function coilCalculationContext(project) {
  project.modelInputs = { ...modelInputDefaults, ...(project.modelInputs || {}) };
  const model = project.modelInputs;
  const calculated = modelInputCalculations(model);
  const zoningTable = independentTables.find((candidate) => candidate.id === "calc-equipment-zoning");
  const setpointTable = independentTables.find((candidate) => candidate.id === "calc-space-condition-setpoints");
  const settingsTable = independentTables.find((candidate) => candidate.id === "airside-settings");
  const zoningRows = zoningTable ? ensureProjectTableRows(project, zoningTable) : [];
  if (zoningTable) recalculateEquipmentZoning(zoningTable, zoningRows, project);
  const setpointRows = setpointTable ? ensureProjectTableRows(project, setpointTable) : [];
  const settingsRows = settingsTable ? ensureProjectTableRows(project, settingsTable) : [];
  if (settingsTable) recalculateAirsideSettings(settingsTable, settingsRows, project);
  return {
    model,
    calculated,
    pressure: calculated.pressure,
    zoningRows,
    setpointsBySpace: new Map(setpointRows.map((row) => [String(row[0] ?? ""), row])),
    settingsByEquipment: new Map(settingsRows.map((row) => [String(row[0] ?? "").toLowerCase(), row])),
  };
}

function averageServedCondition(context, equipment, temperatureColumn, humidityColumn) {
  const key = String(equipment).toLowerCase();
  const spaces = [...new Set(context.zoningRows
    .filter((row) => [3, 4, 5, 6, 7, 8, 9, 10].some((column) => String(row[column] ?? "").toLowerCase() === key))
    .map((row) => String(row[2] ?? "")).filter(Boolean))];
  const values = spaces.map((space) => context.setpointsBySpace.get(space)).filter(Boolean);
  const average = (column) => {
    const numbers = values.filter((row) => row[column] !== "" && row[column] !== null && row[column] !== undefined)
      .map((row) => Number(row[column])).filter(Number.isFinite);
    return numbers.length ? numbers.reduce((sum, value) => sum + value, 0) / numbers.length : 0;
  };
  return { dryBulb: average(temperatureColumn), humidityRatio: average(humidityColumn), spaces };
}

function recalculateCoilTable(table, rows, project) {
  const context = coilCalculationContext(project);
  project.coilOverrides ||= {}; project.coilOverrides[table.id] ||= {};
  project.coilAutoValues ||= {}; project.coilAutoValues[table.id] ||= {};
  const overrides = project.coilOverrides[table.id];
  const previousAutos = project.coilAutoValues[table.id];
  const nextAutos = {};
  table.autoCellStates = new Map(); table.lockedCellStates = new Map(); table.lockedCellMessages = new Map();
  const applyAuto = (row, autoCells, column, value) => {
    const key = airsideCellKey(row, column);
    if (overrides[key] && Number(row[column]) === Number(value)) delete overrides[key];
    if (!overrides[key] && previousAutos[key] !== undefined && row[column] !== "" && Number(row[column]) !== Number(previousAutos[key]) && Number(row[column]) !== Number(value)) overrides[key] = true;
    if (!overrides[key]) { row[column] = value; autoCells.add(column); }
    nextAutos[key] = value;
  };
  const lockRange = (row, locked, messages, start, end, message) => {
    for (let column = start; column <= end; column += 1) {
      row[column] = ""; locked.add(column); messages.set(column, message); delete overrides[airsideCellKey(row, column)];
    }
  };
  const state = (db, hr) => ({ db, hr, wb: wetBulbFromState(db, hr, context.pressure), ...airConstantsForState(db, hr, context.pressure) });

  rows.forEach((row, rowIndex) => {
    const equipment = String(row[0] ?? "");
    const autoCells = new Set(); const locked = new Set(); const messages = new Map();
    if (table.coilCalculation === "preheat") {
      applyAuto(row, autoCells, 1, 38);
      const entering = state(Number(context.model.heatingDb) || 0, context.calculated.heatingHr);
      row[5] = entering.db; row[6] = entering.hr; row[7] = entering.wb; row[8] = entering.sensible;
      const leaving = state(row[1], entering.hr);
      row[2] = entering.hr; row[3] = leaving.wb; row[4] = leaving.sensible;
      row[10] = Math.max(0, leaving.sensible * (leaving.db - entering.db) * (Number(row[9]) || 0) / 1000);
    } else if (table.coilCalculation === "cooling") {
      const key = equipment.toLowerCase();
      const isVentilation = context.zoningRows.some((candidate) => String(candidate[3] ?? "").toLowerCase() === key);
      const isCentral = context.zoningRows.some((candidate) => String(candidate[4] ?? "").toLowerCase() === key);
      const isCooling = context.zoningRows.some((candidate) => String(candidate[7] ?? "").toLowerCase() === key);
      const justCooling = isCooling && !isVentilation && !isCentral;
      if (justCooling) lockRange(row, locked, messages, 1, 8, "This section is not used for cooling-only equipment.");
      else {
        applyAuto(row, autoCells, 3, 50); applyAuto(row, autoCells, 4, 0.994);
        const dehumLeaving = state(row[3], humidityRatioForPressure(row[3], row[4], context.pressure));
        row[5] = dehumLeaving.hr; row[6] = dehumLeaving.wb; row[7] = dehumLeaving.sensible; row[8] = dehumLeaving.latent;
      }
      applyAuto(row, autoCells, 9, 55); applyAuto(row, autoCells, 10, 0.994);
      const normalLeaving = state(row[9], humidityRatioForPressure(row[9], row[10], context.pressure));
      row[11] = normalLeaving.hr; row[12] = normalLeaving.wb; row[13] = normalLeaving.sensible; row[14] = normalLeaving.latent;
      const populateEntering = (start, entering, leavingStart, airflowColumn) => {
        row[start] = entering.db; row[start + 1] = entering.hr; row[start + 2] = entering.wb; row[start + 3] = entering.sensible; row[start + 4] = entering.latent;
        const airflow = Number(row[airflowColumn]) || 0;
        row[start + 6] = Math.max(0, Number(row[leavingStart + 4]) * (entering.db - Number(row[leavingStart])) * airflow / 1000);
        row[start + 7] = Math.max(0, Number(row[leavingStart + 5]) * (entering.hr - Number(row[leavingStart + 2])) * airflow / 1000);
        row[start + 8] = row[start + 6] + row[start + 7];
      };
      if (isVentilation) {
        populateEntering(15, state(Number(context.model.coolingDb) || 0, context.calculated.coolingHr), 9, 20);
        populateEntering(24, state(Number(context.model.dehumidificationDb) || 0, context.calculated.dehumidificationHr), justCooling ? 9 : 3, 29);
      } else {
        lockRange(row, locked, messages, 15, 23, "This equipment is not used as ventilation equipment.");
        lockRange(row, locked, messages, 24, 32, "This equipment is not used as ventilation equipment.");
      }
      const room = averageServedCondition(context, equipment, 7, 9);
      populateEntering(33, state(room.dryBulb, room.humidityRatio), 9, 38);
      row[42] = (Number(row[21]) || 0) + (Number(row[30]) || 0) + (Number(row[39]) || 0);
      row[43] = (Number(row[22]) || 0) + (Number(row[31]) || 0) + (Number(row[40]) || 0);
      row[44] = row[42] + row[43];
    } else if (table.coilCalculation === "heating") {
      applyAuto(row, autoCells, 1, 90);
      const room = averageServedCondition(context, equipment, 3, 5);
      const roomState = state(room.dryBulb, room.humidityRatio);
      const leaving = state(row[1], room.humidityRatio);
      row[2] = leaving.hr; row[3] = leaving.wb; row[4] = leaving.sensible;
      const related = context.zoningRows.find((candidate) => [6, 8].some((column) => String(candidate[column] ?? "").toLowerCase() === equipment.toLowerCase()));
      const upstream = String(related?.[3] ?? equipment);
      const hasPreheat = String(context.settingsByEquipment.get(upstream.toLowerCase())?.[6] ?? "").toUpperCase() === "TRUE";
      const preheatTable = independentTables.find((candidate) => candidate.id === "airside-preheat");
      const preheatRows = preheatTable ? ensureProjectTableRows(project, preheatTable) : [];
      if (preheatTable) recalculateCoilTable(preheatTable, preheatRows, project);
      const preheat = preheatRows.find((candidate) => String(candidate[0] ?? "").toLowerCase() === upstream.toLowerCase());
      if (hasPreheat && preheat) {
        row[5] = preheat[1]; row[6] = preheat[2]; row[7] = preheat[3]; row[8] = preheat[4]; row[9] = preheat[9]; row[10] = preheat[10];
      } else lockRange(row, locked, messages, 5, 10, "No preheat coil is associated with this equipment.");
      row[11] = roomState.db; row[12] = roomState.hr; row[13] = roomState.wb; row[14] = roomState.sensible;
      row[16] = Math.max(0, row[4] * (Number(row[15]) || 0) * (Number(row[1]) - roomState.db) / 1000);
      row[17] = (Number(row[10]) || 0) + (Number(row[16]) || 0);
    }
    table.autoCellStates.set(rowIndex, autoCells); table.lockedCellStates.set(rowIndex, locked); table.lockedCellMessages.set(rowIndex, messages);
  });
  project.coilAutoValues[table.id] = nextAutos;
}

function recalculateAirsideSettings(table, rows, project) {
  const zoningTable = independentTables.find((candidate) => candidate.id === "calc-equipment-zoning");
  const zoningRows = zoningTable ? ensureProjectTableRows(project, zoningTable) : [];
  project.airsideOverrides ||= {};
  project.airsideAutoValues ||= {};
  const overrides = project.airsideOverrides;
  const previousAutos = project.airsideAutoValues;
  const nextAutos = {};
  table.autoCellStates = new Map();
  table.lockedCellStates = new Map();
  table.lockedCellMessages = new Map();
  const matches = (value, equipment) => String(value ?? "").localeCompare(equipment, undefined, { sensitivity: "base" }) === 0;
  const servedByEquipment = new Map();
  zoningRows.forEach((candidate) => [3, 4, 5, 6, 7, 8, 9, 10].forEach((column) => {
    const key = String(candidate[column] ?? "").trim().toLowerCase();
    if (!key) return;
    if (!servedByEquipment.has(key)) servedByEquipment.set(key, []);
    servedByEquipment.get(key).push(candidate);
  }));
  const firstMatch = (column, equipment) => zoningRows.find((candidate) => matches(candidate[column], equipment));

  rows.forEach((row, rowIndex) => {
    const equipment = String(row[0] ?? "").trim();
    const servedRows = servedByEquipment.get(equipment.toLowerCase()) || [];
    row[1] = new Set(servedRows.map((candidate) => String(candidate[2] ?? "")).filter(Boolean)).size;
    const autoCells = new Set();
    const lockedCells = new Set();
    const lockMessages = new Map();
    const applyAuto = (column, defaultValue) => {
      const key = airsideCellKey(row, column);
      const normalizedDefault = defaultValue ?? "";
      if (overrides[key] && String(row[column] ?? "") === String(normalizedDefault)) delete overrides[key];
      if (!overrides[key]) {
        const previous = previousAutos[key];
        const current = row[column] ?? "";
        if (previous === undefined && current !== "" && String(current) !== String(normalizedDefault)) overrides[key] = true;
        else if (previous !== undefined && current !== "" && String(current) !== String(previous) && String(current) !== String(normalizedDefault)) overrides[key] = true;
      }
      if (!overrides[key]) {
        row[column] = normalizedDefault;
        autoCells.add(column);
      }
      nextAutos[key] = normalizedDefault;
    };

    applyAuto(4, 1);
    applyAuto(5, 1 / Math.max(Number(row[4]) || 1, 1));
    const isVentilation = Boolean(firstMatch(3, equipment));
    [6, 7].forEach((column) => {
      if (isVentilation) applyAuto(column, "TRUE");
      else {
        row[column] = "";
        lockedCells.add(column);
        lockMessages.set(column, "Equipment must appear in Equipment Zoning > Ventilation Equipment to make this cell editable.");
        delete overrides[airsideCellKey(row, column)];
      }
    });
    [8, 9].forEach((column) => {
      if (String(row[7] ?? "").toUpperCase() === "TRUE") applyAuto(column, 1);
      else {
        row[column] = "";
        lockedCells.add(column);
        lockMessages.set(column, "Set Ventilation Cooling Coil to TRUE to make this cell editable.");
        delete overrides[airsideCellKey(row, column)];
      }
    });
    if (isVentilation && String(row[7] ?? "").toUpperCase() === "TRUE") applyAuto(10, "TRUE");
    else {
      row[10] = "";
      lockedCells.add(10);
      lockMessages.set(10, "Set Ventilation Cooling Coil to TRUE to make this cell editable.");
      delete overrides[airsideCellKey(row, 10)];
    }

    const reheatRow = firstMatch(6, equipment);
    const supplyValveRow = firstMatch(5, equipment);
    const exhaustValveRow = firstMatch(10, equipment);
    const centralRows = servedRows.filter((candidate) => matches(candidate[4], equipment));
    const isCentral = centralRows.length > 0;
    const hasReheat = centralRows.some((candidate) => String(candidate[6] ?? "").trim() !== "");
    if (reheatRow) row[11] = `${reheatRow[4] || reheatRow[3] || ""} RHC`.trim();
    else if (supplyValveRow) row[11] = `${supplyValveRow[4] || ""} Valve`.trim();
    else if (exhaustValveRow) row[11] = `${exhaustValveRow[9] || ""} Valve`.trim();
    else if (isVentilation && String(row[7]).toUpperCase() === "TRUE" && !isCentral) row[11] = "In Unit RHC";
    else if (!isVentilation && isCentral && !hasReheat) row[11] = "In Unit RHC";
    else row[11] = "";

    table.autoCellStates.set(rowIndex, autoCells);
    table.lockedCellStates.set(rowIndex, lockedCells);
    table.lockedCellMessages.set(rowIndex, lockMessages);
  });
  project.airsideAutoValues = nextAutos;
}

function recalculateEquipmentZoning(table, rows, project) {
  if (project?.equipmentZoningTool?.initialized) {
    table.autoCellStates = new Map();
    table.lockedCellStates = new Map();
    table.lockedCellMessages = new Map();
    return;
  }
  const reportTable = independentTables.find((candidate) => candidate.id === "room-zone-loads-report");
  const reportRows = reportTable ? ensureProjectTableRows(project, reportTable) : [];
  const reportByRoom = new Map(reportRows.map((row) => [String(row[2] ?? ""), row]));
  project.zoningOverrides ||= {};
  project.zoningOverrides[table.id] ||= {};
  project.zoningAutoValues ||= {};
  project.zoningAutoValues[table.id] ||= {};
  const overrides = project.zoningOverrides[table.id];
  const previousAutos = project.zoningAutoValues[table.id];
  const nextAutos = {};
  table.autoCellStates = new Map();
  table.lockedCellStates = new Map();
  table.lockedCellMessages = new Map();

  rows.forEach((row, rowIndex) => {
    const report = reportByRoom.get(String(row[2] ?? ""));
    if (report) { row[0] = report[0] ?? ""; row[1] = report[1] ?? ""; }
    const autoCells = new Set();
    const lockedCells = new Set();
    const lockMessages = new Map();
    const applyAuto = (column, defaultValue) => {
      const key = zoningCellKey(row, column);
      const normalizedDefault = defaultValue ?? "";
      if (overrides[key] && String(row[column] ?? "") === String(normalizedDefault)) delete overrides[key];
      if (!overrides[key]) {
        const previous = previousAutos[key];
        const current = row[column] ?? "";
        if (previous === undefined && current !== "" && String(current) !== String(normalizedDefault)) overrides[key] = true;
        else if (previous !== undefined && current !== "" && String(current) !== String(previous) && String(current) !== String(normalizedDefault)) overrides[key] = true;
      }
      if (!overrides[key]) {
        row[column] = normalizedDefault;
        autoCells.add(column);
      }
      nextAutos[key] = normalizedDefault;
    };

    applyAuto(3, row[1]);
    applyAuto(4, row[3]);
    if (row[4]) applyAuto(5, row[1]);
    else {
      lockedCells.add(5);
      lockMessages.set(5, "Populate Central Equipment to make this cell editable.");
      row[5] = "";
      delete overrides[zoningCellKey(row, 5)];
    }
    if (lockedCells.has(5) || !row[5]) {
      lockedCells.add(6);
      lockMessages.set(6, "Populate and unlock Valve to make this cell editable.");
      row[6] = "";
      delete overrides[zoningCellKey(row, 6)];
    } else {
      applyAuto(6, row[5]);
    }

    if (row[4]) {
      lockedCells.add(7);
      lockMessages.set(7, "Clear Central Equipment to make this cell editable.");
      row[7] = "";
      delete overrides[zoningCellKey(row, 7)];
    } else {
      applyAuto(7, row[5] ? "" : row[1]);
      if (row[7]) {
        lockedCells.add(4);
        lockMessages.set(4, "Clear Cooling Equipment to make this cell editable.");
      }
    }

    if (row[6]) {
      lockedCells.add(8);
      lockMessages.set(8, "Clear Reheat Coil to make this cell editable.");
      row[8] = "";
      delete overrides[zoningCellKey(row, 8)];
    } else {
      applyAuto(8, row[7] || "");
      if (row[8]) {
        lockedCells.add(6);
        lockMessages.set(6, "Clear Heating Equipment to make this cell editable.");
      }
    }
    applyAuto(9, row[3]);
    table.autoCellStates.set(rowIndex, autoCells);
    table.lockedCellStates.set(rowIndex, lockedCells);
    table.lockedCellMessages.set(rowIndex, lockMessages);
  });
  project.zoningAutoValues[table.id] = nextAutos;
}

function recalculateTable(table, rows, project = activeProject()) {
  if (table.airsideSettingsCalculation) {
    recalculateAirsideSettings(table, rows, project);
    return;
  }
  if (table.coilCalculation) {
    recalculateCoilTable(table, rows, project);
    return;
  }
  if (table.equipmentZoningCalculation) {
    recalculateEquipmentZoning(table, rows, project);
    return;
  }
  if (table.roomLoadCalculation) {
    recalculateRoomLoadTable(rows, project);
    return;
  }
  if (table.heatingLoadCalculation) {
    recalculateHeatingLoads(rows, project);
    return;
  }
  if (table.coolingLoadCalculation) {
    recalculateCoolingLoads(rows, project);
    return;
  }
  if (table.miscLoadCalculation) {
    recalculateMiscLoadTable(table, rows, project);
    return;
  }
  if (table.gainCalculation) {
    recalculateGainTable(table, rows, project);
    return;
  }
  if (table.preserveImportedValues) return;
  if (table.calculation === "grouped-equipment-schedule") {
    const equipmentTable = independentTables.find((candidate) => candidate.id === "schedule-equipment-sensible-gain");
    if (equipmentTable) recalculateTable(equipmentTable, ensureProjectTableRows(project, equipmentTable), project);
  }

  const equations = tableEquations(table);
  (table.calculatedColumns || []).slice().sort((left, right) => left - right).forEach((column) => {
    rows.forEach((row) => {
      if (row[0] === "" || row[0] === null || row[0] === undefined) {
        row[column] = "";
      } else {
        row[column] = evaluateProjectEquation(equations[column] || "=0", table, row, rows, project);
      }
    });
  });
}

function recalculateDependentTables(table, project = activeProject()) {
  if (table.id !== "schedule-equipment-sensible-gain") return;
  const groupedTable = independentTables.find((candidate) => candidate.id === "schedule-grouped-equipment-sensible-gain");
  if (groupedTable) recalculateTable(groupedTable, ensureProjectTableRows(project, groupedTable), project);
}

function saveEquationEdit() {
  if (!selectedEquationContext) return;
  const { table, column } = selectedEquationContext;
  const equation = selectedEquation.value.trim();
  if (!equation.startsWith("=")) {
    formulaError.textContent = "Equations must begin with =";
    formulaError.hidden = false;
    return;
  }

  const previous = equationOverrides[table.id]?.[column];
  equationOverrides[table.id] ||= {};
  equationOverrides[table.id][column] = equation;
  try {
    if (projects.length) {
      projects.forEach((project) => {
        recalculateTable(table, ensureProjectTableRows(project, table), project);
        recalculateDependentTables(table, project);
      });
    } else {
      recalculateTable(table, table.rows, null);
      recalculateDependentTables(table, null);
    }
  } catch (error) {
    if (previous === undefined) delete equationOverrides[table.id][column];
    else equationOverrides[table.id][column] = previous;
    formulaError.textContent = error.message || "This equation could not be calculated.";
    formulaError.hidden = false;
    return;
  }

  localStorage.setItem(EQUATION_OVERRIDES_KEY, JSON.stringify(equationOverrides));
  saveProjects();
  selectedEquation.readOnly = true;
  editEquationButton.hidden = false;
  saveEquationButton.hidden = true;
  cancelEquationButton.hidden = true;
  formulaError.hidden = true;
  refreshRenderedTableValues(table, projectTableRows(table));
}

function numberFromTableValue(value) {
  const number = Number(String(value ?? "").replace(/,/g, ""));
  return Number.isFinite(number) ? number : 0;
}

function compareTableValues(left, right) {
  const leftBlank = left === null || left === undefined || left === "";
  const rightBlank = right === null || right === undefined || right === "";
  if (leftBlank !== rightBlank) return leftBlank ? 1 : -1;
  if (typeof left === "number" && typeof right === "number") return left - right;
  return String(left ?? "").localeCompare(String(right ?? ""), undefined, { numeric: true, sensitivity: "base" });
}

function calculateColumnWidths(table, headers, rows) {
  const context = document.createElement("canvas").getContext("2d");
  return headers.map((header, index) => {
    if (table.columnWidthOverrides?.[index]) return table.columnWidthOverrides[index];
    context.font = '11px Aptos, "Segoe UI", Arial, sans-serif';
    const contentWidth = rows.reduce((maximum, row) => Math.max(maximum, context.measureText(String(formatTableValue(row[index], table, index))).width), 0);
    const dropdownWidth = table.dropdownColumns?.[index]
      ? tableDropdownOptions(table, index).reduce((maximum, option) => Math.max(maximum, context.measureText(option).width), 0)
      : 0;
    context.font = '700 12px Aptos, "Segoe UI", Arial, sans-serif';
    const labelWidth = String(`${header.label || ""}${header.subscript || ""}`)
      .split(/[\s-]+/)
      .reduce((maximum, part) => Math.max(maximum, context.measureText(part).width), 0) + 54;
    context.font = '650 10px Aptos, "Segoe UI", Arial, sans-serif';
    const unitWidth = context.measureText(header.unit || "").width + 52;
    const numericColumn = table.columnTypes[index] === "number";
    const maximumWidth = table.dropdownColumns?.[index] ? 360 : numericColumn ? 160 : 360;
    const minimumWidth = table.dropdownColumns?.[index] ? 220 : numericColumn ? 96 : 110;
    const desiredContentWidth = Math.max(contentWidth + 24, dropdownWidth + 48);
    return Math.ceil(Math.max(minimumWidth, Math.min(maximumWidth, desiredContentWidth), Math.min(maximumWidth, labelWidth), Math.min(maximumWidth, unitWidth)));
  });
}

function autoFitRenderedTable(table, headers, rows) {
  const widths = calculateColumnWidths(table, headers, rows);
  referenceTable.querySelectorAll("col").forEach((column, index) => {
    column.style.width = `${widths[index]}px`;
  });
  referenceTable.style.width = `${widths.reduce((total, width) => total + width, 0)}px`;
}

function moveToAdjacentCell(cell, key, extendSelection = false) {
  const row = cell.closest("tr");
  const body = row.parentElement;
  const rows = [...body.rows].filter((candidate) => !candidate.classList.contains("table-summary-row"));
  let rowIndex = rows.indexOf(row);
  let columnIndex = cell.cellIndex;
  const rowStep = key === "ArrowUp" ? -1 : key === "ArrowDown" ? 1 : 0;
  const columnStep = key === "ArrowLeft" ? -1 : key === "ArrowRight" ? 1 : 0;

  while (true) {
    rowIndex += rowStep;
    columnIndex += columnStep;
    const targetRow = rows[rowIndex];
    if (!targetRow || columnIndex < 0 || columnIndex >= targetRow.cells.length) return;
    let target = targetRow.cells[columnIndex];
    if (target.classList.contains("editable-cell") || target.classList.contains("calculated-cell")) {
      const targetSourceIndex = Number(targetRow.dataset.sourceIndex);
      if (cell.isContentEditable && document.activeElement === cell) {
        cell.blur();
        const refreshedRow = [...referenceTable.querySelectorAll("tbody tr")]
          .find((candidate) => Number(candidate.dataset.sourceIndex) === targetSourceIndex);
        target = refreshedRow?.cells[columnIndex] || target;
      }
      const focusTarget = target.querySelector("select") || target;
      suppressFillHandleOnce = target.classList.contains("editable-cell");
      focusTarget.focus();
      if (target.isContentEditable) {
        const selection = window.getSelection();
        const range = document.createRange();
        const textNode = [...target.childNodes].find((node) => node.nodeType === Node.TEXT_NODE);
        range.selectNodeContents(textNode || target);
        range.collapse(false);
        selection.removeAllRanges();
        selection.addRange(range);
      }
      selectTableCell(activeTableId, targetSourceIndex, target.cellIndex, {
        shiftKey: extendSelection && rowStep !== 0,
        ctrlKey: false,
        metaKey: false,
      });
      alignCellInTableViewport(target);
      return;
    }
  }
}

function alignCellInTableViewport(cell) {
  const scroll = cell.closest(".table-scroll");
  const row = cell.closest("tr");
  if (!scroll || !row) return;
  const viewport = scroll.getBoundingClientRect();
  const cellRect = cell.getBoundingClientRect();
  const activeTable = independentTables.find((table) => table.id === activeTableId);
  const frozenColumnCount = activeTable?.frozenColumns || 1;
  const frozenRect = row.cells[frozenColumnCount - 1]?.getBoundingClientRect();
  const visibleLeft = cell.cellIndex >= frozenColumnCount && frozenRect ? Math.max(viewport.left, frozenRect.right) : viewport.left;
  const visibleRight = viewport.left + scroll.clientWidth;
  if (cellRect.left < visibleLeft) {
    scroll.scrollLeft = Math.max(0, scroll.scrollLeft - (visibleLeft - cellRect.left));
  } else if (cellRect.right > visibleRight) {
    scroll.scrollLeft += cellRect.right - visibleRight;
  }
}

function sortReferenceTable(tableId, column) {
  tableSort = tableSort.tableId === tableId && tableSort.column === column
    ? { tableId, column, direction: tableSort.direction === "asc" ? "desc" : "asc" }
    : { tableId, column, direction: "asc" };
  renderReferenceTable(tableId);
}

function refreshSelectedTableCells() {
  referenceTable.querySelectorAll("tbody td.multi-cell-selected").forEach((cell) => cell.classList.remove("multi-cell-selected"));
  selectedTableCells.forEach((key) => {
    const [rowIndex, columnIndex] = key.split(":").map(Number);
    const row = referenceTable.querySelector(`tbody tr[data-source-index="${rowIndex}"]`);
    row?.cells[columnIndex]?.classList.add("multi-cell-selected");
  });
}

function selectTableCell(tableId, sourceIndex, columnIndex, event = {}) {
  const key = `${sourceIndex}:${columnIndex}`;
  if (selectedTableId !== tableId) selectedTableCells.clear();
  selectedTableId = tableId;
  selectedTableRowIndexes.clear();
  selectionAnchorIndex = -1;
  referenceTable.querySelectorAll("tbody tr.selected-row").forEach((row) => {
    row.classList.remove("selected-row");
    row.setAttribute("aria-selected", "false");
  });
  removeTableRowButton.disabled = true;
  if (event.shiftKey && cellSelectionAnchor) {
    const visibleRows = [...referenceTable.querySelectorAll("tbody tr")];
    const anchorPosition = visibleRows.findIndex((row) => Number(row.dataset.sourceIndex) === cellSelectionAnchor.sourceIndex);
    const targetPosition = visibleRows.findIndex((row) => Number(row.dataset.sourceIndex) === sourceIndex);
    if (anchorPosition >= 0 && targetPosition >= 0) {
      selectedTableCells.clear();
      const [rowStart, rowEnd] = [Math.min(anchorPosition, targetPosition), Math.max(anchorPosition, targetPosition)];
      const [columnStart, columnEnd] = [Math.min(cellSelectionAnchor.columnIndex, columnIndex), Math.max(cellSelectionAnchor.columnIndex, columnIndex)];
      visibleRows.slice(rowStart, rowEnd + 1).forEach((row) => {
        for (let column = columnStart; column <= columnEnd; column += 1) {
          if (row.cells[column]?.classList.contains("editable-cell")) selectedTableCells.add(`${row.dataset.sourceIndex}:${column}`);
        }
      });
    }
  } else if (event.ctrlKey || event.metaKey) {
    if (selectedTableCells.has(key)) selectedTableCells.delete(key); else selectedTableCells.add(key);
    cellSelectionAnchor = { sourceIndex, columnIndex };
  } else {
    selectedTableCells = new Set([key]);
    cellSelectionAnchor = { sourceIndex, columnIndex };
  }
  refreshSelectedTableCells();
}

function clearSelectedTableCellValues() {
  if (document.activeElement?.isContentEditable) document.activeElement.blur();
  const table = independentTables.find((candidate) => candidate.id === activeTableId);
  if (!table || !selectedTableCells.size) return false;
  const rows = projectTableRows(table);
  let changed = false;
  selectedTableCells.forEach((key) => {
    const [rowIndex, columnIndex] = key.split(":").map(Number);
    const row = rows[rowIndex];
    if (!row || (table.lockedColumns || []).includes(columnIndex) || (table.calculatedColumns || []).includes(columnIndex)
      || table.lockedCellStates?.get(rowIndex)?.has(columnIndex)) return;
    recordZoningOverride(table, row, columnIndex, "", activeProject());
    recordAirsideOverride(table, row, columnIndex, "", activeProject());
    recordCoilOverride(table, row, columnIndex, "", activeProject());
    recordSpaceLoadFactorOverride(table, row, columnIndex, "", activeProject());
    row[columnIndex] = "";
    changed = true;
  });
  if (!changed) return false;
  recalculateTable(table, rows);
  recalculateDependentTables(table);
  saveProjects();
  selectedTableCells.clear();
  cellSelectionAnchor = null;
  renderReferenceTable(table.id, tableSearch.value);
  return true;
}

function selectTableRow(tableId, tableRow, sourceIndex, event = {}) {
  if (selectedTableId !== tableId) {
    selectedTableRowIndexes.clear();
    selectionAnchorIndex = -1;
  }
  selectedTableId = tableId;
  const toggle = Boolean(event.ctrlKey || event.metaKey);
  if (event.shiftKey && selectionAnchorIndex >= 0) {
    const visibleRows = [...referenceTable.querySelectorAll("tbody tr")];
    const anchorPosition = visibleRows.findIndex((row) => Number(row.dataset.sourceIndex) === selectionAnchorIndex);
    const targetPosition = visibleRows.indexOf(tableRow);
    if (anchorPosition >= 0 && targetPosition >= 0) {
      selectedTableRowIndexes = new Set(visibleRows
        .slice(Math.min(anchorPosition, targetPosition), Math.max(anchorPosition, targetPosition) + 1)
        .map((row) => Number(row.dataset.sourceIndex)));
    }
  } else if (toggle) {
    if (selectedTableRowIndexes.has(sourceIndex)) selectedTableRowIndexes.delete(sourceIndex);
    else selectedTableRowIndexes.add(sourceIndex);
    selectionAnchorIndex = sourceIndex;
  } else {
    selectedTableRowIndexes = new Set([sourceIndex]);
    selectionAnchorIndex = sourceIndex;
  }
  referenceTable.querySelectorAll("tbody tr").forEach((row) => {
    const selected = selectedTableRowIndexes.has(Number(row.dataset.sourceIndex));
    row.classList.toggle("selected-row", selected);
    row.setAttribute("aria-selected", String(selected));
  });
  removeTableRowButton.disabled = selectedTableRowIndexes.size === 0;
}

function addTableRow() {
  const table = independentTables.find((candidate) => candidate.id === activeTableId);
  if (!table) return;
  const rows = projectTableRows(table);
  const row = Array(table.columns.length).fill("");
  rows.push(row);
  recalculateTable(table, rows);
  recalculateDependentTables(table);
  selectedTableId = table.id;
  selectedTableRowIndexes = new Set([rows.length - 1]);
  selectionAnchorIndex = rows.length - 1;
  saveProjects();
  tableSearch.value = "";
  tableSort = { tableId: table.id, column: -1, direction: "asc" };
  renderReferenceTable(table.id);
  requestAnimationFrame(() => {
    const scroll = document.querySelector(".table-scroll");
    scroll.scrollTop = scroll.scrollHeight;
    referenceTable.querySelector("tbody tr:last-child .editable-cell")?.focus();
  });
}

function removeTableRow() {
  if (!activeTableId || selectedTableId !== activeTableId || selectedTableRowIndexes.size === 0) return;
  const table = independentTables.find((candidate) => candidate.id === activeTableId);
  if (!table) return;
  const rows = projectTableRows(table);
  [...selectedTableRowIndexes].sort((left, right) => right - left).forEach((index) => {
    rows.splice(index, 1);
  });
  recalculateTable(table, rows);
  recalculateDependentTables(table);
  saveProjects();
  selectedTableId = "";
  selectedTableRowIndexes.clear();
  selectionAnchorIndex = -1;
  removeTableRowButton.disabled = true;
  renderReferenceTable(table.id);
}

function renderSummaryLinks(groupName) {
  summaryLinks.innerHTML = "";
  summaryLinks.hidden = !groupName;
  if (!groupName) return;

  const section = modules.find((candidate) => candidate.group === groupName);
  if (!section || !section.items.length) {
    const note = document.createElement("span");
    note.className = "summary-note";
    note.textContent = "Reference tables will be added as their calculation dependencies are migrated.";
    summaryLinks.appendChild(note);
    return;
  }

  section.items.forEach((item) => {
    const button = document.createElement("button");
    button.type = "button";
    button.textContent = item[0];
    button.addEventListener("click", () => {
      search.value = "";
      renderTree();
      const target = document.querySelector(`[data-id="${CSS.escape(slugify(item[0]))}"]`);
      if (target) selectModule(target);
    });
    summaryLinks.appendChild(button);
  });
}

function syncActiveState() {
  const id = location.hash.slice(1) || "space-condition-setpoints";
  document.querySelectorAll("[data-id]").forEach((button) => button.classList.toggle("active", button.dataset.id === id));
  const active = document.querySelector(`[data-id="${CSS.escape(id)}"]`);
  if (active) updateWorkspace(active.dataset);
}

function openBrowser() {
  browser.classList.add("open");
  scrim.classList.add("open");
  document.body.style.overflow = "hidden";
}

function closeBrowser() {
  browser.classList.remove("open");
  scrim.classList.remove("open");
  document.body.style.overflow = "";
}

function createProjectId() {
  return globalThis.crypto?.randomUUID?.() || `project-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function defaultProject() {
  const project = { id: createProjectId() };
  projectFields.forEach((input) => {
    const field = input.dataset.projectField;
    project[field] = localStorage.getItem(`hvac-project-${field}`) ?? input.value ?? "";
  });
  project.number ||= "185021";
  project.name ||= "IESVE 2025 Energy Model";
  return project;
}

function saveProjects() {
  const next = JSON.stringify(projects);
  const previous = localStorage.getItem(PROJECTS_KEY);
  if (!applyingHistory && previous && previous !== next) {
    undoStack.push(previous);
    if (undoStack.length > 100) undoStack.shift();
    redoStack.length = 0;
  }
  localStorage.setItem(PROJECTS_KEY, next);
  localStorage.setItem(ACTIVE_PROJECT_KEY, activeProjectId);
}

function restoreProjectHistory(snapshot) {
  applyingHistory = true;
  try {
    projects = JSON.parse(snapshot);
    if (!projects.some((project) => project.id === activeProjectId)) activeProjectId = projects[0]?.id || "";
    localStorage.setItem(PROJECTS_KEY, JSON.stringify(projects));
    localStorage.setItem(ACTIVE_PROJECT_KEY, activeProjectId);
    selectedTableCells.clear();
    cellSelectionAnchor = null;
    fillProjectFields();
    renderProjectList();
    syncActiveState();
  } finally {
    applyingHistory = false;
  }
}

function undoProjectChange() {
  const snapshot = undoStack.pop();
  if (!snapshot) return;
  redoStack.push(JSON.stringify(projects));
  restoreProjectHistory(snapshot);
}

function redoProjectChange() {
  const snapshot = redoStack.pop();
  if (!snapshot) return;
  undoStack.push(JSON.stringify(projects));
  restoreProjectHistory(snapshot);
}

function loadProjects() {
  try {
    const saved = JSON.parse(localStorage.getItem(PROJECTS_KEY) || "null");
    projects = Array.isArray(saved) && saved.length ? saved : [defaultProject()];
  } catch {
    projects = [defaultProject()];
  }

  const savedActiveId = localStorage.getItem(ACTIVE_PROJECT_KEY);
  activeProjectId = projects.some((project) => project.id === savedActiveId) ? savedActiveId : projects[0].id;
  saveProjects();
}

function activeProject() {
  return projects.find((project) => project.id === activeProjectId) || projects[0];
}

function fillProjectFields() {
  const project = activeProject();
  if (!project) return;
  projectFields.forEach((input) => {
    input.value = project[input.dataset.projectField] || "";
  });
}

function renderProjectList(query = projectSearch.value) {
  const normalized = query.trim().toLowerCase();
  const matches = projects.filter((project) =>
    [project.number, project.name, project.client].some((value) => String(value || "").toLowerCase().includes(normalized)),
  );
  projectList.innerHTML = "";

  if (!matches.length) {
    const empty = document.createElement("p");
    empty.className = "project-list-empty";
    empty.textContent = "No projects match this search.";
    projectList.appendChild(empty);
    return;
  }

  matches.forEach((project) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "project-list-item";
    button.classList.toggle("active", project.id === activeProjectId);
    if (project.id === activeProjectId) button.setAttribute("aria-current", "true");

    const number = document.createElement("strong");
    number.textContent = project.number;
    const name = document.createElement("span");
    name.textContent = project.name || "Untitled project";
    button.append(number, name);
    button.addEventListener("click", () => selectProject(project.id));
    projectList.appendChild(button);
  });
}

function selectProject(projectId) {
  if (!projects.some((project) => project.id === projectId)) return;
  activeProjectId = projectId;
  selectedTableId = "";
  selectedTableRowIndexes.clear();
  selectionAnchorIndex = -1;
  saveProjects();
  fillProjectFields();
  renderProjectList();
  syncActiveState();
}

function setProjectSwitcher(open) {
  shell.classList.toggle("projects-open", open);
  projectSwitcherToggle.setAttribute("aria-expanded", String(open));
  projectSwitcherToggle.setAttribute("aria-label", `${open ? "Close" : "Open"} project list`);
  projectSwitcherToggle.title = `${open ? "Close" : "Open"} project list`;
  if (open) {
    renderProjectList();
    projectSearch.focus();
  }
}

function openProjectDialog() {
  projectForm.reset();
  projectDialogError.textContent = "";
  projectDialog.showModal();
  requestAnimationFrame(() => newProjectNumber.focus());
}

function addProject(event) {
  event.preventDefault();
  const number = newProjectNumber.value.trim();
  if (!number) {
    projectDialogError.textContent = "Enter a project number.";
    newProjectNumber.focus();
    return;
  }
  if (projects.some((project) => String(project.number).toLowerCase() === number.toLowerCase())) {
    projectDialogError.textContent = "That project number already exists.";
    newProjectNumber.focus();
    return;
  }

  const project = {
    id: createProjectId(),
    number,
    client: "",
    name: "",
    date: "",
    made_by: "",
    checked_by: "",
    submittal: "",
  };
  projects.push(project);
  projectSearch.value = "";
  projectDialog.close();
  selectProject(project.id);
}

function initializeProjects() {
  loadProjects();
  fillProjectFields();
  renderProjectList();

  projectFields.forEach((input) => {
    if (input.readOnly) return;
    input.addEventListener("input", () => {
      const project = activeProject();
      if (!project) return;
      project[input.dataset.projectField] = input.value;
      saveProjects();
      renderProjectList();
    });
  });
}

search.addEventListener("input", (event) => renderTree(event.target.value));
projectSearch.addEventListener("input", (event) => renderProjectList(event.target.value));
tableSearch.addEventListener("input", (event) => {
  if (activeTableId) renderReferenceTable(activeTableId, event.target.value);
});
twoValueSchedule.addEventListener("change", () => {
  const project = activeProject();
  if (!project || activeTableId !== "calc-space-condition-setpoints") return;
  project.calcSettings ||= {};
  project.calcSettings.twoValueSchedule = twoValueSchedule.value.trim();
  saveProjects();
});
document.querySelector("#cancel-space-reconcile").addEventListener("click", () => {
  pendingSpaceReconciliation = null;
  spaceReconcileDialog.close();
});
document.querySelector("#apply-space-reconcile").addEventListener("click", () => {
  if (!pendingSpaceReconciliation) return;
  const { table, importedRows, state, newSpaces, oldSpaces } = pendingSpaceReconciliation;
  try {
    applyCalculationSpaceChanges(newSpaces, oldSpaces);
    commitTabularImport(table, importedRows, state);
    pendingSpaceReconciliation = null;
    spaceReconcileDialog.close();
  } catch (error) {
    spaceReconcileError.textContent = error.message || "The space changes could not be applied.";
  }
});
[
  [sensibleLoadFactor, "sensible"],
  [latentLoadFactor, "latent"],
  [heatingLoadFactor, "heating"],
].forEach(([input, key]) => input.addEventListener("change", () => {
  const project = activeProject();
  const table = independentTables.find((candidate) => candidate.id === "calc-room-loads");
  if (!project || !table) return;
  const parsed = Number(String(input.value).replace(/,/g, "").replace(/%$/, ""));
  if (!Number.isFinite(parsed) || parsed < 0) {
    updateTableSettings(table);
    return;
  }
  project.calcSettings ||= {};
  project.calcSettings.spaceLoadFactors ||= { sensible: 0.1, latent: 0.1, heating: 0.1 };
  project.calcSettings.spaceLoadFactors[key] = parsed / 100;
  recalculateTable(table, ensureProjectTableRows(project, table), project);
  saveProjects();
  if (activeTableId === table.id) renderReferenceTable(table.id, tableSearch.value);
}));
document.addEventListener("keydown", (event) => {
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "z") {
    event.preventDefault();
    if (event.shiftKey) redoProjectChange(); else undoProjectChange();
    return;
  }
  if (event.key === "Delete" && selectedTableCells.size) {
    const selection = window.getSelection();
    if (selectedTableCells.size === 1 && document.activeElement?.isContentEditable && selection && !selection.isCollapsed) return;
    if (clearSelectedTableCellValues()) event.preventDefault();
    return;
  }
  if (!["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(event.key)) return;
  const cell = event.composedPath().find((node) => node instanceof HTMLTableCellElement && referenceTable.contains(node));
  if (!cell || event.altKey || event.ctrlKey || event.metaKey) return;
  if (event.shiftKey && cell.isContentEditable && ["ArrowLeft", "ArrowRight"].includes(event.key)) return;
  event.preventDefault();
  event.stopImmediatePropagation();
  moveToAdjacentCell(cell, event.key, event.shiftKey);
}, true);

addTableRowButton.addEventListener("click", addTableRow);
removeTableRowButton.addEventListener("click", removeTableRow);
pasteDataButton.addEventListener("click", pasteDataFromClipboard);
copyDataButton.addEventListener("click", copyTabularData);
importExcelButton.addEventListener("click", () => importExcelInput.click());
importExcelInput.addEventListener("change", () => {
  importRoomZoneLoads(importExcelInput.files?.[0]);
});
editEquationButton.addEventListener("click", beginEquationEdit);
saveEquationButton.addEventListener("click", saveEquationEdit);
cancelEquationButton.addEventListener("click", cancelEquationEdit);
selectedEquation.addEventListener("keydown", (event) => {
  if (selectedEquation.readOnly) return;
  if (event.key === "Enter") {
    event.preventDefault();
    saveEquationEdit();
  } else if (event.key === "Escape") {
    event.preventDefault();
    event.stopPropagation();
    cancelEquationEdit();
  }
});
projectSwitcherToggle.addEventListener("click", () => setProjectSwitcher(!shell.classList.contains("projects-open")));
document.querySelector("#add-project").addEventListener("click", openProjectDialog);
document.querySelector("#cancel-project").addEventListener("click", () => projectDialog.close());
projectForm.addEventListener("submit", addProject);
document.querySelector("#open-browser").addEventListener("click", openBrowser);
document.querySelector("#close-browser").addEventListener("click", closeBrowser);
scrim.addEventListener("click", closeBrowser);
window.addEventListener("hashchange", syncActiveState);
document.addEventListener("pointermove", (event) => updateFillPreview(event.clientX, event.clientY));
document.addEventListener("pointerup", finishFillDrag);
document.addEventListener("pointercancel", finishFillDrag);
document.addEventListener("pointerdown", (event) => {
  if (event.target.closest?.(".fill-handle") || event.target.closest?.("td.editable-cell")) return;
  clearFillHandle();
});
tableScroll.addEventListener("scroll", clearFillHandle);
modelInputsView.addEventListener("pointerdown", (event) => {
  if (!event.target.closest("input.calculated-value")) hideModelInputEquation();
});
window.addEventListener("paste", (event) => {
  if (activeTableId !== "iesve-tabular-space-data") return;
  if (event.target instanceof HTMLInputElement || event.target instanceof HTMLTextAreaElement || event.target.isContentEditable) return;
  const text = event.clipboardData?.getData("text/plain") || "";
  if (!text.trim()) return;
  event.preventDefault();
  try {
    pasteTabularData(text);
  } catch (error) {
    setCsvFileStatus(error.message || "The pasted clipboard data could not be used.", true);
  }
});
window.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && !projectDialog.open) {
    closeBrowser();
    setProjectSwitcher(false);
  }
});

initializeProjects();
renderTree();

let loadedVersion = null;
async function checkForUpdates() {
  if (document.visibilityState !== "visible") return;
  try {
    const isLocal = location.hostname === "127.0.0.1" || location.hostname === "localhost";
    const versionUrl = isLocal ? `/version?t=${Date.now()}` : `./version.json?t=${Date.now()}`;
    const response = await fetch(versionUrl, { cache: "no-store" });
    if (!response.ok) return;
    const { version } = await response.json();
    if (loadedVersion !== null && version !== loadedVersion) location.reload();
    loadedVersion = version;
  } catch {
    // The local server may be restarting; the next poll will reconnect.
  }
}

checkForUpdates();
setInterval(checkForUpdates, 1200);
