/* Export the chart's original drawing primitives as native PDF paths and text. */
async function drawPsychVectorPDF({page,doc,nodes,left,top,scale,normal,bold,imageCache}){
 const I=[1,0,0,1,0,0],mul=(a,b)=>[a[0]*b[0]+a[2]*b[1],a[1]*b[0]+a[3]*b[1],a[0]*b[2]+a[2]*b[3],a[1]*b[2]+a[3]*b[3],a[0]*b[4]+a[2]*b[5]+a[4],a[1]*b[4]+a[3]*b[5]+a[5]];
 const transform=(value,m=I)=>{for(const match of String(value||'').matchAll(/(translate|rotate|scale|matrix)\(([^)]*)\)/g)){const a=match[2].trim().split(/[ ,]+/).map(Number);let n=I;if(match[1]==='translate')n=[1,0,0,1,a[0],a[1]||0];if(match[1]==='scale')n=[a[0],0,0,a[1]??a[0],0,0];if(match[1]==='matrix')n=a;if(match[1]==='rotate'){const r=a[0]*Math.PI/180,c=Math.cos(r),s=Math.sin(r);n=[c,s,-s,c,0,0];if(a.length>1)n=mul(mul([1,0,0,1,a[1],a[2]],n),[1,0,0,1,-a[1],-a[2]]);}m=mul(m,n);}return m;};
 const point=(m,x,y)=>({x:left+(m[0]*x+m[2]*y+m[4])*scale,y:top-(m[1]*x+m[3]*y+m[5])*scale});
 const color=v=>{const named={white:'#ffffff',black:'#000000',none:null};v=named[v]??v;if(!v||v==='none')return null;if(/^#[\da-f]{3}$/i.test(v))v='#'+[...v.slice(1)].map(x=>x+x).join('');return PDFLib.rgb(parseInt(v.slice(1,3),16)/255,parseInt(v.slice(3,5),16)/255,parseInt(v.slice(5,7),16)/255);};
 const pathOps=(d,m)=>{const tokens=String(d).match(/[MLZmlz]|[-+]?(?:\d*\.\d+|\d+\.?\d*)(?:[eE][-+]?\d+)?/g)||[],ops=[];let command='M';for(let i=0;i<tokens.length;){if(/^[MLZ]$/i.test(tokens[i]))command=tokens[i++].toUpperCase();if(command==='Z'){ops.push(PDFLib.closePath());command='M';continue;}const x=Number(tokens[i++]),y=Number(tokens[i++]);if(!Number.isFinite(x)||!Number.isFinite(y))break;const p=point(m,x,y);ops.push(command==='M'?PDFLib.moveTo(p.x,p.y):PDFLib.lineTo(p.x,p.y));command='L';}return ops;};
 const alphaStates=new Map();
 const children=new Map();nodes.forEach((n,i)=>{const list=children.get(n.parent)||[];list.push(i);children.set(n.parent,list);});
 const clips=new Map();for(let i=0;i<nodes.length;i++)if(nodes[i].tag==='clipPath')clips.set(nodes[i].attrs.id,(children.get(i)||[]).map(j=>nodes[j]).filter(n=>n.tag==='path').map(n=>n.attrs.d).join(' '));
 const polygon=(points,fill,stroke,width)=>{page.pushOperators(PDFLib.pushGraphicsState(),...(fill?[PDFLib.setFillingColor(fill)]:[]),...(stroke?[PDFLib.setStrokingColor(stroke),PDFLib.setLineWidth(width)]:[]),PDFLib.moveTo(points[0].x,points[0].y),...points.slice(1).map(p=>PDFLib.lineTo(p.x,p.y)),PDFLib.closePath(),fill&&stroke?PDFLib.fillAndStroke():fill?PDFLib.fill():PDFLib.stroke(),PDFLib.popGraphicsState());};
 const textClean=t=>String(t).replace(/ₜ/g,'t').replace(/ₛ/g,'s').replace(/ₗ/g,'l').replace(/Δ/g,'d').replace(/V̇/g,'V').replace(/[^\x20-\x7e\xa0-\xff]/g,'');
 async function draw(index,parentMatrix=I){
  const n=nodes[index],a=n.attrs,m=transform(a.transform,parentMatrix);if(['defs','clipPath'].includes(n.tag)||(n.tag==='rect'&&n.parent===-1))return;
  const hasOpacity=a.opacity!==undefined;if(hasOpacity){const alpha=Number(a.opacity);if(!alphaStates.has(alpha)){const ref=doc.context.register(doc.context.obj({Type:'ExtGState',ca:alpha,CA:alpha}));alphaStates.set(alpha,page.node.newExtGState('PsychAlpha',ref));}page.pushOperators(PDFLib.pushGraphicsState(),PDFLib.setGraphicsState(alphaStates.get(alpha)));}
  const clip=a['clip-path']?.match(/#([^)]*)/),clipD=clip&&clips.get(clip[1]);if(clipD)page.pushOperators(PDFLib.pushGraphicsState(),...pathOps(clipD,m),PDFLib.clip(),PDFLib.endPath());
  const num=k=>Number(a[k]||0),stroke=color(a.stroke),fill=color(a.fill),width=Number(a['stroke-width']||1)*scale;
  if(n.tag==='line'&&stroke)page.drawLine({start:point(m,num('x1'),num('y1')),end:point(m,num('x2'),num('y2')),color:stroke,thickness:width});
  if(n.tag==='rect'&&(fill||stroke)){if(a.fill==='white'||a.fill==='#ffffff'){if(!alphaStates.has(1)){const ref=doc.context.register(doc.context.obj({Type:'ExtGState',ca:1,CA:1}));alphaStates.set(1,page.node.newExtGState('PsychAlpha',ref));}page.pushOperators(PDFLib.pushGraphicsState(),PDFLib.setGraphicsState(alphaStates.get(1)));}let x=num('x'),y=num('y'),w=num('width'),h=num('height');const label=(children.get(n.parent)||[]).map(i=>nodes[i]).find(s=>s.tag==='text'&&s.attrs['text-anchor']==='middle');if(label&&a.fill==='white'){const font=Number(label.attrs['font-weight']||400)>=600?bold:normal;w=font.widthOfTextAtSize(textClean(label.text),Number(label.attrs['font-size']||12))+12;x=-w/2;}polygon([[x,y],[x+w,y],[x+w,y+h],[x,y+h]].map(([x,y])=>point(m,x,y)),fill,stroke,width);if(a.fill==='white'||a.fill==='#ffffff')page.pushOperators(PDFLib.popGraphicsState());}
  if(n.tag==='path'&&(fill||stroke)){const ops=pathOps(a.d,m);if(ops.length)page.pushOperators(PDFLib.pushGraphicsState(),...(fill?[PDFLib.setFillingColor(fill)]:[]),...(stroke?[PDFLib.setStrokingColor(stroke),PDFLib.setLineWidth(width)]:[]),...ops,fill&&stroke?PDFLib.fillAndStroke():fill?PDFLib.fill():PDFLib.stroke(),PDFLib.popGraphicsState());}
  if(n.tag==='text'){
    const raw=String(n.text||''),font=Number(a['font-weight']||400)>=600?bold:normal,size=Number(a['font-size']||12)*scale,angle=-Math.atan2(m[1],m[0]),anchor=a['text-anchor'],p=point(m,num('x'),num('y'));
    if(/[\u2080-\u209f\u0300-\u036f\u0394\u2206\u00b7]/u.test(raw) && typeof document!=='undefined'){
      // Render mathematical glyphs in the browser font, not the restricted PDF font subset.
      // Only equation text is rasterized; chart geometry and ordinary text stay vector.
      const px=4,canvas=document.createElement('canvas'),ctx=canvas.getContext('2d');
      const fontPx=Number(a['font-size']||12)*px,weight=Number(a['font-weight']||400)>=600?'700':'400';
      ctx.font=weight+' '+fontPx+'px Arial, DejaVu Sans, sans-serif';
      const measured=Math.ceil(ctx.measureText(raw).width),pad=8*px;
      canvas.width=measured+2*pad;canvas.height=Math.ceil(fontPx*1.7)+pad;
      const ink=String(a.fill||'#000000');ctx.font=weight+' '+fontPx+'px Arial, DejaVu Sans, sans-serif';ctx.textBaseline='alphabetic';ctx.fillStyle=ink;
      const baseline=Math.ceil(fontPx*1.15);ctx.fillText(raw,pad,baseline);
      const png=await doc.embedPng(new Uint8Array(await (await fetch(canvas.toDataURL('image/png'))).arrayBuffer()));
      const w=canvas.width*scale/px,h=canvas.height*scale/px;
      const x=p.x-(anchor==='middle'?w/2:anchor==='end'?w:0),y=p.y-(canvas.height-baseline)*scale/px;
      page.drawImage(png,{x,y,width:w,height:h,rotate:PDFLib.radians(angle)});
    }else{
      const text=textClean(raw),w=font.widthOfTextAtSize(text,size),offset=anchor==='middle'?w/2:anchor==='end'?w:0;
      page.drawText(text,{x:p.x-offset*Math.cos(angle),y:p.y-offset*Math.sin(angle),size,font,color:fill||color('#000000'),rotate:PDFLib.radians(angle)});
    }
  }
  if(n.tag==='image'){
   const href=a.href||a['xlink:href'];if(!imageCache.has(href)){const response=await fetch(href);if(!response.ok)throw Error('Cannot load chart logo');imageCache.set(href,await doc.embedPng(new Uint8Array(await response.arrayBuffer())));}
   const image=imageCache.get(href),ratio=Math.min(num('width')/image.width,num('height')/image.height),w=image.width*ratio,h=image.height*ratio,p=point(m,num('x')+(num('width')-w)/2,num('y')+(num('height')+h)/2);page.drawImage(image,{x:p.x,y:p.y,width:w*scale,height:h*scale});
  }
  for(const child of children.get(index)||[])await draw(child,m);if(clipD)page.pushOperators(PDFLib.popGraphicsState());if(hasOpacity)page.pushOperators(PDFLib.popGraphicsState());
 }
 for(const index of children.get(-1)||[])await draw(index);
}
