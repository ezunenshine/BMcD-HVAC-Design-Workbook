/* Engineering storage remains canonical IP. SI is a reversible presentation/input boundary. */
Object.defineProperty(globalThis,'si',{configurable:true,get(){return typeof activeProject==='function'&&activeProject()?.modelInputs?.unitSystem==='SI';}});
function siTable(t){return !!t&&!t.id.startsWith('iesve-')&&!t.energySimulation&&!t.energySummary&&(t.id.startsWith('calc-')||t.id.startsWith('selected-')||t.airsideSection||t.plantCalculation||t.psychCalculation||t.psychMixedCalculation);}
function unitSpec(unit,label=''){
 const u=String(unit||'').toLowerCase().replaceAll('²','2').replaceAll('³','3').replaceAll('·','-').replace(/\s/g,'');
 const r=(unit,factor,offset=0,digits=2)=>({unit,factor,offset,digits});
 if(u==='°f')return /difference|rise|delta|Δ/i.test(label)?r('K',5/9,0,1):r('°C',5/9,-160/9,1);
 if(u==='ft')return r('m',.3048);if(['ft2','sqft'].includes(u))return r('m²',.09290304);if(u==='ft3')return r('m³',.028316846592);
 if(u==='psia')return r('kPa',6.894757293);if(/in\.?w\.?g\.?|in\.water/.test(u))return r('Pa',249.08891);
 if(u==='mbh')return r('kW',.293071070172);if(u==='btu/h')return r('W',.293071070172);
 if(['btu/lb','btu/lbm'].includes(u))return r('kJ/kg',2.326,-17.86368,1);
 if(u==='gr/lb')return r('g/kg',1/7,0,3);if(u==='lb/lb')return r('g/kg',1000,0,3);
 if(['ft3/lb','ft3/lbm'].includes(u))return r('m³/kg',.062427960576,0,3);
 if(u==='btu/lb-°f'||u==='btu/lbm-r')return r('kJ/(kg·K)',4.1868,0,3);
 if(u==='lb/gal')return r('kg/m³',119.8264273,0,1);if(['lb/ft3','lbm/ft3'].includes(u))return r('kg/m³',16.01846337,0,2);
 if(u==='gpm')return r('L/min',3.785411784);if(['gph','usgal/h'].includes(u))return r('L/h',3.785411784);
 if(u==='inwc')return r('Pa',249.08891);if(u==='ftwc')return r('kPa',2.98906692);if(u==='ft/min')return r('m/s',.00508);if(u==='lbs')return r('kg',.45359237);if(u==='ton')return r('kW',3.516852842064);
 if(u==='ft/s')return r('m/s',.3048);
 if(u.startsWith('cfm')||u==='ft3/min/pers'){let f=.4719474432,suffix=u.replace(/^cfm|^ft3\/min/,'');if(/ft2|sqft/.test(suffix)){f/=.09290304;suffix='/m²';}return r('L/s'+suffix,f,0,0);}
 if(/^w\/ft2$/.test(u))return r('W/m²',1/.09290304);
 if(u.startsWith('btu/h-')){const area=/ft2/.test(u);return r(area?'W/m²':'W/person',.293071070172/(area?.09290304:1));}
 if(u==='ft2/person')return r('m²/person',.09290304);
 if(u==='people/ft2')return r('people/m²',1/.09290304);
 if(['people/1,000ft2','people/1000ft2'].includes(u))return r('people/100 m²',100/(1000*.09290304));
 if(u==='gal/person-day')return r('L/person-day',3.785411784);
 if(/sensible constant|^cs$/i.test(label)||u==='cs')return r('',.293071070172*1.8/.4719474432,0,3);
 if(/latent constant|^cl$/i.test(label)||u==='cl')return r('',.293071070172*7/.4719474432,0,3);
 return null;
}
function tableUnitSpec(t,c){return siTable(t)?unitSpec(t.headers[c]?.unit,t.headers[c]?.label):null;}
function toSI(value,spec){return spec&&typeof value==='number'&&Number.isFinite(value)?value*spec.factor+spec.offset:value;}
function fromSI(value,spec){return spec&&typeof value==='number'&&Number.isFinite(value)?(value-spec.offset)/spec.factor:value;}
function unitValue(t,c,value){return si?toSI(value,tableUnitSpec(t,c)):value;}
function unitInput(t,c,raw){if(!si||raw===''||raw==null)return raw;const n=Number(String(raw).replaceAll(',',''));return Number.isFinite(n)?fromSI(n,tableUnitSpec(t,c)):raw;}
function unitHeader(t,c,h=t.headers[c]){if(/sensible constant|latent constant|^Cs$|^Cl$/i.test(h.label))return {...h,unit:''};const s=si&&tableUnitSpec(t,c);return s?{...h,unit:s.unit}:h;}
function unitLabel(text){if(/sensible constant|latent constant/i.test(text))return String(text).replace(/\s*\[[^\]]*\]/g,'');if(!si)return text;return String(text).replace(/0\.3 in\. pressure differential/gi,'74.7 Pa pressure differential').replace(/\[([^\]]+)\]/g,(all,u)=>{const s=unitSpec(u,text);return s?(s.unit?'['+s.unit+']':''):all;});}
function unitEquation(e,s){if(!s||!e||e.includes('unitIPValue'))return e;const conversion=s.unit==='°C'?'FtoC(unitIPValue)':s.unit==='L/s'?'unitIPValue*CFMtoLPS()':s.unit==='m'?'unitIPValue*FTtoM()':s.unit==='m²'?'unitIPValue*FT2toM2()':s.unit==='g/kg'&&s.factor===1/7?'unitIPValue*GRtoGKG()':s.unit==='kW'&&s.factor===.293071070172?'unitIPValue*MBHtoKW()':`unitIPValue*${s.factor}${s.offset?'+'+s.offset:''}`;return `=LET(unitIPValue,${e.replace(/^=/,'')},IF(ISNUMBER(unitIPValue),IF(SI,${conversion},unitIPValue),unitIPValue))`;}
function unitDigits(t,c,s){if(/^L\/s/.test(s.unit))return 0;if(s.unit==='°C'||s.unit==='K')return 1;for(const [key,n]of [['zeroDecimalColumns',0],['oneDecimalColumns',1],['decimalColumns',2],['threeDecimalColumns',3],['fourDecimalColumns',4],['fiveDecimalColumns',5]])if(t[key]?.includes(c))return n;return s.digits;}
function tableUnitEquation(t,c,e){return unitEquation(e,tableUnitSpec(t,c));}
function modelUnitSpec(k){return unitSpec(k==='elevation'?'ft':/Db$|Wb$/.test(k)?'°F':/HrGr$/.test(k)?'gr/lb':/Infiltration/.test(k)?'CFM/ft2':'');}
function modelUnitValue(k,v){return si?toSI(v,modelUnitSpec(k)):v;}
function modelUnitInput(k,v){return si?fromSI(v,modelUnitSpec(k)):v;}
function applyUnitColumns(t){if(!t.plantCalculation)return;t.ipHiddenColumns??=[...(t.hiddenColumns||[])];t.hiddenColumns=[...t.ipHiddenColumns,...(si?t.headers.flatMap((h,c)=>/^tons?$/i.test(h.unit||'')?[c]:[]):[])];}
function installPageExcel(){let b=document.querySelector('#export-current-excel');if(b)return;b=document.createElement('button');b.id='export-current-excel';b.className='copy-data-button';b.type='button';b.textContent='Export to Excel';const title=document.querySelector('#page-title'),row=document.createElement('div');row.className='page-title-row';title.before(row);row.append(title,b);b.onclick=exportCurrentPageExcel;}
function psychHeaderUnit259(label){const unit=label.match(/\[([^\]]+)\]$/)?.[1]||'';return /constant/i.test(label)?'':si?(unitSpec(unit,label.split(' [')[0])?.unit??unit):unit;}
function psychStateInSelectedUnits(db,w,pressure,siMode=si){
 const temp=siMode?fromSI(db,unitSpec('°F')):db,ratio=siMode?fromSI(w,unitSpec('gr/lb')):w,p=siMode?fromSI(pressure,unitSpec('psia')):pressure;
 const result={wb:wetBulbFromState(temp,ratio,p),h:moistAirEnthalpy(temp,ratio),v:moistAirVolume(temp,ratio,p),rh:relativeHumidityForRatio(temp,ratio,p),...airConstantsForState(temp,ratio,p)};
 if(siMode)for(const [key,u]of Object.entries({wb:'°F',h:'Btu/lb',v:'ft³/lb',sensible:'Cs',latent:'Cl'}))result[key]=toSI(result[key],unitSpec(u));return result;
}
function psychChartLabelSI(text,a){
 if(!si)return text;
 const numeric=/^-?\d+(?:\.\d+)?$/.test(text),fill=a.fill;
 if(numeric){const n=Number(text);let spec;
  if(fill==='#b8860b')spec=unitSpec('°F');
  else if(fill==='#23864c')spec=unitSpec('Btu/lb');
  else if(fill==='#c0268a')spec=unitSpec('ft³/lb');
  else if(fill==='#59636e')spec=Number(a.y)>665?unitSpec('°F'):Number(a.x)>1018?unitSpec('gr/lb'):null;
  if(spec)return toSI(n,spec).toFixed(spec.unit==='m³/kg'?2:1);
 }
 return text.replaceAll('°F','°C').replaceAll('GRAINS/LB DRY AIR','g/kg DRY AIR').replaceAll('BTU/LB','kJ/kg').replaceAll('Btu/lb','kJ/kg').replaceAll('ft³/lb','m³/kg').replaceAll('FT³/LB','m³/kg');
}
