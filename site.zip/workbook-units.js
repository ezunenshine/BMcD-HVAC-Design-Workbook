/* Engineering storage remains canonical IP. SI is a reversible presentation/input boundary. */
Object.defineProperty(globalThis,'si',{configurable:true,get(){return typeof activeProject==='function'&&activeProject()?.modelInputs?.unitSystem==='SI';}});
function siTable(t){return !!t&&!t.id.startsWith('iesve-')&&!t.energySimulation&&!t.energySummary&&(t.id.startsWith('calc-')||t.id.startsWith('selected-')||t.airsideSection||t.plantCalculation||t.psychCalculation||t.psychMixedCalculation);}
function unitSpec(unit,label=''){
 const u=String(unit||'').toLowerCase().replaceAll('²','2').replaceAll('³','3').replaceAll('·','-').replace(/\s/g,'');
 const r=(unit,factor,offset=0,digits=2)=>({unit,factor,offset,digits});
 if(u==='°f')return /difference|rise|delta|Δ/i.test(label)?r('K',5/9,0,1):r('°C',5/9,-160/9,1);
 if(u==='ft')return r('m',.3048);if(['ft2','sqft'].includes(u))return r('m²',.09290304);if(u==='ft3')return r('m³',.028316846592);
 if(u==='psia')return r('kPa',6.894757293);if(/in\.?w\.?g\.?|in\.water/.test(u))return r('Pa',249.08891);
 if(u==='mbh')return r('kW',.293071070172);if(u==='btu/h')return r('W',.293071070172);
 if(['btu/lb','btu/lbm'].includes(u))return r('kJ/kg',2.326,-17.86368,1);
 if(u==='gr/lb')return r('g/kg',1/7,0,3);if(u==='lb/lb')return r('g/kg',1000,0,3);
 if(['ft3/lb','ft3/lbm'].includes(u))return r('m³/kg',.062427960576,0,3);
 if(u==='btu/lb-°f'||u==='btu/lbm-r')return r('kJ/(kg·K)',4.1868,0,3);
 if(u==='lb/gal')return r('kg/m³',119.8264273,0,1);if(['lb/ft3','lbm/ft3'].includes(u))return r('kg/m³',16.01846337,0,2);
 if(u==='gpm')return r('L/min',3.785411784);if(['gph','usgal/h'].includes(u))return r('L/h',3.785411784);
 if(u==='inwc')return r('Pa',249.08891);if(u==='ftwc')return r('kPa',2.98906692);if(u==='ft/min')return r('m/s',.00508);if(u==='lbs')return r('kg',.45359237);if(u==='ton')return r('kW',3.516852842064);
 if(u==='ft/s')return r('m/s',.3048);
 if(u.startsWith('cfm')||u==='ft3/min/pers'){let f=28.316846592,suffix=u.replace(/^cfm|^ft3\/min/,'');if(/ft2|sqft/.test(suffix)){f/=.09290304;suffix='/m²';}return r('L/min'+suffix,f);}
 if(/^w\/ft2$/.test(u))return r('W/m²',1/.09290304);
 if(u.startsWith('btu/h-')){const area=/ft2/.test(u);return r(area?'W/m²':'W/person',.293071070172/(area?.09290304:1));}
 if(u==='ft2/person')return r('m²/person',.09290304);
 if(u==='people/ft2')return r('people/m²',1/.09290304);
 if(['people/1,000ft2','people/1000ft2'].includes(u))return r('people/100 m²',100/(1000*.09290304));
 if(u==='gal/person-day')return r('L/person-day',3.785411784);
 if(/sensible constant|^cs$/i.test(label)||u==='cs')return r('W/(L/min·K)',.293071070172*1.8/28.316846592,0,3);
 if(/latent constant|^cl$/i.test(label)||u==='cl')return r('W/(L/min·g/kg)',.293071070172*7/28.316846592,0,3);
 return null;
}
function tableUnitSpec(t,c){return siTable(t)?unitSpec(t.headers[c]?.unit,t.headers[c]?.label):null;}
function toSI(value,spec){return spec&&typeof value==='number'&&Number.isFinite(value)?value*spec.factor+spec.offset:value;}
function fromSI(value,spec){return spec&&typeof value==='number'&&Number.isFinite(value)?(value-spec.offset)/spec.factor:value;}
function unitValue(t,c,value){return si?toSI(value,tableUnitSpec(t,c)):value;}
function unitInput(t,c,raw){if(!si||raw===''||raw==null)return raw;const n=Number(String(raw).replaceAll(',',''));return Number.isFinite(n)?fromSI(n,tableUnitSpec(t,c)):raw;}
function unitHeader(t,c,h=t.headers[c]){const s=si&&tableUnitSpec(t,c);return s?{...h,unit:s.unit}:h;}
function unitLabel(text){if(!si)return text;return String(text).replace(/0\.3 in\. pressure differential/gi,'74.7 Pa pressure differential').replace(/\[([^\]]+)\]/g,(all,u)=>{const s=unitSpec(u,text);return s?'['+s.unit+']':all;});}
function unitEquation(e,s){if(!s||!si||!e||e.includes('unitIPValue'))return e;return `=LET(si,@si,unitIPValue,${e.replace(/^=/,'')},IF(ISNUMBER(unitIPValue),unitIPValue*IF(si,${s.factor},1)+IF(si,${s.offset},0),unitIPValue))`;}
function tableUnitEquation(t,c,e){return unitEquation(e,tableUnitSpec(t,c));}
function modelUnitSpec(k){return unitSpec(k==='elevation'?'ft':/Db$|Wb$/.test(k)?'°F':/HrGr$/.test(k)?'gr/lb':/Infiltration/.test(k)?'CFM/ft2':'');}
function modelUnitValue(k,v){return si?toSI(v,modelUnitSpec(k)):v;}
function modelUnitInput(k,v){return si?fromSI(v,modelUnitSpec(k)):v;}
function applyUnitColumns(t){if(!t.plantCalculation)return;t.ipHiddenColumns??=[...(t.hiddenColumns||[])];t.hiddenColumns=[...t.ipHiddenColumns,...(si?t.headers.flatMap((h,c)=>/^tons?$/i.test(h.unit||'')?[c]:[]):[])];}
function installPageExcel(){let b=document.querySelector('#export-current-excel');if(b)return;b=document.createElement('button');b.id='export-current-excel';b.className='copy-data-button';b.type='button';b.textContent='Export to Excel';document.querySelector('#page-title').after(b);b.onclick=exportCurrentPageExcel;}
function exportCurrentPageExcel(){
 if(!si&&activeTableId==='airside-schedules'&&!tableView.hidden)return exportEquipmentSchedules();
 const sheets=[];const tables=[...document.querySelectorAll('#psych-mixed-summary table,#reference-table')].filter(t=>t.getClientRects().length);
 for(const table of tables){const rows=[...table.rows].map(tr=>[...tr.cells].filter(td=>td.style.display!=='none').flatMap(td=>{const control=td.querySelector('input,select');const v=control?control.value:td.innerText.trim();const n=Number(v.replaceAll(',',''));return [v!==''&&Number.isFinite(n)?n:v,...Array(Math.max(0,(td.colSpan||1)-1)).fill('')];}));if(rows.length)sheets.push({name:table.id==='reference-table'?'Calculation':'Mixed-Air',rows});}
 if(!sheets.length){const fields=[...document.querySelectorAll('#model-inputs-view input,#model-inputs-view select')].filter(e=>e.getClientRects().length);sheets.push({name:'Page',rows:fields.length?fields.map(e=>[e.closest('label')?.querySelector('span')?.innerText||e.dataset.modelInput||'Value',e.value]):[[document.querySelector('#page-title').textContent],[document.querySelector('#module-content')?.innerText||'']]});}
 downloadWorkbookFile(simpleWorkbookExcel(sheets),(document.querySelector('#page-title').textContent||'Workbook').replace(/[^a-z0-9 -]/gi,'')+'.xlsx');
}
function simpleWorkbookExcel(sheets){
 const x=v=>String(v??'').replace(/[<>&"']/g,c=>({'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;',"'":'&apos;'}[c]));const letters=n=>{let s='';for(n++;n;n=Math.floor((n-1)/26))s=String.fromCharCode(65+(n-1)%26)+s;return s;};
 const files=[];sheets.forEach((s,i)=>files.push({name:`xl/worksheets/sheet${i+1}.xml`,bytes:new TextEncoder().encode(`<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>${s.rows.map((r,j)=>`<row r="${j+1}">${r.map((v,c)=>`<c r="${letters(c)}${j+1}"${typeof v==='number'?`><v>${v}</v>`:` t="inlineStr"><is><t xml:space="preserve">${x(v)}</t></is>`}</c>`).join('')}</row>`).join('')}</sheetData></worksheet>`)}));
 const add=(name,text)=>files.push({name,bytes:new TextEncoder().encode(text)});
 add('[Content_Types].xml',`<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>${sheets.map((_,i)=>`<Override PartName="/xl/worksheets/sheet${i+1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join('')}</Types>`);
 add('_rels/.rels','<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>');
 add('xl/workbook.xml',`<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>${sheets.map((s,i)=>`<sheet name="${x(s.name.slice(0,31))}" sheetId="${i+1}" r:id="rId${i+1}"/>`).join('')}</sheets></workbook>`);
 add('xl/_rels/workbook.xml.rels',`<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${sheets.map((_,i)=>`<Relationship Id="rId${i+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i+1}.xml"/>`).join('')}</Relationships>`);return WorkbookPrintPDF.zip(files);
}

function psychHeaderUnit259(label){const unit=label.match(/\[([^\]]+)\]$/)?.[1]||'';return si?(unitSpec(unit,label.split(' [')[0])?.unit||unit):unit;}
function psychStateInSelectedUnits(db,w,pressure,siMode=si){
 const temp=siMode?fromSI(db,unitSpec('°F')):db,ratio=siMode?fromSI(w,unitSpec('gr/lb')):w,p=siMode?fromSI(pressure,unitSpec('psia')):pressure;
 const result={wb:wetBulbFromState(temp,ratio,p),h:moistAirEnthalpy(temp,ratio),v:moistAirVolume(temp,ratio,p),rh:relativeHumidityForRatio(temp,ratio,p),...airConstantsForState(temp,ratio,p)};
 if(siMode)for(const [key,u]of Object.entries({wb:'°F',h:'Btu/lb',v:'ft³/lb',sensible:'Cs',latent:'Cl'}))result[key]=toSI(result[key],unitSpec(u));return result;
}
function psychChartLabelSI(text,a){
 if(!si)return text;
 const numeric=/^-?\d+(?:\.\d+)?$/.test(text),fill=a.fill;
 if(numeric){const n=Number(text);let spec;
  if(fill==='#b8860b')spec=unitSpec('°F');
  else if(fill==='#23864c')spec=unitSpec('Btu/lb');
  else if(fill==='#c0268a')spec=unitSpec('ft³/lb');
  else if(fill==='#59636e')spec=Number(a.y)>665?unitSpec('°F'):Number(a.x)>1018?unitSpec('gr/lb'):null;
  if(spec)return toSI(n,spec).toFixed(spec.unit==='m³/kg'?2:1);
 }
 return text.replaceAll('°F','°C').replaceAll('GRAINS/LB DRY AIR','g/kg DRY AIR').replaceAll('BTU/LB','kJ/kg').replaceAll('Btu/lb','kJ/kg').replaceAll('ft³/lb','m³/kg').replaceAll('FT³/LB','m³/kg');
}
