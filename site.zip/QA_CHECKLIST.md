# Manual browser QA — v3.184.0

Serve the extracted files over HTTP/HTTPS with `index.html` at the root. Use the same origin when testing existing browser-stored projects. This checklist records tests that could not be executed in the build environment.

## Projects and control

- [ ] Open and switch projects: View Only initially; printing, exporting, copying, and Evaluate available; editing blocked.
- [ ] Take Control: static mode clearly says browser-local editing; Connectivity is Unavailable. A second tab should not edit the same locally controlled project. Separate projects remain independent.
- [ ] If an authenticated host lease service is configured, test two actual clients, atomic ownership, Request Control, 15-second acknowledgments, 60-second failures/revocation, stale replies, and the 30-minute edit inactivity timeout.
- [ ] Heartbeat footer has one centered row of white icons/text on navy; pulse occurs with a displayed countdown change. Scrolling/viewing does not reset Activity; actual editing does.
- [ ] Browser context menu contains only Rename/Delete; both hover colors change. Rename changes project number only and allows correction after a rejected duplicate/blank entry. Separate existing project actions remain usable.
- [ ] Archive, open archive, restore archive, delete/restore project, browser refresh, and switching projects preserve their existing behavior and data.

## New and existing data

- [ ] Create independent projects A/B. All blue fields start blank except the permitted two Grouped Equipment rows and six Proposed/six Baseline construction assemblies. No prior project import/weather/plant values appear.
- [ ] Open an existing saved project. Check manual inputs, notes, source associations, overrides, filtering/sorting, and reload persistence. Humidity ratios must not convert twice.
- [ ] Import IESVE data with missing templates: Yes creates each once and finishes the same paste; No changes neither templates nor data. Reimport preserves manual people and other intentional overrides; rise stays blank unless manually entered.
- [ ] Check Real/Proposed/Baseline gains and numeric comparisons at ±0.01 Btu/h.
- [ ] Equipment density: edit, equal-default entry, different override, clear, reimport, reload, and downstream gains. Green/blue appearance remains correct when focus changes.
- [ ] Thermal Space Type editable; number of spaces calculated; first two columns frozen. No Ventilation Requirements gives both Ez dashes. Ez 1 and 1.0 keep the automatic appearance.

## Table interaction and Evaluate

- [ ] Click and navigate editable/calculated/locked cells: whole row highlights and purple cell outlines. Shift+Arrow expands immediately in every direction.
- [ ] Copy/paste one cell, A1:A5 into B1, 2D rectangles, full columns, filtered/sorted/reordered/hidden-column ranges. Include first cell and no extra destination rows.
- [ ] Copy calculated/locked displayed values; reject mixed invalid destinations atomically. Ctrl+X clears only after successful paste and respects overlaps/locks.
- [ ] Delete changes editable cells only; locked/formula/conditional cells remain intact. Remove row(s) removes all selected removable rows when selecting Space or Quantity columns and retains protected reference rows.
- [ ] Drag selection and fill scroll smoothly in both axes near/outside edges; stop on release/cancel; frozen panes remain aligned; lost control prevents completion of an edit/fill.
- [ ] Enter navigation scrolls an offscreen next cell to the visible bottom. Data stays on one line; headers wrap only at spaces; headers and frozen columns remain aligned while scrolling.
- [ ] Original Evaluate opens and Previous/Next/Restart/Final work. Highlight and Ctrl+C any substring in Evaluate/formula panels and normal inputs; table clipboard still works afterwards.
- [ ] Hover locked/calculated cells and links: full equation/explanation visible, explicit grains conversions correct, renamed tab destination matches tooltip.

## Engineering and export

- [ ] Setpoints: numeric/two-value/missing second value; RH from import; separate overrides; cooling rise priority; h/v immediately after each HR with correct colors, units, formatting, and Evaluate source.
- [ ] Model Inputs: only three weather rows; cooling HR from current DB/WB/elevation; no redundant lb/lb column; h whole, v/HR to 0.1; empty and invalid inputs remain distinguishable.
- [ ] Economizer: noncentral locked blank, central-only locked TRUE, combined central/vent editable blank/TRUE. CLG/HTG Recirc allowed; incompatible roles red.
- [ ] Airflows includes blue Ventilation before Relief and brown Exhaust headers. Mixed-Air follows Airflows and lists only economized ventilation units. Check 1/3 and 2/3 flows and a manual example using unequal specific volumes.
- [ ] Economizer ventilation coil entering conditions match the two Mixed-Air states; non-economizer weather fallback unchanged. Room entering HR/h/DB order, colors, group boundaries, plant associations, and actual mass mixing correct. Reheat and plant calculations still work.
- [ ] MET defaults/overrides persist independently; Thermal Template effective MET follows the reference. Appendix D references are protected and included in CO₂ output.
- [ ] CO₂ has exactly 13 columns and editable default criteria. Check threshold equality, high density, each fallback system, missing/zero ventilation, source row, and formulas. Download Excel/PDF: portrait, all columns legible, criteria/reference included.
- [ ] Mixed-Air table/chart appears above the coil table only for economized ventilation equipment; dashed purple/blue/green mixing; shared return and independent mixed-day states; solid coil processes elsewhere.
- [ ] Review chart labels/curves at 0/1000/2000/4000/10000/15000 ft, including 90°F, pressure, logo alignment, SV coverage, and neighboring enthalpy/WB ticks.
- [ ] Browser print preview and downloaded native PDF retain ṁ, V̇, Δ, subscripts, fraction bars, colors, dashed mixing, and all chart/table content.
