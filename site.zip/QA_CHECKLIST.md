# Manual browser QA — v3.185.0

All boxes below remain unverified in a real browser. Extract all files together, serve over HTTP/HTTPS, and use the same origin to retain access to existing browser projects. Back up important projects before migration QA.

## Data integrity first

- [ ] Open an existing v3.184 project. Confirm project fields, Tabular Space Data, templates, manual setpoints, overrides, notes, calculations, and archives are intact.
- [ ] Import a large Tabular Space Data file. Switch projects, leave Edit Mode, take control again, reload, and reopen the browser. Confirm all imported rows and manual values survive.
- [ ] Confirm IndexedDB migration retains original localStorage and a legacy recovery record. Verify previous project revisions survive successful later commits.
- [ ] With a disposable test profile, simulate storage failure. Confirm a clear save error, retained current values, Retry, Download recovery, and navigation warning. Restore the downloaded JSON as separate recovered projects; existing projects must remain intact.
- [ ] Simulate stale concurrent saves in two tabs. Confirm the second conflicting write does not overwrite the first. Test recovery after the visible conflict error.

## Editing and imports

- [ ] In People Gains, type Manual People using ordinary typing/F2/double-click. Verify visible typing, Enter/Tab/click-away commit, downstream Actual People/load, save/reload, and blank automatic fallback.
- [ ] Repeat typing/commit/reopen in Equipment and Lighting Gains, including cells with automatic/default or grey unused styling.
- [ ] Change all three CO₂ criteria, tab between them, click elsewhere, Restore defaults, Evaluate, save and reopen. Confirm no crash and immediate dependent updates. Invalid/negative text must preserve the previous value.
- [ ] Import a new space with numeric/two-value setpoints and RH. Confirm initialization as blue inputs without source equations; heating/cooling schedules and HR/h/v still calculate.
- [ ] Change only one setpoint in a saved row and reimport altered source temperatures. Existing values and intentionally blank inputs must remain. Test cooling Ventilated Temperature Rise.
- [ ] Test the formerly failing Room/Zone XLSX, including custom worksheet names and the first data row. Check sensible versus percent columns, latent/heating values, inherited zone names, units, and invalid-file rejection.
- [ ] Test IESVE missing-template Yes/No import flow and project isolation. Manual People must begin blank.

## Projects and editing control

- [ ] New projects immediately contain all frozen Thermal Templates, preserve allowed custom templates, and cannot rename/remove built-ins. Grouped Equipment and twelve construction defaults remain.
- [ ] Rename/Delete menu has only those two actions, matching bold dimensions/radius/border, blue/red colors, and hover changes. Rename dialog has only “Rename Project Number”.
- [ ] Add works in Cooling Plant, Heating Plant, Lighting Schedule, Equipment Sensible Gain Schedule, and other editable schedules after repeated Edit/View transitions. View Only/fixed tables must block mutation.
- [ ] Project fields, archive/restore, delete/restore, pins, duplicate project numbers, project changes during async operations, and switching projects retain prior behavior.
- [ ] Mouse movement, cell clicks, keyboard input, selection, edits, and navigation reset Activity to 30:00. Continuous movement must not cause project saves/server calls.
- [ ] Heartbeat appears directly below Open Export Window; white outline, navy compact styling, one active pulse/second. View Only/Archived/Deleted show --:-- for both timers; deleted uses an unpulsed broken heart.
- [ ] Local editing displays Connectivity Unavailable; the removed browser-local notice must not appear above Add Project.
- [ ] With a real authenticated host service, test two clients, atomic Take Control/Request Control/revocation, 15-second heartbeats, reset only on a valid acknowledgment, one-second decrement, 60-second loss release, and 30-minute inactivity release. This cannot pass without a backend.

## Calculations, charts, and exports

- [ ] Heating weather shows green 0.0 gr/lb; existing manual nonzero values remain. Weather columns have equal widths, fill the section, and put units on their own line without splitting words.
- [ ] Construction controls alone use + and − in the gutter; Assembly left edge aligns with other fields.
- [ ] Thermal Template heading and Number of Spaces work; MET defaults show literal equations, overrides persist blue and propagate, and Thermal MET has no hyperlink.
- [ ] Equipment density becomes grey when Detailed Equipment Gains is present and normal again when cleared, without losing its override.
- [ ] Airflows Ventilation matches existing Ventilation Blue; all Exhaust headers match existing Exhaust Brown.
- [ ] CO₂ missing/zero/invalid ventilation propagates a dash into People/Space/Alarm concentration. Unmonitored spaces keep their blank condition.
- [ ] Appendix D is an editable/removable green default in References, supports Restore, preserves user references, and has no extra header row.
- [ ] CO₂ page has no Excel button or historical explanation. In Open Export Window, test portrait PDF and CO₂ Excel, Space sorting and filters, references, constants, and actual downloads.
- [ ] Only Detailed Equipment Gains, General Exhaust Requirements, Exhaust Equipment Requirements, and Transfer Air lose totals. Check other totals and energy baseline equation inspection.
- [ ] Test GL-04 rectangular paste, first/last cells, locked/calculated rejection, native equation substring copying, Ctrl+X followed by valid/invalid paste, fill/drag/scroll, and canceled/read-only operations.
- [ ] Test MX-01–08: six sections, actual dry-air mass weighting, both outdoor design days and mixed states, economizer entering conditions, room heating/cooling mass mixtures, and derived dry-bulb.
- [ ] Test PC-04–06/09: mixed table only when applicable, both days' independent points, dashed mixing/solid coil lines, and HR/h/v precision.
- [ ] At narrow and wide browser widths, verify the coil table does not cover the chart and boundary/90°F labels remain visible. Check scrolling and changing equipment.
- [ ] Inspect browser and PDF “MIXED-AIR”, separated V dot, dotted mass variables/subscripts, and single-line W/h mixing equations. Print at all supported elevations and compare browser/PDF geometry.
- [ ] Use original Evaluate, Previous, Next, Restart, and Final on simple formulas, humidity conversion, MET literals, mixed-air and coil equations. Confirm the supplied debugger remains functional.
