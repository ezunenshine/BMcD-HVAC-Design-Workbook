# Manual browser QA — v3.186.0

Every checkbox below remains unverified in a real browser. Automated model/native-file checks are separately recorded in AUTOMATED_TEST_RESULTS.txt. Extract all files together and serve over HTTP/HTTPS. Use a disposable copy of important project data for migration/failure tests and retain the same origin when testing existing projects.

## Projects, control and storage

- [ ] Confirm project numbers sort naturally descending (e.g. 100, 20, 9, 2). Rename changes only Project Number; Rename/Delete styling and hover still work. Recovery-import control and archive notice are absent.
- [ ] Take Control of a local project without any Azure service. Editing works; Connectivity reads Local. Verify no fake 01:00 server acknowledgment appears.
- [ ] Open a project in two tabs. Confirm a living owner keeps control; close it and verify stale/phantom control can be recovered. Test background tabs and browsers without BroadcastChannel. Request Control must require a verified foreign service editor.
- [ ] If a real complete lease service is available, verify successful matching acknowledgments reset to 01:00, a second passes each countdown tick, requests occur every 15 seconds, and failures/invalid tokens never reset success. Verify expiry and View Only preserve pending edits.
- [ ] Inspect the single-line navy footer: white outline heart, subtle second pulse, same font/alignment as version, matching Add Project/Export dividers. View Only/Archived/Deleted show --:--; Deleted shows a still broken heart. Footer reads v3.186.0.
- [ ] Reopen an existing v3.185 project and older supported project. Confirm all imported rows, overrides, assignments, notes, templates, archives, and project independence remain.
- [ ] Import a large dataset, switch projects, leave/reenter Edit Mode and reload. Confirm durable data survives. With disposable storage, simulate failed saves/quota and stale concurrent writes; verify retained pending edits, visible error, Retry/Download recovery and navigation warning.

## Cells, paste and Evaluate

- [ ] Copy A1:B2, paste at C1 with C1/C2/D1 locked and D2 editable. Only D2 changes, receiving B2. Repeat with multi-row selections and automatic override destinations; no shifting occurs.
- [ ] Repeat as Cut: only the source position successfully written is cleared. Copy locked/calculated source cells. Invalid editable numeric inputs must still reject the paste without partial changes.
- [ ] Focus an input, automatic cell, overridden cell, conditional locked cell, calculated cell and protected imported cell. Confirm Evaluate is available and actual values/conditions appear.
- [ ] Verify Userinput(), Autopopulate(default), and Autopopulate(default,Userinput()). Automatic result and override are separately labeled. Test Restart/Previous/Next/Final, arrow keys, Escape, and ordinary text selection/copy in the original evaluator.
- [ ] Confirm redundant cell formula popups are absent while header tooltips, validation messages and hyperlinks still work. Restore still clears an override rather than opening Evaluate.
- [ ] Verify People/Equipment/Lighting direct typing, F2/double-click, Enter/Tab/blur, Escape and save/reopen.

## Zoning, exhaust and Air Balance

- [ ] Confirm locked System Type is directly after Space. Test CVZ (no Central/no general valve), VC (combined without economizer), EVC (combined with economizer), CVC (different Central/Ventilation), and VC with no Central but a general valve.
- [ ] Confirm every space appears in exactly one correct balance table. Change equipment and Economizer; verify immediate row migration and correct hyperlinks/filtering/export.
- [ ] Populate Cooling Equipment and then General Exhaust Valve through valid transitions. The opposite cell becomes blank/grey/locked; prior saved choices survive suppression. Reheat uses Supply Valve whenever Central exists, regardless of Heating Equipment.
- [ ] Exhaust Valve is editable/automatic only for VC; other types show blank/grey/locked while retaining saved inactive assignments. Exhaust Equipment assignment is calculated. The separate equipment schedule selection remains editable.
- [ ] Confirm Equipment Max/Min include all detail rows, Different Valve Max/Min exclude the general valve, occupied flows use MAX(equipment,general)+additional, and unoccupied min uses MAX(equipment,general). Removed same-valve columns stay absent from screen/export.
- [ ] VC: task quantity counts unique different valves; quantity is after unoccupied exhaust. Check all six brown breakdown columns/totals and general-valve count. General maximum subtracts task MINIMUM; general minima subtract task MAXIMUM and clamp at zero.
- [ ] Export VC with no valves, task-only, general-only, both, and filtered rows. Empty task/general groups disappear only in export; all columns remain in the interactive table.
- [ ] EVC: verify Maximum Central Relief, Maximum Valve Return, and Minimum Occupied Central Relief; relief uses brown styling and correct source/print headers.

## Airflows and gains

- [ ] Confirm section order Cooling → Heating → Ventilation → Return → Relief → Exhaust; Relief is brown. Heating PFP and Return Minimum Unoccupied are absent from screen/export.
- [ ] Independently total all eight Return source contributions and economized supply/3. Check occupied return, all Ventilation branches and the three Relief sums against corresponding source balance rows.
- [ ] Test equipment and valve tags that coincide; verify a source contribution is not added twice. Test multiple task valves, shared spaces, and balance tables of unequal sizes.
- [ ] Check Exhaust max/occupied min/unoccupied min with and without economizer. Compare the non-economized occupied minimum with the prior release. Confirm mixed-air/coil states update after revised flows.
- [ ] Disable People/Equipment/Lighting gains: applicable inputs grey/lock, saved Manual People and density overrides remain, and detailed equipment/lighting totals still calculate grey. Reactivate and confirm styling/values restore.
- [ ] Change MET, verify blue override and dependent Thermal/CO₂ results; reload; clear and confirm green literal default. Add/clear Detailed Equipment Gain and verify density text greys/restores without losing its override.

## Imports, charts and exports

- [ ] Import the supplied RM LOADS_p_loads.xlsx. Confirm 139 rooms. Destination is MBH: the first room sensible/latent/heating values are 15.86906879824389, 0.414451912321849, 1.440929883105731 before display rounding. No ×1000 or other scaling applies.
- [ ] Test invalid XLSX rejection and existing import layouts. Reimport existing space setpoints/RH; preserve manual edits and intentionally cleared inputs.
- [ ] Confirm Required beside Design Weather Data. Import new Thermal Templates: original paste completes, then Thermal Templates opens with all newly created rows selected.
- [ ] In Calculation View, test wide/narrow screens and horizontal/vertical table scrolling; table and psychrometric chart must not overlap. Confirm Qs, Ql and Mixed-Air dots sit above V.
- [ ] PC-04/05/06/07/09: toggle economizer; inspect mixed-air table visibility, independently placed mixed states, dashed mixing/solid coil lines, single-line mixed equations, and HR/h/v precision. Compare printed chart appearance.
- [ ] Change all CO₂ criteria, blur/tab, restore, Evaluate and reload without a crash. Blank source People returns 0; invalid ventilation retains the established dash behavior.
- [ ] Confirm no CO₂-specific Export button. Main Export Window includes CO₂, sorted by Space, portrait, with References. Check native downloads, PDF preview and actual printing.
- [ ] Print new System Type, exhaust requirements, VC/EVC and Airflows; verify headers, divider positions, totals, column visibility, hyperlinks and text alignment at realistic project sizes.
- [ ] Recheck previously passing plant/schedule Add, frozen built-in Thermal Templates, construction controls, energy baselines, mass-weighted mixed-air calculations, project archives and independent project data.
