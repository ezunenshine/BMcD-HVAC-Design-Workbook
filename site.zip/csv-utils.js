(function initializeCsvTools(global) {
  function parse(text) {
    const source = String(text ?? "").replace(/^\uFEFF/, "");
    const rows = [];
    let row = [];
    let field = "";
    let quoted = false;

    for (let index = 0; index < source.length; index += 1) {
      const character = source[index];
      if (quoted) {
        if (character === '"' && source[index + 1] === '"') {
          field += '"';
          index += 1;
        } else if (character === '"') {
          quoted = false;
        } else {
          field += character;
        }
      } else if (character === '"' && field === "") {
        quoted = true;
      } else if (character === ",") {
        row.push(field);
        field = "";
      } else if (character === "\r" || character === "\n") {
        row.push(field);
        rows.push(row);
        row = [];
        field = "";
        if (character === "\r" && source[index + 1] === "\n") index += 1;
      } else {
        field += character;
      }
    }

    if (quoted) throw new Error("The CSV contains an unfinished quoted value.");
    if (field !== "" || row.length) {
      row.push(field);
      rows.push(row);
    }
    while (rows.length && rows.at(-1).every((value) => value === "")) rows.pop();
    return rows;
  }

  function stringify(rows) {
    const escape = (value) => {
      const text = String(value ?? "");
      return /[",\r\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
    };
    return rows.map((row) => row.map(escape).join(",")).join("\r\n");
  }

  function normalizeHeader(value) {
    return String(value ?? "").replace(/^\uFEFF/, "").trim().replace(/\s+/g, " ").toLowerCase();
  }

  global.CsvTools = { parse, stringify, normalizeHeader };
}(globalThis));
