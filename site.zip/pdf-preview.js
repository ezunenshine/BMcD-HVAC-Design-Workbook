/* Canvas preview uses the bundled renderer, never the browser's PDF download handler. */
function createWorkbookPDFPreview(container,onPageChange=()=>{}) {
  let pdf=null,loading=null,observer=null,revision=0,currentPage=1,disposed=false,renderTasks=new Set(),resizeTimer;
  const updatePage=()=>{const top=container.getBoundingClientRect().top;let nearest=null,distance=Infinity;for(const page of container.querySelectorAll('.pdf-preview-page')){const delta=Math.abs(page.getBoundingClientRect().top-top-12);if(delta<distance){nearest=page;distance=delta;}}if(nearest){currentPage=Number(nearest.dataset.page);onPageChange(currentPage,pdf?.numPages||0);}};
  container.addEventListener('scroll',updatePage,{passive:true});
  async function clear(){const version=++revision;observer?.disconnect();observer=null;for(const task of renderTasks)task.cancel();renderTasks.clear();container.replaceChildren();const old=pdf,oldLoading=loading;pdf=null;loading=null;await old?.destroy();await oldLoading?.destroy();return version;}
  async function show(bytes){
    const version=await clear();if(disposed||version!==revision)return;
    const module=await import('./pdf-preview.mjs?v=20261008-export29');if(version!==revision||disposed)return;
    module.GlobalWorkerOptions.workerSrc=new URL('pdf-preview-worker.mjs',document.baseURI).href;
    const task=module.getDocument({data:bytes.slice(),isEvalSupported:false,useWasm:false});loading=task;const documentPDF=await task.promise;if(version!==revision||disposed){await documentPDF.destroy();return;}loading=null;pdf=documentPDF;
    const width=Math.max(200,container.clientWidth-32),ratio=Math.min(Math.max(window.devicePixelRatio||1,2),3),pages=[];
    async function drawPage(wrapper){
      if(wrapper.dataset.rendered||version!==revision)return;wrapper.dataset.rendered='true';
      try{const page=await pdf.getPage(Number(wrapper.dataset.page));if(version!==revision)return;const base=page.getViewport({scale:1}),viewport=page.getViewport({scale:width/base.width}),canvas=document.createElement('canvas');canvas.width=Math.ceil(viewport.width*ratio);canvas.height=Math.ceil(viewport.height*ratio);canvas.style.width=viewport.width+'px';canvas.style.height=viewport.height+'px';canvas.setAttribute('aria-label',`Page ${wrapper.dataset.page}`);wrapper.replaceChildren(canvas);const render=page.render({canvasContext:canvas.getContext('2d'),viewport,transform:ratio===1?null:[ratio,0,0,ratio,0,0]});renderTasks.add(render);try{await render.promise;}finally{renderTasks.delete(render);}}
      catch(error){if(error.name!=='RenderingCancelledException'&&version===revision){wrapper.textContent='This page could not be rendered. '+error.message;wrapper.classList.add('pdf-page-error');}}
    }
    const first=await pdf.getPage(1),firstViewport=first.getViewport({scale:1});if(version!==revision)return;
    for(let number=1;number<=pdf.numPages;number++){const wrapper=document.createElement('article');wrapper.className='pdf-preview-page';wrapper.dataset.page=number;wrapper.style.width=width+'px';wrapper.style.minHeight=(width*firstViewport.height/firstViewport.width)+'px';wrapper.textContent=`Page ${number}`;container.appendChild(wrapper);pages.push(wrapper);}
    if(typeof IntersectionObserver==='function'){observer=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){observer.unobserve(entry.target);drawPage(entry.target);}}),{root:container,rootMargin:'800px'});pages.forEach(page=>observer.observe(page));}
    else for(const page of pages)await drawPage(page);
    await drawPage(pages[0]);container.scrollTop=0;currentPage=1;onPageChange(1,pdf.numPages);
  }
  const resize=new ResizeObserver(()=>{clearTimeout(resizeTimer);resizeTimer=setTimeout(()=>{const width=container.clientWidth-32;for(const page of container.querySelectorAll('.pdf-preview-page')){page.style.width=Math.max(200,width)+'px';page.style.minHeight='0';const canvas=page.querySelector('canvas');if(canvas){canvas.style.width='100%';canvas.style.height='auto';}}},150);});resize.observe(container);
  return {show,clear,go(delta){const page=container.querySelector(`[data-page="${Math.max(1,Math.min(pdf?.numPages||1,currentPage+delta))}"]`);if(page)container.scrollTo({top:container.scrollTop+page.getBoundingClientRect().top-container.getBoundingClientRect().top-12,behavior:'smooth'});},async destroy(){disposed=true;resize.disconnect();clearTimeout(resizeTimer);container.removeEventListener('scroll',updatePage);await clear();}};
}
