/* Offline PDF generation. A single layout function powers preview and export. */
const WorkbookPrintPDF = (() => {
  const clean=value=>String(value??'').replace(/[\u2080-\u2089]/g,c=>String(c.charCodeAt(0)-0x2080)).replace(/²/g,'2').replace(/³/g,'3').replace(/≥/g,'>=').replace(/≤/g,'<=').replace(/−/g,'-').replace(/→/g,' -> ').replace(/\u00a0/g,' ').replace(/[^\x20-\x7e\xa0-\xff\n]/g,' ');
  const rgb=hex=>PDFLib.rgb(parseInt(hex.slice(1,3),16)/255,parseInt(hex.slice(3,5),16)/255,parseInt(hex.slice(5,7),16)/255);
  function wrap(text,width,font,size) {
    const lines=[];
    for(const paragraph of clean(text).split('\n')){
      let line='';for(const word of paragraph.split(/\s+/)){
        if(font.widthOfTextAtSize((line?line+' ':'')+word,size)<=width){line+=(line?' ':'')+word;continue;}
        if(line){lines.push(line);line='';}
        for(const letter of word){if(font.widthOfTextAtSize(line+letter,size)>width&&line){lines.push(line);line='';}line+=letter;}
      }lines.push(line);
    }return lines;
  }
  function embeddedFont(doc,metadata) {
    const context=doc.context,bytes=Uint8Array.from(atob(metadata.data),c=>c.charCodeAt(0)),fontFile=context.register(context.flateStream(bytes,{Length1:bytes.length}));
    const descriptor=context.register(context.obj({Type:'FontDescriptor',FontName:metadata.name,Flags:32,FontBBox:metadata.bbox,ItalicAngle:0,Ascent:metadata.ascent,Descent:metadata.descent,CapHeight:metadata.ascent,StemV:80,FontFile2:fontFile}));
    const mapping=new Uint8Array(512);metadata.glyphs.forEach((glyph,c)=>{mapping[c*2]=glyph>>8;mapping[c*2+1]=glyph&255;});
    const descendant=context.register(context.obj({Type:'Font',Subtype:'CIDFontType2',BaseFont:metadata.name,CIDSystemInfo:{Registry:PDFLib.PDFString.of('Adobe'),Ordering:PDFLib.PDFString.of('Identity'),Supplement:0},FontDescriptor:descriptor,DW:1000,W:[0,metadata.widths],CIDToGIDMap:context.register(context.flateStream(mapping))}));
    const cmap='/CIDInit /ProcSet findresource begin\n12 dict begin\nbegincmap\n/CIDSystemInfo << /Registry (Adobe) /Ordering (UCS) /Supplement 0 >> def\n/CMapName /WorkbookLatin def\n/CMapType 2 def\n1 begincodespacerange\n<0000> <00FF>\nendcodespacerange\n1 beginbfrange\n<0000> <00FF> <0000>\nendbfrange\nendcmap\nCMapName currentdict /CMap defineresource pop\nend\nend';
    const ref=context.register(context.obj({Type:'Font',Subtype:'Type0',BaseFont:metadata.name,Encoding:'Identity-H',DescendantFonts:[descendant],ToUnicode:context.register(context.flateStream(cmap))}));
    const embedder=PDFLib.StandardFontEmbedder.for(PDFLib.StandardFonts.Helvetica);embedder.fontName=metadata.name;
    embedder.encodeText=text=>PDFLib.PDFHexString.of([...text].map(c=>c.charCodeAt(0).toString(16).padStart(4,'0')).join(''));
    embedder.widthOfTextAtSize=(text,size)=>[...text].reduce((n,c)=>n+(metadata.widths[c.charCodeAt(0)]||0),0)*size/1000;
    embedder.heightOfFontAtSize=(size,options={})=>(metadata.ascent-(options.descender===false?0:metadata.descent))*size/1000;
    embedder.sizeOfFontAtHeight=height=>height*1000/(metadata.ascent-metadata.descent);embedder.embedIntoContext=async()=>ref;
    return PDFLib.PDFFont.of(ref,doc,embedder);
  }
  async function create(model,project,orientation='auto') {
    const doc=await PDFLib.PDFDocument.create(),normal=embeddedFont(doc,WorkbookPrintFonts.regular),bold=embeddedFont(doc,WorkbookPrintFonts.bold);
    doc.setTitle(model.title);doc.setAuthor(project.made_by||'');doc.setSubject('HVAC Design Workbook');
    const size=8,lineHeight=10,pad=5,margin=30;
    const measure=(text,font=normal)=>font.widthOfTextAtSize(clean(text).replace(/\n/g,' '),size);
    const columns=model.columns.map((c,i)=>({...c,index:i,width:Math.min(c.maxWidth||170,Math.max(c.minWidth||48,Math.max(...clean(c.label).split(/[\s-]+/).map(word=>measure(word,bold)))+pad*2,...model.rows.map(r=>Math.min(170,Math.max(...clean(r.values[i]).split('\n').map(line=>measure(line,r.bold||r.boldColumns?.includes(i)?bold:normal)+pad*2))))))}));
    const totalWidth=columns.reduce((sum,c)=>sum+c.width,0),landscape=orientation==='landscape'||orientation==='auto'&&(totalWidth>552||model.chart);
    const pageSize=landscape?[792,612]:[612,792],available=pageSize[0]-margin*2;
    // Wide tables continue horizontally with their identity columns repeated.
    const identity=columns.filter(c=>c.frozen),identityWidth=identity.reduce((n,c)=>n+c.width,0);
    if(identityWidth>available*.48){const scale=available*.48/identityWidth;identity.forEach(c=>c.width=Math.max(40,c.width*scale));}
    const rest=columns.filter(c=>!c.frozen),bands=[];let band=[...identity],width=identity.reduce((n,c)=>n+c.width,0);
    for(const column of rest){if(width+column.width>available&&band.some(c=>!c.frozen)){bands.push(band);band=[...identity];width=identity.reduce((n,c)=>n+c.width,0);}if(column.width>available-width)column.width=Math.max(40,available-width);band.push(column);width+=column.width;}
    if(band.length)bands.push(band);if(!bands.length)bands.push(columns);
    let page,y;const pageMeta=[];
    const text=(value,x,top,font=normal,color='#051c38',fontSize=size)=>page.drawText(clean(value),{x,y:top-fontSize,size:fontSize,font,color:rgb(color)});
    const header=(part)=>{
      page=doc.addPage(pageSize);y=pageSize[1]-margin;
      const titleLines=wrap(model.title+(part>=0&&bands.length>1?` — columns ${part+1}/${bands.length}`:''),available,bold,13);
      for(const line of titleLines){text(line,margin,y,bold,'#003b8c',13);y-=16;}y-=7;
      const date=project.dateMode==='today'?new Date().toLocaleDateString():project.date||'';
      const fields=[['Client',project.client],['Project',project.name],['Project number',project.number],['Date',date],['Made by',project.made_by],['Checked by',project.checked_by],['Submittal',project.submittal]];
      for(let i=0;i<fields.length;i+=2){let height=0;for(let j=0;j<2&&i+j<fields.length;j++){const [label,value]=fields[i+j],lines=wrap(`${label}: ${value||''}`,available/2-12,normal,size);height=Math.max(height,lines.length*lineHeight);lines.forEach((line,k)=>text(line,margin+j*available/2,y-k*lineHeight));}y-=height+3;}
      for(const line of wrap(model.filterDescription||'',available,normal,7)){if(line){text(line,margin,y,normal,'#51636e',7);y-=10;}}
      for(const value of model.topLines||[])for(const line of wrap(value,available,normal,size)){text(line,margin,y);y-=12;}
      y-=8;pageMeta.push(page);
    };
    const drawHeaders=band=>{
      const groups=[];for(const c of band){const prev=groups.at(-1);if(prev&&prev.name===(c.group||''))prev.width+=c.width;else groups.push({name:c.group||'',width:c.width,color:c.groupColor||c.color||'#003b8c'});}
      if(groups.some(g=>g.name)){
        const height=Math.max(20,...groups.map(g=>wrap(g.name,g.width-pad*2,bold,size).length*lineHeight+pad*2));let x=margin;
        for(const g of groups){page.drawRectangle({x,y:y-height,width:g.width,height,color:rgb(g.color),borderColor:rgb('#c7d1d8'),borderWidth:.5});wrap(g.name,g.width-pad*2,bold,size).forEach((line,i)=>text(line,x+pad,y-pad-i*lineHeight,bold,'#ffffff'));x+=g.width;}y-=height;
      }
      const height=Math.max(...band.map(c=>wrap(c.label,c.width-pad*2,bold,size).length*lineHeight+pad*2));let x=margin;
      for(const c of band){page.drawRectangle({x,y:y-height,width:c.width,height,color:rgb(c.color||'#003b8c'),borderColor:rgb('#c7d1d8'),borderWidth:.5});wrap(c.label,c.width-pad*2,bold,size).forEach((line,i)=>text(line,x+pad,y-pad-i*lineHeight,bold,'#ffffff'));x+=c.width;}y-=height;
    };
    bands.forEach((band,part)=>{
      header(part);drawHeaders(band);
      if(!model.rows.length){text('No rows match the selected filters.',margin+pad,y-pad);y-=24;}
      for(const row of model.rows){
        const wrapped=band.map(c=>wrap(row.values[c.index],c.width-pad*2,row.bold||row.boldColumns?.includes(c.index)?bold:normal,size));
        let offset=0,maxLines=Math.max(1,...wrapped.map(lines=>lines.length));
        while(offset<maxLines){
          if(y<margin+lineHeight+pad*2+20){header(part);drawHeaders(band);}
          const room=Math.max(1,Math.floor((y-margin-20-pad*2)/lineHeight)),count=Math.min(maxLines-offset,room),height=count*lineHeight+pad*2;let x=margin;
          band.forEach((c,i)=>{
            const color=row.backgrounds?.[c.index]||row.fill||(row.total?'#e4eaf0':'#ffffff');
            page.drawRectangle({x,y:y-height,width:c.width,height,color:rgb(color),borderColor:rgb('#bdcad2'),borderWidth:.4});
            if(c.divider)page.drawLine({start:{x,y},end:{x,y:y-height},color:rgb('#627781'),thickness:1.5});
            if(row.divider&&offset===0)page.drawLine({start:{x,y},end:{x:x+c.width,y},color:rgb('#627781'),thickness:1.5});
            const font=row.bold||row.boldColumns?.includes(c.index)?bold:normal;
            wrapped[i].slice(offset,offset+count).forEach((line,j)=>{const left=c.numeric?x+c.width-pad-font.widthOfTextAtSize(line,size):x+pad;text(line,left,y-pad-j*lineHeight,font,row.textColors?.[c.index]||'#051c38');});x+=c.width;
          });y-=height;offset+=count;
        }
      }
    });
    if(model.chart){
      header(-1);const image=await doc.embedPng(model.chart.image),chartWidth=available,chartHeight=chartWidth*1014/1318;
      // Give the chart its own landscape sheet so the image keeps its calibrated aspect ratio.
      const scale=Math.min(chartWidth/1318,(y-margin-20)/1014),left=margin,base=y-1014*scale;
      page.drawImage(image,{x:left,y:base,width:1318*scale,height:1014*scale});
      for(const line of model.chart.lines){const points=line.points.map(p=>({x:left+p.x*scale,y:base+(1014-p.y)*scale})),color=rgb(line.color);
        for(let j=1;j<points.length;j++)page.drawLine({start:points[j-1],end:points[j],color,thickness:1.6});
        const lengths=points.slice(1).map((p,j)=>Math.hypot(p.x-points[j].x,p.y-points[j].y));let remain=lengths.reduce((a,b)=>a+b,0)/2;
        for(let j=0;j<lengths.length;j++){if(remain<=lengths[j]&&lengths[j]){const a=points[j],b=points[j+1],t=remain/lengths[j],x=a.x+(b.x-a.x)*t,y=a.y+(b.y-a.y)*t,angle=Math.atan2(b.y-a.y,b.x-a.x);for(const sign of [-1,1])page.drawLine({start:{x,y},end:{x:x-6*Math.cos(angle)+sign*3*Math.sin(angle),y:y-6*Math.sin(angle)-sign*3*Math.cos(angle)},color,thickness:1.6});break;}remain-=lengths[j];}
        for(const [i,p] of [points[0],points.at(-1)].entries())page.drawCircle({x:p.x,y:p.y,size:2.5,color:i?color:rgb('#ffffff'),borderColor:color,borderWidth:1});
      }
    }
    doc.getPages().forEach((p,i)=>{p.drawText(`HVAC Design Workbook  |  ${clean(project.number)}  |  ${i+1} / ${doc.getPageCount()}`,{x:margin,y:16,size:7,font:normal,color:rgb('#51636e')});});
    return await doc.save();
  }
  // ZIP fallback bundles independent PDF files without relying on network services.
  function zip(files) {
    const encoder=new TextEncoder(),parts=[],central=[];let offset=0;
    const crc=bytes=>{let c=0xffffffff;for(const b of bytes){c^=b;for(let k=0;k<8;k++)c=(c>>>1)^((c&1)?0xedb88320:0);}return (c^0xffffffff)>>>0;};
    const record=(length,values)=>{const a=new Uint8Array(length),v=new DataView(a.buffer);for(const [at,value,size] of values)size===2?v.setUint16(at,value,true):v.setUint32(at,value,true);return a;};
    for(const file of files){const name=encoder.encode(file.name),bytes=file.bytes,check=crc(bytes);const local=record(30,[[0,0x04034b50,4],[4,20,2],[6,0x800,2],[14,check,4],[18,bytes.length,4],[22,bytes.length,4],[26,name.length,2]]);parts.push(local,name,bytes);const entry=record(46,[[0,0x02014b50,4],[4,20,2],[6,20,2],[8,0x800,2],[16,check,4],[20,bytes.length,4],[24,bytes.length,4],[28,name.length,2],[42,offset,4]]);central.push(entry,name);offset+=30+name.length+bytes.length;}
    const length=central.reduce((n,a)=>n+a.length,0),end=record(22,[[0,0x06054b50,4],[8,files.length,2],[10,files.length,2],[12,length,4],[16,offset,4]]);return new Blob([...parts,...central,end],{type:'application/zip'});
  }
  return {create,zip,wrap};
})();
