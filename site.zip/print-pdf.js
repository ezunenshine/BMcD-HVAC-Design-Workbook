/* Offline PDF generation. A single layout function powers preview and export. */
const WorkbookPrintPDF = (() => {
  const clean=value=>String(value??'').replace(/[\u2080-\u2089]/g,c=>String(c.charCodeAt(0)-0x2080)).replace(/≥/g,'>=').replace(/≤/g,'<=').replace(/−/g,'-').replace(/→/g,' -> ').replace(/[’‘]/g,"'").replace(/[–—]/g,'-').replace(/\u00a0/g,' ').replace(/[^\x20-\x7e\xa0-\xff\n]/g,' ');
  const rgb=hex=>PDFLib.rgb(parseInt(hex.slice(1,3),16)/255,parseInt(hex.slice(3,5),16)/255,parseInt(hex.slice(5,7),16)/255);
  function wrap(value,width,font,size) {
    const lines=[];for(const paragraph of clean(value).split('\n')){let current='';const words=paragraph.match(/[^\s-]+-?|-/g)||[];for(const word of words){const gap=current&&!current.endsWith('-')?' ':'';const next=current+gap+word;if(!current||font.widthOfTextAtSize(next,size)<=width+.05)current=next;else{lines.push(current);current=word;}}lines.push(current);}return lines;
  }
  function embeddedFont(doc,metadata) {
    const context=doc.context,bytes=Uint8Array.from(atob(metadata.data),c=>c.charCodeAt(0)),fontFile=context.register(context.flateStream(bytes,{Length1:bytes.length}));
    const descriptor=context.register(context.obj({Type:'FontDescriptor',FontName:metadata.name,Flags:32,FontBBox:metadata.bbox,ItalicAngle:0,Ascent:metadata.ascent,Descent:metadata.descent,CapHeight:metadata.ascent,StemV:80,FontFile2:fontFile}));
    const mapping=new Uint8Array(512);metadata.glyphs.forEach((glyph,c)=>{mapping[c*2]=glyph>>8;mapping[c*2+1]=glyph&255;});
    const descendant=context.register(context.obj({Type:'Font',Subtype:'CIDFontType2',BaseFont:metadata.name,CIDSystemInfo:{Registry:PDFLib.PDFString.of('Adobe'),Ordering:PDFLib.PDFString.of('Identity'),Supplement:0},FontDescriptor:descriptor,DW:1000,W:[0,metadata.widths],CIDToGIDMap:context.register(context.flateStream(mapping))}));
    const cmap='/CIDInit /ProcSet findresource begin\n12 dict begin\nbegincmap\n/CIDSystemInfo << /Registry (Adobe) /Ordering (UCS) /Supplement 0 >> def\n/CMapName /WorkbookLatin def\n/CMapType 2 def\n1 begincodespacerange\n<0000> <00FF>\nendcodespacerange\n1 beginbfrange\n<0000> <00FF> <0000>\nendbfrange\nendcmap\nCMapName currentdict /CMap defineresource pop\nend\nend';
    const ref=context.register(context.obj({Type:'Font',Subtype:'Type0',BaseFont:metadata.name,Encoding:'Identity-H',DescendantFonts:[descendant],ToUnicode:context.register(context.flateStream(cmap))}));
    const embedder=PDFLib.StandardFontEmbedder.for(PDFLib.StandardFonts.Helvetica);embedder.fontName=metadata.name;
    embedder.encodeText=text=>PDFLib.PDFHexString.of([...text].map(c=>c.charCodeAt(0).toString(16).padStart(4,'0')).join(''));
    embedder.widthOfTextAtSize=(text,size)=>[...text].reduce((n,c)=>n+(metadata.widths[c.charCodeAt(0)]||0),0)*size/1000;
    embedder.heightOfFontAtSize=(size,options={})=>(metadata.ascent-(options.descender===false?0:metadata.descent))*size/1000;
    embedder.sizeOfFontAtHeight=height=>height*1000/(metadata.ascent-metadata.descent);embedder.embedIntoContext=async()=>ref;
    return PDFLib.PDFFont.of(ref,doc,embedder);
  }
  async function create(input,project) {
    const models=Array.isArray(input)?input:[input],doc=await PDFLib.PDFDocument.create(),normal=embeddedFont(doc,WorkbookPrintFonts.regular),bold=embeddedFont(doc,WorkbookPrintFonts.bold);
    doc.setTitle(models[0].title);doc.setAuthor(project.made_by||'');doc.setSubject('HVAC Design Workbook');
    let logo=null,footerLogo=null;if(typeof fetch==='function'){for(const [file,kind] of [['burns-mcdonnell-heritage-badge.png','header'],['burns-mcdonnell-ampersand.png','footer']])try{const response=await fetch(file);if(response.ok){const image=await doc.embedPng(await response.arrayBuffer());if(kind==='header')logo=image;else footerLogo=image;}}catch{}}
    const margin=14,pageMeta=[];let page,y;
    const text=(value,x,top,font=normal,color='#051c38',size=9)=>page.drawText(clean(value),{x,y:top-size,size,font,color:rgb(color)});
    const line=(x,y,x2,y2,color='#a1afb3',width=.35)=>page.drawLine({start:{x,y},end:{x:x2,y:y2},color:rgb(color),thickness:width});
    const rect=(x,top,width,height,fill,border='#bdcad2',borderWidth=.3)=>page.drawRectangle({x,y:top-height,width,height,...(fill?{color:rgb(fill)}:{}),borderColor:rgb(border),borderWidth});
    function projectHeader(model,first=true){
      const portrait=model.portrait,w=portrait?612:792,h=portrait?792:612;page=doc.addPage([w,h]);pageMeta.push({page,model});y=h-margin;
      if(!first)return w-margin*2;
      const logoWidth=59,logoX=w-margin-logoWidth,fieldsX=portrait?margin:margin+240,fieldsWidth=logoX-14-fieldsX;
      if(logo){const dims=logo.scaleToFit(logoWidth,59);page.drawImage(logo,{x:logoX+(logoWidth-dims.width)/2,y:y-dims.height,width:dims.width,height:dims.height});}
      const fields=[[['Client',project.client],['Project',project.name],['Project Number',project.number]],[['Date',project.dateMode==='today'?new Date().toLocaleDateString():project.date],['Made By',project.made_by],['Checked By',project.checked_by],['Submittal',project.submittal]]];
      fields.forEach((row,r)=>{let x=fieldsX;const ratios=r===0?[.28,.45,.27]:[.24,.25,.25,.26];row.forEach(([label,value],i)=>{const width=fieldsWidth*ratios[i]-6,top=y-r*29;text(label.toUpperCase(),x,top,bold,'#4d5e66',5.7);rect(x,top-10,width,17,label==='Project Number'?'#e3e8e8':'#eaf2ff','#a8c3df');const str=clean(value||''),size=Math.min(8.5,(width-10)/Math.max(1,normal.widthOfTextAtSize(str,1)));text(str,x+5,top-13,bold,'#051c38',size);x+=width+6;});});
      if(portrait){y-=65;if(!model.form){text(String(model.section||'').toUpperCase(),margin,y,bold,'#376aff',8);y-=13;}text(model.title,margin,y,bold,'#051c38',14);y-=21;}
      else {text(String(model.section||'').toUpperCase(),margin,y-4,bold,'#376aff',8);let top=y-18;for(const t of wrap(model.title,228,bold,14)){text(t,margin,top,bold,'#051c38',14);top-=16;}y-=66;}
      return w-margin*2;
    }
    function drawNotes(model,available){
      for(const [key,label] of [['reference','References:']]){const values=model.notes?.[key]||[];if(!values.length)continue;text(label,margin,y,bold,'#051c38',8);y-=10;values.forEach((value,index)=>{const lines=wrap(`${index+1}. ${value}`,available-18,normal,8);for(const value of lines){if(y<48)projectHeader(model,false);text(value,margin+18,y,normal,'#051c38',8);y-=10;}});y-=3;}
    }
    function drawControls(model,available){
      const fields=model.topFields||[];
      for(const f of fields){const unit=f.label.match(/\s*\[([^\]]+)\]$/)?.[1],label=f.label.replace(/\s*\[[^\]]+\]$/,''),value=`${label} = ${f.value}${unit?' '+unit:''}`;for(const part of wrap(value,available,bold,8)){text(part,margin,y,bold,'#051c38',8);y-=10;}}
      if(fields.length)y-=4;
      if(model.energyChecks){const e=model.energyChecks,half=(available-9)/2,quarter=(half-8)/2,left=(page.getWidth()-available)/2;for(const [i,label,value] of [[0,'PCI',e.pci],[1,'PCI',e.target]]){const x=left+i*(quarter+8);text(label,x,y,bold,'#051c38',8);if(i)text('t',x+bold.widthOfTextAtSize('PCI',8)+.3,y-4,bold,'#051c38',6);rect(x,y-14,quarter,25,'#d7eaff','#aac1d6');text(value,x+7,y-20,normal,'#051c38',8);}y-=49;const blocks=[[e.pciText,e.pciPass],[e.energyText,e.energyPass]],height=Math.max(...blocks.map(([v])=>wrap(v,half-16,normal,8).length*12+18));blocks.forEach(([value,pass],i)=>{const x=left+i*(half+9);rect(x,y,half,height,pass===true?'#d3ebcd':pass===false?'#f4cccc':'#e0e5e7');wrap(value,half-16,normal,8).forEach((v,k)=>text(v,x+8,y-8-k*12,normal,'#051c38',8));});y-=height+14;}
    }
    for(const model of models){
      const pageWidth=model.portrait?612:792,available=pageWidth-margin*2;
      if(model.form){projectHeader(model);drawNotes(model,available);const form=model.form,scale=Math.min(available/form.width,(y-40)/form.height),left=(pageWidth-form.width*scale)/2,top=y;for(const item of form.items){const x=left+item.x*scale,yy=top-item.y*scale;if(item.type==='box')rect(x,yy,item.width*scale,item.height*scale,item.fill,item.border,.25);else if(item.type==='line')line(x,yy,x+item.width*scale,yy,item.color,.25);else{const value=item.uppercase?item.text.toUpperCase():item.text,font=item.bold?bold:normal,size=Math.min(8,item.size*scale,(item.width*scale)/Math.max(.1,font.widthOfTextAtSize(clean(value),1)));const lines=item.singleLine?[value]:wrap(value,item.width*scale+.5,font,size);lines.forEach((v,i)=>text(v,item.align==='right'?x+item.width*scale-font.widthOfTextAtSize(clean(v),size):x,yy-i*size*1.2,font,item.color,size));}}continue;}
      const baseSize=8,basePad=6;
      const columns=model.columns.map((c,i)=>{const longest=Math.max(0,...(clean(c.label).match(/[^\s-]+-?|-/g)||[]).map(v=>bold.widthOfTextAtSize(v,baseSize)),...clean(c.unit||'').split(/[\s-]+/).map(v=>bold.widthOfTextAtSize(v,7.5)));const content=Math.max(0,...model.rows.map(r=>Math.max(...clean(r.values[i]).split('\n').map(v=>(r.bold||r.boldColumns?.includes(i)?bold:normal).widthOfTextAtSize(v,baseSize)))));return {...c,index:i,width:Math.max(c.minWidth||45,longest+basePad*2,content+basePad*2)};});
      const naturalWidth=columns.reduce((n,c)=>n+c.width,0),scale=Math.min(1,available/Math.max(1,naturalWidth));columns.forEach(c=>c.width*=scale);const size=baseSize*scale,pad=basePad*scale,lineHeight=10.5*scale,tableWidth=columns.reduce((n,c)=>n+c.width,0),tableLeft=(pageWidth-tableWidth)/2;
      function headers(){
        const groups=[];for(const c of columns){const prev=groups.at(-1);if(prev&&prev.label===(c.group||''))prev.width+=c.width;else groups.push({label:c.group||'',width:c.width,color:c.groupColor||c.color||'#003b8c'});}
        if(groups.some(g=>g.label)){const height=Math.max(25*scale,...groups.map(g=>wrap(g.label,g.width-pad*2,bold,size).length*lineHeight+pad));let x=tableLeft;for(const g of groups){rect(x,y,g.width,height,g.color,'#a1b3c8',.25);const ls=wrap(g.label,g.width-pad*2,bold,size);ls.forEach((v,i)=>text(v,x+(g.width-bold.widthOfTextAtSize(v,size))/2,y-(height-ls.length*lineHeight)/2-i*lineHeight,bold,'#ffffff',size));x+=g.width;}y-=height;}
        const lines=columns.map(c=>wrap(c.label,c.width-pad*2,bold,size)),units=columns.map(c=>c.unit?wrap(c.unit,c.width-pad*2,bold,size*.82):[]),height=Math.max(42*scale,...columns.map((c,i)=>lines[i].length*lineHeight+units[i].length*lineHeight*.85+pad*2+5*scale));let x=tableLeft;
        columns.forEach((c,i)=>{rect(x,y,c.width,height,c.color||'#003b8c','#9cacc2',.25);const top=y-pad;let offset=0;lines[i].forEach((v,k)=>{const at=clean(c.label).indexOf(v,offset);let xx=x+pad;for(let j=0;j<v.length;j++){const sub=c.subscripts?.includes(at+j),ss=sub?size*.72:size;text(v[j],xx,top-k*lineHeight-(sub?size*.57:0),bold,'#ffffff',ss);xx+=bold.widthOfTextAtSize(v[j],ss);}offset=at+v.length;});const underline=top-lines[i].length*lineHeight-2*scale;line(x+pad,underline,x+c.width-pad,underline,c.color&&c.color!=='#003b8c'?'#ffffff':'#80b8ff',.35);units[i].forEach((v,k)=>text(v,x+pad,underline-4*scale-k*lineHeight*.85,bold,'#ffffff',size*.82));x+=c.width;});y-=height;
      }
      let firstPage=true;function newPage(){projectHeader(model,firstPage);if(firstPage){drawNotes(model,available);drawControls(model,model.energySummary?tableWidth:available);}firstPage=false;headers();}
      newPage();if(!model.rows.length){text('No rows match the selected filters.',tableLeft+pad,y-pad,normal,'#051c38',9);y-=30;}
      for(const row of model.rows){const values=columns.map(c=>clean(row.values[c.index]).split('\n')),height=Math.max(24*scale,...values.map(v=>v.length*lineHeight+pad*2));if(y-height<40)newPage();let x=tableLeft;
        columns.forEach((c,i)=>{rect(x,y,c.width,height,row.backgrounds?.[i]||row.fill||(row.total?'#e4e9ec':'#ffffff'),'#c7d0d5',.25);if(c.divider)line(x,y,x,y-height,'#667b86',.8);if(row.divider)line(x,y,x+c.width,y,'#667b86',1);const font=row.bold||row.boldColumns?.includes(i)?bold:normal;values[i].forEach((v,k)=>text(v,c.numeric?x+c.width-pad-font.widthOfTextAtSize(v,size):x+pad,y-(height-values[i].length*lineHeight)/2-k*lineHeight,font,row.textColors?.[i]||'#051c38',size));x+=c.width;});if(row.outlineColor){const w=tableWidth,h=height,r=Math.min(7*scale,h/3);page.drawSvgPath(`M${r},0 H${w-r} Q${w},0 ${w},${r} V${h-r} Q${w},${h} ${w-r},${h} H${r} Q0,${h} 0,${h-r} V${r} Q0,0 ${r},0 Z`,{x:tableLeft,y,borderColor:rgb(row.outlineColor),borderWidth:3*scale});}y-=height;if(row.outlineColor)y-=4*scale;
      }
      if(model.chart){y-=12;const image=await doc.embedPng(model.chart.image),scale=Math.min(available/1318,(y-40)/1014),left=(pageWidth-1318*scale)/2,base=y-1014*scale;page.drawImage(image,{x:left,y:base,width:1318*scale,height:1014*scale});const plotted=[];
        const onSegment=(p,a,b)=>{const dx=b.x-a.x,dy=b.y-a.y,l=dx*dx+dy*dy;if(!l)return false;const t=((p.x-a.x)*dx+(p.y-a.y)*dy)/l;return t>=0&&t<=1&&Math.hypot(p.x-a.x-t*dx,p.y-a.y-t*dy)<.6*scale;};
        for(const process of model.chart.lines){const points=process.points.map(p=>({x:left+p.x*scale,y:base+(1014-p.y)*scale})),color=rgb(process.color);for(let j=1;j<points.length;j++)page.drawLine({start:points[j-1],end:points[j],color,thickness:1.8});
          for(const previous of plotted)if(previous.color!==process.color)for(let j=1;j<points.length;j++){const a=points[j-1],b=points[j],mid={x:(a.x+b.x)/2,y:(a.y+b.y)/2};if(previous.points.slice(1).some((q,k)=>onSegment(mid,previous.points[k],q)))page.drawLine({start:a,end:b,color:rgb(previous.color),thickness:1.8,dashArray:[4,4]});}plotted.push({points,color:process.color});
          const lengths=points.slice(1).map((p,j)=>Math.hypot(p.x-points[j].x,p.y-points[j].y));let remaining=lengths.reduce((a,b)=>a+b,0)/2;for(let j=0;j<lengths.length;j++){if(remaining<=lengths[j]&&lengths[j]){const a=points[j],b=points[j+1],t=remaining/lengths[j],x=a.x+(b.x-a.x)*t,yy=a.y+(b.y-a.y)*t,angle=Math.atan2(b.y-a.y,b.x-a.x),shape=[[-16,-9],[6,0],[-16,9],[-11,0]].map(([px,py])=>({x:(px*Math.cos(angle)-py*Math.sin(angle))*scale,y:-(px*Math.sin(angle)+py*Math.cos(angle))*scale}));page.drawSvgPath(shape.map((p,k)=>`${k?'L':'M'}${p.x},${p.y}`).join(' ')+' Z',{x,y:yy,color,borderColor:rgb('#ffffff'),borderWidth:1.2*scale});break;}remaining-=lengths[j];}
        }
        const markers=model.chart.markers||[];
        for(const marker of markers){const point={x:left+marker.point.x*scale,y:base+(1014-marker.point.y)*scale},outer=8*scale,inner=6.5*scale,enter=marker.enter,leave=marker.leave;
          page.drawCircle({x:point.x,y:point.y,size:enter.length?outer:inner,color:rgb(leave[0]||'#ffffff'),...(enter.length?{borderColor:rgb(enter[0]),borderWidth:3*scale}:{})});
          if(leave.length>1)for(let i=0;i<leave.length;i++){const steps=20,a=i*2*Math.PI/leave.length,b=(i+1)*2*Math.PI/leave.length;let path='M0,0';for(let k=0;k<=steps;k++){const angle=a+(b-a)*k/steps;path+=` L${inner*Math.cos(angle)},${inner*Math.sin(angle)}`;}page.drawSvgPath(path+' Z',{x:point.x,y:point.y,color:rgb(leave[i])});}
          if(enter.length>1)for(let i=0;i<enter.length;i++)for(let k=0;k<20;k++){const a=(i+k/20)*2*Math.PI/enter.length,b=(i+(k+1)/20)*2*Math.PI/enter.length;page.drawLine({start:{x:point.x+outer*Math.cos(a),y:point.y+outer*Math.sin(a)},end:{x:point.x+outer*Math.cos(b),y:point.y+outer*Math.sin(b)},color:rgb(enter[i]),thickness:3*scale});}
        }
      }
    }
    const totals=new Map(),indices=new Map();for(const entry of pageMeta)totals.set(entry.model,(totals.get(entry.model)||0)+1);
    for(const entry of pageMeta){page=entry.page;const index=(indices.get(entry.model)||0)+1;indices.set(entry.model,index);line(margin,30,page.getWidth()-margin,30,'#a1afb3',.5);if(footerLogo){const dims=footerLogo.scaleToFit(17,18);page.drawImage(footerLogo,{x:margin+1,y:7,width:dims.width,height:dims.height});}const footer=clean([project.number,project.name,entry.model.section,entry.model.title].filter((v,i,a)=>v&&(i===0||v!==a[i-1])).join(' / ')),footerSize=Math.min(8,(page.getWidth()-margin*2-90)/Math.max(1,normal.widthOfTextAtSize(footer,1)));page.drawText(footer,{x:margin+25,y:11,size:footerSize,font:normal,color:rgb('#51636e')});const label=`Page ${index}/${totals.get(entry.model)}`;page.drawText(label,{x:page.getWidth()-margin-normal.widthOfTextAtSize(label,7),y:11,size:7,font:normal,color:rgb('#51636e')});}
    return await doc.save();
  }
  // ZIP fallback bundles independent PDF files without relying on network services.
  function zip(files) {
    const encoder=new TextEncoder(),parts=[],central=[];let offset=0;
    const crc=bytes=>{let c=0xffffffff;for(const b of bytes){c^=b;for(let k=0;k<8;k++)c=(c>>>1)^((c&1)?0xedb88320:0);}return (c^0xffffffff)>>>0;};
    const record=(length,values)=>{const a=new Uint8Array(length),v=new DataView(a.buffer);for(const [at,value,size] of values)size===2?v.setUint16(at,value,true):v.setUint32(at,value,true);return a;};
    for(const file of files){const name=encoder.encode(file.name),bytes=file.bytes,check=crc(bytes);const local=record(30,[[0,0x04034b50,4],[4,20,2],[6,0x800,2],[14,check,4],[18,bytes.length,4],[22,bytes.length,4],[26,name.length,2]]);parts.push(local,name,bytes);const entry=record(46,[[0,0x02014b50,4],[4,20,2],[6,20,2],[8,0x800,2],[16,check,4],[20,bytes.length,4],[24,bytes.length,4],[28,name.length,2],[42,offset,4]]);central.push(entry,name);offset+=30+name.length+bytes.length;}
    const length=central.reduce((n,a)=>n+a.length,0),end=record(22,[[0,0x06054b50,4],[8,files.length,2],[10,files.length,2],[12,length,4],[16,offset,4]]);return new Blob([...parts,...central,end],{type:'application/zip'});
  }
  return {create,zip,wrap};
})();
