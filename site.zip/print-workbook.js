/* Print workspace preserves the workbook's project data and keeps separate print filters. */
function printHeaderColor(name='') {
  if(name.includes('preheat'))return '#ce6f09';if(name.includes('latent'))return '#008577';if(name.includes('heating'))return '#bd3818';if(name.includes('sensible-cooling'))return '#0066ff';if(name.includes('exhaust'))return '#805b3f';if(name.includes('ventilation'))return '#008ca8';return '#003b8c';
}
function printFilterDescription(project) {
  const parts=[];
  for(const [kind,search,state,excluded] of [['Spaces',project.sharedSpaceSearch,project.sharedSpaceFilter,project.excludedSpaces],['Equipment',project.equipmentSearch,project.equipmentFilter,project.excludedEquipment]]){
    if(search)parts.push(`${kind} search: ${search}`);
    if(state?.values)parts.push(`${kind} — ${spaceFilterDescriptor(state.field)?.label||state.field}: ${state.values.join(', ')||'(none)'}`);
    if(excluded?.length)parts.push(`${kind}: ${excluded.length} excluded`);
  }return parts.join(' | ');
}
function printTableModel(table,project) {
  if(table.energySimulation)configureEnergyColumns(table,project);
  const rows=ensureProjectTableRows(project,table);recalculateTable(table,rows,project);
  const context=prepareSharedSpaceFilter(table,rows,project),visible=rows.map((row,sourceIndex)=>({row,sourceIndex})).filter(({row})=>!context||sharedSpaceSearchMatches(table,row,project)&&rowMatchesSpaceSet(table,row,context.matchingSpaces)&&(!context.matchingRows||context.matchingRows.has(row)));
  if(!table.energySimulation&&!table.energySummary)orderTableRows(table,rows,visible,project);
  const cols=table.headers.map((_,i)=>i).filter(i=>!table.hiddenColumns?.includes(i));
  const model={title:table.name,filterDescription:printFilterDescription(project),columns:cols.map(c=>{const h=table.headers[c],g=table.headerGroups?.find(g=>c>=g.start&&c<g.start+g.span);return {label:`${h.label}${h.subscript||''}${h.unit?' ['+h.unit+']':''}`,group:g?.label||'',color:printHeaderColor(table.headerClasses?.[c]),groupColor:printHeaderColor(g?.className),numeric:table.columnTypes[c]==='number',frozen:c<(table.frozenColumns??1),divider:table.sectionStartColumns?.includes(c)};}),rows:[]};
  for(const {row,sourceIndex} of visible){const backgrounds=cols.map(c=>{
    if(table.tabularCalculation){const comparison=csvComparisonForCell(table,row,sourceIndex,c);if(c===tabularColumn.differences)return row[c]?'#fff1b7':'#ffffff';if(comparison?.specified&&comparison.mapped)return comparison.matches?'#e9e3f4':'#fff1b7';if(!comparison?.specified)return '#f1f3f4';}
    if(table.autoCellStates?.get(sourceIndex)?.has(c))return '#e2efe7';
    if(table.calculatedColumns?.includes(c)||table.lockedColumns?.includes(c)||table.lockedCellStates?.get(sourceIndex)?.has(c))return sourceIndex%2?'#dce3e6':'#e6ebed';
    return table.identityColumns?.includes(c)?(sourceIndex%2?'#f4f7f8':'#ffffff'):'#e3eeff';
  });model.rows.push({values:cols.map(c=>formatTableValue(row[c],table,c)),backgrounds,divider:table.energySummary&&sourceIndex===2,boldColumns:table.energySummary&&sourceIndex<2?[0,3,4,5]:[],textColors:cols.map(c=>table.mutedCellStates?.get(sourceIndex)?.has(c)?'#899198':'#051c38')});}
  if(table.tabularCalculation){model.rows.push({total:true,bold:true,values:cols.map(c=>{
    if(c===tabularColumn.id)return 'Total Differing Values';if(c===tabularColumn.space)return '';
    const total=c===tabularColumn.differences?visible.reduce((n,{row})=>n+requirementNumber(row[c]),0):tabularMismatchTotal(table,visible,c);return total?String(total):'';
  })});}
  else if(table.summaryColumns?.length){model.rows.push({total:true,bold:true,values:cols.map(c=>table.summaryColumns.includes(c)?formatTableValue(summaryValue(visible.map(v=>v.row),c,table.summaryAggregations?.[c]||'sum'),table,c):c===0?table.summaryLabel||'Total':'')});}
  model.topLines=[];
  for(const [flag,label,fallback] of [['ventilationMinimumDefault','Ventilation Minimum',25],['exhaustMinimumDefault','Exhaust Minimum',25],['supplyMinimumDefault','Supply Minimum',50]])if(table[flag])model.topLines.push(`${label}: ${airflowMinimum(project,table.id,fallback)} CFM`);
  if(table.conditionBaselineCalculation){const d=conditionBaselineDefaults(project);model.topLines.push(`Cooled Space Relative Bound: ${d.cooling} Btu/h-ft2 | Heated Space Relative Bound: ${d.heating} Btu/h-ft2 | Semi-Heated Space Relative Bound: ${d.semiheated} Btu/h-ft2`);}
  const sum=c=>visible.reduce((n,{row})=>n+requirementNumber(row[c]),0);
  for(const metric of table.topMetrics||(table.topMetric?[table.topMetric]:[])){const numerator=metric.numeratorDifference?sum(metric.numeratorDifference[0])-sum(metric.numeratorDifference[1]):sum(metric.numerator),denominator=sum(metric.denominator);model.topLines.push(`${metric.label}: ${denominator?(100*numerator/denominator).toFixed(1)+'%':'-'}`);}
  if(table.energySummary){const pci=project.energyAnalysis?.pci,target=project.energyAnalysis?.pciTarget,ready=pci!==undefined&&pci!==''&&target!==undefined&&target!=='';model.topLines.push(`PCI: ${pci??''} | PCIt: ${target??''}`,ready?`The performance cost index ${pci<=target?'is less than or equal to':'exceeds'} the performance cost index target.`:'Enter both index values.');const proposed=rows[0]?.[3],baseline=rows[1]?.[3];if(typeof proposed==='number'&&typeof baseline==='number')model.topLines.push(`The proposed building's energy consumption ${proposed<=baseline?'is less than or equal to':'exceeds'} the baseline building's energy consumption.`);}
  return model;
}
async function printPsychModels(project) {
  const data=buildPsychChartData(project),settings=independentTables.find(t=>t.id==='airside-settings'),rows=ensureProjectTableRows(project,settings),filter=prepareEquipmentFilter(settings,rows,project);
  const equipment=new Set(rows.filter(r=>sharedSpaceSearchMatches(settings,r,project)&&rowMatchesSpaceSet(settings,r,filter.matchingSpaces)).map(r=>requirementKey(r[0])));
  const response=await fetch('psych-chart.png');if(!response.ok)throw Error('The psychrometric chart image could not be loaded.');const sourceImage=await createImageBitmap(await response.blob()),canvas=document.createElement('canvas');canvas.width=sourceImage.width;canvas.height=sourceImage.height;const context=canvas.getContext('2d');context.filter='grayscale(1)';context.drawImage(sourceImage,0,0);sourceImage.close();const blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/png'));const image=new Uint8Array(await blob.arrayBuffer());
  return [...new Set(data.lines.filter(l=>equipment.has(requirementKey(l.equipment))).map(l=>l.equipment))].map(tag=>{
    const lines=data.lines.filter(l=>l.equipment===tag);return {title:`Psychrometric Chart — ${tag}`,filterDescription:printFilterDescription(project),columns:psychTableHeaders().map((label,c)=>({label,group:c===0?'Coil':c<7?'Entering Conditions':c<11?'Leaving Condition':'Capacity',frozen:c===0,numeric:c>0,color:'#003b8c',divider:[1,7,11].includes(c)})),rows:lines.map((line,i)=>({values:psychTableValues(line,data.pressure),fill:'#ffffff',outlineColor:psychLineStyle(line).color,textColors:psychTableHeaders().map((_,c)=>line.loser&&c>0?'#899198':'#051c38'),divider:i>0&&(lines[i-1].tableId==='airside-preheat'||lines[i-1].cooling&&!line.cooling)})),chart:{image,lines:lines.map(line=>({color:psychLineStyle(line).color,points:(line.cooling?psychCoolingPath(line.enter,line.leave,data.pressure):[line.enter,line.leave]).map(p=>psychChartPoint(p.db,p.hr))}))}};
  });
}
function printModelInputs() {
  renderModelInputs();const rows=[];
  modelInputsView.querySelectorAll('.model-input-section').forEach(section=>{
    const heading=section.querySelector('h2,h3,legend')?.textContent||'';rows.push({values:[heading,''],bold:true,divider:true});
    section.querySelectorAll('label').forEach(label=>{const input=label.querySelector('input,select,output');if(!input)return;const caption=label.querySelector('span')?.textContent||label.textContent.replace(input.textContent,'');rows.push({values:[caption,input.tagName==='SELECT'?input.selectedOptions[0]?.textContent||'':input.type==='checkbox'?(input.checked?'TRUE':''):input.value??input.textContent]});});
    section.querySelectorAll('.construction-grid').forEach(grid=>{let values=[];for(const child of grid.children){if(child.tagName==='INPUT'){values.push(child.value);if(values.length===(grid.classList.contains('baseline-grid')?4:7)){rows.push({values:[values[0],values.slice(1).join(' | ')]});values=[];}}}});
  });
  return {title:'Model Inputs',columns:[{label:'Input / calculation',minWidth:220},{label:'Value',minWidth:280}],rows};
}
function openWorkbookPrint() {
  if(document.body.classList.contains('print-mode'))return;
  closeCellDropdown();clearTableSelection();setProjectSwitcher(false);
  const source=activeProject(),settings={sharedSpaceSearch:'',sharedSpaceFilter:structuredClone(source.sharedSpaceFilter||{field:'meta:zoneGroup',values:null}),excludedSpaces:[...(source.excludedSpaces||[])],equipmentSearch:'',equipmentFilter:structuredClone(source.equipmentFilter||{field:'equipment:unitType',values:null}),excludedEquipment:[...(source.excludedEquipment||[])]};
  const selected=new Set(),orientations=new Map(),catalog=[{id:'model-inputs',label:'Model Inputs',group:'Model Inputs'}],seen=new Set(['model-inputs']),cache=new Map();let generation=0,busy=false,previewId='',closed=false;
  const node=(tag,className,text)=>{const n=document.createElement(tag);if(className)n.className=className;if(text!==undefined)n.textContent=text;return n;};
  for(const group of modules){if(group.group==='IESVE 2025'||/independent/i.test(group.group))continue;for(const item of group.items){const id=item[0]==='Psychrometric Chart'?'psych-chart':item[3];if(!id||seen.has(id)||id!=='psych-chart'&&!independentTables.some(t=>t.id===id))continue;seen.add(id);catalog.push({id,label:item[0],group:group.group});}}
  if(activeTableId&&seen.has(activeTableId))selected.add(activeTableId);else if(document.querySelector('#psych-chart-view'))selected.add('psych-chart');else if(!modelInputsView.hidden)selected.add('model-inputs');
  const sidebar=node('div','print-sidebar');sidebar.id='print-sidebar';const heading=node('div','export-heading'),back=node('button','project-switcher-toggle export-back');back.type='button';back.title='Back to Calculations Workbook';back.setAttribute('aria-label',back.title);back.innerHTML='<svg aria-hidden="true" viewBox="0 0 24 24"><path d="M19 12H5"></path><path d="m11 18-6-6 6-6"></path></svg>';heading.append(back,node('h2','','Export Calculations'));
  const listSearch=node('input','print-list-search');listSearch.type='search';listSearch.placeholder='Find a calculation';listSearch.setAttribute('aria-label','Find a calculation to export');
  const actions=node('div','print-list-actions'),list=node('div','print-table-list');
  sidebar.append(heading,listSearch,actions,list);browser.insertBefore(sidebar,browser.querySelector('.browser-footer'));
  const screen=node('section','print-workspace');screen.id='print-workspace';const pages=node('div','print-preview-pages');pages.setAttribute('aria-label','Calculation pages');screen.appendChild(pages);document.querySelector('.app-shell').appendChild(screen);
  const footer=node('div','print-footer-controls'),previewSelect=node('select','print-preview-select'),orientation=node('select','print-orientation'),status=node('p','print-status'),pageControls=node('div','print-page-controls'),previous=node('button','','↑'),pageLabel=node('span','','No pages'),next=node('button','','↓'),exportButton=node('button','print-export','Export (0) PDFs');
  previewSelect.setAttribute('aria-label','Calculation to preview');orientation.setAttribute('aria-label','Page orientation');previous.title='Previous page';next.title='Next page';previous.setAttribute('aria-label',previous.title);next.setAttribute('aria-label',next.title);status.setAttribute('role','status');exportButton.type='button';previous.type='button';next.type='button';
  for(const [value,label] of [['auto','Automatic orientation'],['portrait','Portrait'],['landscape','Landscape']]){const option=node('option','',label);option.value=value;orientation.appendChild(option);}
  pageControls.append(previous,pageLabel,next);footer.append(previewSelect,orientation,pageControls,status,exportButton);browser.querySelector('.browser-footer').prepend(footer);
  const preview=createWorkbookPDFPreview(pages,(page,count)=>{pageLabel.textContent=`Page ${page} of ${count}`;previous.disabled=page<=1;next.disabled=page>=count;});previous.onclick=()=>preview.go(-1);next.onclick=()=>preview.go(1);
  const copyProject=()=>Object.assign(structuredClone(source),structuredClone(settings));
  const selectionChanged=()=>{
    previewSelect.replaceChildren();for(const item of catalog.filter(i=>selected.has(i.id))){const option=node('option','',item.label);option.value=item.id;previewSelect.appendChild(option);}
    if(!selected.has(previewId))previewId=catalog.find(i=>selected.has(i.id))?.id||'';previewSelect.value=previewId;orientation.value=orientations.get(previewId)||'auto';exportButton.textContent=`Export (${selected.size}) PDFs`;exportButton.disabled=!selected.size||busy;refreshPreview();
  };
  const filterElements={space:buildFilter(false),equipment:buildFilter(true)};
  function drawList(){
    list.replaceChildren();let group='';for(const item of catalog.filter(item=>item.label.toLowerCase().includes(listSearch.value.toLowerCase()))){
      if(group!==item.group){const head=node('div','print-section-heading');if(['Space Calculations','Airside Equipment','Plantside Equipment','Energy Analysis','Energy'].includes(item.group))head.classList.add('print-section-divider');if(item.group==='Space Calculations')head.appendChild(filterElements.space);if(item.group==='Airside Equipment')head.appendChild(filterElements.equipment);head.appendChild(node('h3','',item.group));list.appendChild(head);group=item.group;}
      const label=node('label','print-table-option'),check=node('input');check.type='checkbox';check.checked=selected.has(item.id);check.onchange=()=>{check.checked?selected.add(item.id):selected.delete(item.id);if(check.checked)previewId=item.id;selectionChanged();};label.append(check,node('span','',item.label));list.appendChild(label);
    }selectionChanged();
  }
  for(const [label,on] of [['Select all',true],['Clear',false]]){const button=node('button','',label);button.type='button';button.onclick=()=>{for(const item of catalog.filter(i=>i.label.toLowerCase().includes(listSearch.value.toLowerCase())))on?selected.add(item.id):selected.delete(item.id);drawList();};actions.appendChild(button);}
  async function getPDF(id){
    const key=JSON.stringify([id,settings,orientations.get(id)||'auto']);if(cache.has(key))return cache.get(key);
    const pending=(async()=>{const project=copyProject(),item=catalog.find(i=>i.id===id);let models=id==='psych-chart'?await printPsychModels(project):id==='model-inputs'?[printModelInputs()]:[printTableModel(independentTables.find(t=>t.id===id),project)];
      if(!models.length)models=[{title:item.label,columns:[{label:'Equipment'}],rows:[],filterDescription:'No equipment matches the selected filters.'}];
      if(models.length===1)return await WorkbookPrintPDF.create(models[0],project,orientations.get(id)||'auto');
      const combined=await PDFLib.PDFDocument.create();combined.setTitle(item.label);for(const model of models){const bytes=await WorkbookPrintPDF.create(model,project,orientations.get(id)||'auto'),part=await PDFLib.PDFDocument.load(bytes);for(const page of await combined.copyPages(part,part.getPageIndices()))combined.addPage(page);}return await combined.save();})();cache.set(key,pending);try{return await pending;}catch(e){cache.delete(key);throw e;}
  }
  async function refreshPreview(){
    const request=++generation,id=previewId;previous.disabled=true;next.disabled=true;pageLabel.textContent='No pages';
    if(!id){await preview.clear();status.textContent='Select calculations to view their pages.';return;}
    status.textContent='Preparing pages…';await new Promise(resolve=>setTimeout(resolve,0));if(request!==generation||closed)return;
    try{const bytes=await getPDF(id);if(request!==generation||closed)return;await preview.show(bytes);if(request===generation)status.textContent='';}
    catch(error){if(request===generation&&!closed)status.textContent=`Unable to show these pages. ${error.message}`;}
  }
  function filtersChanged(){cache.clear();filterElements.space.refreshLabels();filterElements.equipment.refreshLabels();refreshPreview();}
  function buildFilter(equipment){
    const box=node('div','space-filter print-filter-strip'),stateKey=equipment?'equipmentFilter':'sharedSpaceFilter',excludedKey=equipment?'excludedEquipment':'excludedSpaces';
    const fieldLabel=node('label','filter-field'),field=node('select');field.setAttribute('aria-label',equipment?'Equipment filter by':'Space filter by');fieldLabel.append(node('span','','Filter by'),field);
    const shared=node('optgroup');shared.label='Shared fields';for(const [value,label] of equipment?[['equipment:unitType','Unit Type']]:[['meta:zoneGroup','Zone Group'],['meta:zone','Zone'],['meta:type','Thermal Template']]){const option=node('option','',label);option.value=value;shared.appendChild(option);}field.appendChild(shared);
    for(const table of independentTables.filter(t=>equipment?supportsEquipmentFilter(t):supportsSharedSpaceFilter(t)&&!supportsEquipmentFilter(t)&&!t.thermalTemplateCalculation)){
      const group=node('optgroup');group.label=table.name;table.headers.forEach((header,c)=>{if(table.hiddenColumns?.includes(c)||c===(equipment?0:table.spaceColumn))return;const option=node('option','',spaceFilterColumnLabel(table,c));option.value=`col:${table.id}:${c}`;group.appendChild(option);});field.appendChild(group);
    }field.value=settings[stateKey].field;
    const values=node('button','print-filter-toggle','All values'),spaces=node('button','print-filter-toggle',equipment?'All equipment':'All spaces');values.type='button';spaces.type='button';for(const button of [values,spaces]){button.setAttribute('aria-haspopup','dialog');button.setAttribute('aria-expanded','false');button.onpointermove=event=>button.classList.toggle('arrow-hover',event.clientX>=button.getBoundingClientRect().right-34);button.onpointerleave=()=>button.classList.remove('arrow-hover');}
    const wrap=(label,control)=>{const el=node('label');el.append(node('span','',label),control);return el;};box.append(fieldLabel,wrap('Values',values),wrap(equipment?'Equipment':'Spaces',spaces));
    const clear=node('button','filter-clear print-filter-clear','×');clear.type='button';clear.title='Clear filter';clear.setAttribute('aria-label','Clear filter');box.appendChild(clear);
    box.refreshLabels=()=>{values.textContent=settings[stateKey].values?`${settings[stateKey].values.length} values selected`:'All values';spaces.textContent=settings[excludedKey].length?`${settings[excludedKey].length} excluded`:equipment?'All equipment':'All spaces';clear.hidden=!settings[stateKey].values&&!settings[excludedKey].length;};
    const getContext=()=>{const project=copyProject(),table=independentTables.find(t=>t.id===(equipment?'airside-settings':'iesve-tabular-space-data')),rows=ensureProjectTableRows(project,table);return prepareSharedSpaceFilter(table,rows,project);};
    function openOptions(button,spaceChoice,initial=''){
      closeCellDropdown();const context=getContext(),options=spaceChoice?context.spaceOptions:context.options,chosen=new Set(spaceChoice?options.filter(o=>!settings[excludedKey].includes(o.value)).map(o=>o.value):settings[stateKey].values||options.map(o=>o.value));
      const popup=node('div','cell-dropdown-popup print-filter-popover');popup.setAttribute('role','dialog');popup.setAttribute('aria-label',spaceChoice?equipment?'Equipment':'Spaces':'Values');const query=node('input');query.type='search';query.placeholder='Search';query.value=initial;query.setAttribute('aria-label','Search filter choices');const allLabel=node('label','filter-option'),all=node('input');all.type='checkbox';allLabel.append(all,node('span','','Select all'));const choices=node('div','filter-options'),buttons=node('div','filter-popover-actions'),cancel=node('button','','Cancel'),apply=node('button','','Apply');cancel.type='button';apply.type='button';buttons.append(cancel,apply);popup.append(query,allLabel,choices,buttons);document.body.appendChild(popup);button.setAttribute('aria-expanded','true');
      const dismiss=()=>{popup.remove();button.setAttribute('aria-expanded','false');document.removeEventListener('pointerdown',outside,true);};const outside=event=>{if(!popup.contains(event.target)&&event.target!==button)dismiss();};document.addEventListener('pointerdown',outside,true);
      const shown=()=>options.filter(o=>o.label.toLowerCase().includes(query.value.toLowerCase()));
      const draw=()=>{choices.replaceChildren();const matches=shown();all.checked=matches.length>0&&matches.every(o=>chosen.has(o.value));all.indeterminate=matches.some(o=>chosen.has(o.value))&&!all.checked;for(const option of matches){const label=node('label','filter-option'),check=node('input');check.type='checkbox';check.checked=chosen.has(option.value);check.onchange=()=>{check.checked?chosen.add(option.value):chosen.delete(option.value);all.checked=shown().every(o=>chosen.has(o.value));all.indeterminate=shown().some(o=>chosen.has(o.value))&&!all.checked;};label.append(check,node('span','',option.label));choices.appendChild(label);}if(!matches.length)choices.appendChild(node('p','','No matching values'));};
      query.oninput=draw;all.onchange=()=>{for(const option of shown())all.checked?chosen.add(option.value):chosen.delete(option.value);draw();};cancel.onclick=dismiss;apply.onclick=()=>{if(spaceChoice){const excluded=new Set(settings[excludedKey]);for(const option of options)chosen.has(option.value)?excluded.delete(option.value):excluded.add(option.value);settings[excludedKey]=[...excluded];}else settings[stateKey].values=chosen.size===options.length?null:[...chosen];dismiss();filtersChanged();};popup.onkeydown=event=>{if(event.key==='Escape'){event.preventDefault();event.stopPropagation();dismiss();button.focus();}};
      draw();positionCellPopup(popup,button);query.focus();
    }
    for(const [button,choice] of [[values,false],[spaces,true]]){button.onclick=event=>{if(event.detail===0||event.clientX>=button.getBoundingClientRect().right-34)openOptions(button,choice);};button.onkeydown=event=>{if(!event.ctrlKey&&!event.metaKey&&event.key.length===1){event.preventDefault();openOptions(button,choice,event.key);}else if(event.altKey&&event.key==='ArrowDown'){event.preventDefault();openOptions(button,choice);}};}
    field.onchange=()=>{settings[stateKey]={field:field.value,values:null};filtersChanged();};clear.onclick=()=>{settings[stateKey].values=null;settings[excludedKey]=[];filtersChanged();};box.refreshLabels();return box;
  }
  function close(){if(busy)return;closed=true;++generation;closeCellDropdown();preview.destroy();sidebar.remove();footer.remove();screen.remove();document.body.classList.remove('print-mode');document.removeEventListener('keydown',escape);closeBrowser();syncActiveState();}
  function escape(event){if(!event.defaultPrevented&&event.key==='Escape'&&!document.querySelector('dialog[open],.cell-dropdown-popup')){event.preventDefault();close();}}
  back.onclick=close;document.addEventListener('keydown',escape);listSearch.oninput=drawList;previewSelect.onchange=()=>{previewId=previewSelect.value;orientation.value=orientations.get(previewId)||'auto';refreshPreview();};orientation.onchange=()=>{orientations.set(previewId,orientation.value);refreshPreview();};
  exportButton.onclick=async()=>{
    if(busy||!selected.size)return;if(!window.showDirectoryPicker){status.textContent='Folder export is not available in this browser. Open the workbook in Edge or Chrome to choose an export folder.';return;}
    busy=true;exportButton.disabled=true;back.disabled=true;let directory;
    try{directory=await window.showDirectoryPicker({mode:'readwrite'});let count=0;const ids=catalog.filter(item=>selected.has(item.id));for(const item of ids){status.textContent=`Exporting ${++count} of ${ids.length}…`;await new Promise(resolve=>setTimeout(resolve,0));const bytes=await getPDF(item.id),name=`${source.number||'Project'} - ${item.label}`.replace(/[<>:"/\\|?*\x00-\x1f]/g,'-').slice(0,160)+'.pdf',handle=await directory.getFileHandle(name,{create:true}),stream=await handle.createWritable();await stream.write(bytes);await stream.close();}status.textContent=`Exported ${ids.length} PDFs to ${directory.name}.`;}
    catch(error){status.textContent=error.name==='AbortError'?'':`Unable to export. ${error.message}`;}finally{busy=false;back.disabled=false;exportButton.disabled=!selected.size;}
  };
  document.body.classList.add('print-mode');scrim.classList.remove('open');document.body.style.overflow='hidden';drawList();
}
document.querySelector('#open-print').addEventListener('click',openWorkbookPrint);
