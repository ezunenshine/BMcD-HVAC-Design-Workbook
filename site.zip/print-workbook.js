/* Print workspace preserves the workbook's project data and keeps separate print filters. */
function printHeaderColor(name='') {
  if(name.includes('preheat'))return '#ce6f09';if(name.includes('latent'))return '#008577';if(name.includes('heating'))return '#bd3818';if(name.includes('sensible-cooling'))return '#0066ff';if(name.includes('exhaust'))return '#805b3f';if(name.includes('ventilation'))return '#008ca8';return '#003b8c';
}
function printFilterDescription(project) {
  const parts=[];
  for(const [kind,search,state,excluded] of [['Spaces',project.sharedSpaceSearch,project.sharedSpaceFilter,project.excludedSpaces],['Equipment',project.equipmentSearch,project.equipmentFilter,project.excludedEquipment]]){
    if(search)parts.push(`${kind} search: ${search}`);
    if(state?.values)parts.push(`${kind} — ${spaceFilterDescriptor(state.field)?.label||state.field}: ${state.values.join(', ')||'(none)'}`);
    if(excluded?.length)parts.push(`${kind}: ${excluded.length} excluded`);
  }return parts.join(' | ');
}
function printTableModel(table,project) {
  if(table.energySimulation)configureEnergyColumns(table,project);
  const rows=ensureProjectTableRows(project,table);recalculateTable(table,rows,project);
  const context=prepareSharedSpaceFilter(table,rows,project),visible=rows.map((row,sourceIndex)=>({row,sourceIndex})).filter(({row})=>!context||sharedSpaceSearchMatches(table,row,project)&&rowMatchesSpaceSet(table,row,context.matchingSpaces)&&(!context.matchingRows||context.matchingRows.has(row)));
  if(!table.energySimulation&&!table.energySummary)orderTableRows(table,rows,visible,project);
  const cols=table.headers.map((_,i)=>i).filter(i=>!table.hiddenColumns?.includes(i));
  const model={title:table.name,filterDescription:printFilterDescription(project),columns:cols.map(c=>{const h=table.headers[c],g=table.headerGroups?.find(g=>c>=g.start&&c<g.start+g.span);return {label:`${h.label}${h.subscript||''}${h.unit?' ['+h.unit+']':''}`,group:g?.label||'',color:printHeaderColor(table.headerClasses?.[c]),groupColor:printHeaderColor(g?.className),numeric:table.columnTypes[c]==='number',frozen:c<(table.frozenColumns??1),divider:table.sectionStartColumns?.includes(c)};}),rows:[]};
  for(const {row,sourceIndex} of visible){const backgrounds=cols.map(c=>{
    if(table.tabularCalculation){const comparison=csvComparisonForCell(table,row,sourceIndex,c);if(c===tabularColumn.differences)return row[c]?'#fff1b7':'#ffffff';if(comparison?.specified&&comparison.mapped)return comparison.matches?'#e9e3f4':'#fff1b7';if(!comparison?.specified)return '#f1f3f4';}
    if(table.autoCellStates?.get(sourceIndex)?.has(c))return '#e2efe7';
    if(table.calculatedColumns?.includes(c)||table.lockedColumns?.includes(c)||table.lockedCellStates?.get(sourceIndex)?.has(c))return sourceIndex%2?'#dce3e6':'#e6ebed';
    return table.identityColumns?.includes(c)?(sourceIndex%2?'#f4f7f8':'#ffffff'):'#e3eeff';
  });model.rows.push({values:cols.map(c=>formatTableValue(row[c],table,c)),backgrounds,divider:table.energySummary&&sourceIndex===2,boldColumns:table.energySummary&&sourceIndex<2?[0,3,4,5]:[],textColors:cols.map(c=>table.mutedCellStates?.get(sourceIndex)?.has(c)?'#899198':'#051c38')});}
  if(table.tabularCalculation){model.rows.push({total:true,bold:true,values:cols.map(c=>{
    if(c===tabularColumn.id)return 'Total Differing Values';if(c===tabularColumn.space)return '';
    const total=c===tabularColumn.differences?visible.reduce((n,{row})=>n+requirementNumber(row[c]),0):tabularMismatchTotal(table,visible,c);return total?String(total):'';
  })});}
  else if(table.summaryColumns?.length){model.rows.push({total:true,bold:true,values:cols.map(c=>table.summaryColumns.includes(c)?formatTableValue(summaryValue(visible.map(v=>v.row),c,table.summaryAggregations?.[c]||'sum'),table,c):c===0?table.summaryLabel||'Total':'')});}
  model.topLines=[];
  for(const [flag,label,fallback] of [['ventilationMinimumDefault','Ventilation Minimum',25],['exhaustMinimumDefault','Exhaust Minimum',25],['supplyMinimumDefault','Supply Minimum',50]])if(table[flag])model.topLines.push(`${label}: ${airflowMinimum(project,table.id,fallback)} CFM`);
  if(table.conditionBaselineCalculation){const d=conditionBaselineDefaults(project);model.topLines.push(`Cooled Space Relative Bound: ${d.cooling} Btu/h-ft2 | Heated Space Relative Bound: ${d.heating} Btu/h-ft2 | Semi-Heated Space Relative Bound: ${d.semiheated} Btu/h-ft2`);}
  const sum=c=>visible.reduce((n,{row})=>n+requirementNumber(row[c]),0);
  for(const metric of table.topMetrics||(table.topMetric?[table.topMetric]:[])){const numerator=metric.numeratorDifference?sum(metric.numeratorDifference[0])-sum(metric.numeratorDifference[1]):sum(metric.numerator),denominator=sum(metric.denominator);model.topLines.push(`${metric.label}: ${denominator?(100*numerator/denominator).toFixed(1)+'%':'-'}`);}
  if(table.energySummary){const pci=project.energyAnalysis?.pci,target=project.energyAnalysis?.pciTarget,ready=pci!==undefined&&pci!==''&&target!==undefined&&target!=='';model.topLines.push(`PCI: ${pci??''} | PCIt: ${target??''}`,ready?`The performance cost index ${pci<=target?'is less than or equal to':'exceeds'} the performance cost index target.`:'Enter both index values.');const proposed=rows[0]?.[3],baseline=rows[1]?.[3];if(typeof proposed==='number'&&typeof baseline==='number')model.topLines.push(`The proposed building's energy consumption ${proposed<=baseline?'is less than or equal to':'exceeds'} the baseline building's energy consumption.`);}
  return model;
}
async function printPsychModels(project) {
  const data=buildPsychChartData(project),settings=independentTables.find(t=>t.id==='airside-settings'),rows=ensureProjectTableRows(project,settings),filter=prepareEquipmentFilter(settings,rows,project);
  const equipment=new Set(rows.filter(r=>sharedSpaceSearchMatches(settings,r,project)&&rowMatchesSpaceSet(settings,r,filter.matchingSpaces)).map(r=>requirementKey(r[0])));
  const response=await fetch('psych-chart.png');if(!response.ok)throw Error('The psychrometric chart image could not be loaded.');const image=new Uint8Array(await response.arrayBuffer());
  return [...new Set(data.lines.filter(l=>equipment.has(requirementKey(l.equipment))).map(l=>l.equipment))].map(tag=>{
    const lines=data.lines.filter(l=>l.equipment===tag);return {title:`Psychrometric Chart — ${tag}`,filterDescription:printFilterDescription(project),columns:psychTableHeaders().map((label,c)=>({label,group:c===0?'Coil':c<7?'Entering Conditions':c<11?'Leaving Condition':'Capacity',frozen:c===0,numeric:c>0,color:'#003b8c',divider:[1,7,11].includes(c)})),rows:lines.map((line,i)=>({values:psychTableValues(line,data.pressure),fill:psychLineStyle(line).fill,textColors:psychTableHeaders().map((_,c)=>line.loser&&c>0?'#899198':'#051c38'),divider:i>0&&(lines[i-1].tableId==='airside-preheat'||lines[i-1].cooling&&!line.cooling)})),chart:{image,lines:lines.map(line=>({color:psychLineStyle(line).color,points:(line.cooling?psychCoolingPath(line.enter,line.leave,data.pressure):[line.enter,line.leave]).map(p=>psychChartPoint(p.db,p.hr))}))}};
  });
}
function printModelInputs() {
  renderModelInputs();const rows=[];
  modelInputsView.querySelectorAll('.model-input-section').forEach(section=>{
    const heading=section.querySelector('h2,h3,legend')?.textContent||'';rows.push({values:[heading,''],bold:true,divider:true});
    section.querySelectorAll('label').forEach(label=>{const input=label.querySelector('input,select,output');if(!input)return;const caption=label.querySelector('span')?.textContent||label.textContent.replace(input.textContent,'');rows.push({values:[caption,input.tagName==='SELECT'?input.selectedOptions[0]?.textContent||'':input.type==='checkbox'?(input.checked?'TRUE':''):input.value??input.textContent]});});
    section.querySelectorAll('.construction-grid').forEach(grid=>{let values=[];for(const child of grid.children){if(child.tagName==='INPUT'){values.push(child.value);if(values.length===(grid.classList.contains('baseline-grid')?4:7)){rows.push({values:[values[0],values.slice(1).join(' | ')]});values=[];}}}});
  });
  return {title:'Model Inputs',columns:[{label:'Input / calculation',minWidth:220},{label:'Value',minWidth:280}],rows};
}
function openWorkbookPrint() {
  if(document.body.classList.contains('print-mode'))return;
  closeCellDropdown();clearTableSelection();setProjectSwitcher(false);
  const source=activeProject(),settings={sharedSpaceSearch:source.sharedSpaceSearch||'',sharedSpaceFilter:structuredClone(source.sharedSpaceFilter||{field:'meta:zoneGroup',values:null}),excludedSpaces:[...(source.excludedSpaces||[])],equipmentSearch:source.equipmentSearch||'',equipmentFilter:structuredClone(source.equipmentFilter||{field:'equipment:unitType',values:null}),excludedEquipment:[...(source.excludedEquipment||[])]};
  const selected=new Set(),orientations=new Map(),catalog=[],seen=new Set();let previewURL='',generation=0,busy=false,previewId='';
  const node=(tag,className,text)=>{const n=document.createElement(tag);if(className)n.className=className;if(text!==undefined)n.textContent=text;return n;};
  catalog.push({id:'model-inputs',label:'Model Inputs',group:'Model Inputs'});seen.add('model-inputs');
  for(const group of modules){for(const item of group.items){let id=item[3];if(item[0]==='Psychrometric Chart')id='psych-chart';if(item[0]==='Model Inputs')id='model-inputs';if(!id||seen.has(id)||!['psych-chart','model-inputs'].includes(id)&&!independentTables.some(t=>t.id===id))continue;seen.add(id);catalog.push({id,label:item[0],group:group.group});}}
  for(const t of independentTables)if(!seen.has(t.id)){catalog.push({id:t.id,label:t.name,group:'Independent Tables'});seen.add(t.id);}
  if(activeTableId&&seen.has(activeTableId))selected.add(activeTableId);else if(document.querySelector('#psych-chart-view'))selected.add('psych-chart');else if(!modelInputsView.hidden)selected.add('model-inputs');
  const sidebar=node('div','print-sidebar');sidebar.id='print-sidebar';const heading=node('h2','','Print tables'),list=node('div','print-table-list'),filters=node('div','print-filters');
  const listSearch=node('input','print-list-search');listSearch.type='search';listSearch.placeholder='Find a table';listSearch.setAttribute('aria-label','Find a table to print');
  const actions=node('div','print-list-actions');for(const [label,on] of [['Select all',true],['Clear',false]]){const b=node('button','',label);b.type='button';b.onclick=()=>{for(const item of catalog.filter(i=>i.label.toLowerCase().includes(listSearch.value.toLowerCase())))on?selected.add(item.id):selected.delete(item.id);drawList();};actions.appendChild(b);}
  sidebar.append(heading,listSearch,actions,list,filters);browser.insertBefore(sidebar,browser.querySelector('.browser-footer'));
  const screen=node('section','print-workspace');screen.id='print-workspace';const top=node('div','print-toolbar'),title=node('h1','','Print preview'),exit=node('button','','Back to workbook'),exportButton=node('button','print-export','Export individual PDFs'),previewSelect=node('select','print-preview-select'),orientation=node('select','print-orientation');
  previewSelect.setAttribute('aria-label','Table to preview');orientation.setAttribute('aria-label','Page orientation');for(const [value,label] of [['auto','Automatic orientation'],['portrait','Portrait'],['landscape','Landscape']]){const option=node('option','',label);option.value=value;orientation.appendChild(option);}
  const status=node('p','print-status');status.setAttribute('role','status');const frame=node('iframe','print-preview');frame.title='PDF print preview';
  top.append(title,exit,exportButton);const controls=node('div','print-preview-controls');controls.append(previewSelect,orientation);screen.append(top,controls,status,frame);document.querySelector('.app-shell').appendChild(screen);
  const copyProject=()=>Object.assign(structuredClone(source),structuredClone(settings));
  const drawList=()=>{
    list.replaceChildren();let group='';for(const item of catalog.filter(i=>i.label.toLowerCase().includes(listSearch.value.toLowerCase()))){if(group!==item.group){list.appendChild(node('h3','',item.group));group=item.group;}
      const label=node('label','print-table-option'),check=node('input');check.type='checkbox';check.checked=selected.has(item.id);check.onchange=()=>{check.checked?selected.add(item.id):selected.delete(item.id);previewId=item.id;updatePreviewChoices();};label.append(check,node('span','',item.label));list.appendChild(label);}
    updatePreviewChoices();
  };
  const updatePreviewChoices=()=>{
    previewSelect.replaceChildren();for(const item of catalog.filter(i=>selected.has(i.id))){const o=node('option','',item.label);o.value=item.id;previewSelect.appendChild(o);}
    if(!selected.has(previewId))previewId=[...selected][0]||'';previewSelect.value=previewId;exportButton.disabled=!selected.size||busy;orientation.value=orientations.get(previewId)||'auto';refreshPreview();
  };
  async function modelsFor(id,project){if(id==='psych-chart')return await printPsychModels(project);if(id==='model-inputs')return [printModelInputs()];return [printTableModel(independentTables.find(t=>t.id===id),project)];}
  async function refreshPreview(){
    const request=++generation,id=previewId;if(previewURL){URL.revokeObjectURL(previewURL);previewURL='';}frame.removeAttribute('src');
    if(!id){status.textContent='Select the tables to print in the project browser.';return;}
    status.textContent='Preparing preview…';await new Promise(resolve=>setTimeout(resolve,0));
    try{const project=copyProject(),models=await modelsFor(id,project);if(request!==generation)return;if(!models.length){status.textContent='No rows match these filters.';return;}
      const doc=await PDFLib.PDFDocument.create();for(const model of models){const bytes=await WorkbookPrintPDF.create(model,project,orientations.get(id)||'auto');const part=await PDFLib.PDFDocument.load(bytes);for(const page of await doc.copyPages(part,part.getPageIndices()))doc.addPage(page);}
      const bytes=await doc.save();if(request!==generation)return;previewURL=URL.createObjectURL(new Blob([bytes],{type:'application/pdf'}));frame.src=previewURL;status.textContent=`${selected.size} table${selected.size===1?'':'s'} selected · ${doc.getPageCount()} page${doc.getPageCount()===1?'':'s'} in this preview`;
    }catch(error){if(request===generation)status.textContent=`Preview could not be generated: ${error.message}`;}
  }
  function buildFilter(kind){
    const equipment=kind==='equipment',title=equipment?'Equipment / FCU filter':'Space filter',details=node('details','print-filter'),summary=node('summary','',title);details.appendChild(summary);
    const searchKey=equipment?'equipmentSearch':'sharedSpaceSearch',stateKey=equipment?'equipmentFilter':'sharedSpaceFilter',excludedKey=equipment?'excludedEquipment':'excludedSpaces';
    const search=node('input');search.type='search';search.placeholder=equipment?'Search equipment':'Search space';search.value=settings[searchKey];search.setAttribute('aria-label',search.placeholder);
    const field=node('select');field.setAttribute('aria-label',title+' field');
    const group=node('optgroup');group.label='Shared fields';for(const [value,label] of equipment?[['equipment:unitType','Unit Type']]:[['meta:zoneGroup','Zone Group'],['meta:zone','Zone'],['meta:type','Thermal Template']]){const o=node('option','',label);o.value=value;group.appendChild(o);}field.appendChild(group);
    for(const t of independentTables.filter(t=>equipment?supportsEquipmentFilter(t):supportsSharedSpaceFilter(t)&&!supportsEquipmentFilter(t)&&!t.thermalTemplateCalculation)){
      const group=node('optgroup');group.label=t.name;t.headers.forEach((h,c)=>{if(t.hiddenColumns?.includes(c)||c===(equipment?0:t.spaceColumn)||!equipment&&['Space','Transfer From Space','Transfer To Space'].includes(h.label))return;const o=node('option','',spaceFilterColumnLabel(t,c));o.value=`col:${t.id}:${c}`;group.appendChild(o);});field.appendChild(group);
    }
    field.value=settings[stateKey].field;const values=node('details','print-value-picker'),valueTitle=node('summary','','Values'),valueSearch=node('input');valueSearch.type='search';valueSearch.placeholder='Search values';const options=node('div','print-check-options');values.append(valueTitle,valueSearch,options);
    const choices=node('details','print-value-picker'),choiceTitle=node('summary','',equipment?'Equipment':'Spaces'),choiceSearch=node('input');choiceSearch.type='search';choiceSearch.placeholder=equipment?'Search equipment':'Search spaces';const choiceOptions=node('div','print-check-options');choices.append(choiceTitle,choiceSearch,choiceOptions);
    const clear=node('button','','Clear filter');clear.type='button';let context=null;
    const drawOptions=()=>{options.replaceChildren();for(const option of context?.options||[]){if(!option.label.toLowerCase().includes(valueSearch.value.toLowerCase()))continue;const label=node('label'),check=node('input');check.type='checkbox';check.checked=!settings[stateKey].values||settings[stateKey].values.includes(option.value);check.onchange=()=>{const set=new Set(settings[stateKey].values||context.options.map(o=>o.value));check.checked?set.add(option.value):set.delete(option.value);settings[stateKey].values=set.size===context.options.length?null:[...set];refreshContext();refreshPreview();};label.append(check,node('span','',option.label));options.appendChild(label);}};
    const drawChoices=()=>{choiceOptions.replaceChildren();for(const option of context?.spaceOptions||[]){if(!option.label.toLowerCase().includes(choiceSearch.value.toLowerCase()))continue;const label=node('label'),check=node('input');check.type='checkbox';check.checked=!settings[excludedKey].includes(option.value);check.onchange=()=>{const set=new Set(settings[excludedKey]);check.checked?set.delete(option.value):set.add(option.value);settings[excludedKey]=[...set];refreshPreview();};label.append(check,node('span','',option.label));choiceOptions.appendChild(label);}};
    function refreshContext(){const project=copyProject(),table=independentTables.find(t=>t.id===(equipment?'airside-settings':'iesve-tabular-space-data')),rows=ensureProjectTableRows(project,table);context=prepareSharedSpaceFilter(table,rows,project);drawOptions();drawChoices();}
    field.onchange=()=>{settings[stateKey]={field:field.value,values:null};refreshContext();refreshPreview();};let timer;search.oninput=()=>{settings[searchKey]=search.value;clearTimeout(timer);timer=setTimeout(()=>{refreshContext();refreshPreview();},200);};valueSearch.oninput=drawOptions;choiceSearch.oninput=drawChoices;
    clear.onclick=()=>{settings[searchKey]='';search.value='';settings[stateKey].values=null;settings[excludedKey]=[];refreshContext();refreshPreview();};
    details.append(search,field,values,choices,clear);filters.appendChild(details);refreshContext();
  }
  const close=()=>{if(busy)return;++generation;if(previewURL)URL.revokeObjectURL(previewURL);sidebar.remove();screen.remove();document.body.classList.remove('print-mode');document.querySelector('#close-browser').removeEventListener('click',close);document.removeEventListener('keydown',escape);closeBrowser();syncActiveState();};
  const escape=event=>{if(event.defaultPrevented)return;if(event.key==='Escape'&&!document.querySelector('dialog[open],.cell-dropdown-popup')){event.preventDefault();close();}};
  exit.onclick=close;document.querySelector('#close-browser').addEventListener('click',close);document.addEventListener('keydown',escape);
  previewSelect.onchange=()=>{previewId=previewSelect.value;orientation.value=orientations.get(previewId)||'auto';refreshPreview();};orientation.onchange=()=>{orientations.set(previewId,orientation.value);refreshPreview();};listSearch.oninput=drawList;
  exportButton.onclick=async()=>{
    if(busy||!selected.size)return;busy=true;exportButton.disabled=true;exit.disabled=true;let directory=null;
    try{
      if(window.showDirectoryPicker)try{directory=await window.showDirectoryPicker({mode:'readwrite'});}catch(e){if(e.name==='AbortError')return;if(!['SecurityError','NotAllowedError'].includes(e.name))throw e;}
      const project=copyProject(),files=[];let count=0;const ids=[...selected];
      for(const id of ids){status.textContent=`Preparing ${++count} of ${ids.length}…`;await new Promise(resolve=>setTimeout(resolve,0));const models=await modelsFor(id,project);
        for(const model of models){const bytes=await WorkbookPrintPDF.create(model,project,orientations.get(id)||'auto');const name=`${project.number||'Project'} - ${model.title}`.replace(/[<>:"/\\|?*\x00-\x1f]/g,'-').slice(0,160)+'.pdf';files.push({name,bytes});}
      }
      if(!files.length){status.textContent='No rows match the selected filters.';return;}
      if(directory){for(const file of files){const handle=await directory.getFileHandle(file.name,{create:true}),stream=await handle.createWritable();await stream.write(file.bytes);await stream.close();}status.textContent=`Exported ${files.length} individual PDFs to ${directory.name}.`;}
      else {const url=URL.createObjectURL(WorkbookPrintPDF.zip(files)),link=node('a');link.href=url;link.download=`${project.number||'Project'} - Calculations.zip`;document.body.appendChild(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);status.textContent=`Downloaded ${files.length} individual PDFs in a ZIP. Folder export is available in browsers that support folder selection.`;}
    }catch(error){status.textContent=`Export could not be completed: ${error.message}`;}finally{busy=false;exit.disabled=false;exportButton.disabled=!selected.size;}
  };
  document.body.classList.add('print-mode');scrim.classList.remove('open');document.body.style.overflow='hidden';buildFilter('space');buildFilter('equipment');drawList();
}
document.querySelector('#open-print').addEventListener('click',openWorkbookPrint);
