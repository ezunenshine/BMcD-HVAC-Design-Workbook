/* Print workspace preserves the workbook's project data and keeps separate print filters. */
function printHeaderColor(name='') {
  if(name.includes('preheat'))return '#ce6f09';if(name.includes('latent'))return '#008577';if(name.includes('heating'))return '#bd3818';if(name.includes('sensible-cooling'))return '#0066ff';if(name.includes('exhaust'))return '#805b3f';if(name.includes('ventilation'))return '#008ca8';return '#003b8c';
}
function printFilterDescription(project) {
  const parts=[];
  for(const [kind,search,state,excluded] of [['Spaces',project.sharedSpaceSearch,project.sharedSpaceFilter,project.excludedSpaces],['Equipment',project.equipmentSearch,project.equipmentFilter,project.excludedEquipment]]){
    if(search)parts.push(`${kind} search: ${search}`);
    if(state?.values)parts.push(`${kind} — ${spaceFilterDescriptor(state.field)?.label||state.field}: ${state.values.join(', ')||'(none)'}`);
    if(excluded?.length)parts.push(`${kind}: ${excluded.length} excluded`);
  }return parts.join(' | ');
}
function printTableRules(table){
  const portrait=new Set(['calc-dhw','calc-lighting-gains','calc-people-gains','calc-misc-gains','calc-equipment-zoning','selected-lighting-loads','selected-misc-loads','selected-general-exhaust','selected-exhaust-equipment','selected-transfer-air','airside-settings','airside-airflows','airside-preheat','airside-room-cooling','airside-in-unit-reheat','airside-downstream-reheat','airside-room-heating']);
  return {portrait:portrait.has(table.id)||!!table.energySummary,sort:table.id==='calc-equipment-zoning'?[0,1,2]:table.ventilationRequirementsCalculation?[0,1]:table.id==='calc-exhaust-requirements'?[0,1,2]:['calc-pressurization','calc-air-balancing-requirements'].includes(table.id)?[0,1]:null};
}
function printRowHasValue(value){return value!==null&&value!==undefined&&String(value).trim()!==''&&String(value).trim()!=='-'&&!(Number.isFinite(Number(value))&&Number(value)===0);}
function printTableModel(table,project) {
  if(table.energySimulation)configureEnergyColumns(table,project);
  const rows=ensureProjectTableRows(project,table);recalculateTable(table,rows,project);
  const rules=printTableRules(table),context=prepareSharedSpaceFilter(table,rows,project);let visible=rows.map((row,sourceIndex)=>({row,sourceIndex})).filter(({row})=>!context||sharedSpaceSearchMatches(table,row,project)&&rowMatchesSpaceSet(table,row,context.matchingSpaces)&&(!context.matchingRows||context.matchingRows.has(row)));
  if(table.id==='calc-dhw')visible=visible.filter(({row})=>row.slice(1).some(printRowHasValue));
  if(table.id==='calc-exhaust-requirements')visible=visible.filter(({row})=>[12,13,14].some(c=>printRowHasValue(row[c])));
  if(rules.sort)visible.sort((a,b)=>{for(const c of rules.sort){const n=String(a.row[c]??'').localeCompare(String(b.row[c]??''),undefined,{numeric:true,sensitivity:'base'});if(n)return n;}return a.sourceIndex-b.sourceIndex;});
  else if(!table.energySimulation&&!table.energySummary)orderTableRows(table,rows,visible,project);
  const cols=table.headers.map((_,i)=>i).filter(i=>!table.hiddenColumns?.includes(i));
  const model={notes:calculationDocumentation(project,table.id),title:table.name,section:modules.find(g=>g.items.some(i=>i[3]===table.id))?.group||'',portrait:rules.portrait,energySummary:Boolean(table.energySummary),filterDescription:printFilterDescription(project),columns:cols.map(c=>{const h=table.headers[c],g=table.headerGroups?.find(g=>c>=g.start&&c<g.start+g.span);return {label:`${h.label}${h.subscript||''}`,subscripts:h.subscripts||[],unit:h.unit||'',group:g?.label||'',color:printHeaderColor(table.headerClasses?.[c]),groupColor:printHeaderColor(g?.className),numeric:table.columnTypes[c]==='number',frozen:c<(table.frozenColumns??1),divider:table.sectionStartColumns?.includes(c)};}),rows:[]};
  const palette={white:['#ffffff','#f1f4f7'],blue:['#e9f2ff','#dae9fc'],green:['#e5f3e9','#d7ecdd'],purple:['#eee8fb','#e2daf4'],yellow:['#fff2bd','#f5e4a5'],grey:['#e4e9ec','#d7dfe3']};
  visible.forEach(({row,sourceIndex},visibleIndex)=>{const comparisons=new Map(),backgrounds=cols.map(c=>{
    let tone='white';const locked=table.lockedCellStates?.get(sourceIndex)?.has(c)||table.lockedColumns?.includes(c)||isConditionalCalculatedCell(table,row,c);
    if(table.autoCellStates?.get(sourceIndex)?.has(c)&&!locked)tone='green';
    else if(!locked&&!table.calculatedColumns?.includes(c))tone='blue';
    else if(table.identityColumns?.includes(c))tone='white';else tone='grey';
    if(table.tabularCalculation){const comparison=csvComparisonForCell(table,row,sourceIndex,c);comparisons.set(c,comparison);if(c===tabularColumn.differences)tone=row[c]?'yellow':'white';else if(comparison?.specified&&comparison.mapped)tone=comparison.matches?'purple':'yellow';else if(!comparison?.specified)tone='grey';}
    return table.underPeakCellStates?.get(sourceIndex)?.has(c)?'#ffd5ce':palette[tone][visibleIndex%2];
  });model.rows.push({values:cols.map(c=>formatTableValue(row[c],table,c)),backgrounds,divider:table.energySummary&&sourceIndex===2,boldColumns:table.energySummary&&sourceIndex<2?[0,3,4,5]:[],textColors:cols.map(c=>table.mutedCellStates?.get(sourceIndex)?.has(c)||comparisons.get(c)?.matches===true||table.tabularCalculation&&comparisons.get(c)?.specified===false?'#899198':'#051c38')});});
  if(table.tabularCalculation){model.rows.push({total:true,bold:true,values:cols.map(c=>{
    if(c===tabularColumn.id)return 'Total Differing Values';if(c===tabularColumn.space)return '';
    const total=c===tabularColumn.differences?visible.reduce((n,{row})=>n+requirementNumber(row[c]),0):tabularMismatchTotal(table,visible,c);return total?String(total):'';
  })});}
  else if(table.summaryColumns?.length){model.rows.push({total:true,bold:true,values:cols.map(c=>table.summaryColumns.includes(c)?formatTableValue(summaryValue(visible.map(v=>v.row),c,table.summaryAggregations?.[c]||'sum'),table,c):c===0?table.summaryLabel||'Total':'')});}
  model.topLines=[];model.topFields=[];
  for(const [flag,label,fallback] of [['ventilationMinimumDefault','Ventilation Minimum',25],['exhaustMinimumDefault','Exhaust Minimum',25],['supplyMinimumDefault','Supply Minimum',50]])if(table[flag]&&flag!=='supplyMinimumDefault'){const value=airflowMinimum(project,table.id,fallback);model.topFields.push({label:label+' [CFM]',value:String(value),fill:value===fallback?'#e5f3e9':'#e9f2ff'});}
  if(table.conditionBaselineCalculation){const d=conditionBaselineDefaults(project);for(const [label,value] of [['Cooled Space Relative Bound',d.cooling],['Heated Space Relative Bound',d.heating],['Semi-Heated Space Relative Bound',d.semiheated]])model.topFields.push({label,value:value+' Btu/h-ft2',fill:'#e4e9ec'});}
  const sum=c=>visible.reduce((n,{row})=>n+requirementNumber(row[c]),0);
  for(const metric of table.topMetrics||(table.topMetric?[table.topMetric]:[])){const numerator=metric.numeratorDifference?sum(metric.numeratorDifference[0])-sum(metric.numeratorDifference[1]):sum(metric.numerator),denominator=sum(metric.denominator);model.topFields.push({label:metric.label,value:denominator?(100*numerator/denominator).toFixed(1)+'%':'-',fill:'#e4e9ec'});}
  if(table.energySummary){const pci=project.energyAnalysis?.pci,target=project.energyAnalysis?.pciTarget,ready=pci!==undefined&&pci!==''&&target!==undefined&&target!=='';const proposed=rows[0]?.[3],baseline=rows[1]?.[3],energyReady=typeof proposed==='number'&&typeof baseline==='number';model.energyChecks={pci:pci??'',target:target??'',pciText:ready?`The performance cost index\n${pci<=target?'is less than or equal to':'exceeds'}\nthe performance cost index target`:'Enter both index values',pciPass:ready?pci<=target:null,energyText:energyReady?`The proposed building’s energy consumption\n${proposed<=baseline?'is less than or equal to':'exceeds'}\nthe baseline building’s energy consumption`:'Import electricity and natural gas for all five simulations',energyPass:energyReady?proposed<=baseline:null};}
  return model;
}
async function printPsychModels(project,equipmentTag) {
  const data=buildPsychChartData(project),settings=independentTables.find(t=>t.id==='airside-settings'),rows=ensureProjectTableRows(project,settings),filter=prepareEquipmentFilter(settings,rows,project);
  const equipment=new Set(rows.filter(r=>sharedSpaceSearchMatches(settings,r,project)&&rowMatchesSpaceSet(settings,r,filter.matchingSpaces)).map(r=>requirementKey(r[0])));
  const response=await fetch('psych-chart.png');if(!response.ok)throw Error('The psychrometric chart image could not be loaded.');const sourceImage=await createImageBitmap(await response.blob()),canvas=document.createElement('canvas');canvas.width=sourceImage.width;canvas.height=sourceImage.height;const context=canvas.getContext('2d');context.filter='grayscale(1)';context.drawImage(sourceImage,0,0);sourceImage.close();const blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/png'));const image=new Uint8Array(await blob.arrayBuffer());
  return [...new Set(data.lines.filter(l=>equipmentTag?requirementKey(l.equipment)===requirementKey(equipmentTag):equipment.has(requirementKey(l.equipment))).map(l=>l.equipment))].map(tag=>{
    const lines=data.lines.filter(l=>l.equipment===tag);return {portrait:true,notes:calculationDocumentation(project,'psych:'+tag),title:`${tag} Psychrometric Chart`,section:'Psychrometric Calculations',filterDescription:printFilterDescription(project),columns:psychTableHeaders().map((label,c)=>({label:label.replace(/\s*\[[^\]]+\]$/,''),unit:label.match(/\[([^\]]+)\]$/)?.[1]||'',group:c===0?'Coil':c<7?'Entering Conditions':c<11?'Leaving Condition':'Capacity',frozen:c===0,numeric:c>0,color:'#003b8c',divider:[1,7,11].includes(c)})),rows:lines.map((line,i)=>({values:psychTableValues(line,data.pressure),fill:'#ffffff',outlineColor:psychLineStyle(line).color,textColors:psychTableHeaders().map((_,c)=>line.loser&&c>0?'#899198':'#051c38')})),chart:{image,markers:psychStateMarkers(lines).map(m=>({...m,point:psychChartPoint(m.db,m.hr)})),lines:lines.map(line=>({color:psychLineStyle(line).color,points:(line.cooling?psychCoolingPath(line.enter,line.leave,data.pressure):[line.enter,line.leave]).map(p=>psychChartPoint(p.db,p.hr))}))}};
  });
}
// Capture the actual Model Inputs layout as vector boxes and text, not a bitmap.
function printModelInputs() {
  renderModelInputs();const clone=modelInputsView.cloneNode(true);clone.id='';clone.hidden=false;clone.className='model-inputs-view print-model-capture';
  const sources=modelInputsView.querySelectorAll('input,select');clone.querySelectorAll('input,select').forEach((el,i)=>{el.value=sources[i].value;el.checked=sources[i].checked;});
  clone.querySelectorAll('.required-marker,.iesve-set-marker,.model-input-formula,.model-input-key').forEach(n=>n.remove());clone.querySelectorAll('.construction-add,.construction-remove').forEach(n=>{n.style.visibility='hidden';});
  clone.style.cssText='position:fixed;left:-14000px;top:0;width:1120px;padding:0;display:block;visibility:hidden;pointer-events:none';document.body.appendChild(clone);
  const origin=clone.getBoundingClientRect(),form={width:origin.width,height:origin.height,items:[]};
  const box=n=>{const r=n.getBoundingClientRect();return {x:r.left-origin.left,y:r.top-origin.top,width:r.width,height:r.height};};
  const color=v=>{const a=v.match(/[\d.]+/g);return a?'#'+a.slice(0,3).map(x=>Math.round(Number(x)).toString(16).padStart(2,'0')).join(''):'#051c38';};
  const addText=(n,value,rect)=>{const css=getComputedStyle(n);if(!value||!rect.width||!rect.height)return;form.items.push({...rect,singleLine:true,type:'text',text:value,color:color(css.color),size:parseFloat(css.fontSize),bold:Number(css.fontWeight)>=600,align:css.textAlign,uppercase:css.textTransform==='uppercase'});};
  for(const n of clone.querySelectorAll('*')){
    if(n.closest('button,.construction-add,.construction-remove')||getComputedStyle(n).display==='none')continue;
    const css=getComputedStyle(n),r=box(n);if(!r.width||!r.height)continue;
    if(n.matches('input,select')){form.items.push({...r,type:'box',fill:color(css.backgroundColor),border:color(css.borderColor)});addText(n,n.tagName==='SELECT'?n.selectedOptions[0]?.textContent||'':n.type==='checkbox'?(n.checked?'TRUE':''):n.value,{x:r.x+8,y:r.y+7,width:r.width-16,height:r.height-10});continue;}
    if(n.matches('.model-input-section'))form.items.push({type:'line',x:r.x,y:r.y+r.height,width:r.width,color:'#d3dce2'});
    for(const textNode of n.childNodes)if(textNode.nodeType===3&&textNode.textContent.trim()){
      const range=document.createRange(),chunks=[];for(let k=0;k<textNode.textContent.length;k++){range.setStart(textNode,k);range.setEnd(textNode,k+1);const t=range.getBoundingClientRect();if(!t.width)continue;let item=chunks.at(-1);if(!item||Math.abs(item.top-t.top)>1){item={text:'',left:t.left,right:t.right,top:t.top,height:t.height};chunks.push(item);}item.text+=textNode.textContent[k];item.right=t.right;}
      for(const chunk of chunks)addText(n,chunk.text,{x:chunk.left-origin.left,y:chunk.top-origin.top,width:chunk.right-chunk.left+.8,height:chunk.height});
    }
  }
  clone.remove();return {notes:calculationDocumentation(activeProject(),'model-inputs'),title:'Model Inputs',section:'Model Inputs',portrait:true,form,columns:[],rows:[]};
}
function openWorkbookPrint() {
  if(document.body.classList.contains('print-mode'))return;
  closeCellDropdown();clearTableSelection();setProjectSwitcher(false);
  syncPsychChartSelections(activeProject());
  const source=activeProject(),settings={sharedSpaceSearch:'',sharedSpaceFilter:structuredClone(source.sharedSpaceFilter||{field:'meta:zoneGroup',values:null}),excludedSpaces:[...(source.excludedSpaces||[])],equipmentSearch:'',equipmentFilter:structuredClone(source.equipmentFilter||{field:'equipment:unitType',values:null}),excludedEquipment:[...(source.excludedEquipment||[])]};
  const selected=new Set(),catalog=[{id:'model-inputs',label:'Model Inputs',group:'Model Inputs'}],seen=new Set(['model-inputs']),cache=new Map();let generation=0,busy=false,previewId='',closed=false;
  const node=(tag,className,text)=>{const n=document.createElement(tag);if(className)n.className=className;if(text!==undefined)n.textContent=text;return n;};
  function rebuildCatalog(){catalog.splice(1);seen.clear();seen.add('model-inputs');for(const group of modules){if(group.group==='IESVE 2025'||/independent/i.test(group.group))continue;for(const item of group.items){const id=item[4]?'psych:'+item[4]:item[3];if(!id||id==='airside-schedules'||seen.has(id)||!item[4]&&!independentTables.some(t=>t.id===id))continue;seen.add(id);catalog.push({id,label:item[0],group:group.group});}}for(const id of selected)if(!seen.has(id))selected.delete(id);}
  rebuildCatalog();
  if(activeTableId&&seen.has(activeTableId))selected.add(activeTableId);else if(document.querySelector('#psych-chart-view')&&seen.has('psych:'+source.psychEquipment))selected.add('psych:'+source.psychEquipment);else if(!modelInputsView.hidden)selected.add('model-inputs');
  const sidebar=node('div','print-sidebar');sidebar.id='print-sidebar';const heading=node('div','export-heading'),back=node('button','project-switcher-toggle export-back');back.type='button';back.title='Back to Calculations Workbook';back.setAttribute('aria-label',back.title);back.innerHTML='<svg aria-hidden="true" viewBox="0 0 24 24"><path d="M19 12H5"></path><path d="m11 18-6-6 6-6"></path></svg>';const identity=node('div','sidebar-identity'),logo=node('img','browser-logo');logo.src='./burns-mcdonnell-stacked-white.png';logo.alt='Burns & McDonnell';identity.appendChild(logo);heading.append(back,identity);
  const listSearch=node('input','print-list-search');listSearch.type='search';listSearch.placeholder='Find a calculation';listSearch.setAttribute('aria-label','Find a calculation to export');
  const actions=node('div','print-list-actions'),list=node('div','print-table-list');
  sidebar.append(heading,listSearch,actions,list);browser.insertBefore(sidebar,browser.querySelector('.browser-footer'));
  const screen=node('section','print-workspace');screen.id='print-workspace';const pages=node('div','print-preview-pages');pages.setAttribute('aria-label','Calculation pages');screen.appendChild(pages);document.querySelector('.app-shell').appendChild(screen);
  const footer=node('div','print-footer-controls'),status=node('p','print-status'),exportButton=node('button','print-export','Export (0) PDFs');status.setAttribute('role','status');exportButton.type='button';footer.append(status,exportButton);browser.querySelector('.browser-footer').prepend(footer);
  const preview=createWorkbookPDFPreview(pages);
  const copyProject=()=>Object.assign(structuredClone(source),structuredClone(settings));
  previewId=[...selected][0]||catalog[0].id;
  const selectionChanged=()=>{exportButton.textContent=`Export (${selected.size}) PDFs`;exportButton.disabled=!selected.size||busy;const candidates=catalog.filter(i=>!i.picker&&!i.disabled);const all=actions.querySelector('.select-all'),none=actions.querySelector('.unselect-all');if(all)all.disabled=candidates.every(i=>selected.has(i.id));if(none)none.disabled=!selected.size;if(clearFilters)clearFilters.disabled=!settings.sharedSpaceFilter.values&&!settings.equipmentFilter.values&&!settings.excludedSpaces.length&&!settings.excludedEquipment.length;};
  const filterElements={space:buildFilter(false),equipment:buildFilter(true)};
  function drawList(){
    list.replaceChildren();let group='';for(const item of catalog.filter(item=>item.picker||item.label.toLowerCase().includes(listSearch.value.toLowerCase()))){
      if(group!==item.group&&item.id!=='model-inputs'){const head=node('div','print-section-heading');if(['Space Calculations','Airside Equipment Calculations','Psychrometric Calculations','Plantside Equipment Calculations','Energy Analysis','Energy'].includes(item.group))head.classList.add('print-section-divider');if(item.group==='Space Calculations')head.appendChild(filterElements.space);if(item.group==='Airside Equipment Calculations')head.appendChild(filterElements.equipment);head.appendChild(node('h3','',item.group));list.appendChild(head);group=item.group;}
      const row=node('div','print-table-option'),check=node('input'),button=node('button','print-table-name',item.label);row.dataset.previewId=item.id;row.classList.toggle('is-previewed',previewId===item.id);check.type='checkbox';check.checked=selected.has(item.id);check.setAttribute('aria-label','Include '+item.label+' in export');check.onchange=()=>{check.checked?selected.add(item.id):selected.delete(item.id);selectionChanged();};button.type='button';button.onclick=()=>{previewId=item.id;list.querySelectorAll('[data-preview-id]').forEach(n=>n.classList.toggle('is-previewed',n.dataset.previewId===previewId));refreshPreview();};row.append(check,button);if(item.id!=='model-inputs'&&!item.id.startsWith('psych:')){const badge=node('span','item-count');badge.dataset.printCountTable=item.id;row.appendChild(badge);}list.appendChild(row);
    }updatePrintCounts();selectionChanged();
  }
  function updatePrintCounts(){
    const project=copyProject();
    for(const item of catalog){
      let total=1,visible=1;
      if(item.id!=='model-inputs'&&!item.id.startsWith('psych:')){
        const table=independentTables.find(t=>t.id===item.id),rows=project.independentTables?.[table.id]||table.rows,context=prepareSharedSpaceFilter(table,rows,project,false);
        total=rows.length;visible=rows.filter(row=>!context||sharedSpaceSearchMatches(table,row,project)&&rowMatchesSpaceSet(table,row,context.matchingSpaces)&&(!context.matchingRows||context.matchingRows.has(row))).length;
      }
      item.disabled=visible===0;if(item.disabled)selected.delete(item.id);
      const row=[...list.querySelectorAll('[data-preview-id]')].find(row=>row.dataset.previewId===item.id);if(!row)continue;
      row.classList.toggle('is-empty',item.disabled);const check=row.querySelector('input'),button=row.querySelector('button');check.disabled=button.disabled=item.disabled;check.checked=selected.has(item.id);button.title=item.disabled?'No visible rows to export':'';
      const badge=row.querySelector('[data-print-count-table]');if(badge){badge.textContent=visible===total?String(total):`${visible}/${total}`;badge.classList.toggle('is-filtered',visible!==total);}
    }
    if(catalog.find(i=>i.id===previewId)?.disabled){previewId='';++generation;preview.clear();status.textContent='Select a calculation with visible rows to preview.';}
  }
  for(const [label,on,cls] of [['Select all',true,'select-all'],['Select None',false,'unselect-all']]){const button=node('button',cls,label);button.type='button';button.onclick=()=>{for(const item of catalog.filter(i=>!i.picker&&(!on||!i.disabled)&&i.label.toLowerCase().includes(listSearch.value.toLowerCase())))on?selected.add(item.id):selected.delete(item.id);drawList();};actions.appendChild(button);}
  const clearFilters=node('button','clear-all-filters','Clear Filters');clearFilters.type='button';clearFilters.onclick=()=>{for(const key of ['sharedSpaceFilter','equipmentFilter'])settings[key].values=null;settings.excludedSpaces=[];settings.excludedEquipment=[];filtersChanged();};actions.appendChild(clearFilters);
  async function getPDF(id){
    const key=JSON.stringify([id,settings]);if(cache.has(key))return cache.get(key);
    const pending=(async()=>{const project=copyProject(),item=catalog.find(i=>i.id===id);let models=id.startsWith('psych:')?await printPsychModels(project,id.slice(6)):id==='model-inputs'?[printModelInputs()]:[printTableModel(independentTables.find(t=>t.id===id),project)];
      if(!models.length)models=[{title:item.label,columns:[{label:'Equipment'}],rows:[],filterDescription:'No equipment matches the selected filters.'}];
      return await WorkbookPrintPDF.create(models,project);})();cache.set(key,pending);try{return await pending;}catch(e){cache.delete(key);throw e;}
  }
  async function refreshPreview(){
    const request=++generation,id=previewId;
    if(!id){await preview.clear();status.textContent='Select calculations to view their pages.';return;}
    status.textContent='Preparing pages…';await new Promise(resolve=>setTimeout(resolve,0));if(request!==generation||closed)return;
    try{const bytes=await getPDF(id);if(request!==generation||closed)return;await preview.show(bytes);if(request===generation)status.textContent='';}
    catch(error){if(request===generation&&!closed)status.textContent=`Unable to show these pages. ${error.message}`;}
  }
  function filtersChanged(){cache.clear();filterElements.space.refreshLabels();filterElements.equipment.refreshLabels();updatePrintCounts();selectionChanged();refreshPreview();}
  function buildFilter(equipment){
    const box=node('div','space-filter print-filter-strip'),stateKey=equipment?'equipmentFilter':'sharedSpaceFilter',excludedKey=equipment?'excludedEquipment':'excludedSpaces';
    const fieldLabel=node('label','filter-field'),field=node('select');field.setAttribute('aria-label',equipment?'Equipment filter by':'Space filter by');fieldLabel.append(node('span','','Filter by'),field);
    const shared=node('optgroup');shared.label='Shared fields';for(const [value,label] of equipment?[['equipment:unitType','Unit Type']]:[['meta:zoneGroup','Zone Group'],['meta:zone','Zone'],['meta:type','Thermal Template']]){const option=node('option','',label);option.value=value;shared.appendChild(option);}field.appendChild(shared);
    for(const table of independentTables.filter(t=>equipment?supportsEquipmentFilter(t):supportsSharedSpaceFilter(t)&&!supportsEquipmentFilter(t)&&!t.thermalTemplateCalculation)){
      const group=node('optgroup');group.label=table.name;table.headers.forEach((header,c)=>{if(table.hiddenColumns?.includes(c)||c===(equipment?0:table.spaceColumn))return;const option=node('option','',spaceFilterColumnLabel(table,c));option.value=`col:${table.id}:${c}`;group.appendChild(option);});field.appendChild(group);
    }field.value=settings[stateKey].field;field.onpointermove=event=>field.classList.toggle('arrow-hover',event.clientX>=field.getBoundingClientRect().right-34);field.onpointerleave=()=>field.classList.remove('arrow-hover');
    const values=node('button','print-filter-toggle','All values'),spaces=node('button','print-filter-toggle',equipment?'All equipment':'All spaces');values.type='button';spaces.type='button';for(const button of [values,spaces]){button.setAttribute('aria-haspopup','dialog');button.setAttribute('aria-expanded','false');button.onpointermove=event=>button.classList.toggle('arrow-hover',event.clientX>=button.getBoundingClientRect().right-34);button.onpointerleave=()=>button.classList.remove('arrow-hover');}
    const wrap=(label,control)=>{const el=node('label');el.append(node('span','',label),control);return el;};box.append(fieldLabel,wrap('Values',values),wrap(equipment?'Equipment':'Spaces',spaces));
    box.refreshLabels=()=>{values.textContent=settings[stateKey].values?`${settings[stateKey].values.length} values selected`:'All values';spaces.textContent=settings[excludedKey].length?`${settings[excludedKey].length} excluded`:equipment?'All equipment':'All spaces';};
    const getContext=()=>{const project=copyProject(),table=independentTables.find(t=>t.id===(equipment?'airside-settings':'iesve-tabular-space-data')),rows=ensureProjectTableRows(project,table);return prepareSharedSpaceFilter(table,rows,project);};
    function openOptions(button,spaceChoice,initial=''){
      closeCellDropdown();const context=getContext(),options=spaceChoice?context.spaceOptions:context.options,chosen=new Set(spaceChoice?options.filter(o=>!settings[excludedKey].includes(o.value)).map(o=>o.value):settings[stateKey].values||options.map(o=>o.value));
      const popup=node('div','cell-dropdown-popup print-filter-popover');popup.setAttribute('role','dialog');popup.setAttribute('aria-label',spaceChoice?equipment?'Equipment':'Spaces':'Values');const query=node('input');query.type='search';query.placeholder='Search';query.value=initial;query.setAttribute('aria-label','Search filter choices');const allLabel=node('label','filter-option'),all=node('input');all.type='checkbox';allLabel.append(all,node('span','','Select all'));const choices=node('div','filter-options'),buttons=node('div','filter-popover-actions'),cancel=node('button','','Cancel'),apply=node('button','','Apply');cancel.type='button';apply.type='button';buttons.append(cancel,apply);popup.append(query,allLabel,choices,buttons);document.body.appendChild(popup);button.setAttribute('aria-expanded','true');
      const dismiss=()=>{popup.remove();button.setAttribute('aria-expanded','false');document.removeEventListener('pointerdown',outside,true);};const outside=event=>{if(!popup.contains(event.target)&&event.target!==button)dismiss();};document.addEventListener('pointerdown',outside,true);
      const shown=()=>options.filter(o=>o.label.toLowerCase().includes(query.value.toLowerCase()));
      const draw=()=>{choices.replaceChildren();const matches=shown();all.checked=matches.length>0&&matches.every(o=>chosen.has(o.value));all.indeterminate=matches.some(o=>chosen.has(o.value))&&!all.checked;for(const option of matches){const label=node('label','filter-option'),check=node('input');check.type='checkbox';check.checked=chosen.has(option.value);check.onchange=()=>{check.checked?chosen.add(option.value):chosen.delete(option.value);all.checked=shown().every(o=>chosen.has(o.value));all.indeterminate=shown().some(o=>chosen.has(o.value))&&!all.checked;};label.append(check,node('span','',option.label));choices.appendChild(label);}if(!matches.length)choices.appendChild(node('p','','No matching values'));};
      query.oninput=draw;all.onchange=()=>{for(const option of shown())all.checked?chosen.add(option.value):chosen.delete(option.value);draw();};cancel.onclick=dismiss;apply.onclick=()=>{if(spaceChoice){const excluded=new Set(settings[excludedKey]);for(const option of options)chosen.has(option.value)?excluded.delete(option.value):excluded.add(option.value);settings[excludedKey]=[...excluded];}else settings[stateKey].values=chosen.size===options.length?null:[...chosen];dismiss();filtersChanged();};popup.onkeydown=event=>{if(event.key==='Escape'){event.preventDefault();event.stopPropagation();dismiss();button.focus();}};
      draw();positionCellPopup(popup,button);query.focus();
    }
    for(const [button,choice] of [[values,false],[spaces,true]]){button.onclick=event=>{if(event.detail===0||event.clientX>=button.getBoundingClientRect().right-34)openOptions(button,choice);};button.onkeydown=event=>{if(!event.ctrlKey&&!event.metaKey&&event.key.length===1){event.preventDefault();openOptions(button,choice,event.key);}else if(event.altKey&&event.key==='ArrowDown'){event.preventDefault();openOptions(button,choice);}};}
    field.onchange=()=>{settings[stateKey]={field:field.value,values:null};filtersChanged();};box.refreshLabels();return box;
  }
  function close(){if(busy)return;closed=true;++generation;closeCellDropdown();preview.destroy();sidebar.remove();footer.remove();screen.remove();document.body.classList.remove('print-mode');document.removeEventListener('keydown',escape);closeBrowser();renderTree(search.value);}
  function escape(event){if(!event.defaultPrevented&&event.key==='Escape'&&!document.querySelector('dialog[open],.cell-dropdown-popup')){event.preventDefault();close();}}
  back.onclick=close;document.addEventListener('keydown',escape);listSearch.oninput=drawList;
  exportButton.onclick=async()=>{
    if(busy||!selected.size)return;busy=true;exportButton.disabled=true;back.disabled=true;
    try{let count=0;const ids=catalog.filter(item=>selected.has(item.id)&&!item.disabled);for(const item of ids){status.textContent=`Preparing download ${++count} of ${ids.length}…`;const bytes=await getPDF(item.id),name=item.label.replace(/[<>:"/\\|?*\x00-\x1f]/g,'-').slice(0,180)+'.pdf';downloadWorkbookFile(new Blob([bytes],{type:'application/pdf'}),name);await new Promise(resolve=>setTimeout(resolve,250));}status.textContent=`Downloaded ${ids.length} PDFs.`;}
    catch(error){status.textContent=`Unable to export. ${error.message}`;}finally{busy=false;back.disabled=false;selectionChanged();}
  };
  document.body.classList.add('print-mode');scrim.classList.remove('open');document.body.style.overflow='hidden';drawList();requestAnimationFrame(()=>requestAnimationFrame(refreshPreview));
}
document.querySelector('#open-print').addEventListener('click',openWorkbookPrint);
