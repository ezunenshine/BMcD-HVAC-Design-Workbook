/* Preserve stored column positions while extending workbook behavior. */
const WATER_PROPERTY_REFERENCE='NIST Chemistry WebBook, SRD 69 - Isobaric Properties for Water.';
const IMC_EXHAUST_REFERENCE='2021 Internation Mechanical Code (IMC) - Table 403.3.1.1.';
const INDEPENDENT_REFERENCE_TEXT={
 'water-nist-properties':[WATER_PROPERTY_REFERENCE],
 'ashrae-90-1-baseline-systems':['ASHRAE Standard 90.1-2019 - Table G3.1.1-4.'],
 'ashrae-climate-zones':['ASHRAE Standard 90.1-2019 - Table G3.1.1-3.'],
 'ashrae-fundamentals-people-heat':['ASHRAE Fundamentals-2025 - Chapter 18, Table 4'],
 'ashrae-90-1-proposed-lighting':['ASHRAE Standard 90.1-2019 - Table 9.6.1'],
 'ashrae-90-1-baseline-lighting':['ASHRAE Standard 90.1-2019 - Table G3.7'],
 'ashrae-62-1-ventilation':['ASHRAE Standard 62.1-2016 - Table 6.2.2.1'],
 'schedule-general-exhaust':[IMC_EXHAUST_REFERENCE,'ASHRAE Standard 62.1-2016 - Table 6.5.']
};
for(const kind of ['ethylene','propylene'])for(const property of ['density','specific-heat'])INDEPENDENT_REFERENCE_TEXT['water-'+kind+'-'+property]=['ASHRAE Fundamentals - Fundamentals, 2025.',WATER_PROPERTY_REFERENCE];
function configureWorkbookSecondUpdates(){
 const get=id=>independentTables.find(t=>t.id===id);
 const coil=get('airside-ventilation-cooling');coil.sectionStartColumns=[...new Set([...coil.sectionStartColumns,1,9])];
 for(const t of independentTables.filter(t=>t.systemAirBalanceMode)){delete t.topMetric;delete t.topMetrics;}
 for(const id of ['room-zone-loads-report','iesve-apachehvac-controllers'])get(id).zoneGroupDividers=true;
 const controllers=get('iesve-apachehvac-controllers');controllers.zeroAsDashColumns=Array.from({length:15},(_,i)=>i+2);
 controllers.headers[3].label=controllers.columns[3]='Cooling Maximum';controllers.headers[4].label=controllers.columns[4]='Heating Maximum';
 controllers.headerGroups.splice(1,2,{label:'Zone Level Recirculation',start:3,span:2,className:'space-group-header'});controllers.sectionStartColumns=controllers.sectionStartColumns.filter(c=>c!==4);
 // Disambiguate identical labels in the two cooling/heating groups.
 controllers.formulaColumnAliases={'Zone Cooling Maximum':3,'Zone Heating Maximum':4,'VAV Cooling Maximum':7,'VAV Heating Maximum':8};
 for(const [id,refs]of Object.entries(INDEPENDENT_REFERENCE_TEXT)){
  const t=get(id);if(!t)continue;t.fixedReferences=refs;t.identityColumns=[];
  const full=id.startsWith('water-')||['ashrae-90-1-baseline-systems','ashrae-climate-zones'].includes(id);
  t.referencePolicy=full?'all':id==='schedule-general-exhaust'?'exhaust':'baseline';
  if(full){t.fixedRows=true;t.noSearch=true;t.noSort=true;t.lockedColumns=t.headers.map((_,i)=>i);}
  if(id.startsWith('water-')&&id!=='water-nist-properties'){t.referenceBlueColumns=[1];t.referenceBlueRows=[1];}
  if(t.referencePolicy==='exhaust'){
   t.headers.push({label:'Source'},{label:'Lookup Key'});t.columns.push('Source','Lookup Key');t.columnTypes.push('text','text');
   t.sourceColumn=8;t.lockedColumns=[...(t.lockedColumns||[]),8,9];t.hiddenColumns=[...(t.hiddenColumns||[]),9];
   t.displayColumnOrder=[8,0,1,2,3,4,5,6,7,9];t.frozenColumns=0;t.equations[7]='=COUNTIF([General Exhaust Requirements]@Requirement,@[Lookup Key])';
   t.displayEquations={...t.displayEquations,7:t.equations[7]};
   const requirements=get('selected-general-exhaust');requirements.dropdownColumns[4]={...requirements.dropdownColumns[4],sourceColumn:9,groupBySource:true};
   for(const c of [6,7,8,10,11,12])requirements.displayEquations[c]=requirements.displayEquations[c].replace('[General Exhaust Schedule]@Requirement','[General Exhaust Schedule]@[Lookup Key]');
  }
  t.referenceMarkerColumn=t.columns.length;t.headers.push({label:'Reference Row Status'});t.columns.push('Reference Row Status');t.columnTypes.push('text');t.hiddenColumns=[...(t.hiddenColumns||[]),t.referenceMarkerColumn];
  if(t.displayColumnOrder)t.displayColumnOrder.push(t.referenceMarkerColumn);
  t.rows=t.rows.map(row=>{const r=[...row];while(r.length<t.columns.length)r.push('');r[t.referenceMarkerColumn]=full||t.referencePolicy==='baseline'?'standard':'user';if(t.referencePolicy==='exhaust'){r[8]='User-Input';r[9]=r[0];}return r;});
 }
 for(const t of independentTables.filter(t=>t.plantCalculation)){
  const water=t.plantCalculation==='cooling'?12:10,c=t.columns.length;t.glycolTypeColumn=c;
  t.headers.push({label:'Glycol Type'});t.columns.push('Glycol Type');t.columnTypes.push('text');t.rows.forEach(r=>r.push(Number(r[water+3])>0?'Ethylene':'None'));
  t.autoColumns.push(c);t.dropdownColumns[c]={options:['Ethylene','Propylene'],noBlank:true};t.displayEquations[c]='=IF(@Glycol=0,"None","Ethylene")';
  t.displayColumnOrder=[...Array.from({length:water+4},(_,i)=>i),c,...Array.from({length:4},(_,i)=>water+4+i)];
  t.headerGroups.find(g=>g.start===water).span++;
 }
}
function markReferenceUserRow(table,row){row[table.referenceMarkerColumn]='user';if(table.referencePolicy==='equipment'){row[7]='User-Inputs';row[12]=row[0];}if(table.referencePolicy==='hotwater')row[3]='User-Input';if(table.referencePolicy==='exhaust'){row[8]='User-Input';row[9]=row[0];}}
function initializeSecondUpdateRows(project,table){
 if(table.plantCalculation){const rows=project.independentTables[table.id];if(Array.isArray(rows))for(const r of rows)if(r.length===table.glycolTypeColumn)r.push(Number(r[(table.plantCalculation==='cooling'?12:10)+3])>0?'Ethylene':'None');}
 if(!table.referencePolicy)return;
 let rows=project.independentTables[table.id];
 if(!Array.isArray(rows))rows=project.independentTables[table.id]=table.rows.map(r=>[...r]);
 for(const row of rows){while(row.length<table.columns.length)row.push('');if(!row[table.referenceMarkerColumn])row[table.referenceMarkerColumn]=table.referencePolicy==='exhaust'?'user':'standard';}
 if(table.referencePolicy==='exhaust'){
  project.referenceDataMigrations||={};
  if(!project.referenceDataMigrations.exhaust2026){
   for(const r of rows){r[8]='User-Input';r[9]=r[0];r[table.referenceMarkerColumn]='user';}
   for(const source of EXHAUST_REFERENCE_ROWS){if(project.newProjectDefaultsFourth&&source[8]==='User-Input')continue;const r=[...source];r[table.referenceMarkerColumn]=source[8]==='User-Input'?'laboratory':'standard';rows.push(r);}
   project.referenceDataMigrations.exhaust2026=true;
  }
  for(const r of rows){r[8]=r[table.referenceMarkerColumn]==='user'?'User-Input':r[8];r[9]=r[8]==='User-Input'?r[0]:`${r[8]} — ${r[0]}`;}
 }
 // Prevent generic schema migration from replacing protected/user rows with defaults.
 if(table.schemaVersion)project.independentTableSchemaVersions[table.id]=table.schemaVersion;
}
function referenceCellLocked(table,row,column){
 if(table?.id==='ashrae-fundamentals-people-heat'&&column===4)return false;
 if(!table?.referencePolicy)return false;
 const third=thirdCellLocked(table,row,column);if(third!==null)return third;
 const marker=row?.[table.referenceMarkerColumn];
 return table.referencePolicy==='all'||column===table.referenceMarkerColumn||marker==='standard'||(table.referencePolicy==='exhaust'&&([8,9].includes(column)||marker==='laboratory'&&column===0));
}
function referenceRowProtected(table,row){return !!table&&(!!table.fixedRows||!!table.referencePolicy&&['standard','laboratory'].includes(row?.[table.referenceMarkerColumn]));}
function updateRemoveRowAvailability(){
 const table=independentTables.find(t=>t.id===activeTableId);if(!table)return;
 const selected=selectedRemovalIndexes();
 const rows=activeProject()?.independentTables?.[table.id]||table.rows;
 removeTableRowButton.disabled=isWorkbookReadOnly()||!selected.size||[...selected].every(i=>referenceRowProtected(table,rows[i]));
}
function configureControllerFormulaFunctions(){
 formulaFunctionDefinitions.WEIGHTEDAVERAGE=args=>{const values=args.length===4?`VSTACK(${args[0]},${args[2]})`:args[0],weights=args.length===4?`VSTACK(${args[1]},${args[3]})`:args[1];return `LET(values,${values},weights,${weights},IF(SUM(weights)=0,"",SUMPRODUCT(values,weights)/SUM(weights)))`;};
 const ref=(id,c)=>scheduleSourceReference(id,c),zone='calc-equipment-zoning',report='room-zone-loads-report';
 const inZone=(id,group,z)=>`(XLOOKUP(${ref(id,independentTables.find(t=>t.id===id).spaceColumn??0)},${ref(zone,2)},${ref(zone,0)},"")=${group})*(XLOOKUP(${ref(id,independentTables.find(t=>t.id===id).spaceColumn??0)},${ref(zone,2)},${ref(zone,1)},"")=${z})`;
 formulaFunctionDefinitions.COUNT_SPACES_IN_ZONE=([group,z])=>`SUMPRODUCT(N(UNIQUE(FILTER(${ref(report,2)},(${ref(report,0)}=${group})*(${ref(report,1)}=${z}),""))<>""))`;
 formulaFunctionDefinitions.SUM_ZONE_PEAK=([group,z,kind])=>{
  const type=String(kind).replaceAll('"',''),heat=type==='Zone Recirculation Heating'||type==='Reheat Heating',equipment=type==='Zone Recirculation Cooling'?9:type==='Zone Recirculation Heating'?10:type==='Central Cooling'?4:6;
  const id='calc-peak-airflows',pc=heat?6:1,flow=type==='Zone Recirculation Heating'?`(${ref(id,10)}+${ref(id,18)})`:ref(id,heat?10:4);
  return `SUMPRODUCT(${inZone(id,group,z)}*(${ref(id,pc)}<>"")*(${ref(id,pc)}<>"-")*(COUNTIF(${ref(zone,equipment)},${ref(id,pc)})>0),${flow})`;
 };
 formulaFunctionDefinitions.SUM_ZONE_AIRFLOW=([group,z,kind])=>{
  const type=String(kind).replaceAll('"',''),spec={
   'Occupied Ventilation':[['doas-zone','occupiedVentilation'],['doas-ahu','occupiedVentilation']],
   'Occupied Exhaust':[['doas-zone','occupiedExhaust'],['doas-ahu','occupiedExhaust'],['ahu-economizing','occupiedExhaust']],
   'Occupied Minimum':[['ahu-oa','minimumOccupiedSupply'],['ahu-economizing','minimumOccupiedSupply']],
   'Unoccupied Minimum':[['ahu-oa','minimumUnoccupiedSupply']],
   'Required Ventilation':[['ahu-economizing','requiredVentilation']],
   'Maximum Valve Return':[['ahu-economizing','returnToValve']]
  }[type];
  if(spec)return spec.map(([mode,field])=>{const id='calc-'+mode+'-air-balance',t=independentTables.find(t=>t.id===id);return `SUMPRODUCT(${inZone(id,group,z)},${ref(id,t.balanceFields.indexOf(field))})`;}).join('+');
  const id='calc-air-balancing-requirements',t=independentTables.find(t=>t.id===id),label=type==='Pressurized Air'?'Pressurization':type,c=t.headers.findIndex(h=>h.label===label);
  return `SUMPRODUCT(${inZone(id,group,z)},${ref(id,c)})`;
 };
}
function undoChangeLogThrough(changeId){return removeChangeLogActions(changeId);}

function clipboardTableValue(value,table,column){return table.apacheControllersCalculation&&value===0?"0":formatTableValue(value,table,column);}
