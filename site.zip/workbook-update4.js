/* Non-destructive schema extensions and workbook interaction fixes. */
const MULTI_SPACE_TABLES=new Set(['selected-lighting-loads','selected-misc-loads','selected-general-exhaust','selected-exhaust-equipment']);
const pendingAddSpaces=new Map();
function configureWorkbookFourthUpdates(){
 const get=id=>independentTables.find(t=>t.id===id);
 get('calc-ahu-oa-air-balance').sectionStartColumns=get('calc-ahu-oa-air-balance').sectionStartColumns.filter(c=>c!==2);
 get('calc-misc-gains').zeroAsDashColumns=[6];
 for(const id of MULTI_SPACE_TABLES){const t=get(id);t.lockedColumns=[...new Set([...(t.lockedColumns||[]),0])];delete t.dropdownColumns[0];}
 const b=get('calc-air-balancing-requirements');b.headers[6].label='Initial Balance';b.columns[6]='Initial Balance (CFM)';b.formulaColumnAliases={...b.formulaColumnAliases,'Balance':6,'Initial Balance':6};
 for(const c of [8,9])b.displayEquations[c]=b.displayEquations[c].replaceAll('@Balance','@Initial Balance');
 const t=get('selected-transfer-air');t.hiddenColumns=[1,2,3,7,8,9];t.displayColumnOrder=[0,4,5,6,10,11,1,2,3,7,8,9];t.calculatedColumns=[0,10];t.summaryColumns=[5];t.frozenColumns=0;
 t.headers[0].label=t.headers[10].label='Initial Balance';t.columns[0]='From Initial Balance';t.columns[10]='To Initial Balance';t.formulaColumnAliases={...t.formulaColumnAliases,'From Initial Balance':0,'To Initial Balance':10};
 t.headerGroups=[{label:'Transfer From',columns:[0,4],start:0,span:2},{label:'Amount',columns:[5],start:5,span:1},{label:'Transfer To',columns:[6,10],start:6,span:2},{label:'Type',columns:[11],start:11,span:1}];t.sectionStartColumns=[5,6,11];
 for(const [c,side]of [[0,'From'],[10,'To']])t.displayEquations[c]=`=XLOOKUP(@${side} Space,[Air Balancing Requirements]@Space,[Air Balancing Requirements]@Initial Balance,"")`;
 t.dropdownColumns[4]={choiceKind:'transfer',side:'from'};t.dropdownColumns[6]={choiceKind:'transfer',side:'to'};
 for(const plant of independentTables.filter(t=>t.plantCalculation)){const w=plant.plantCalculation==='cooling'?12:10;plant.displayEquations[w+4]=bilinearPlantFormula('Cp');plant.displayEquations[w+5]=bilinearPlantFormula('Density');}
 // Explicit selection avoids an IFERROR fallback being suppressed by a blank XLOOKUP result.
 const d=get('selected-misc-loads');for(const [c,kind]of [[5,'Sensible'],[9,'Latent']])d.displayEquations[c]=`=IF(COUNTIF([Grouped Equipment Sensible Gain Schedule]@Group,@Equipment)>0,XLOOKUP(@Equipment,[Grouped Equipment Sensible Gain Schedule]@Group,[Grouped Equipment Sensible Gain Schedule]@[${kind} Summed Gain],0),XLOOKUP(@Equipment,[Equipment Sensible Gain Schedule]@[Lookup Key],[Equipment Sensible Gain Schedule]@[${kind} Gain],0))`;
}
function initializeFourthUpdateRows(project,table){
 project.fourthUpdateMigrations||={};if(project.fourthUpdateMigrations[table.id])return;
 if(table.id==='schedule-grouped-equipment-sensible-gain'){
  const rows=project.independentTables[table.id]||table.rows.map(r=>[...r]);
  for(const seed of table.rows)if(!rows.some(r=>requirementKey(r[0])===requirementKey(seed[0])&&(r[1]===seed[1]||String(r[1]).startsWith(seed[1].split(' - ')[0]+' - '))))rows.push([...seed]);
  project.independentTables[table.id]=rows;
 }
 project.changeLog=(project.changeLog||[]).filter(e=>!/^undid\b/i.test(e.message||''));
 project.fourthUpdateMigrations[table.id]=true;
}
function selectedRemovalIndexes(){return selectedTableId===activeTableId&&selectedTableRowIndexes.size?new Set(selectedTableRowIndexes):new Set([...selectedTableCells].map(k=>Number(k.split(':')[0])));}
function sourceSpaceChoices(table,project){
 const tab=independentTables.find(t=>t.tabularCalculation),rs=ensureProjectTableRows(project,tab),bySpace=new Map();
 const zt=independentTables.find(t=>t.id==='calc-equipment-zoning'),zones=ensureProjectTableRows(project,zt);recalculateEquipmentZoning(zt,zones,project);const zoneBySpace=new Map(zones.map(r=>[requirementKey(r[2]),r[0]||'Unassigned Zone Group']));
 for(const r of rs){const space=String(r[tabularColumn.space]||'').trim();if(!space)continue;bySpace.set(requirementKey(space),{space,group:table.id==='selected-lighting-loads'?zoneBySpace.get(requirementKey(space))||'Unassigned Zone Group':String(r[tabularColumn.thermal]||'Unassigned Thermal Template')});}
 return [...bySpace.values()].sort((a,b)=>a.group.localeCompare(b.group,undefined,{numeric:true})||a.space.localeCompare(b.space,undefined,{numeric:true}));
}
function renderAddSpacesControl(table){
 document.querySelector('#add-spaces-control')?.remove();
 if(!MULTI_SPACE_TABLES.has(table.id)){addTableRowButton.innerHTML='<span aria-hidden="true">+</span>Add row';return;}
 const project=activeProject(),key=project.id+'::'+table.id,selected=pendingAddSpaces.get(key)||new Set();pendingAddSpaces.set(key,selected);
 const options=sourceSpaceChoices(table,project),valid=new Set(options.map(o=>o.space));for(const space of selected)if(!valid.has(space))selected.delete(space);
 const button=document.createElement('button');button.id='add-spaces-control';button.type='button';button.className='add-spaces-control';button.setAttribute('aria-haspopup','dialog');button.disabled=isWorkbookReadOnly();
 const update=()=>{button.textContent=`Spaces (${selected.size}) ▾`;addTableRowButton.textContent='Add row(s)';addTableRowButton.disabled=isWorkbookReadOnly()||!selected.size;};update();addTableRowButton.after(button);
 button.onclick=()=>{
  if(isWorkbookReadOnly())return;closeCellDropdown();const popup=document.createElement('div');popup.className='cell-dropdown-popup add-spaces-popup';popup.setAttribute('role','dialog');popup.setAttribute('aria-label','Select spaces to add');const search=document.createElement('input');search.type='search';search.placeholder='Search spaces';const controls=document.createElement('div');controls.className='filter-popover-actions';const all=document.createElement('button'),none=document.createElement('button'),done=document.createElement('button');all.textContent='Select all';none.textContent='Select none';done.textContent='Done';for(const b of [all,none,done])b.type='button';controls.append(all,none,done);const list=document.createElement('div');list.className='cell-dropdown-options';popup.append(search,controls,list);document.body.appendChild(popup);
  const filtered=()=>options.filter(o=>(o.space+' '+o.group).toLowerCase().includes(search.value.toLowerCase()));
  const draw=()=>{list.replaceChildren();let group='';for(const option of filtered()){if(option.group!==group){const h=document.createElement('div');h.className='dropdown-source-heading';h.textContent=option.group;list.appendChild(h);group=option.group;}const label=document.createElement('label');label.className='filter-option';const check=document.createElement('input');check.type='checkbox';check.checked=selected.has(option.space);check.onchange=()=>{check.checked?selected.add(option.space):selected.delete(option.space);update();};const name=document.createElement('span');name.className='space-option-name';name.textContent=option.space;label.append(check,name);list.appendChild(label);}};
  all.onclick=()=>{filtered().forEach(o=>selected.add(o.space));update();draw();};none.onclick=()=>{filtered().forEach(o=>selected.delete(o.space));update();draw();};done.onclick=()=>{closeCellDropdown();button.focus();};search.oninput=draw;popup.onkeydown=e=>{if(e.key==='Escape'){e.preventDefault();closeCellDropdown();button.focus();}};draw();positionCellPopup(popup,button);popup.style.left=`${Math.max(8,button.getBoundingClientRect().right-popup.getBoundingClientRect().width)}px`;search.focus();
 };
}
function addSelectedSpaceRows(table){
 if(isWorkbookReadOnly())return false;const project=activeProject(),key=project.id+'::'+table.id,selected=pendingAddSpaces.get(key)||new Set(),choices=sourceSpaceChoices(table,project).filter(o=>selected.has(o.space));if(!choices.length)return false;
 const rows=projectTableRows(table),start=rows.length;for(const {space}of choices){const row=Array(table.columns.length).fill('');row[0]=space;rows.push(row);}project.independentTables[table.id]=rows;
 recalculateTable(table,rows,project);recalculateDependentTables(table,project);selectedTableCells.clear();selectedTableId=table.id;selectedTableRowIndexes=new Set(choices.map((_,i)=>start+i));selectionAnchorIndex=start;selected.clear();pendingTableRow={tableId:table.id,row:rows.at(-1)};saveProjects();tableSearch.value='';renderReferenceTable(table.id);return true;
}
function transferChoiceRecords(config,project){
 const table=independentTables.find(t=>t.id==='calc-air-balancing-requirements'),rows=project.independentTables?.[table.id]||withWorkbookPass(project,()=>{const r=ensureProjectTableRows(project,table);recalculateAirBalancingRequirements(table,r,project);return r;});
 const labels={a:'Spaces With Air To Give',b:'Spaces That Need Air',c:'Balanced Spaces'},order=config.side==='from'?['a','c','b']:['b','c','a'];
 return rows.filter(r=>r[1]).map(r=>{const value=requirementNumber(r[6]),section=value>0?'a':value<0?'b':'c';return {value:String(r[1]),label:`${r[1]} (${value.toLocaleString(undefined,{maximumFractionDigits:1})} CFM)`,group:labels[section],section};}).sort((a,b)=>order.indexOf(a.section)-order.indexOf(b.section)||a.value.localeCompare(b.value,undefined,{numeric:true}));
}
function bilinearPlantFormula(property){
 const get=kind=>independentTables.find(t=>t.id===`water-${kind}-${property==='Cp'?'specific-heat':'density'}`),eth=get('ethylene'),pro=get('propylene'),cols=eth.headers.map((h,c)=>({c,x:parseFloat(h.label)})).filter(v=>v.c>0&&/^\d+%$/.test(eth.headers[v.c].label));
 const matrix=t=>`VSTACK(${cols.map(v=>`[${t.name}]@[${t.headers[v.c].label}]`).join(',')})`;
 const corner=(r,c)=>`INDEX(table,(XMATCH(${c},headers)-1)*ROWS(temperatures)+XMATCH(${r},temperatures))`;
 const core=`LET(x,MAX(0,MIN(100,@Glycol*100)),y,@EWT,type,@Glycol Type,table,IF(type="Propylene",${matrix(pro)},${matrix(eth)}),temperatures,VSTACK(IF(type="Propylene",[${pro.name}]@Temperature,[${eth.name}]@Temperature)),headers,VSTACK(${cols.map(c=>c.x).join(',')}),row1,MAX(FILTER(temperatures,temperatures<=y,MIN(temperatures))),row2,MIN(FILTER(temperatures,temperatures>=y,MAX(temperatures))),col1,MAX(FILTER(headers,headers<=x,MIN(headers))),col2,MIN(FILTER(headers,headers>=x,MAX(headers))),v11,${corner('row1','col1')},v12,${corner('row1','col2')},v21,${corner('row2','col1')},v22,${corner('row2','col2')},IF(AND(ISNUMBER(v11),ISNUMBER(v12),ISNUMBER(v21),ISNUMBER(v22)),LET(x1,INTERPOLATE(row1,v11,row2,v21,y),x2,INTERPOLATE(row1,v12,row2,v22,y),INTERPOLATE(col1,x1,col2,x2,x))${property==='Density'?'/7.48052':''},"-"))`;
 return `=IF(@Water="TRUE",${core},"")`;
}
function bilinearPlantValue(project,kind,property,temperature,concentration){
 const table=independentTables.find(t=>t.id===`water-${kind}-${property==='Cp'?'specific-heat':'density'}`),rows=ensureProjectTableRows(project,table);recalculateThirdReferenceTable(table,rows,project);
 const temps=rows.map(r=>Number(r[0])).filter(Number.isFinite),cols=table.headers.map((h,c)=>({c,x:parseFloat(h.label)})).filter(v=>v.c>0&&/^\d+%$/.test(table.headers[v.c].label)),xs=cols.map(v=>v.x);
 const low=(a,x)=>Math.max(...a.filter(v=>v<=x),Math.min(...a)),high=(a,x)=>Math.min(...a.filter(v=>v>=x),Math.max(...a)),r1=low(temps,temperature),r2=high(temps,temperature),c1=low(xs,concentration),c2=high(xs,concentration);
 const at=(r,c)=>rows.find(v=>Number(v[0])===r)?.[cols.find(v=>v.x===c).c],v11=at(r1,c1),v12=at(r1,c2),v21=at(r2,c1),v22=at(r2,c2);if(![v11,v12,v21,v22].every(v=>typeof v==='number'&&Number.isFinite(v)))return '-';
 const lerp=(x,a,b,u,v)=>a===b?u:u+(x-a)*(v-u)/(b-a),x1=lerp(temperature,r1,r2,v11,v21),x2=lerp(temperature,r1,r2,v12,v22),value=lerp(concentration,c1,c2,x1,x2);return property==='Density'?value/7.48052:value;
}
function removeChangeLogActions(changeId){
 if(isWorkbookReadOnly()||!ownsProjectControl())return;completeHistoryActions();const ids=changeLogUndoIds(changeId),actions=undoStack.filter(a=>ids.has(a.changeId));if(!actions.length)return;
 let current=structuredClone(activeProject());const before=JSON.stringify(projects),entries=(current.changeLog||[]).filter(e=>ids.has(e.changeId));for(const action of [...actions].reverse())current=historyPatch(current,historyProject(action.afterSnapshot),historyProject(action.snapshot));
 const history=(current.changeLog||[]).filter(e=>!ids.has(e.changeId)&&!/^undid\b/i.test(e.message||''));for(let i=undoStack.length-1;i>=0;i--)if(ids.has(undoStack[i].changeId))undoStack.splice(i,1);
 const after=JSON.stringify(projects.map(p=>p.id===activeProjectId?current:p));redoStack.push({snapshot:after,afterSnapshot:before,changeId:actions[0].changeId,batchActions:actions,logEntries:entries});restoreProjectHistory(after,{changeLog:history});
}
