/* Native fields and filter controls use the same arrow-only opening behavior as grid cells. */
(() => {
  const filters='#space-filter-toggle,#space-choice-toggle';
  const inArrow=(node,event)=>event.clientX>=node.getBoundingClientRect().right-34;
  const openNative=(select,initial='')=>{
    if(select.disabled)return;
    closeCellDropdown();
    const popup=document.createElement('div');popup.className='cell-dropdown-popup';popup.setAttribute('role','dialog');popup.setAttribute('aria-label',select.getAttribute('aria-label')||'Choose a value');
    const search=document.createElement('input');search.type='search';search.placeholder='Type to filter';search.value=initial;search.setAttribute('aria-label','Filter choices');
    const list=document.createElement('div');list.className='cell-dropdown-options';list.setAttribute('role','listbox');
    const options=[...select.options].filter(o=>!o.disabled);let matches=[],cursor=0;
    const choose=o=>{const old=select.value;select.value=o.value;closeCellDropdown();select.setAttribute('aria-expanded','false');if(old!==select.value){select.dispatchEvent(new Event('input',{bubbles:true}));select.dispatchEvent(new Event('change',{bubbles:true}));}if(select.isConnected)select.focus({preventScroll:true});};
    const draw=()=>{
      matches=options.filter(o=>o.textContent.toLowerCase().includes(search.value.toLowerCase()));cursor=Math.max(0,Math.min(cursor,matches.length-1));list.replaceChildren();
      let group='';matches.forEach((o,i)=>{
        const label=o.parentElement.tagName==='OPTGROUP'?o.parentElement.label:'';
        if(label&&label!==group){const heading=document.createElement('div');heading.className='dropdown-option-group';heading.textContent=label;list.appendChild(heading);group=label;}
        const button=document.createElement('button');button.type='button';button.setAttribute('role','option');button.setAttribute('aria-selected',String(i===cursor));button.classList.toggle('active-option',i===cursor);button.textContent=o.textContent||'(Blank)';button.addEventListener('pointerdown',e=>e.preventDefault());button.addEventListener('click',()=>choose(o));list.appendChild(button);
      });
      if(!matches.length){const p=document.createElement('p');p.textContent='No matching values';list.appendChild(p);}
    };
    search.addEventListener('input',()=>{cursor=0;draw();});search.addEventListener('keydown',e=>{
      if(['ArrowDown','ArrowUp'].includes(e.key)){e.preventDefault();cursor=Math.max(0,Math.min(matches.length-1,cursor+(e.key==='ArrowDown'?1:-1)));draw();list.querySelector('.active-option')?.scrollIntoView({block:'nearest'});}
      if(e.key==='Enter'&&matches[cursor]){e.preventDefault();choose(matches[cursor]);}
      if(e.key==='Escape'){e.preventDefault();closeCellDropdown();select.focus({preventScroll:true});}
    });
    popup.append(search,list);document.body.appendChild(popup);popup.style.minWidth=`${Math.max(220,select.getBoundingClientRect().width)}px`;
    select.setAttribute('aria-haspopup','listbox');select.setAttribute('aria-expanded','true');draw();positionCellPopup(popup,select);search.focus();search.setSelectionRange(initial.length,initial.length);
  };
  document.addEventListener('pointermove',e=>{
    const node=e.target.closest?.(`select,${filters},.print-filter-toggle`);document.querySelectorAll('select.arrow-hover,button.arrow-hover').forEach(other=>{if(other!==node)other.classList.remove('arrow-hover');});
    if(node)node.classList.toggle('arrow-hover',inArrow(node,e));
  },{passive:true});
  document.addEventListener('pointerout',e=>{const node=e.target.closest?.(`select,${filters},.print-filter-toggle`);if(node&&!node.contains(e.relatedTarget))node.classList.remove('arrow-hover');},{passive:true});
  document.addEventListener('pointerdown',e=>{
    const select=e.target.closest?.('select');if(!select)return;
    e.preventDefault();select.focus({preventScroll:true});
  },true);
  document.addEventListener('mousedown',e=>{if(e.target.closest?.('select'))e.preventDefault();},true);
  document.addEventListener('click',e=>{
    const select=e.target.closest?.('select');if(select){e.preventDefault();e.stopImmediatePropagation();if(e.detail===0||inArrow(select,e))openNative(select);return;}
    const filter=e.target.closest?.(filters);if(filter&&e.detail!==0&&!inArrow(filter,e)){e.preventDefault();e.stopImmediatePropagation();filter.focus({preventScroll:true});}
  },true);
  document.addEventListener('keydown',e=>{
    const node=e.target.closest?.(`select,${filters}`);if(!node||e.ctrlKey||e.metaKey)return;
    const typing=e.key.length===1&&!e.altKey;
    if(typing || (e.altKey&&e.key==='ArrowDown')){
      e.preventDefault();e.stopImmediatePropagation();
      if(node.tagName==='SELECT')openNative(node,typing?e.key:'');
      else {if(node.getAttribute('aria-expanded')!=='true')node.click();const search=document.querySelector(node.id==='space-filter-toggle'?'#space-filter-search':'#space-choice-search');search.value=typing?e.key:'';search.dispatchEvent(new Event('input',{bubbles:true}));search.focus();}
    }else if(node.tagName==='SELECT'&&['ArrowDown','ArrowUp','Enter',' '].includes(e.key))e.preventDefault();
  },true);
})();
