/* The supplied image is 1318 × 1014. Its 120°F/0 baseline intersection is
   (1231,928); 5°F spans 65.2 pixels, and 0.002 lb/lb spans 56.2 pixels. */
function psychChartPoint(db,hr) {
  return {x:1231+(Number(db)-120)*13.04,y:928-Number(hr)*28100};
}
function psychCoolingPath(entering,leaving,pressure) {
  const points=[{db:entering.db,hr:entering.hr}];
  if(leaving.db>=entering.db||leaving.hr>=entering.hr){points.push({db:leaving.db,hr:leaving.hr});return points;}
  const rh=leaving.rh;
  const target=db=>humidityRatioForPressure(db,rh,pressure);
  let lo=leaving.db,hi=entering.db;
  // Find where the initial horizontal sensible segment meets the leaving-RH curve.
  for(let i=0;i<50;i++){const mid=(lo+hi)/2;if(target(mid)>entering.hr)hi=mid;else lo=mid;}
  const intersection=(lo+hi)/2;
  if(target(entering.db)>=entering.hr)points.push({db:intersection,hr:entering.hr});
  const start=target(entering.db)>=entering.hr?intersection:entering.db;
  for(let i=1;i<=60;i++){const db=start+(leaving.db-start)*i/60;points.push({db,hr:target(db)});}
  points[points.length-1]={db:leaving.db,hr:leaving.hr};return points;
}
function buildPsychChartData(project) {
  const owned=!activeCalculationCache;if(owned)activeCalculationCache={project};
  try {
    const context=coilCalculationContext(project),pressure=context.pressure,lines=[],equipment=new Set();
    const state=(db,hr)=>({db:Number(db),hr:Number(hr),wb:wetBulbFromState(db,hr,pressure),rh:relativeHumidityForRatio(db,hr,pressure)});
    const add=(table,row,label,enter,leave,flow,sens,latent,loser=false)=>{
      if([enter.db,enter.hr,leave.db,leave.hr,flow,sens,latent].some(v=>!Number.isFinite(Number(v))))return;
      lines.push({equipment:String(row[0]),tableId:table.id,label,cooling:table.coilCalculation.includes('cooling'),enter,leave,flow,sens,latent,total:sens+latent,loser});
    };
    const ids=['airside-preheat','airside-ventilation-cooling','airside-room-cooling','airside-in-unit-reheat','airside-downstream-reheat','airside-room-heating'];
    for(const id of ids){const t=independentTables.find(t=>t.id===id),rows=ensureProjectTableRows(project,t,context);if(!context.calculatedCoils?.has(id))recalculateCoilTable(t,rows,project,context);
      for(const r of rows){
        if(r[0])equipment.add(String(r[0]));
        if(id==='airside-ventilation-cooling') {
          const leave=state(r[9],r[11]);const candidates=[[15,20,'Ventilation cooling — Cooling design day'],[24,29,'Ventilation cooling — Dehumidification design day']].map(([c,f,label])=>{const enter=state(r[c],r[c+1]),flow=requirementNumber(r[f]),sens=requirementNumber(r[c+3])*flow*(enter.db-leave.db)/1000,latent=requirementNumber(r[c+4])*flow*(enter.hr-leave.hr)/1000;return {enter,flow,label,sens,latent};});
          const winner=candidates[0].sens+candidates[0].latent>=candidates[1].sens+candidates[1].latent?0:1;
          candidates.forEach((c,i)=>add(t,r,c.label,c.enter,leave,c.flow,c.sens,c.latent,i!==winner));
        }else if(id==='airside-room-cooling')add(t,r,'Room air cooling',state(r[33],r[34]),state(r[9],r[11]),requirementNumber(r[38]),requirementNumber(r[39]),requirementNumber(r[40]));
        else {const c=id==='airside-preheat'?5:id==='airside-room-heating'?11:5,flowCol=id==='airside-room-heating'?15:9,capCol=id==='airside-room-heating'?16:10;if(r[c]===''||r[c+1]==='')continue;const entering=state(r[c],r[c+1]);add(t,r,t.name.replace(/ Coils?$/,''),entering,state(r[1],entering.hr),requirementNumber(r[flowCol]),requirementNumber(r[capCol]),0);}
      }
    }
    return {lines,pressure,equipment:[...equipment]};
  } finally {if(owned)activeCalculationCache=null;}
}
function renderPsychChart() {
  const project=activeProject();if(!project)return;
  const root=document.createElement('section');root.id='psych-chart-view';root.className='psych-chart-view';modelInputsView.parentElement.appendChild(root);
  const data=buildPsychChartData(project),equipment=data.equipment.sort((a,b)=>a.localeCompare(b,undefined,{numeric:true,sensitivity:'base'}));
  const toolbar=document.createElement('div');toolbar.className='psych-toolbar';const label=document.createElement('label');label.textContent='Equipment';const select=document.createElement('select');select.setAttribute('aria-label','Equipment with coils');
  for(const tag of equipment){const o=document.createElement('option');o.value=tag;o.textContent=tag;select.appendChild(o);}label.appendChild(select);toolbar.appendChild(label);
  const note=document.createElement('p');note.textContent=`Chart background: sea level (14.696 psia). Coil states: project pressure (${Number(data.pressure).toFixed(3)} psia). Ventilation paths use normal-operation leaving conditions; the lower-capacity path is halftoned.`;toolbar.appendChild(note);root.appendChild(toolbar);
  const content=document.createElement('div');root.appendChild(content);select.value=equipment.includes(project.psychEquipment)?project.psychEquipment:equipment[0]||'';
  const draw=()=>{
    content.replaceChildren();const lines=data.lines.filter(l=>l.equipment===select.value);
    if(!lines.length){const p=document.createElement('p');p.textContent='Assign equipment and coils in Equipment Zoning and Settings to display their air states.';content.appendChild(p);return;}
    const scroller=document.createElement('div');scroller.className='psych-state-scroll';const table=document.createElement('table');table.className='psych-state-table';
    const header=document.createElement('thead'),head=document.createElement('tr');for(const text of ['Coil Line','Entering DB [°F]','Entering WB [°F]','Entering RH [%]','Entering HR [lb/lb]','Leaving DB [°F]','Leaving WB [°F]','Leaving RH [%]','Leaving HR [lb/lb]','Airflow [CFM]','Sensible Capacity [MBH]','Latent Capacity [MBH]','Total Capacity [MBH]']){const th=document.createElement('th');th.textContent=text;head.appendChild(th);}header.appendChild(head);table.appendChild(header);
    const body=document.createElement('tbody');lines.forEach((l,i)=>{const row=document.createElement('tr');row.dataset.line=String(i);if(l.loser)row.classList.add('psych-losing-row');const values=[`${i+1} · ${l.label}`,l.enter.db.toFixed(1),Number(l.enter.wb).toFixed(1),(l.enter.rh*100).toFixed(1),l.enter.hr.toFixed(5),l.leave.db.toFixed(1),Number(l.leave.wb).toFixed(1),(l.leave.rh*100).toFixed(1),l.leave.hr.toFixed(5),Math.round(l.flow).toLocaleString(),l.sens.toFixed(2),l.latent.toFixed(2),l.total.toFixed(2)];values.forEach((v,c)=>{const cell=document.createElement('td');cell.textContent=v;if(!c){const marker=document.createElement('span');marker.className='psych-line-swatch';marker.style.background=l.cooling?'#0066ff':'#c00000';cell.prepend(marker);}row.appendChild(cell);});row.tabIndex=0;row.addEventListener('pointerenter',()=>highlight(i));row.addEventListener('pointerleave',()=>highlight(null));row.addEventListener('focus',()=>highlight(i));row.addEventListener('blur',()=>highlight(null));body.appendChild(row);});table.appendChild(body);scroller.appendChild(table);content.appendChild(scroller);
    const ns='http://www.w3.org/2000/svg',svg=document.createElementNS(ns,'svg');svg.setAttribute('viewBox','0 0 1318 1014');svg.classList.add('psych-image-overlay');svg.setAttribute('role','img');svg.setAttribute('aria-label',`${select.value} coil entering and leaving states on the ASHRAE psychrometric chart`);
    const el=(tag,attrs,parent=svg)=>{const n=document.createElementNS(ns,tag);for(const [k,v] of Object.entries(attrs))n.setAttribute(k,String(v));parent.appendChild(n);return n;};
    el('image',{href:'psych-chart.png',x:0,y:0,width:1318,height:1014});
    const defs=el('defs',{}),clip=el('clipPath',{id:'psych-plot-clip'},defs);el('rect',{x:0,y:84,width:1232,height:844},clip);
    const group=el('g',{'clip-path':'url(#psych-plot-clip)'});
    lines.forEach((l,i)=>{const color=l.cooling?'#0066ff':'#c00000',g=el('g',{'data-line':i,class:'psych-process'+(l.loser?' psych-losing-process':'')},group),points=l.cooling?psychCoolingPath(l.enter,l.leave,data.pressure):[l.enter,l.leave],coords=points.map(p=>psychChartPoint(p.db,p.hr));
      const path=el('path',{d:coords.map((p,j)=>`${j?'L':'M'}${p.x.toFixed(2)},${p.y.toFixed(2)}`).join(' '),fill:'none',stroke:color,'stroke-width':3.5,'vector-effect':'non-scaling-stroke',...(l.loser?{'stroke-dasharray':'6 4'}:{})},g);const title=el('title',{},path);title.textContent=`${i+1} · ${l.label}: ${l.enter.db.toFixed(1)}°F / ${l.enter.hr.toFixed(5)} → ${l.leave.db.toFixed(1)}°F / ${l.leave.hr.toFixed(5)} lb/lb`;
      for(const [kind,state] of [['Entering',l.enter],['Leaving',l.leave]]){const p=psychChartPoint(state.db,state.hr);el('circle',{cx:p.x,cy:p.y,r:5,fill:kind==='Entering'?'white':color,stroke:color,'stroke-width':2},g);const x=Math.min(1150,Math.max(6,p.x+8)),y=Math.min(912,Math.max(100,p.y-14-(i%3)*18));const label=el('text',{x,y,fill:color,'font-size':13,'font-family':'Arial,sans-serif','font-weight':700,stroke:'white','stroke-width':3,'paint-order':'stroke'},g);label.textContent=`${i+1} ${kind}`;}
    });content.appendChild(svg);
    function highlight(index){svg.querySelectorAll('.psych-process').forEach(g=>g.classList.toggle('psych-focused-process',index!==null&&Number(g.dataset.line)===index));body.querySelectorAll('tr').forEach(row=>row.classList.toggle('psych-active-row',index!==null&&Number(row.dataset.line)===index));}
  };
  select.addEventListener('change',()=>{project.psychEquipment=select.value;saveProjects();draw();});draw();
}
