/* The supplied image is 1318 × 1014. Its 120°F/0 baseline intersection is
   (1231,928); 5°F spans 65.2 pixels, and 0.002 lb/lb spans 56.2 pixels. */
function psychChartPoint(db,hr) {
  return {x:1231+(Number(db)-120)*13.04,y:928-Number(hr)*28100};
}
function psychCoolingPath(entering,leaving,pressure) {
  const points=[{db:entering.db,hr:entering.hr}];
  if(leaving.db>=entering.db||leaving.hr>=entering.hr){points.push({db:leaving.db,hr:leaving.hr});return points;}
  const rh=leaving.rh;
  const target=db=>humidityRatioForPressure(db,rh,pressure);
  let lo=leaving.db,hi=entering.db;
  // Find where the initial horizontal sensible segment meets the leaving-RH curve.
  for(let i=0;i<50;i++){const mid=(lo+hi)/2;if(target(mid)>entering.hr)hi=mid;else lo=mid;}
  const intersection=(lo+hi)/2;
  if(target(entering.db)>=entering.hr)points.push({db:intersection,hr:entering.hr});
  const start=target(entering.db)>=entering.hr?intersection:entering.db;
  for(let i=1;i<=60;i++){const db=start+(leaving.db-start)*i/60;points.push({db,hr:target(db)});}
  points[points.length-1]={db:leaving.db,hr:leaving.hr};return points;
}
function buildPsychChartData(project) {
  const owned=!activeCalculationCache;if(owned)activeCalculationCache={project};
  try {
    const context=coilCalculationContext(project),pressure=context.pressure,lines=[],equipment=new Set();
    const state=(db,hr)=>({db:Number(db),hr:Number(hr),wb:wetBulbFromState(db,hr,pressure),rh:relativeHumidityForRatio(db,hr,pressure)});
    const add=(table,row,label,enter,leave,flow,sens,latent,loser=false)=>{
      if([enter.db,enter.hr,leave.db,leave.hr,flow,sens,latent].some(v=>!Number.isFinite(Number(v))))return;
      lines.push({equipment:String(row[0]),tableId:table.id,coilName:table.name,label,cooling:table.coilCalculation.includes('cooling'),enter,leave,flow,sens,latent,total:sens+latent,loser});
    };
    const ids=['airside-preheat','airside-ventilation-cooling','airside-room-cooling','airside-in-unit-reheat','airside-downstream-reheat','airside-room-heating'];
    for(const id of ids){const t=independentTables.find(t=>t.id===id),rows=ensureProjectTableRows(project,t,context);if(!context.calculatedCoils?.has(id))recalculateCoilTable(t,rows,project,context);
      for(const r of rows){
        if(r[0])equipment.add(String(r[0]));
        if(id==='airside-ventilation-cooling') {
          const leave=state(r[9],r[11]);const candidates=[[15,20,'Ventilation cooling — Cooling design day'],[24,29,'Ventilation cooling — Dehumidification design day']].map(([c,f,label])=>{const enter=state(r[c],r[c+1]),flow=requirementNumber(r[f]),sens=requirementNumber(r[c+3])*flow*(enter.db-leave.db)/1000,latent=requirementNumber(r[c+4])*flow*(enter.hr-leave.hr)/1000;return {enter,flow,label,sens,latent};});
          const winner=candidates[0].sens+candidates[0].latent>=candidates[1].sens+candidates[1].latent?0:1;
          candidates.forEach((c,i)=>add(t,r,c.label,c.enter,leave,c.flow,c.sens,c.latent,i!==winner));
        }else if(id==='airside-room-cooling')add(t,r,'Room air cooling',state(r[33],r[34]),state(r[9],r[11]),requirementNumber(r[38]),requirementNumber(r[39]),requirementNumber(r[40]));
        else {const c=id==='airside-preheat'?5:id==='airside-room-heating'?11:5,flowCol=id==='airside-room-heating'?15:9,capCol=id==='airside-room-heating'?16:10;if(r[c]===''||r[c+1]==='')continue;const entering=state(r[c],r[c+1]);add(t,r,t.name.replace(/ Coils?$/,''),entering,state(r[1],entering.hr),requirementNumber(r[flowCol]),requirementNumber(r[capCol]),0);}
      }
    }
    return {lines,pressure,equipment:[...equipment]};
  } finally {if(owned)activeCalculationCache=null;}
}

function psychLineStyle(line) {
  const preheat=line.tableId==='airside-preheat',dehum=line.label.includes('Dehumidification'),vent=line.tableId==='airside-ventilation-cooling';
  return preheat?{color:'#ce6f09',fill:'#ffffff',name:'preheat'}:dehum?{color:'#008577',fill:'#ffffff',name:'latent'}:line.cooling?{color:'#0066ff',fill:'#ffffff',name:'cooling'}:{color:'#bd3818',fill:'#ffffff',name:'heating'};
}
function psychTableHeaders() {
  return ['Leaving Condition','Dry-Bulb [degF]','Wet-Bulb [degF]','Rel-Hum [%]','Hum-Ratio [lb/lb]','Sensible Constant','Latent Constant','Dry-Bulb [degF]','Wet-Bulb [degF]','Rel-Hum [%]','Hum-Ratio [lb/lb]','Airflow [CFM]','Sensible [MBH]','Latent [MBH]','Total [MBH]'];
}
function psychConditionName(line) {
  if(line.label.includes('Dehumidification'))return 'Dehumidification Design Day';
  if(line.cooling)return 'Cooling Design Day';
  return line.tableId.includes('reheat')?'Upstream Coil Leaving':'Heating Design Day';
}
function psychTableValues(line,pressure) {
  const constants=airConstantsForState(line.enter.db,line.enter.hr,pressure);
  return [`${line.coilName}\n${psychConditionName(line)}`,line.enter.db.toFixed(1),line.enter.wb.toFixed(1),(line.enter.rh*100).toFixed(1)+'%',line.enter.hr.toFixed(5),constants.sensible.toFixed(3),constants.latent.toFixed(0),line.leave.db.toFixed(1),line.leave.wb.toFixed(1),(line.leave.rh*100).toFixed(1)+'%',line.leave.hr.toFixed(5),Math.round(line.flow).toLocaleString(),line.sens.toFixed(2),line.latent.toFixed(2),line.total.toFixed(2)];
}
function psychCellFormula(line,column,pressure) {
  const constants=airConstantsForState(line.enter.db,line.enter.hr,pressure);
  const values={'Equipment':line.equipment,'Entering Dry-Bulb':line.enter.db,'Entering Hum-Ratio':line.enter.hr,'Leaving Dry-Bulb':line.leave.db,'Leaving Hum-Ratio':line.leave.hr,'Barometric Pressure':pressure,'Airflow':line.flow,'Sensible Constant':constants.sensible,'Latent Constant':constants.latent,'Sensible Capacity':line.sens,'Latent Capacity':line.latent};
  const equations={0:'="'+line.coilName+' — '+psychConditionName(line)+'"',1:'=@Entering Dry-Bulb',2:'=WETBULB(@Entering Dry-Bulb,@Entering Hum-Ratio,@Barometric Pressure)',3:'=LET(TC,(@Entering Dry-Bulb-32)*5/9,VP,@Entering Hum-Ratio*@Barometric Pressure/(0.621945+@Entering Hum-Ratio),MAX(0,MIN(1,VP/(0.145038*0.61094*EXP(17.625*TC/(TC+243.04)))))*100)',4:'=@Entering Hum-Ratio',5:'=SENSIBLECONSTANT(@Entering Dry-Bulb,@Entering Hum-Ratio,@Barometric Pressure)',6:'=LATENTCONSTANT(@Entering Dry-Bulb,@Entering Hum-Ratio,@Barometric Pressure)',7:'=@Leaving Dry-Bulb',8:'=WETBULB(@Leaving Dry-Bulb,@Leaving Hum-Ratio,@Barometric Pressure)',9:'=LET(TC,(@Leaving Dry-Bulb-32)*5/9,VP,@Leaving Hum-Ratio*@Barometric Pressure/(0.621945+@Leaving Hum-Ratio),MAX(0,MIN(1,VP/(0.145038*0.61094*EXP(17.625*TC/(TC+243.04)))))*100)',10:'=@Leaving Hum-Ratio',11:'=@Airflow',12:line.cooling?'=@Sensible Constant * @Airflow * (@Entering Dry-Bulb - @Leaving Dry-Bulb) / 1000':'=@Sensible Constant * @Airflow * (@Leaving Dry-Bulb - @Entering Dry-Bulb) / 1000',13:line.cooling?'=@Latent Constant * @Airflow * (@Entering Hum-Ratio - @Leaving Hum-Ratio) / 1000':'=0',14:'=@Sensible Capacity + @Latent Capacity'};
  return {equation:equations[column],values,model:true};
}
function renderPsychChart() {
  const project=activeProject();if(!project)return;
  const root=document.createElement('section');root.id='psych-chart-view';root.className='psych-chart-view';modelInputsView.parentElement.appendChild(root);
  const data=buildPsychChartData(project),equipment=data.equipment.sort((a,b)=>a.localeCompare(b,undefined,{numeric:true,sensitivity:'base'}));
  const toolbar=document.createElement('div');toolbar.className='psych-toolbar';const label=document.createElement('label');label.textContent='Equipment';const select=document.createElement('select');select.setAttribute('aria-label','Equipment with coils');
  for(const tag of equipment){const option=document.createElement('option');option.value=tag;option.textContent=tag;select.appendChild(option);}label.appendChild(select);toolbar.appendChild(label);root.appendChild(toolbar);
  const content=document.createElement('div');root.appendChild(content);select.value=equipment.includes(project.psychEquipment)?project.psychEquipment:equipment[0]||'';
  const draw=()=>{
    content.replaceChildren();const lines=data.lines.filter(l=>l.equipment===select.value);
    if(!lines.length){const p=document.createElement('p');p.textContent='Assign equipment and coils in Equipment Zoning and Settings to display their air states.';content.appendChild(p);return;}
    const frame=document.createElement('div');frame.className='psych-table-frame';const scroller=document.createElement('div');scroller.className='psych-state-scroll';const table=document.createElement('table');table.className='psych-state-table';
    const header=document.createElement('thead'),groups=document.createElement('tr'),head=document.createElement('tr');groups.className='group-header-row';
    for(const [text,span] of [['Coil',1],['Entering Conditions',6],['Leaving Condition',4],['Capacity',4]]){const th=document.createElement('th');th.textContent=text;th.colSpan=span;groups.appendChild(th);}
    psychTableHeaders().forEach((text,c)=>{const th=document.createElement('th');const box=document.createElement('div');box.className='table-header-content';const label=document.createElement('span');label.className='column-label';const match=text.match(/^(.*?)\s*\[([^\]]+)\]$/);label.textContent=match?match[1]:text;box.appendChild(label);if(match){const unit=document.createElement('span');unit.className='column-unit';unit.textContent=match[2];box.appendChild(unit);}th.appendChild(box);if([1,7,11].includes(c))th.className='section-divider';head.appendChild(th);});header.append(groups,head);table.appendChild(header);
    const body=document.createElement('tbody');
    const bar=document.createElement('div');bar.className='psych-formula-bar model-input-formula';bar.hidden=true;
    const fx=document.createElement('span');fx.className='formula-symbol';fx.textContent='fx';const output=document.createElement('output');output.className='formula-function-view';const detail=document.createElement('div');detail.className='formula-function-detail';const evaluate=document.createElement('button');evaluate.type='button';evaluate.textContent='Evaluate';let selectedFormula=null;evaluate.addEventListener('click',()=>openFormulaEvaluator(selectedFormula));bar.append(fx,output,evaluate,detail);
    lines.forEach((line,i)=>{const row=document.createElement('tr');row.dataset.line=String(i);const style=psychLineStyle(line);row.style.setProperty('--psych-fill',style.fill);row.style.setProperty('--psych-color',style.color);if(line.loser)row.classList.add('psych-losing-row');
      if(i>0&&(lines[i-1].tableId==='airside-preheat'||lines[i-1].cooling&&!line.cooling))row.classList.add('psych-section-divider');
      psychTableValues(line,data.pressure).forEach((value,c)=>{const cell=document.createElement('td');cell.textContent=value;cell.tabIndex=0;if([1,7,11].includes(c))cell.classList.add('section-divider');
        cell.addEventListener('pointerenter',()=>{highlight(i);for(const tr of body.rows)tr.cells[c].classList.add('psych-hover-column');cell.classList.add('psych-hover-cell');});
        cell.addEventListener('pointerleave',()=>{highlight(null);body.querySelectorAll('.psych-hover-column,.psych-hover-cell').forEach(n=>n.classList.remove('psych-hover-column','psych-hover-cell'));});
        const choose=()=>{body.querySelectorAll('.psych-selected-cell').forEach(n=>n.classList.remove('psych-selected-cell'));cell.classList.add('psych-selected-cell');selectedFormula=psychCellFormula(line,c,data.pressure);displayFormulaFunctions(selectedFormula.equation,output,detail);bar.hidden=false;};
        cell.addEventListener('click',choose);cell.addEventListener('keydown',event=>{if(event.key==='Enter'){event.preventDefault();choose();}});row.appendChild(cell);
      });body.appendChild(row);
    });table.appendChild(body);scroller.appendChild(table);frame.append(scroller,bar);content.appendChild(frame);
    const ns='http://www.w3.org/2000/svg',svg=document.createElementNS(ns,'svg');svg.setAttribute('viewBox','0 0 1318 1014');svg.classList.add('psych-image-overlay');svg.setAttribute('role','img');svg.setAttribute('aria-label',`${select.value}: coil entering to leaving paths`);
    const el=(tag,attrs,parent=svg)=>{const n=document.createElementNS(ns,tag);for(const [k,v] of Object.entries(attrs))n.setAttribute(k,String(v));parent.appendChild(n);return n;};
    el('image',{href:'psych-chart.png',x:0,y:0,width:1318,height:1014,style:'filter:grayscale(1)'});const defs=el('defs',{}),clip=el('clipPath',{id:'psych-plot-clip'},defs);el('rect',{x:0,y:78,width:1240,height:860},clip);const group=el('g',{'clip-path':'url(#psych-plot-clip)'});
    lines.forEach((line,i)=>{const color=psychLineStyle(line).color,g=el('g',{'data-line':i,class:'psych-process'},group),points=line.cooling?psychCoolingPath(line.enter,line.leave,data.pressure):[line.enter,line.leave],coords=points.map(p=>psychChartPoint(p.db,p.hr));
      const path=el('path',{d:coords.map((p,j)=>`${j?'L':'M'}${p.x.toFixed(2)},${p.y.toFixed(2)}`).join(' '),fill:'none',stroke:color,'stroke-width':3.5,'vector-effect':'non-scaling-stroke'},g);el('title',{},path).textContent=line.label;
      // Direction arrow at half the path length remains visible even for zero-HR heating lines.
      const lengths=coords.slice(1).map((p,j)=>Math.hypot(p.x-coords[j].x,p.y-coords[j].y));let remaining=lengths.reduce((a,b)=>a+b,0)*.5;
      for(let j=0;j<lengths.length;j++){if(remaining<=lengths[j]&&lengths[j]>0){const a=coords[j],b=coords[j+1],fraction=remaining/lengths[j],x=a.x+(b.x-a.x)*fraction,y=a.y+(b.y-a.y)*fraction,angle=Math.atan2(b.y-a.y,b.x-a.x)*180/Math.PI;el('path',{d:'M-9,-5 L3,0 L-9,5 Z',fill:color,transform:`translate(${x},${y}) rotate(${angle})`},g);break;}remaining-=lengths[j];}
      for(const [kind,state] of [['Entering',line.enter],['Leaving',line.leave]]){const p=psychChartPoint(state.db,state.hr);el('circle',{cx:p.x,cy:p.y,r:5,fill:kind==='Entering'?'white':color,stroke:color,'stroke-width':2},g);}
    });content.appendChild(svg);
    function highlight(index){svg.querySelectorAll('.psych-process').forEach(g=>g.classList.toggle('psych-focused-process',index!==null&&Number(g.dataset.line)===index));body.querySelectorAll('tr').forEach(row=>row.classList.toggle('psych-active-row',index!==null&&Number(row.dataset.line)===index));}
    root.onpointerdown=event=>{if(!event.target.closest('.psych-state-table td,.psych-formula-bar')){body.querySelectorAll('.psych-selected-cell').forEach(n=>n.classList.remove('psych-selected-cell'));bar.hidden=true;}};
  };
  select.addEventListener('change',()=>{project.psychEquipment=select.value;saveProjects();draw();});draw();
}
