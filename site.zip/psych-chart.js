/* Process points use the same dry-bulb/humidity-ratio axes as the SVG chart. */
function psychChartPoint(db,hr) {
  return si?{x:125+((Number(db)-32)/1.8)*893/50,y:665-Number(hr)/7*20}:{x:125+(Math.max(25,Number(db))-30)*893/90,y:665-Number(hr)*3};
}
function psychChartBounds(lines,pressure){
  const points=[];
  for(const line of lines)for(const state of line.cooling?psychCoolingPath(line.enter,line.leave,pressure):[line.enter,line.leave]){const p=psychChartPoint(state.db,state.hr);if(Number.isFinite(p.x)&&Number.isFinite(p.y))points.push(p);}
  // Preserve the complete chart header, axes and annotations in Calculation View.
  // The previous dynamic crop started at x=95/y=40 and clipped the chart itself.
  const left=Math.min(0,...points.map(p=>p.x-20)),top=Math.min(0,...points.map(p=>p.y-20));
  return {x:left,y:top,width:Math.max(1100,...points.map(p=>p.x+20))-left,height:Math.max(750,...points.map(p=>p.y+20))-top};
}
function psychPointOnSegment(p,a,b,tolerance=.6) {
  const dx=b.x-a.x,dy=b.y-a.y,length=dx*dx+dy*dy;if(!length)return false;
  const t=((p.x-a.x)*dx+(p.y-a.y)*dy)/length;return t>=0&&t<=1&&Math.hypot(p.x-a.x-t*dx,p.y-a.y-t*dy)<tolerance;
}
function psychCoolingPath(entering,leaving,pressure) {
  const points=[{db:entering.db,hr:entering.hr}];
  if(leaving.db>=entering.db||leaving.hr>=entering.hr){points.push({db:leaving.db,hr:leaving.hr});return points;}
  const target=db=>saturationHumidityRatio(db,pressure);
  let lo=leaving.db,hi=entering.db;
  // Find where the initial horizontal sensible segment meets the saturation curve.
  for(let i=0;i<50;i++){const mid=(lo+hi)/2;if(target(mid)>entering.hr)hi=mid;else lo=mid;}
  const intersection=(lo+hi)/2;
  if(target(entering.db)>=entering.hr)points.push({db:intersection,hr:entering.hr});
  const start=target(entering.db)>=entering.hr?intersection:entering.db;
  for(let i=1;i<=60;i++){const db=start+(leaving.db-start)*i/60;points.push({db,hr:target(db)});}
  points[points.length-1]={db:leaving.db,hr:leaving.hr};return points;
}
const psychChartDataCache = new WeakMap();
function invalidatePsychChartData(project) { if(project) psychChartDataCache.delete(project); }
function buildPsychChartData(project) {
  const cached=psychChartDataCache.get(project);if(cached)return cached;
  const owned=!activeCalculationCache;if(owned)activeCalculationCache={project};
  try {
    const context=coilCalculationContext(project),pressure=context.pressure,lines=[],equipment=new Set();
    const state=(db,hr)=>({db:presentNumber(db)?Number(db):NaN,hr:presentNumber(hr)?Number(hr):NaN,wb:wetBulbFromState(db,hr,pressure),rh:relativeHumidityForRatio(db,hr,pressure)});
    const add=(table,row,label,enter,leave,flow,sens,latent,loser=false)=>{
      if([enter.db,enter.hr,leave.db,leave.hr,flow,sens,latent].some(v=>!Number.isFinite(Number(v))))return;
      lines.push({equipment:String(row[0]),tableId:table.id,coilName:table.name.replace(/Coils$/,'Coil'),label,cooling:table.coilCalculation.includes('cooling'),enter,leave,flow,sens,latent,total:sens+latent,loser});
    };
    const ids=['airside-preheat','airside-ventilation-cooling','airside-room-cooling','airside-in-unit-reheat','airside-downstream-reheat','airside-room-heating'];
    for(const id of ids){const t=independentTables.find(t=>t.id===id),rows=ensureProjectTableRows(project,t,context);if(!context.calculatedCoils?.has(id))recalculateCoilTable(t,rows,project,context);
      for(const r of rows){
        if(r[0])equipment.add(String(r[0]));
        if(id==='airside-ventilation-cooling') {
          const candidates=[[15,20,9,'Ventilation cooling — Cooling design day'],[24,29,3,'Ventilation cooling — Dehumidification design day']].map(([c,f,l,label])=>{const leave=state(r[l],r[l+2]),enter=state(r[c],r[c+1]),flow=requirementNumber(r[f]),sens=requirementNumber(r[c+3])*flow*(enter.db-leave.db)/1000,latent=requirementNumber(r[c+4])*flow*(enter.hr-leave.hr)/1000;return {enter,leave,flow,label,sens,latent};});
          const winner=candidates[0].sens+candidates[0].latent>=candidates[1].sens+candidates[1].latent?0:1;
          candidates.forEach((c,i)=>add(t,r,c.label,c.enter,c.leave,c.flow,c.sens,c.latent,i!==winner));
        }else if(id==='airside-room-cooling')add(t,r,'Room air cooling',state(r[33],r[34]),state(r[9],r[11]),requirementNumber(r[38]),requirementNumber(r[39]),requirementNumber(r[40]));
        else {const c=id==='airside-preheat'?5:id==='airside-room-heating'?11:5,flowCol=id==='airside-room-heating'?15:9,capCol=id==='airside-room-heating'?16:10;if(r[c]===''||r[c+1]==='')continue;const entering=state(r[c],r[c+1]);add(t,r,t.name.replace(/ Coils?$/,''),entering,state(r[1],requirementNumber(r[2])),requirementNumber(r[flowCol]),requirementNumber(r[capCol]),airConstantsForState(entering.db,entering.hr,pressure).latent*requirementNumber(r[flowCol])*(entering.hr-requirementNumber(r[2]))/1000);}
      }
    }
    const result={lines,pressure,equipment:[...equipment]};psychChartDataCache.set(project,result);return result;
  } finally {if(owned)activeCalculationCache=null;}
}

function psychLineStyle(line) {
  if(line.mixing)return {color:line.mixingColor,fill:'#ffffff',name:'mixing'};
  if(line.tableId==='airside-room-cooling')return {color:'#0066ff',fill:'#ffffff',name:'room-cooling'};
  if(line.tableId==='airside-room-heating')return {color:'#bd3818',fill:'#ffffff',name:'room-heating'};
  if(line.saturation)return {color:'#000000',fill:'#ffffff',name:'saturation'};
  const preheat=line.tableId==='airside-preheat',dehum=line.label.includes('Dehumidification'),vent=line.tableId==='airside-ventilation-cooling';
  return preheat?{color:'#ce6f09',fill:'#ffffff',name:'preheat'}:dehum?{color:'#008577',fill:'#ffffff',name:'latent'}:line.cooling?{color:'#0066ff',fill:'#ffffff',name:'cooling'}:{color:'#bd3818',fill:'#ffffff',name:'heating'};
}
function psychTableHeaders() {
  return ['Curve','TDB [°F]','TWB [°F]','W [gr/lb]','h [Btu/lb]','RH [%]','Cs','Cl','TDB [°F]','TWB [°F]','W [gr/lb]','h [Btu/lb]','RH [%]','V̇ [CFM]','Qs [MBH]','Ql [MBH]','Qt [MBH]'];
}
function psychConditionName(line) {
  const table=independentTables.find(t=>t.id===line.tableId);
  const start=line.tableId==='airside-room-cooling'?33:line.tableId==='airside-room-heating'?11:line.tableId==='airside-ventilation-cooling'?(line.label.includes('Dehumidification')?24:15):5;
  const heading=table?.headerGroups?.find(g=>g.start===start)?.label;
  return heading?heading.replace(/^Entering (?:Air )?Conditions?\s*[-–]\s*/i,'') : ({'airside-preheat':'Heating Design Day','airside-room-cooling':'Cooling Room Air','airside-room-heating':'Heating Room Air','airside-in-unit-reheat':'Upstream Coil Leaving','airside-downstream-reheat':'Upstream Coil Leaving'}[line.tableId]||'Cooling Design Day');
}
function psychTableValues(line,pressure) {
  if(line.saturation)return [line.label,...Array(16).fill('-')];
  const constants=airConstantsForState(line.enter.db,line.enter.hr,pressure);
  const values=[`${line.coilName}\n${psychConditionName(line)}`,line.enter.db.toFixed(1),line.enter.wb.toFixed(1),(line.enter.hr).toFixed(1),moistAirEnthalpy(line.enter.db,line.enter.hr).toFixed(1),(100*relativeHumidityForRatio(line.enter.db,line.enter.hr,pressure)).toFixed(1),constants.sensible.toFixed(3),constants.latent.toFixed(3),line.leave.db.toFixed(1),line.leave.wb.toFixed(1),(line.leave.hr).toFixed(1),moistAirEnthalpy(line.leave.db,line.leave.hr).toFixed(1),(100*relativeHumidityForRatio(line.leave.db,line.leave.hr,pressure)).toFixed(1),Math.round(line.flow).toLocaleString(),line.sens.toFixed(2),line.latent.toFixed(2),line.total.toFixed(2)];
  const raw=[values[0],line.enter.db,line.enter.wb,line.enter.hr,moistAirEnthalpy(line.enter.db,line.enter.hr),100*relativeHumidityForRatio(line.enter.db,line.enter.hr,pressure),constants.sensible,constants.latent,line.leave.db,line.leave.wb,line.leave.hr,moistAirEnthalpy(line.leave.db,line.leave.hr),100*relativeHumidityForRatio(line.leave.db,line.leave.hr,pressure),line.flow,line.sens,line.latent,line.total];
  return values.map((v,c)=>{const h=psychTableHeaders()[c],s=unitSpec(h.match(/\[([^\]]+)\]/)?.[1],h.split(' [')[0]);return si&&s&&c?toSI(raw[c],s).toFixed(c===13?0:[6,7].includes(c)?3:c>=14?2:1):v;});
}
function psychCellFormula(line,column,pressure) {
  if(line.saturation)return {equation:'='+JSON.stringify(column?'-':line.label),values:{},model:true};
  const constants=airConstantsForState(line.enter.db,line.enter.hr,pressure);
  const values={'Equipment':line.equipment,'Entering Dry-Bulb':line.enter.db,'Entering Hum-Ratio [gr/lb]':line.enter.hr,'Leaving Dry-Bulb':line.leave.db,'Leaving Hum-Ratio [gr/lb]':line.leave.hr,'Barometric Pressure':pressure,'Airflow':line.flow,'Sensible Constant':constants.sensible,'Latent Constant':constants.latent,'Sensible Capacity':line.sens,'Latent Capacity':line.latent};
  const equations={0:'='+JSON.stringify(line.coilName+' — '+psychConditionName(line)),1:'=@Entering Dry-Bulb',2:'=WETBULB(@Entering Dry-Bulb,@Entering Hum-Ratio [gr/lb],@Barometric Pressure)',3:'=@Entering Hum-Ratio [gr/lb]',4:'=SENSIBLECONSTANT(@Entering Dry-Bulb,@Entering Hum-Ratio [gr/lb],@Barometric Pressure)',5:'=LATENTCONSTANT(@Entering Dry-Bulb,@Entering Hum-Ratio [gr/lb],@Barometric Pressure)',6:'=@Leaving Dry-Bulb',7:'=WETBULB(@Leaving Dry-Bulb,@Leaving Hum-Ratio [gr/lb],@Barometric Pressure)',8:'=@Leaving Hum-Ratio [gr/lb]',9:'=@Airflow',10:line.cooling?'=@Sensible Constant * @Airflow * (@Entering Dry-Bulb - @Leaving Dry-Bulb) / 1000':'=@Sensible Constant * @Airflow * (@Leaving Dry-Bulb - @Entering Dry-Bulb) / 1000',11:'=@Latent Constant * @Airflow * ((@Entering Hum-Ratio [gr/lb] - @Leaving Hum-Ratio [gr/lb])) / 1000',12:'=@Sensible Capacity + @Latent Capacity'};
  const old=[0,1,2,3,null,null,4,5,6,7,8,null,null,9,10,11,12][column];
  let equation=equations[old];if([4,5,11,12].includes(column)){const side=column<8?'Entering':'Leaving',db='@'+side+' Dry-Bulb',w='@'+side+' Hum-Ratio [gr/lb]';equation=[4,11].includes(column)?`=0.24*${db}+${w}*(0.15157142857142858+0.00006342857142857143*${db})`:`=100*${w}*@Barometric Pressure/(4353.615+${w})/SATURATIONPRESSURE(${db})`;}
  const header=psychTableHeaders()[column],spec=unitSpec(header.match(/\[([^\]]+)\]/)?.[1],header.split(' [')[0]);return {equation:unitEquation(equation,spec),values,model:true};
}
// The visible chart is a five-sided region, not the full image rectangle.
function psychPlotPolygon() { return [{x:84,y:928},{x:75,y:800},{x:773,y:84},{x:1231,y:84},{x:1231,y:928}]; }
function psychPointInPlot(point) {
  const polygon=psychPlotPolygon();let inside=false;
  for(let i=0,j=polygon.length-1;i<polygon.length;j=i++){
    const a=polygon[i],b=polygon[j];
    if(psychPointOnSegment(point,a,b))return true;
    if((a.y>point.y)!==(b.y>point.y)&&point.x<(b.x-a.x)*(point.y-a.y)/(b.y-a.y)+a.x)inside=!inside;
  }
  return inside;
}

function psychStateMarkers(lines){
  const map=new Map();for(const line of lines)for(const [kind,state] of [['enter',line.enter],['leave',line.leave]]){const key=Number(state.db).toFixed(5)+':'+Number(state.hr).toFixed(7);if(!map.has(key))map.set(key,{db:state.db,hr:state.hr,enter:[],leave:[]});const list=map.get(key)[kind],color=kind==='leave'&&line.mixing?line.mixedColor||line.mixingColor:psychLineStyle(line).color;if(!list.includes(color))list.push(color);}return [...map.values()];
}
function psychEquipmentOptions(project){
  if(!project)return [];const context=coilCalculationContext(project),tags=[];for(const id of ['airside-preheat','airside-ventilation-cooling','airside-room-cooling','airside-in-unit-reheat','airside-downstream-reheat','airside-room-heating']){const table=independentTables.find(t=>t.id===id);for(const row of ensureProjectTableRows(project,table,context))if(row[0])tags.push(String(row[0]));}return [...new Set(tags)].sort((a,b)=>a.localeCompare(b,undefined,{numeric:true,sensitivity:'base'}));
}
function syncPsychChartSelections(project){
  const section=modules.find(g=>g.psychSection);if(!section||!project)return;
  let options;try{options=psychEquipmentOptions(project);}catch(error){console.warn('Chart equipment list is temporarily unavailable:',error);options=[];}
  const byKey=new Map(options.map(v=>[requirementKey(v),v]));// Rendering must not delete saved chart selections when coil rows are temporarily unavailable.
  project.psychChartEquipment=[...new Map((project.psychChartEquipment||[]).filter(v=>String(v).trim()).map(v=>[requirementKey(v),byKey.get(requirementKey(v))||v])).values()];
  if(project!==activeProject())return options;
  const changed=JSON.stringify(section.items.map(i=>i[4]))!==JSON.stringify(project.psychChartEquipment);
  section.items=project.psychChartEquipment.map(tag=>[tag+' Psychrometric Chart','Psych','Coil entering and leaving conditions for '+tag,null,tag]);
  // Keep the section summary and Project Browser chart links in sync.

  return options;
}
function createPsychEquipmentPicker(onChange){
  const wrap=document.createElement('div');wrap.className='psych-equipment-picker';const label=document.createElement('span');label.textContent='Equipment with coils';const button=document.createElement('button');button.type='button';button.className='print-filter-toggle';button.textContent=(activeProject().psychChartEquipment||[]).length+' selected';button.setAttribute('aria-haspopup','dialog');button.setAttribute('aria-expanded','false');button.onpointermove=e=>button.classList.toggle('arrow-hover',e.clientX>=button.getBoundingClientRect().right-34);button.onpointerleave=()=>button.classList.remove('arrow-hover');wrap.append(label,button);
  const open=()=>{closeCellDropdown();const project=activeProject(),options=psychEquipmentOptions(project),selected=new Set(project.psychChartEquipment||[]),popup=document.createElement('div');popup.className='cell-dropdown-popup psych-picker-popup';popup.setAttribute('role','dialog');popup.setAttribute('aria-label','Equipment with coils');const input=document.createElement('input');input.type='search';input.placeholder='Search equipment';const list=document.createElement('div');list.className='cell-dropdown-options';const controls=document.createElement('div');controls.className='filter-popover-actions';const all=document.createElement('button'),none=document.createElement('button'),apply=document.createElement('button');all.textContent='Select all';none.textContent='Select None';apply.textContent='Apply';for(const b of [all,none,apply])b.type='button';controls.append(all,none,apply);popup.append(input,list,controls);document.body.appendChild(popup);
    const draw=()=>{list.replaceChildren();for(const tag of options.filter(v=>v.toLowerCase().includes(input.value.toLowerCase()))){const l=document.createElement('label');l.className='filter-option';const c=document.createElement('input');c.type='checkbox';c.checked=selected.has(tag);c.onchange=()=>{c.checked?selected.add(tag):selected.delete(tag);all.disabled=selected.size===options.length;none.disabled=!selected.size;};l.append(c,document.createTextNode(tag));list.appendChild(l);}all.disabled=selected.size===options.length;none.disabled=!selected.size;};
    all.onclick=()=>{options.forEach(v=>selected.add(v));draw();};none.onclick=()=>{selected.clear();draw();};apply.onclick=()=>{project.psychChartEquipment=options.filter(v=>selected.has(v));syncPsychChartSelections(project);saveProjects();closeCellDropdown();button.textContent=selected.size+' selected';button.setAttribute('aria-expanded','false');renderTree();onChange?.();};input.oninput=draw;popup.onkeydown=e=>{if(e.key==='Escape'){e.preventDefault();e.stopPropagation();closeCellDropdown();button.focus();}};draw();const rect=button.getBoundingClientRect();popup.style.width=rect.width+'px';popup.style.boxSizing='border-box';popup.style.left=Math.max(8,Math.min(rect.left,window.innerWidth-rect.width-8))+'px';popup.style.top=(rect.bottom+popup.offsetHeight<window.innerHeight-8?rect.bottom:Math.max(8,rect.top-popup.offsetHeight))+'px';button.setAttribute('aria-expanded','true');input.focus();
  };button.onclick=e=>{if(e.detail===0||e.clientX>=button.getBoundingClientRect().right-34)open();};button.onkeydown=e=>{if(!e.ctrlKey&&!e.metaKey&&(e.key.length===1||e.altKey&&e.key==='ArrowDown')){e.preventDefault();open();const input=document.querySelector('.psych-picker-popup input[type=search]');if(input&&e.key.length===1){input.value=e.key;input.dispatchEvent(new Event('input'));}}};return wrap;
}
function decoratePsychSharedTable(table){
  referenceTable.querySelectorAll('.group-header-row th').forEach(cell=>{const c=Number(cell.dataset.groupStart);if(![0,1,8].includes(c))return;const icon=document.createElementNS('http://www.w3.org/2000/svg','svg');icon.setAttribute('viewBox',c===0?'0 0 56 28':'0 0 26 26');icon.classList.add('psych-header-symbol');icon.dataset.symbolWidth=c===0?'56':'26';icon.dataset.symbolHeight=c===0?'28':'26';icon.setAttribute('aria-hidden','true');icon.style.width=c===0?'56px':'26px';icon.style.height='28px';icon.innerHTML=c===0?'<path d="M1 14H12 M39 14H55" stroke="white" stroke-width="3.5"/><path d="M13 5L35 14 13 23 18 14Z" fill="white"/>':`<circle cx="13" cy="13" r="${c===1?8:6.5}" stroke="white" stroke-width="${c===1?3:0}" fill="${c===1?'none':'white'}"/>`;cell.appendChild(icon);});
  document.querySelector('.table-toolbar').hidden=true;tableSettings.hidden=true;tableSearch.hidden=true;tableSearch.closest("label").hidden=true;rowActions.hidden=true;
  referenceTable.querySelectorAll('tbody tr').forEach((row,i)=>{row.style.setProperty('--psych-color',psychLineStyle(table.psychCalculation.lines[i]).color);row.dataset.line=i;if(table.psychCalculation.lines[i].saturation)row.classList.add('psych-saturation-row');if(table.psychCalculation.lines[i].loser)row.classList.add('psych-losing-row');});
}
function renderPsychChart(equipment){
  document.querySelector("#psych-mixed-summary")?.remove();
  const project=activeProject();if(!project)return;const data=buildPsychChartData(project),selected=project.psychChartEquipment||[],tag=selected.includes(equipment)?equipment:selected.includes(project.psychEquipment)?project.psychEquipment:selected[0]||'',lines=data.lines.filter(l=>l.equipment===tag);project.psychEquipment=tag;
  const mixed=renderMixedPsych(project,tag),allLines=[...(mixed?.lines||[]),...lines];
  const elevation=Number(project.modelInputs?.elevation??modelInputDefaults.elevation)||0,tableLines=lines;
  const headers=psychTableHeaders().map(v=>({...psychSymbolHeader253(v.replace(/\s*\[[^\]]+\]$/,'')),unit:psychHeaderUnit259(v)}));
  let table=independentTables.find(t=>t.id==='psych-active');if(!table){table={id:'psych-active'};independentTables.push(table);}Object.assign(table,{name:tag+' Psychrometric Chart',standard:tag+' Psychrometric Chart',headers,columns:headers.map(h=>h.label),columnTypes:headers.map((h,i)=>i?'number':'text'),rows:tableLines.map(l=>psychTableValues(l,data.pressure)),frozenColumns:1,identityColumns:headers.map((_,i)=>i),calculatedColumns:headers.map((_,i)=>i),lockedColumns:[],headerGroups:[{label:'Coils',start:0,span:1},{label:'Entering Conditions',start:1,span:7},{label:'Leaving Condition',start:8,span:5},{label:'Capacity',start:13,span:4}],headerClasses:{},headerLinks:{},summaryColumns:[],sectionStartColumns:[1,8,13],fixedRows:true,readonlyEquations:true,psychCalculation:{lines:tableLines,pressure:data.pressure},displayEquations:Object.fromEntries(headers.map((_,c)=>[c,'=0']))});
  tableView.hidden=false;shell.classList.add('table-mode');document.querySelector('.cell-keys').hidden=false;tableCount.hidden=false;renderReferenceTable(table.id,'',{skipRecalculation:true});if(mixed?.element)referenceTable.before(mixed.element);
  const root=document.createElement('section');tableView.classList.add('psych-coil-calculation');root.id='psych-chart-view';root.className='psych-chart-view';tableView.after(root);const content=document.createElement('div');root.appendChild(content);const body=referenceTable.tBodies[0],select={value:tag};
    const ns='http://www.w3.org/2000/svg',svg=window.PsychrometricChart.render({container:content,elevationFt:elevation,points:[]}).svg;const bounds=psychChartBounds(allLines,data.pressure);svg.setAttribute('viewBox',`${bounds.x} ${bounds.y} ${bounds.width} ${bounds.height}`);svg.classList.add('psych-image-overlay');svg.setAttribute('role','img');svg.setAttribute('aria-label',`${select.value}: coil entering to leaving paths`);
    const el=(tag,attrs,parent=svg)=>{const n=document.createElementNS(ns,tag);for(const [k,v] of Object.entries(attrs))n.setAttribute(k,String(v));parent.appendChild(n);return n;};
    drawPsychProcesses250(svg,allLines,data.pressure);
    content.appendChild(svg);
    const resizeSymbols=()=>{const scale=svg.getBoundingClientRect().width/bounds.width;if(!scale)return;document.querySelectorAll('.psych-header-symbol').forEach(icon=>{icon.style.width=`${Number(icon.dataset.symbolWidth)*scale}px`;icon.style.height=`${Number(icon.dataset.symbolHeight)*scale}px`;});};
    const resizeTables=()=>{resizeSymbols();alignMixedPsych251(mixed);};requestAnimationFrame(resizeTables);const observer=new ResizeObserver(()=>{if(!svg.isConnected){observer.disconnect();return;}resizeTables();});observer.observe(content);
    function highlight(index){}
}

/* Shared screen/PDF geometry: clipped state markers and side-by-side process colors. */
function psychProcessGeometry(lines,markers){
 const epsilon=.025,segments=[];for(const line of lines){let distance=0;for(let i=1;i<line.points.length;i++){const a=line.points[i-1],b=line.points[i],length=Math.hypot(b.x-a.x,b.y-a.y);if(length>1e-5)segments.push({a,b,color:line.color,length,distance,dashed:!!line.dashed,width:line.width||3.5});distance+=length;}}
 const cross=(a,b)=>a.x*b.y-a.y*b.x,diff=(a,b)=>({x:a.x-b.x,y:a.y-b.y}),at=(s,t)=>({x:s.a.x+(s.b.x-s.a.x)*t,y:s.a.y+(s.b.y-s.a.y)*t});
 const covers=(s,p)=>psychPointOnSegment(p,s.a,s.b,epsilon),colorsAt=p=>[...new Set(segments.filter(s=>covers(s,p)).map(s=>s.color))];
 const clipCircle=(a,b,p,r)=>{const d=diff(b,a),f=diff(a,p),A=d.x*d.x+d.y*d.y,B=2*(f.x*d.x+f.y*d.y),C=f.x*f.x+f.y*f.y-r*r,D=B*B-4*A*C;if(D<=0)return C>=0?[[a,b]]:[];const lo=Math.max(0,(-B-Math.sqrt(D))/(2*A)),hi=Math.min(1,(-B+Math.sqrt(D))/(2*A));if(lo>=hi)return [[a,b]];const out=[];if(lo>1e-8)out.push([a,at({a,b},lo)]);if(hi<1-1e-8)out.push([at({a,b},hi),b]);return out;};
 const hollow=markers.filter(m=>m.enter.length).map(m=>({...m.point||psychChartPoint(m.db,m.hr),radius:m.radius||8}));const strokes=[],seen=new Set();
 for(const segment of segments){let a=segment.a,b=segment.b;if(a.x>b.x+1e-7||Math.abs(a.x-b.x)<1e-7&&a.y>b.y)[a,b]=[b,a];const s={a,b},d=diff(b,a),len=Math.hypot(d.x,d.y),cuts=[0,1];
  for(const candidate of segments){if(Math.abs(cross(d,diff(candidate.b,candidate.a)))/len>epsilon||Math.abs(cross(d,diff(candidate.a,a)))/len>epsilon)continue;for(const p of [candidate.a,candidate.b]){const t=((p.x-a.x)*d.x+(p.y-a.y)*d.y)/(len*len);if(t>0&&t<1)cuts.push(t);}}
  cuts.sort((x,y)=>x-y);for(let i=1;i<cuts.length;i++){if(cuts[i]-cuts[i-1]<1e-7)continue;const start=at(s,cuts[i-1]),end=at(s,cuts[i]),key=[start.x,start.y,end.x,end.y].map(v=>v.toFixed(4)).join(',');if(seen.has(key))continue;seen.add(key);const colors=colorsAt(at(s,(cuts[i]+cuts[i-1])/2)),width=Math.max(...segments.filter(s=>covers(s,at({a:start,b:end},.5))).map(s=>s.width))/Math.max(1,colors.length);
   colors.forEach((color,k)=>{const offset=(k-(colors.length-1)/2)*width,shift=p=>({x:p.x-d.y/len*offset,y:p.y+d.x/len*offset});let pieces=[[shift(start),shift(end)]];for(const p of hollow)pieces=pieces.flatMap(([a,b])=>clipCircle(a,b,p,p.radius||8));for(let [a,b]of pieces){const matching=segments.filter(s=>s.color===color&&covers(s,at({a:start,b:end},.5))),source=matching[0],dx=source.b.x-source.a.x,dy=source.b.y-source.a.y;if((b.x-a.x)*dx+(b.y-a.y)*dy<0)[a,b]=[b,a];const distance=source.distance+((a.x-source.a.x)*dx+(a.y-source.a.y)*dy)/source.length;strokes.push({a,b,color,width,dashed:matching.every(s=>s.dashed),dashOffset:-distance});}});
  }
 }
 const bandClip=(points,bound,above)=>{const out=[];for(let i=0;i<points.length;i++){const p=points[i],q=points[(i+1)%points.length],pin=above?p.y>=bound:p.y<=bound,qin=above?q.y>=bound:q.y<=bound;if(pin)out.push(p);if(pin!==qin){const t=(bound-p.y)/(q.y-p.y);out.push({x:p.x+(q.x-p.x)*t,y:bound});}}return out;};
 const arrows=[],arrowSeen=new Set();for(const line of lines){const lengths=line.points.slice(1).map((p,i)=>Math.hypot(p.x-line.points[i].x,p.y-line.points[i].y));let remaining=lengths.reduce((a,b)=>a+b,0)/2;for(let i=0;i<lengths.length;i++){if(lengths[i]>0&&remaining<=lengths[i]){const a=line.points[i],b=line.points[i+1],p=at({a,b},remaining/lengths[i]),dx=(b.x-a.x)/lengths[i],dy=(b.y-a.y)/lengths[i],key=[p.x,p.y,dx,dy].map(x=>x.toFixed(3)).join(',');if(arrowSeen.has(key))break;arrowSeen.add(key);let colors=colorsAt(p);if(dx<0||Math.abs(dx)<1e-7&&dy<0)colors.reverse();if(!colors.length)colors=[line.color];const transform=q=>({x:p.x+(q.x*dx-q.y*dy)*(line.arrowScale||1),y:p.y+(q.x*dy+q.y*dx)*(line.arrowScale||1)}),shape=[{x:-16,y:-9},{x:6,y:0},{x:-16,y:9},{x:-11,y:0}];const bands=colors.map((color,i)=>({color,points:bandClip(bandClip(shape,-9+18*i/colors.length,true),-9+18*(i+1)/colors.length,false).map(transform)}));if(!hollow.some(c=>Math.hypot(c.x-p.x,c.y-p.y)<20))arrows.push({points:shape.map(transform),bands});break;}remaining-=lengths[i];}}
 return {strokes,arrows};
}
