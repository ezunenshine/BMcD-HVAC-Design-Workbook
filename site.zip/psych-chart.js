/* The supplied image is 1318 × 1014. Its 120°F/0 baseline intersection is
   (1231,928); 5°F spans 65.2 pixels, and 0.002 lb/lb spans 56.2 pixels. */
function psychChartPoint(db,hr) {
  return {x:1231+(Number(db)-120)*13.04,y:928-Number(hr)*28100};
}
function psychPointOnSegment(p,a,b) {
  const dx=b.x-a.x,dy=b.y-a.y,length=dx*dx+dy*dy;if(!length)return false;
  const t=((p.x-a.x)*dx+(p.y-a.y)*dy)/length;return t>=0&&t<=1&&Math.hypot(p.x-a.x-t*dx,p.y-a.y-t*dy)<.6;
}
function psychCoolingPath(entering,leaving,pressure) {
  const points=[{db:entering.db,hr:entering.hr}];
  if(leaving.db>=entering.db||leaving.hr>=entering.hr){points.push({db:leaving.db,hr:leaving.hr});return points;}
  const rh=leaving.rh;
  const target=db=>humidityRatioForPressure(db,rh,pressure);
  let lo=leaving.db,hi=entering.db;
  // Find where the initial horizontal sensible segment meets the leaving-RH curve.
  for(let i=0;i<50;i++){const mid=(lo+hi)/2;if(target(mid)>entering.hr)hi=mid;else lo=mid;}
  const intersection=(lo+hi)/2;
  if(target(entering.db)>=entering.hr)points.push({db:intersection,hr:entering.hr});
  const start=target(entering.db)>=entering.hr?intersection:entering.db;
  for(let i=1;i<=60;i++){const db=start+(leaving.db-start)*i/60;points.push({db,hr:target(db)});}
  points[points.length-1]={db:leaving.db,hr:leaving.hr};return points;
}
function buildPsychChartData(project) {
  const owned=!activeCalculationCache;if(owned)activeCalculationCache={project};
  try {
    const context=coilCalculationContext(project),pressure=context.pressure,lines=[],equipment=new Set();
    const state=(db,hr)=>({db:Number(db),hr:Number(hr),wb:wetBulbFromState(db,hr,pressure),rh:relativeHumidityForRatio(db,hr,pressure)});
    const add=(table,row,label,enter,leave,flow,sens,latent,loser=false)=>{
      if([enter.db,enter.hr,leave.db,leave.hr,flow,sens,latent].some(v=>!Number.isFinite(Number(v))))return;
      lines.push({equipment:String(row[0]),tableId:table.id,coilName:table.name,label,cooling:table.coilCalculation.includes('cooling'),enter,leave,flow,sens,latent,total:sens+latent,loser});
    };
    const ids=['airside-preheat','airside-ventilation-cooling','airside-room-cooling','airside-in-unit-reheat','airside-downstream-reheat','airside-room-heating'];
    for(const id of ids){const t=independentTables.find(t=>t.id===id),rows=ensureProjectTableRows(project,t,context);if(!context.calculatedCoils?.has(id))recalculateCoilTable(t,rows,project,context);
      for(const r of rows){
        if(r[0])equipment.add(String(r[0]));
        if(id==='airside-ventilation-cooling') {
          const leave=state(r[9],r[11]);const candidates=[[15,20,'Ventilation cooling — Cooling design day'],[24,29,'Ventilation cooling — Dehumidification design day']].map(([c,f,label])=>{const enter=state(r[c],r[c+1]),flow=requirementNumber(r[f]),sens=requirementNumber(r[c+3])*flow*(enter.db-leave.db)/1000,latent=requirementNumber(r[c+4])*flow*(enter.hr-leave.hr)/1000;return {enter,flow,label,sens,latent};});
          const winner=candidates[0].sens+candidates[0].latent>=candidates[1].sens+candidates[1].latent?0:1;
          candidates.forEach((c,i)=>add(t,r,c.label,c.enter,leave,c.flow,c.sens,c.latent,i!==winner));
        }else if(id==='airside-room-cooling')add(t,r,'Room air cooling',state(r[33],r[34]),state(r[9],r[11]),requirementNumber(r[38]),requirementNumber(r[39]),requirementNumber(r[40]));
        else {const c=id==='airside-preheat'?5:id==='airside-room-heating'?11:5,flowCol=id==='airside-room-heating'?15:9,capCol=id==='airside-room-heating'?16:10;if(r[c]===''||r[c+1]==='')continue;const entering=state(r[c],r[c+1]);add(t,r,t.name.replace(/ Coils?$/,''),entering,state(r[1],entering.hr),requirementNumber(r[flowCol]),requirementNumber(r[capCol]),0);}
      }
    }
    return {lines,pressure,equipment:[...equipment]};
  } finally {if(owned)activeCalculationCache=null;}
}

function psychLineStyle(line) {
  const preheat=line.tableId==='airside-preheat',dehum=line.label.includes('Dehumidification'),vent=line.tableId==='airside-ventilation-cooling';
  return preheat?{color:'#ce6f09',fill:'#ffffff',name:'preheat'}:dehum?{color:'#008577',fill:'#ffffff',name:'latent'}:line.cooling?{color:'#0066ff',fill:'#ffffff',name:'cooling'}:{color:'#bd3818',fill:'#ffffff',name:'heating'};
}
function psychTableHeaders() {
  return ['Leaving Condition','Dry-Bulb [degF]','Wet-Bulb [degF]','Rel-Hum [%]','Hum-Ratio [lb/lb]','Sensible Constant','Latent Constant','Dry-Bulb [degF]','Wet-Bulb [degF]','Rel-Hum [%]','Hum-Ratio [lb/lb]','Airflow [CFM]','Sensible [MBH]','Latent [MBH]','Total [MBH]'];
}
function psychConditionName(line) {
  const table=independentTables.find(t=>t.id===line.tableId);
  const start=line.tableId==='airside-room-cooling'?33:line.tableId==='airside-room-heating'?11:line.tableId==='airside-ventilation-cooling'?(line.label.includes('Dehumidification')?24:15):5;
  const heading=table?.headerGroups?.find(g=>g.start===start)?.label;
  return heading?heading.replace(/^Entering (?:Air )?Conditions?\s*[-–]\s*/i,'') : ({'airside-preheat':'Heating Design Day','airside-room-cooling':'Cooling Room Air','airside-room-heating':'Heating Room Air','airside-in-unit-reheat':'Upstream Coil Leaving','airside-downstream-reheat':'Upstream Coil Leaving'}[line.tableId]||'Cooling Design Day');
}
function psychTableValues(line,pressure) {
  const constants=airConstantsForState(line.enter.db,line.enter.hr,pressure);
  return [`${line.coilName.replace(/Coils\b/g,'Coil')}\n${psychConditionName(line)}`,line.enter.db.toFixed(1),line.enter.wb.toFixed(1),(line.enter.rh*100).toFixed(1)+'%',line.enter.hr.toFixed(5),constants.sensible.toFixed(3),constants.latent.toFixed(0),line.leave.db.toFixed(1),line.leave.wb.toFixed(1),(line.leave.rh*100).toFixed(1)+'%',line.leave.hr.toFixed(5),Math.round(line.flow).toLocaleString(),line.sens.toFixed(2),line.latent.toFixed(2),line.total.toFixed(2)];
}
function psychCellFormula(line,column,pressure) {
  const constants=airConstantsForState(line.enter.db,line.enter.hr,pressure);
  const values={'Equipment':line.equipment,'Entering Dry-Bulb':line.enter.db,'Entering Hum-Ratio':line.enter.hr,'Leaving Dry-Bulb':line.leave.db,'Leaving Hum-Ratio':line.leave.hr,'Barometric Pressure':pressure,'Airflow':line.flow,'Sensible Constant':constants.sensible,'Latent Constant':constants.latent,'Sensible Capacity':line.sens,'Latent Capacity':line.latent};
  const equations={0:'="'+line.coilName+' — '+psychConditionName(line)+'"',1:'=@Entering Dry-Bulb',2:'=WETBULB(@Entering Dry-Bulb,@Entering Hum-Ratio,@Barometric Pressure)',3:'=LET(TC,(@Entering Dry-Bulb-32)*5/9,VP,@Entering Hum-Ratio*@Barometric Pressure/(0.621945+@Entering Hum-Ratio),MAX(0,MIN(1,VP/(0.145038*0.61094*EXP(17.625*TC/(TC+243.04)))))*100)',4:'=@Entering Hum-Ratio',5:'=SENSIBLECONSTANT(@Entering Dry-Bulb,@Entering Hum-Ratio,@Barometric Pressure)',6:'=LATENTCONSTANT(@Entering Dry-Bulb,@Entering Hum-Ratio,@Barometric Pressure)',7:'=@Leaving Dry-Bulb',8:'=WETBULB(@Leaving Dry-Bulb,@Leaving Hum-Ratio,@Barometric Pressure)',9:'=LET(TC,(@Leaving Dry-Bulb-32)*5/9,VP,@Leaving Hum-Ratio*@Barometric Pressure/(0.621945+@Leaving Hum-Ratio),MAX(0,MIN(1,VP/(0.145038*0.61094*EXP(17.625*TC/(TC+243.04)))))*100)',10:'=@Leaving Hum-Ratio',11:'=@Airflow',12:line.cooling?'=@Sensible Constant * @Airflow * (@Entering Dry-Bulb - @Leaving Dry-Bulb) / 1000':'=@Sensible Constant * @Airflow * (@Leaving Dry-Bulb - @Entering Dry-Bulb) / 1000',13:line.cooling?'=@Latent Constant * @Airflow * (@Entering Hum-Ratio - @Leaving Hum-Ratio) / 1000':'=0',14:'=@Sensible Capacity + @Latent Capacity'};
  return {equation:equations[column],values,model:true};
}
function psychStateMarkers(lines){
  const map=new Map();for(const line of lines)for(const [kind,state] of [['enter',line.enter],['leave',line.leave]]){const key=Number(state.db).toFixed(5)+':'+Number(state.hr).toFixed(7);if(!map.has(key))map.set(key,{db:state.db,hr:state.hr,enter:[],leave:[]});const list=map.get(key)[kind],color=psychLineStyle(line).color;if(!list.includes(color))list.push(color);}return [...map.values()];
}
function psychEquipmentOptions(project){
  if(!project)return [];const context=coilCalculationContext(project),tags=[];for(const id of ['airside-preheat','airside-ventilation-cooling','airside-room-cooling','airside-in-unit-reheat','airside-downstream-reheat','airside-room-heating']){const table=independentTables.find(t=>t.id===id);for(const row of ensureProjectTableRows(project,table,context))if(row[0])tags.push(String(row[0]));}return [...new Set(tags)].sort((a,b)=>a.localeCompare(b,undefined,{numeric:true,sensitivity:'base'}));
}
function syncPsychChartSelections(project){
  const section=modules.find(g=>g.psychSection);if(!section||!project)return;
  const options=psychEquipmentOptions(project),byKey=new Map(options.map(v=>[requirementKey(v),v]));project.psychChartEquipment=(project.psychChartEquipment||[]).map(v=>byKey.get(requirementKey(v))).filter(Boolean);
  const changed=JSON.stringify(section.items.map(i=>i[4]))!==JSON.stringify(project.psychChartEquipment);
  section.items=project.psychChartEquipment.map(tag=>[tag+' Psychrometric Chart','Psych','Coil entering and leaving conditions for '+tag,null,tag]);
  if(changed&&typeof document!=='undefined'){const nav=document.querySelector('#project-tree > .psych-nav-section');if(nav?.querySelector){nav.querySelector('.tree-children')?.remove();if(section.items.length){const children=document.createElement('div');children.className='tree-children';section.items.forEach(item=>children.appendChild(createLeaf(item,section.group)));nav.appendChild(children);}const picker=nav.querySelector('.psych-equipment-picker button');if(picker)picker.textContent=section.items.length+' selected';}}
  return options;
}
function createPsychEquipmentPicker(onChange){
  const wrap=document.createElement('div');wrap.className='psych-equipment-picker';const label=document.createElement('span');label.textContent='Equipment with coils';const button=document.createElement('button');button.type='button';button.className='print-filter-toggle';button.textContent=(activeProject().psychChartEquipment||[]).length+' selected';button.setAttribute('aria-haspopup','dialog');button.onpointermove=e=>button.classList.toggle('arrow-hover',e.clientX>=button.getBoundingClientRect().right-34);button.onpointerleave=()=>button.classList.remove('arrow-hover');wrap.append(label,button);
  const open=()=>{closeCellDropdown();const project=activeProject(),options=psychEquipmentOptions(project),selected=new Set(project.psychChartEquipment||[]),popup=document.createElement('div');popup.className='cell-dropdown-popup psych-picker-popup';const input=document.createElement('input');input.type='search';input.placeholder='Search equipment';const list=document.createElement('div');list.className='cell-dropdown-options';const controls=document.createElement('div');controls.className='filter-popover-actions';const all=document.createElement('button'),none=document.createElement('button'),apply=document.createElement('button');all.textContent='Select all';none.textContent='Select None';apply.textContent='Apply';for(const b of [all,none,apply])b.type='button';controls.append(all,none,apply);popup.append(input,list,controls);document.body.appendChild(popup);
    const draw=()=>{list.replaceChildren();for(const tag of options.filter(v=>v.toLowerCase().includes(input.value.toLowerCase()))){const l=document.createElement('label');l.className='filter-option';const c=document.createElement('input');c.type='checkbox';c.checked=selected.has(tag);c.onchange=()=>{c.checked?selected.add(tag):selected.delete(tag);all.disabled=selected.size===options.length;none.disabled=!selected.size;};l.append(c,document.createTextNode(tag));list.appendChild(l);}all.disabled=selected.size===options.length;none.disabled=!selected.size;};
    all.onclick=()=>{options.forEach(v=>selected.add(v));draw();};none.onclick=()=>{selected.clear();draw();};apply.onclick=()=>{project.psychChartEquipment=options.filter(v=>selected.has(v));syncPsychChartSelections(project);saveProjects();closeCellDropdown();button.textContent=selected.size+' selected';onChange?.();};input.oninput=draw;popup.onkeydown=e=>{if(e.key==='Escape'){e.preventDefault();e.stopPropagation();closeCellDropdown();button.focus();}};draw();positionCellPopup(popup,button);input.focus();
  };button.onclick=e=>{if(e.detail===0||e.clientX>=button.getBoundingClientRect().right-34)open();};button.onkeydown=e=>{if(!e.ctrlKey&&!e.metaKey&&(e.key.length===1||e.altKey&&e.key==='ArrowDown')){e.preventDefault();open();const input=document.querySelector('.psych-picker-popup input[type=search]');if(input&&e.key.length===1){input.value=e.key;input.dispatchEvent(new Event('input'));}}};return wrap;
}
function decoratePsychSharedTable(table){
  document.querySelector('.table-toolbar').hidden=true;tableSettings.hidden=true;tableSearch.hidden=true;rowActions.hidden=true;
  referenceTable.querySelectorAll('tbody tr').forEach((row,i)=>{row.style.setProperty('--psych-color',psychLineStyle(table.psychCalculation.lines[i]).color);row.dataset.line=i;if(table.psychCalculation.lines[i].loser)row.classList.add('psych-losing-row');row.addEventListener('pointerenter',()=>document.querySelectorAll('#psych-chart-view .psych-process').forEach(g=>g.classList.toggle('psych-focused-process',Number(g.dataset.line)===i)));row.addEventListener('pointerleave',()=>document.querySelectorAll('#psych-chart-view .psych-process').forEach(g=>g.classList.remove('psych-focused-process')));});
}
function renderPsychChart(equipment){
  const project=activeProject();if(!project)return;const data=buildPsychChartData(project),tag=equipment||project.psychChartEquipment?.[0]||'',lines=data.lines.filter(l=>l.equipment===tag);project.psychEquipment=tag;
  const headers=psychTableHeaders().map(v=>({label:v.replace(/\s*\[[^\]]+\]$/,''),unit:v.match(/\[([^\]]+)\]$/)?.[1]||''}));
  let table=independentTables.find(t=>t.id==='psych-active');if(!table){table={id:'psych-active'};independentTables.push(table);}Object.assign(table,{name:tag+' Psychrometric Chart',standard:tag+' Psychrometric Chart',headers,columns:headers.map(h=>h.label),columnTypes:headers.map((h,i)=>i?'number':'text'),rows:lines.map(l=>psychTableValues(l,data.pressure)),frozenColumns:1,identityColumns:headers.map((_,i)=>i),calculatedColumns:headers.map((_,i)=>i),lockedColumns:[],headerGroups:[{label:'Coil',start:0,span:1},{label:'Entering Conditions',start:1,span:6},{label:'Leaving Condition',start:7,span:4},{label:'Capacity',start:11,span:4}],headerClasses:{},headerLinks:{},summaryColumns:[],sectionStartColumns:[1,7,11],fixedRows:true,readonlyEquations:true,psychCalculation:{lines,pressure:data.pressure},displayEquations:Object.fromEntries(headers.map((_,c)=>[c,'=0']))});
  tableView.hidden=false;shell.classList.add('table-mode');document.querySelector('.cell-keys').hidden=false;tableCount.hidden=false;renderReferenceTable(table.id,'',{skipRecalculation:true});
  const root=document.createElement('section');root.id='psych-chart-view';root.className='psych-chart-view';tableView.after(root);const content=document.createElement('div');root.appendChild(content);const body=referenceTable.tBodies[0],select={value:tag};
    const ns='http://www.w3.org/2000/svg',svg=document.createElementNS(ns,'svg');svg.setAttribute('viewBox','0 0 1318 1014');svg.classList.add('psych-image-overlay');svg.setAttribute('role','img');svg.setAttribute('aria-label',`${select.value}: coil entering to leaving paths`);
    const el=(tag,attrs,parent=svg)=>{const n=document.createElementNS(ns,tag);for(const [k,v] of Object.entries(attrs))n.setAttribute(k,String(v));parent.appendChild(n);return n;};
    el('image',{href:'psych-chart.png',x:0,y:0,width:1318,height:1014,style:'filter:grayscale(1)'});const defs=el('defs',{}),clip=el('clipPath',{id:'psych-plot-clip'},defs);el('rect',{x:0,y:78,width:1240,height:860},clip);const group=el('g',{'clip-path':'url(#psych-plot-clip)'});
    const plotted=[];
    lines.forEach((line,i)=>{const color=psychLineStyle(line).color,g=el('g',{'data-line':i,class:'psych-process'},group),points=line.cooling?psychCoolingPath(line.enter,line.leave,data.pressure):[line.enter,line.leave],coords=points.map(p=>psychChartPoint(p.db,p.hr));
      const path=el('path',{d:coords.map((p,j)=>`${j?'L':'M'}${p.x.toFixed(2)},${p.y.toFixed(2)}`).join(' '),fill:'none',stroke:color,'stroke-width':3.5,'vector-effect':'non-scaling-stroke'},g);el('title',{},path).textContent=line.label;
      // Overlay only shared segments with alternating colors; preserve exact state coordinates.
      for(const previous of plotted){const shared=[];let last=null;for(let j=1;j<coords.length;j++){const a=coords[j-1],b=coords[j],mid={x:(a.x+b.x)/2,y:(a.y+b.y)/2};if(previous.coords.slice(1).some((q,k)=>psychPointOnSegment(mid,previous.coords[k],q))){shared.push(`${last&&last.x===a.x&&last.y===a.y?'':'M'+a.x+','+a.y+' '}L${b.x},${b.y}`);last=b;}else last=null;}if(shared.length&&previous.color!==color){el('path',{d:shared.join(' '),fill:'none',stroke:previous.color,'stroke-width':3.5,'stroke-dasharray':'9 9','vector-effect':'non-scaling-stroke'},g);}}
      plotted.push({coords,color});
      // Direction arrow at half the path length remains visible even for zero-HR heating lines.
      const lengths=coords.slice(1).map((p,j)=>Math.hypot(p.x-coords[j].x,p.y-coords[j].y));let remaining=lengths.reduce((a,b)=>a+b,0)*.5;
      for(let j=0;j<lengths.length;j++){if(remaining<=lengths[j]&&lengths[j]>0){const a=coords[j],b=coords[j+1],fraction=remaining/lengths[j],x=a.x+(b.x-a.x)*fraction,y=a.y+(b.y-a.y)*fraction,angle=Math.atan2(b.y-a.y,b.x-a.x)*180/Math.PI;el('path',{d:'M-16,-9 L6,0 L-16,9 L-11,0 Z',fill:color,stroke:'white','stroke-width':1.2,transform:`translate(${x},${y}) rotate(${angle})`},g);break;}remaining-=lengths[j];}
    });
    const markers=psychStateMarkers(lines);for(const marker of markers){const p=psychChartPoint(marker.db,marker.hr);const g=el('g',{},group);if(marker.enter.length){el('circle',{cx:p.x,cy:p.y,r:8,fill:marker.leave[0]||'white',stroke:marker.enter[0],'stroke-width':3},g);if(marker.enter.length>1){marker.enter.slice(1).forEach((color,i)=>el('circle',{cx:p.x,cy:p.y,r:8,fill:'none',stroke:color,'stroke-width':3,'stroke-dasharray':`${Math.PI*16/marker.enter.length} ${Math.PI*16*(marker.enter.length-1)/marker.enter.length}`,'stroke-dashoffset':-Math.PI*16*(i+1)/marker.enter.length},g));}}else el('circle',{cx:p.x,cy:p.y,r:6.5,fill:marker.leave[0],stroke:'none'},g);if(marker.leave.length>1){const r=6.5;marker.leave.forEach((color,i)=>{const a=i*2*Math.PI/marker.leave.length,b=(i+1)*2*Math.PI/marker.leave.length;el('path',{d:`M${p.x},${p.y} L${p.x+r*Math.cos(a)},${p.y+r*Math.sin(a)} A${r},${r} 0 ${b-a>Math.PI?1:0} 1 ${p.x+r*Math.cos(b)},${p.y+r*Math.sin(b)} Z`,fill:color},g);});}}
    content.appendChild(svg);
    function highlight(index){svg.querySelectorAll('.psych-process').forEach(g=>g.classList.toggle('psych-focused-process',index!==null&&Number(g.dataset.line)===index));}
}
