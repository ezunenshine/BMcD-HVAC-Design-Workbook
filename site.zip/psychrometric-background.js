/* BMcD psychrometric chart — standalone SVG renderer. No dependencies. */
(function(global){
'use strict';
let instanceCount=0;
function render({container,elevationFt=0,points=[]}={}){
  if(typeof container==='string')container=document.querySelector(container);
  if(!container)throw new Error('PsychrometricChart: container not found');
  elevationFt=Number(elevationFt);
  if(!Number.isFinite(elevationFt)||elevationFt< -1000||elevationFt>15000)throw new RangeError('Elevation must be between -1000 and 15000 ft');
  const NS='http://www.w3.org/2000/svg';
  let svg=container.tagName.toLowerCase()==='svg'?container:container.querySelector('svg[data-psychrometric-chart]');
  if(!svg){svg=document.createElementNS(NS,'svg');svg.setAttribute('data-psychrometric-chart','');container.appendChild(svg)}
  svg.setAttribute('viewBox','0 0 1100 750');
  svg.setAttribute('xmlns',NS);
  svg.setAttribute('role','img');
  svg.setAttribute('aria-label','Psychrometric chart');
  svg.style.width='100%';svg.style.height='auto';svg.style.display='block';
  const clipId='psych-valid-'+(++instanceCount);

const LOGO='BurnsMcDonnell_Stacked_Black_R.png';
const sat=t=>{const k=(t-32)*5/9+273.15;return Math.exp(k<273.16?(-5674.5359/k+6.3925247-.009677843*k+6.2215701e-7*k*k+2.0747825e-9*k**3-9.484024e-13*k**4+4.1635019*Math.log(k)):(-5800.2206/k+1.3914993-.048640239*k+4.1764768e-5*k*k-1.4452093e-8*k**3+6.5459673*Math.log(k)))/1000};
const pressure=z=>14.696*Math.pow(1-6.8754e-6*z,5.2559)*6.894757293;const hum=(t,r,p)=>{let pv=Math.min(.999*p,sat(t)*r);return 4353.615*pv/(p-pv)};const ws=(t,p)=>hum(t,1,p);const gr=w=>w;const enthalpy=(t,w)=>.24*t+w*(0.15157142857142858+.00006342857142857143*t);
const vectorNodes=[],vectorIndex=new WeakMap(),measure=document.createElement('canvas').getContext('2d');
const labelWidth=(text,font)=>{if(measure?.measureText){measure.font=`600 ${font}px Arial`;return measure.measureText(text).width+12;}return text.length*font*.62+12;};
const vectorElements=[];
const add=(tag,attrs={},parent=svg,txt)=>{let e=document.createElementNS(NS,tag);const nativeSet=e.setAttribute.bind(e),nativeRemove=e.removeAttribute.bind(e);e.removeAttribute=k=>{delete attrs[k];nativeRemove(k);};e.setAttribute=(k,v)=>{attrs[k]=v;nativeSet(k,v);};vectorElements.push(e);vectorIndex.set(e,vectorNodes.length);vectorNodes.push({tag,attrs,text:txt??'',parent:vectorIndex.get(parent)??-1});for(const [k,v] of Object.entries(attrs))e.setAttribute(k,v);if(txt!==undefined)e.textContent=txt;parent.appendChild(e);return e};
function draw(){const elev=elevationFt,max=120,p=pressure(elev),min=30,W=1100,H=750,L=125,R=82,T=65,B=85;const x=t=>L+(t-min)/(max-min)*(W-L-R),y=g=>H-B-g/200*(H-T-B);const blue='#59636e',wet='#b8860b',rhColor='#237fbd',major=1.7;svg.replaceChildren();add('rect',{width:W,height:H,fill:'white'});const chartContent=add('g',{'data-layer':'psych-chart-content',opacity:1});const bg=add('g',{'font-family':'Arial, sans-serif'},chartContent);
const logo=add('image',{x:L-13.3,y:65,width:245,height:93,href:LOGO,preserveAspectRatio:'xMidYMid meet'},bg);add('text',{x:L,y:167,'text-anchor':'start','font-size':15,'font-weight':'700',fill:'#30465a'},bg,'PSYCHROMETRIC CHART');add('text',{x:L,y:188,'text-anchor':'start','font-size':12,'font-weight':'600',fill:'#30465a'},bg,`BAROMETRIC PRESSURE: ${(p*.145037738).toFixed(3)} PSIA`);add('text',{x:L,y:221,'text-anchor':'start','font-size':29,'font-weight':'700',fill:'#30465a'},bg,elev===0?'SEA LEVEL':`${elev.toLocaleString()} FEET`);
add('text',{x:L,y:244,'text-anchor':'start','font-size':15,'font-weight':'700',fill:'#30465a'},bg,'Qₜ = Qₛ + Qₗ');
for(const [yy,prefix,suffix]of [[263,'Qₛ = Cₛ ·','· ΔTᴅʙ / 1000'],[282,'Qₗ = Cₗ ·','· ΔW / 1000']]){add('text',{x:L,y:yy,'font-size':13,fill:'#30465a'},bg,prefix);if(measure)measure.font='13px Arial';const vx=L+(measure?.measureText?measure.measureText(prefix).width:prefix.length*7)+8;add('text',{x:vx,y:yy,'font-size':13,fill:'#30465a'},bg,'V');add('circle',{cx:vx+4.3,cy:yy-12.5,r:.9,fill:'#30465a'},bg);add('text',{x:vx+15,y:yy,'font-size':13,fill:'#30465a'},bg,suffix.includes('ΔT')?'· ΔT':suffix);if(suffix.includes('ΔT')){if(measure)measure.font='13px Arial';const dx=vx+15+(measure?.measureText?measure.measureText('· ΔT').width:27);add('text',{x:dx,y:yy+3,'font-size':9,fill:'#30465a'},bg,'DB');if(measure)measure.font='9px Arial';const tail=dx+(measure?.measureText?measure.measureText('DB').width:13);add('text',{x:tail,y:yy,'font-size':13,fill:'#30465a'},bg,' / 1000');}}
add('text',{x:L,y:304,'text-anchor':'start','font-size':13,'font-weight':'700',fill:'#30465a'},bg,'MIXED-AIR');
add('text',{x:L,y:324,'text-anchor':'start','font-size':12,fill:'#30465a'},bg,'ṁ =');
add('text',{x:L+28,y:324,'font-size':12,fill:'#30465a'},bg,'V');
add('circle',{cx:L+32,cy:312,r:.9,fill:'#30465a'},bg);
add('text',{x:L+40,y:324,'font-size':12,fill:'#30465a'},bg,'/ v');
add('text',{x:L,y:347,'text-anchor':'start','font-size':10.5,fill:'#30465a'},bg,'Wₘ = (ṁ₁W₁ + ṁ₂W₂)/(ṁ₁ + ṁ₂)');
add('text',{x:L,y:370,'text-anchor':'start','font-size':10.5,fill:'#30465a'},bg,'hₘ = (ṁ₁h₁ + ṁ₂h₂)/(ṁ₁ + ṁ₂)');
const informationEnd=vectorNodes.length;
const defs=add('defs'),clip=add('clipPath',{id:clipId},defs);let region=`M${x(min)} ${y(0)} L${x(max)} ${y(0)} L${x(max)} ${y(200)}`;for(let i=600;i>=0;i--){let t=min+(max-min)*i/600;region+=` L${x(t)} ${y(Math.min(200,gr(ws(t,p))))}`}region+=' Z';add('path',{d:region},clip);const grid=add('g',{'clip-path':`url(#${clipId})`},bg);
for(let t=min;t<=max;t++){let m=t%5===0;add('line',{x1:x(t),x2:x(t),y1:y(0),y2:y(200),stroke:m?blue:'#9ca5ae','stroke-width':m?major:.4},grid);add('line',{x1:x(t),x2:x(t),y1:y(0),y2:y(0)+(m?10:4),stroke:blue,'stroke-width':m?major:.5},bg);if(m)add('text',{x:x(t),y:y(0)+24,'text-anchor':'middle','font-size':10,fill:blue},bg,String(t))}
for(let g=0;g<=200;g+=2){let m=g%10===0;add('line',{x1:L,x2:W-R,y1:y(g),y2:y(g),stroke:m?blue:'#9ca5ae','stroke-width':m?major:.4},grid);add('line',{x1:W-R,x2:W-R+(m?10:4),y1:y(g),y2:y(g),stroke:blue,'stroke-width':m?major:.5},bg);if(m)add('text',{x:W-R+16,y:y(g)+3,'font-size':10,fill:blue},bg,String(g))}
function curve(fn,color,width=1,a=min,b=max){let d='',on=false;for(let i=0;i<=700;i++){let t=a+(b-a)*i/700,g=gr(fn(t));let valid=Number.isFinite(g)&&g>=0&&g<=200&&g<=gr(ws(t,p))+1e-6;if(valid){d+=(on?'L':'M')+x(t).toFixed(2)+' '+y(g).toFixed(2)+' ';on=true}else on=false}add('path',{d,stroke:color,'stroke-width':width,fill:'none'},grid)}
for(let pct=10;pct<=90;pct+=10){let r=pct/100;curve(t=>hum(t,r,p),rhColor,1);let valid=[];for(let i=0;i<=500;i++){let t=min+(max-min)*i/500,g=gr(hum(t,r,p));if(g>=3&&g<=195)valid.push(t)}if(valid.length){let text=pct===10?'10% RELATIVE HUMIDITY':pct+'%',font=pct===10?9:10,width=labelWidth(text,font),t=valid[Math.floor((valid.length-1)*.95)];t=Math.min(t,max-(width*.56+9)/(W-L-R)*(max-min));let gg=gr(hum(t,r,p)),d=.15,angle=Math.atan2(y(gr(hum(t+d,r,p)))-y(gr(hum(t-d,r,p))),x(t+d)-x(t-d))*180/Math.PI;let group=add('g',{transform:`translate(${x(t)} ${y(gg)}) rotate(${angle})`},bg);add('rect',{x:-width/2,y:-font-1,width,height:font+6,fill:'white'},group);add('text',{x:0,y:1,'text-anchor':'middle','font-size':font,'font-weight':'600',fill:rhColor},group,text)}}
for(let tw=-50;tw<=max;tw++){
 const sw=ws(tw,p),g=gr(sw),m=tw%5===0,fn=t=>tw>=32?((1093-.556*tw)*sw-1680*(t-tw))/(1093+.444*t-tw):((1220-.04*tw)*sw-1680*(t-tw))/(1220+.444*t-.48*tw);
 curve(t=>t<tw?NaN:fn(t),wet,m?1.15:.32,Math.max(min,tw),max);
 let tx,ty,nx,ny;
 if(tw<min){const initial=gr(fn(min));if(initial>=0&&initial<=gr(ws(min,p))){tx=x(min);ty=y(initial);nx=-1;ny=0;}}
 else if(g<=200){const d=.12,dx=x(tw+d)-x(tw-d),dy=y(gr(ws(tw+d,p)))-y(gr(ws(tw-d,p))),len=Math.hypot(dx,dy)||1;tx=x(tw);ty=y(g);nx=dy/len;ny=-dx/len;if(nx>0){nx=-nx;ny=-ny}}
 else if(gr(fn(max))<=200){let lo=tw,hi=max;for(let i=0;i<45;i++){let t=(lo+hi)/2;if(gr(fn(t))>200)lo=t;else hi=t}const t=(lo+hi)/2;tx=x(t);ty=y(200);nx=0;ny=-1;add('line',{x1:tx,y1:ty,x2:x(t+.2),y2:y(gr(fn(t+.2))),stroke:wet,'stroke-width':m?1.15:.32},bg);}
 if(tx!==undefined){add('line',{x1:tx,y1:ty,x2:tx+nx*(m?11:5),y2:ty+ny*(m?11:5),stroke:wet,'stroke-width':m?1.3:.6},bg);if(m)add('text',{x:tx+nx*24,y:ty+ny*24+3,'text-anchor':'middle','font-size':9,fill:wet},bg,String(tw));}
}
// Keep the wet-bulb heading on the visible portion of the saturation curve.
// At high elevation the 77.5 F point can exceed the 200-grain chart ceiling.
let maxVisibleSatT=max;
if(gr(ws(max,p))>200){let lo=min,hi=max;for(let j=0;j<55;j++){const mid=(lo+hi)/2;if(gr(ws(mid,p))>200)hi=mid;else lo=mid;}maxVisibleSatT=(lo+hi)/2;}
const lt=Math.max(min+5,Math.min(77.5,maxVisibleSatT-7));
const lg=gr(ws(lt,p));
if(lg<=200){
  const d=.15,dx=x(lt+d)-x(lt-d),dy=y(gr(ws(lt+d,p)))-y(gr(ws(lt-d,p)));
  const len=Math.hypot(dx,dy)||1;
  let nx=dy/len,ny=-dx/len;
  if(nx>0){nx=-nx;ny=-ny;}
  const tx=x(lt)+nx*36,ty=y(lg)+ny*36,angle=Math.atan2(dy,dx)*180/Math.PI;
  add('text',{x:tx,y:ty,transform:`rotate(${angle} ${tx} ${ty})`,'text-anchor':'middle','font-size':10,'font-weight':'600',fill:wet},bg,'WET-BULB TEMPERATURE (°F)');
}
// Specific-volume isolines every 0.1 ft³/lb, using barometric pressure at the selected elevation.
// v [ft3/lb dry air] = 0.370486 (DB+459.67)(1+0.000229694 W)/P[psia].
// The solid curves are drawn behind the enthalpy scale and above the RH/WB curves.
const vColor='#c0268a';
const pPsia=p*0.1450377377;
// Derive SV bounds from the visible, physically valid chart domain.
// No hard-coded 20 ft3/lb ceiling; only the visible chart clips the lines.
const specificVolume=(t,w)=>0.370486*(t+459.67)*(1+0.000229694*w)/pPsia;
let svMin=Infinity,svMax=-Infinity;
for(let j=0;j<=500;j++){
  const t=min+(max-min)*j/500;
  const maxW=Math.min(200,ws(t,p));
  svMin=Math.min(svMin,specificVolume(t,0));
  svMax=Math.max(svMax,specificVolume(t,maxW));
}
const svFirst=Math.floor(svMin*10-1e-7);
const svLast=Math.ceil(svMax*10+1e-7);
for(let vi=svFirst;vi<=svLast;vi++){
  const v=vi/10;
  const isMajor=vi%5===0;
  let d='',active=false,first=null,last=null;
  for(let i=0;i<=900;i++){
    const t=min+(max-min)*i/900;
    const w=(v*pPsia/(0.370486*(t+459.67))-1)/0.000229694;
    const g=gr(w);
    const valid=Number.isFinite(g)&&g>=0&&g<=200&&w<=ws(t,p)+1e-8;
    if(valid){
      const px=x(t),py=y(g);
      d+=(active?'L':'M')+px.toFixed(2)+' '+py.toFixed(2)+' ';
      if(!first)first={x:px,y:py};last={x:px,y:py};active=true;
    } else active=false;
  }
  if(!d)continue;
  add('path',{d,fill:'none',stroke:vColor,'stroke-width':isMajor?1.05:0.34,'stroke-opacity':1},grid);
  // Put labels near the rightmost visible point, inside the chart.
  if(isMajor&&last&&last.x>x(min)+50){
    const label=v.toFixed(1), lx=last.x-9, ly=last.y-5;
    const labelWidth=label.length*5.0+7;
    // Compact opaque-white knockout inside the halftoned chart layer.
    add('rect',{x:lx-labelWidth,y:ly-9,width:labelWidth,height:12,rx:1.5,fill:'#ffffff'},bg);
    add('text',{x:lx-3,y:ly,'text-anchor':'end','font-size':8,'font-weight':'700',fill:vColor},bg,label);
  }
}
// Specific volume is identified beside the zero-humidity-ratio baseline.
// No specific-volume ticks or numbers are drawn on the saturation curve.
const volumeLabels=[];
const vAtMin=0.370486*(min+459.67)*(1+0.000229694*ws(min,p))/pPsia;
const SCALE_LABEL_OFFSET=24; // Matches wet-bulb numeral offset from the same boundary
// Constant-enthalpy isolines, dashed, with an exterior saturation-curve scale.
const hColor='#23864c';
// Label collision avoidance: preserve WB labels, relocate enthalpy labels.
const numericLabelBoxes=[];
function labelBox(el,pad=3){const b=el.getBBox();return {x:b.x-pad,y:b.y-pad,w:b.width+2*pad,h:b.height+2*pad};}
function intersects(a,b){return a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y;}
// Existing wet-bulb numerals have already been rendered.
for(const node of bg.querySelectorAll('text')){
  const value=(node.textContent||'').trim();
  if(/^[-]?\d+$/.test(value)&&node.getAttribute('fill')===wet) numericLabelBoxes.push(labelBox(node,5));
}
function placeEnthalpyNumber(hv,tx,ty,nx,ny){
  if(hv===25)return; // Render in final pass at the same 24px offset.
  const text=add('text',{x:tx+nx*SCALE_LABEL_OFFSET,y:ty+ny*SCALE_LABEL_OFFSET+3,'text-anchor':'middle','font-size':9,'font-weight':'600',fill:hColor},bg,String(hv));
  let box=labelBox(text,4);
  // Keep 10 and 25 beside their ticks: shift slightly along the boundary,
  // never farther outward from the saturation/boundary line.
  if(hv===10||hv===25){
    const tangentX=-ny, tangentY=nx;
    const shifts=[0,5,-5,10,-10,14,-14];
    for(const shift of shifts){
      text.setAttribute('x',tx+nx*SCALE_LABEL_OFFSET+tangentX*shift);
      text.setAttribute('y',ty+ny*SCALE_LABEL_OFFSET+tangentY*shift+3);
      box=labelBox(text,3);
      if(!numericLabelBoxes.some(other=>intersects(box,other)))break;
    }
  }else{
    for(let i=0;i<12&&numericLabelBoxes.some(other=>intersects(box,other));i++){
      const offset=(i+1)*9;
      text.setAttribute('x',tx+nx*SCALE_LABEL_OFFSET+(i%2?12:0));
      text.setAttribute('y',ty+ny*SCALE_LABEL_OFFSET+3);
      box=labelBox(text,4);
    }
  }
  if(numericLabelBoxes.some(other=>intersects(box,other))){text.setAttribute('stroke','#fff');text.setAttribute('stroke-width','2.5');text.setAttribute('paint-order','stroke');}
  numericLabelBoxes.push(box);
}

const satH=t=>enthalpy(t,ws(t,p));
for(let hv=0;hv<=59;hv++){
  const isMajor=hv%5===0;
  const wh=t=>(hv-.24*t)/(0.15157142857142858+.00006342857142857143*t);
  // Draw dashed enthalpy lines, clipped to the valid psychrometric region.
  let d='',on=false;
  for(let i=0;i<=900;i++){
    const t=min+(max-min)*i/900,w=wh(t),g=gr(w);
    const valid=Number.isFinite(g)&&g>=0&&g<=200&&w<=ws(t,p)+1e-9;
    if(valid){d+=(on?'L':'M')+x(t).toFixed(3)+' '+y(g).toFixed(3)+' ';on=true;}
    else on=false;
  }
  add('path',{d,fill:'none',stroke:hColor,'stroke-width':isMajor?1.05:.48,'stroke-dasharray':isMajor?'5 4':'2.5 4'},grid);
  // Locate the tick at saturation, or at the visible chart boundary for 10/55.
  let tx,ty,nx,ny;
  if(hv>=satH(min)&&hv<=satH(max)){
    let lo=min,hi=max;
    for(let j=0;j<55;j++){let mid=(lo+hi)/2;if(satH(mid)<hv)lo=mid;else hi=mid;}
    const ts=(lo+hi)/2,gs=gr(ws(ts,p));
    if(gs>=0&&gs<=200){
      const ds=.15,dx=x(ts+ds)-x(ts-ds),dy=y(gr(ws(ts+ds,p)))-y(gr(ws(ts-ds,p)));
      const length=Math.hypot(dx,dy)||1;
      tx=x(ts);ty=y(gs);nx=dy/length;ny=-dx/length;
    }
  }
  // At this elevation 10 Btu/lb can be below the 30 F saturation endpoint.
  if(hv===10&&tx===undefined){
    const g=gr(wh(min));
    if(g>=0&&g<=gr(ws(min,p))){tx=x(min);ty=y(g);nx=-1;ny=0;}
  }
  // At this elevation 55 Btu/lb can intersect the 200-grain ceiling first.
  if(isMajor&&tx===undefined){
    const w=200,t=(hv-0.15157142857142858*w)/(.24+.00006342857142857143*w);
    if(t>=min&&t<=max&&200<=gr(ws(t,p))){tx=x(t);ty=y(200);nx=0;ny=-1;}
  }
  if(tx!==undefined){
    const tick=isMajor?12:6;
    add('line',{x1:tx,y1:ty,x2:tx+nx*tick,y2:ty+ny*tick,stroke:hColor,'stroke-width':isMajor?1.25:.7},bg);
    if(isMajor){
      placeEnthalpyNumber(hv,tx,ty,nx,ny);
    }
  }
}
// Exterior heading aligned with the tangent of the saturation curve.
{
  // Place heading halfway between the 15 and 20 Btu/lb saturation intersections.
  const targetH=17.5;
  let hlo=min,hhi=max;
  for(let j=0;j<55;j++){const mid=(hlo+hhi)/2;if(satH(mid)<targetH)hlo=mid;else hhi=mid;}
  const ht=(hlo+hhi)/2,gg=gr(ws(ht,p)),ds=.2;
  if(gg<=200){
    const dx=x(ht+ds)-x(ht-ds),dy=y(gr(ws(ht+ds,p)))-y(gr(ws(ht-ds,p)));
    const len=Math.hypot(dx,dy)||1,nx=dy/len,ny=-dx/len;
    const lx=x(ht)+nx*40,ly=y(gg)+ny*40;
    const angle=Math.atan2(dy,dx)*180/Math.PI;
    add('text',{x:lx,y:ly,transform:`rotate(${angle} ${lx} ${ly})`,'text-anchor':'middle','font-size':10,'font-weight':'700',fill:hColor},bg,'ENTHALPY (BTU/LB DRY AIR)');
  }
}
// Force the 25 Btu/lb label to be visible at its correct saturation tick.
// Draw last, with a small white text halo rather than hiding it on collision.
{
  let lo=min,hi=max;
  for(let j=0;j<55;j++){const mid=(lo+hi)/2;if(satH(mid)<25)lo=mid;else hi=mid;}
  const t=(lo+hi)/2,g=gr(ws(t,p));
  if(g>=0&&g<=200){
    const ds=.12,dx=x(t+ds)-x(t-ds),dy=y(gr(ws(t+ds,p)))-y(gr(ws(t-ds,p)));
    const len=Math.hypot(dx,dy)||1,nx=dy/len,ny=-dx/len;
    // Keep the label near its tick; slight tangent offset prevents collisions.
    const tx=x(t)+nx*SCALE_LABEL_OFFSET,ty=y(g)+ny*SCALE_LABEL_OFFSET;
    add('text',{x:tx,y:ty+3,'text-anchor':'middle','font-size':9,'font-weight':'700',fill:hColor,stroke:'#ffffff','stroke-width':3,'paint-order':'stroke'},bg,'25');
  }
}
// Place specific-volume heading at the bottom-right, along the 0-grain baseline.
// This avoids competing with enthalpy and wet-bulb annotations at saturation.
add('text',{
  x:x(max)-8,y:y(0)+47,'text-anchor':'end',
  'font-size':10,'font-weight':'700',fill:vColor,
  stroke:'#fff','stroke-width':2,'paint-order':'stroke'
},bg,'SPECIFIC VOLUME (FT³/LB DRY AIR)');

// Specific-volume boundary ticks and numeric labels intentionally omitted.
// Final common collision pass across WB, enthalpy and specific-volume numeric labels.
// Move labels ONLY along their boundary tangent, never farther from the curve/axis.
// Keep all numeric labels (including 25 enthalpy) visible.
{
  const scaleColors=new Set([wet,hColor,vColor]);
  const all=Array.from(bg.querySelectorAll('text')).filter(node=>
    scaleColors.has(node.getAttribute('fill')) && /^-?\d+(?:\.\d+)?$/.test((node.textContent||'').trim()));
  const placed=[];
  const overlap=(a,b)=>a.x<b.x+b.width&&a.x+a.width>b.x&&a.y<b.y+b.height&&a.y+a.height>b.y;
  const boxOf=node=>{const b=node.getBBox();return {x:b.x-2,y:b.y-2,width:b.width+4,height:b.height+4};};
  // Sort by the physical position of the label; all three scales share collision avoidance.
  all.sort((a,b)=>Number(a.getAttribute('x'))-Number(b.getAttribute('x')));
  for(const node of all){
    const ox=Number(node.getAttribute('x')),oy=Number(node.getAttribute('y'));
    let nx=0,ny=0;
    // Determine which boundary the tick belongs to using its nearest geometric boundary.
    const topY=y(200),leftX=x(min);
    if(ox<leftX-8){nx=0;ny=1;}
    else if(oy<topY-8){nx=1;ny=0;}
    else {
      let nearest=min,best=Infinity;
      for(let t=min;t<=max;t+=.35){const g=gr(ws(t,p));if(g>200)break;
        const d=(x(t)-ox)**2+(y(g)-oy)**2;
        if(d<best){best=d;nearest=t;}}
      const ds=.1,dx=x(nearest+ds)-x(nearest-ds),dy=y(gr(ws(nearest+ds,p)))-y(gr(ws(nearest-ds,p)));
      const norm=Math.hypot(dx,dy)||1;nx=dx/norm;ny=dy/norm;
    }
    let accepted=false;
    for(const shift of [0,7,-7,14,-14,21,-21,28,-28,35,-35,42,-42,49,-49,56,-56]){
      node.setAttribute('x',ox+nx*shift);node.setAttribute('y',oy+ny*shift);
      const b=boxOf(node);
      if(!placed.some(q=>overlap(b,q))){placed.push(b);accepted=true;break;}
    }
    if(!accepted){
      // Preserve labels and keep them readable against crossing lines.
      node.setAttribute('x',ox);node.setAttribute('y',oy);
      node.setAttribute('stroke','#fff');node.setAttribute('stroke-width','2.5');node.setAttribute('paint-order','stroke');
      placed.push(boxOf(node));
    }
  }
}


// Align enthalpy and wet-bulb numeric labels to a common boundary baseline.
// Left (30 F): same X; upper (200 grains): same Y.  On saturation,
// both scales use the same outward normal offset, preserving tangent shifts.
{
  const labels=Array.from(bg.querySelectorAll('text')).filter(n=>
    [wet,hColor].includes(n.getAttribute('fill')) && /^-?\d+$/.test((n.textContent||'').trim()));
  for(const n of labels){
    const px=Number(n.getAttribute('x')),py=Number(n.getAttribute('y'));
    if(!Number.isFinite(px)||!Number.isFinite(py))continue;
    if(px<x(min)-8 && py>y(200)+5){n.setAttribute('x',x(min)-24);}
    if(py<y(200)-8 && px>x(min)+5){n.setAttribute('y',y(200)-24+3);}
  }
}

// Guarantee major enthalpy values remain legible at sea level and altitude.
// Labels are positioned from the actual saturation or clipped boundary intersection.
for(const hv of [15,20,30,50]){
  const existing=Array.from(bg.querySelectorAll('text')).find(n=>n.getAttribute('fill')===hColor&&(n.textContent||'').trim()===String(hv));
  if(existing)continue;
  let tx,ty,nx,ny;
  if(hv>=satH(min)&&hv<=satH(max)){
    let lo=min,hi=max;
    for(let i=0;i<55;i++){let m=(lo+hi)/2;if(satH(m)<hv)lo=m;else hi=m;}
    const t=(lo+hi)/2,g=gr(ws(t,p));
    if(g<=200){const d=.1,dx=x(t+d)-x(t-d),dy=y(gr(ws(t+d,p)))-y(gr(ws(t-d,p))),len=Math.hypot(dx,dy)||1;
      tx=x(t);ty=y(g);nx=dy/len;ny=-dx/len;}
  }
  if(tx===undefined){const w=200,t=(hv-0.15157142857142858*w)/(.24+.00006342857142857143*w);
    if(t>=min&&t<=max&&200<=gr(ws(t,p))){tx=x(t);ty=y(200);nx=0;ny=-1;}}
  if(tx===undefined){const g=gr((hv-.24*min)/(0.15157142857142858+.00006342857142857143*min));
    if(g>=0&&g<=gr(ws(min,p))){tx=x(min);ty=y(g);nx=-1;ny=0;}}
  if(tx!==undefined){add('text',{x:tx+nx*SCALE_LABEL_OFFSET,y:ty+ny*SCALE_LABEL_OFFSET+3,
    'text-anchor':'middle','font-size':9,'font-weight':'700',fill:hColor,
    stroke:'#fff','stroke-width':2.5,'paint-order':'stroke'},bg,String(hv));}
}

// Final boundary-label layout: preserve the physical ordering of enthalpy
// ticks relative to wet-bulb ticks, and use the same outward offset.
{
  const labels=Array.from(bg.querySelectorAll('text'));
  const getLabel=(color,value)=>labels.find(n=>n.getAttribute('fill')===color&&(n.textContent||'').trim()===String(value));
  const getBoundaryPosition=hv=>{
    const leftW=(hv-.24*min)/(0.15157142857142858+.00006342857142857143*min),leftG=gr(leftW);
    if(leftG>=0&&leftG<=gr(ws(min,p)))return {edge:'left',x:x(min)-SCALE_LABEL_OFFSET,y:y(leftG)+3};
    const topW=200,topT=(hv-0.15157142857142858*topW)/(.24+.00006342857142857143*topW);
    if(topT>=min&&topT<=max&&200<=gr(ws(topT,p)))return {edge:'top',x:x(topT),y:y(200)-SCALE_LABEL_OFFSET+3};
    return null;
  };
  for(const hv of [10,15,20,25,30,50,55]){
    const node=getLabel(hColor,hv),pos=getBoundaryPosition(hv);
    if(!node||!pos)continue;
    node.setAttribute('x',pos.x);node.setAttribute('y',pos.y);
    node.setAttribute('text-anchor','middle');
    node.setAttribute('stroke','#fff');node.setAttribute('stroke-width','2');node.setAttribute('paint-order','stroke');
  }
  // Keep the 15 label on the same side of 40 WB as its own enthalpy tick,
  // and 20 on the same side of 50 WB. Small shifts only; never cross the WB.
  for(const [hv,wbv] of [[15,40],[20,50]]){
    const e=getLabel(hColor,hv),w=getLabel(wet,wbv);
    if(!e||!w)continue;
    const pos=getBoundaryPosition(hv);if(!pos)continue;
    const ex=Number(e.getAttribute('x')),ey=Number(e.getAttribute('y'));
    const wx=Number(w.getAttribute('x')),wy=Number(w.getAttribute('y'));
    if(pos.edge==='left'){
      const tickY=pos.y;
      if((tickY-wy)*(ey-wy)<0)e.setAttribute('y',tickY);
    }else if(pos.edge==='top'){
      const tickX=pos.x;
      if((tickX-wx)*(ex-wx)<0)e.setAttribute('x',tickX);
    }
  }
  // Reapply the exact same top-boundary offset for 55 enthalpy and 85 WB.
  for(const [color,val] of [[hColor,55],[wet,85]]){
    const node=getLabel(color,val);
    if(node&&Number(node.getAttribute('y'))<y(200)-8)node.setAttribute('y',y(200)-SCALE_LABEL_OFFSET+3);
  }
}
// Final deterministic placement for enthalpy values: anchored to their OWN ticks.
// Move conflicting WB numerals along the boundary rather than moving an enthalpy
// numeral across its neighboring WB tick.
{
  const labels=Array.from(bg.querySelectorAll('text'));
  const find=(color,val)=>labels.find(n=>n.getAttribute('fill')===color && (n.textContent||'').trim()===String(val));
  const satAnchor=(value)=>{
    if(value<satH(min)||value>satH(max))return null;
    let lo=min,hi=max;
    for(let i=0;i<55;i++){const m=(lo+hi)/2;if(satH(m)<value)lo=m;else hi=m;}
    const t=(lo+hi)/2,g=gr(ws(t,p));if(g>200)return null;
    const dt=.08,dx=x(t+dt)-x(t-dt),dy=y(gr(ws(t+dt,p)))-y(gr(ws(t-dt,p)));
    const length=Math.hypot(dx,dy)||1;
    return {x:x(t),y:y(g),nx:dy/length,ny:-dx/length,tx:dx/length,ty:dy/length};
  };
  const set=(node,x0,y0)=>{node.setAttribute('x',x0);node.setAttribute('y',y0);node.setAttribute('text-anchor','middle');};
  const rect=node=>{const b=node.getBBox();return {x:b.x-2,y:b.y-2,w:b.width+4,h:b.height+4};};
  const hits=(a,b)=>a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y;
  for(const [hv,wbv] of [[15,40],[20,50],[50,85]]){
    const e=find(hColor,hv),w=find(wet,wbv),a=satAnchor(hv);
    if(!e||!a)continue;
    // Exact equal perpendicular spacing for both families.
    set(e,a.x+a.nx*SCALE_LABEL_OFFSET,a.y+a.ny*SCALE_LABEL_OFFSET+3);
    if(w&&hits(rect(e),rect(w))){
      // Shift WB only, at most 12 px, and never across its own tick.
      const wx=Number(w.getAttribute('x')),wy=Number(w.getAttribute('y'));
      const wbA=satAnchor(enthalpy(wbv,ws(wbv,p)));
      if(wbA){
        for(const d of [5,-5,9,-9,12,-12]){
          set(w,wx+wbA.tx*d,wy+wbA.ty*d);
          if(!hits(rect(e),rect(w)))break;
        }
      }
    }
  }
  // At the 200-grain ceiling, all major numerals have the identical y offset.
  const e55=find(hColor,55),w85=find(wet,85);
  for(const node of [e55,w85])if(node && Number(node.getAttribute('y'))<y(200)-8)
    node.setAttribute('y',y(200)-SCALE_LABEL_OFFSET+3);
}
// FINAL PHYSICAL LABEL ORDER: derive both anchors from their actual saturation
// intersections on every elevation change. Earlier collision passes must never
// reverse the 30 Btu/lb enthalpy label and 65 F wet-bulb label.
{
  const textNodes=Array.from(bg.querySelectorAll('text'));
  const label=(color,value)=>textNodes.find(n=>n.getAttribute('fill')===color && (n.textContent||'').trim()===String(value));
  const e30=label(hColor,30), wb65=label(wet,65);
  function satAnchor(t){
    const d=.12,dx=x(t+d)-x(t-d),dy=y(gr(ws(t+d,p)))-y(gr(ws(t-d,p)));
    const length=Math.hypot(dx,dy)||1;
    return {x:x(t),y:y(gr(ws(t,p))),nx:dy/length,ny:-dx/length,tx:dx/length,ty:dy/length};
  }
  function hSatTemp(hv){
    let lo=min,hi=max;
    if(hv<satH(lo)||hv>satH(hi))return null;
    for(let i=0;i<55;i++){
      const mid=(lo+hi)/2;
      if(satH(mid)<hv)lo=mid;else hi=mid;
    }
    const t=(lo+hi)/2;
    return gr(ws(t,p))<=200?t:null;
  }
  const t30=hSatTemp(30),t65=65;
  if(e30&&wb65&&t30!==null&&gr(ws(t65,p))<=200){
    const a=satAnchor(t30),b=satAnchor(t65);
    const off=SCALE_LABEL_OFFSET;
    const ax=a.x+a.nx*off, ay=a.y+a.ny*off+3;
    const bx=b.x+b.nx*off, by=b.y+b.ny*off+3;
    // Reserve room for both numerals by shifting along the saturation tangent,
    // never across their own ticks. Order comes from the actual intersections.
    const widthA=e30.getComputedTextLength()||12;
    const widthB=wb65.getComputedTextLength()||12;
    const required=(widthA+widthB)/2+4;
    const gap=Math.hypot(bx-ax,by-ay);
    const extra=Math.max(0,(required-gap)/2);
    const direction=t30<=t65?1:-1;
    e30.setAttribute('x',ax-direction*a.tx*extra);
    e30.setAttribute('y',ay-direction*a.ty*extra);
    wb65.setAttribute('x',bx+direction*b.tx*extra);
    wb65.setAttribute('y',by+direction*b.ty*extra);
    for(const n of [e30,wb65]){
      n.setAttribute('text-anchor','middle');
      n.setAttribute('stroke','#fff');
      n.setAttribute('stroke-width','2');
      n.setAttribute('paint-order','stroke');
    }
  }
}
// Re-anchor the 30 F wet-bulb label to the 30 F chart boundary.
// Earlier generic collision logic must never move it far away from its tick.
{
  const wb30=Array.from(bg.querySelectorAll('text')).find(node=>
    node.getAttribute('fill')===wet && (node.textContent||'').trim()==='30');
  if(wb30){
    const px=x(min)-SCALE_LABEL_OFFSET,py=y(gr(ws(min,p)))+3;
    wb30.setAttribute('x',px);
    wb30.setAttribute('y',py);
    wb30.setAttribute('text-anchor','middle');
    wb30.setAttribute('stroke','#fff');
    wb30.setAttribute('stroke-width','2');
    wb30.setAttribute('paint-order','stroke');
  }
}
let satPath='',started=false;for(let i=0;i<=1000;i++){let t=min+(max-min)*i/1000,g=gr(ws(t,p));if(g>200){let lo=t-(max-min)/1000,hi=t;for(let j=0;j<45;j++){const mid=(lo+hi)/2;if(gr(ws(mid,p))>200)hi=mid;else lo=mid}satPath+='L'+x((lo+hi)/2).toFixed(3)+' '+y(200).toFixed(3)+' ';break;}satPath+=(started?'L':'M')+x(t).toFixed(3)+' '+y(g).toFixed(3)+' ';started=true}add('path',{d:satPath,fill:'none',stroke:rhColor,'stroke-width':1,'stroke-linejoin':'round'},bg);add('line',{x1:L,y1:y(0),x2:W-R,y2:y(0),stroke:blue,'stroke-width':major},bg);add('line',{x1:L,y1:y(0),x2:L,y2:y(Math.min(200,gr(ws(min,p)))),stroke:blue,'stroke-width':major},bg);add('line',{x1:W-R,y1:y(0),x2:W-R,y2:y(200),stroke:blue,'stroke-width':major},bg);if(gr(ws(max,p))>=200){let lo=min,hi=max;for(let i=0;i<45;i++){let mid=(lo+hi)/2;if(gr(ws(mid,p))>200)hi=mid;else lo=mid}add('line',{x1:x((lo+hi)/2),y1:y(200),x2:x(max),y2:y(200),stroke:blue,'stroke-width':major},bg)}
// Overlay points in the SAME coordinate system as the background chart.
// Final label separation: keep WB and enthalpy numeric labels from overlapping.
// Move only green enthalpy labels tangentially, leaving their tick geometry intact.
{
  const wetLabels=Array.from(bg.querySelectorAll('text')).filter(n=>n.getAttribute('fill')===wet && /^\d+$/.test((n.textContent||'').trim()));
  const hLabels=Array.from(bg.querySelectorAll('text')).filter(n=>n.getAttribute('fill')===hColor && /^\d+$/.test((n.textContent||'').trim()));
  const box=n=>{const b=n.getBBox();return {x:b.x-3,y:b.y-3,w:b.width+6,h:b.height+6};};
  const overlap=(a,b)=>a.x<b.x+b.w && b.x<a.x+a.w && a.y<b.y+b.h && b.y<a.y+a.h;
  const occupied=wetLabels.map(box);
  for(const n of hLabels){
    const x0=Number(n.getAttribute('x')),y0=Number(n.getAttribute('y'));
    let ok=false;
    for(const dx of [0,-9,9,-18,18,-27,27,-36,36]){
      n.setAttribute('x',x0+dx);n.setAttribute('y',y0);
      const b=box(n);
      if(!occupied.some(other=>overlap(b,other))){occupied.push(b);ok=true;break;}
    }
    if(!ok){n.setAttribute('x',x0);n.setAttribute('y',y0);occupied.push(box(n));}
  }
}
// One invisible boundary shared by all wet-bulb and enthalpy numerals.
// The 30 F edge, saturation curve, and 200-grain ceiling are sampled in
// physical order. Only this final pass sets numeric-label positions.
{
  const scaleOffset=17; // Closer to the property ticks than the previous 25px.
  const boundary=[];
  const push=(px,py,nx,ny)=>boundary.push({x:px+nx*scaleOffset,y:py+ny*scaleOffset});
  const leftMax=Math.min(200,gr(ws(min,p)));
  for(let i=0;i<=32;i++)push(x(min),y(i*leftMax/32),-1,0);
  let end=min;
  for(let i=0;i<=850;i++){
    const t=min+(max-min)*i/850,g=gr(ws(t,p));
    if(g>200)break;
    const dx=x(t+.06)-x(t-.06),dy=y(gr(ws(t+.06,p)))-y(gr(ws(t-.06,p)));
    const len=Math.hypot(dx,dy)||1;
    push(x(t),y(g),dy/len,-dx/len);
    end=t;
  }
  if(gr(ws(max,p))>200){
    let lo=end,hi=max;
    for(let j=0;j<40;j++){const mid=(lo+hi)/2;if(gr(ws(mid,p))>200)hi=mid;else lo=mid;}
    const topT=(lo+hi)/2;
    for(let i=1;i<=100;i++)push(x(topT+(max-topT)*i/100),y(200),0,-1);
  }
  const cumulative=[0];
  for(let i=1;i<boundary.length;i++)cumulative.push(cumulative[i-1]+Math.hypot(boundary[i].x-boundary[i-1].x,boundary[i].y-boundary[i-1].y));
  const limit=cumulative[cumulative.length-1];
  const at=d=>{
    d=Math.max(0,Math.min(limit,d));
    let lo=0,hi=cumulative.length-1;
    while(lo+1<hi){const m=(lo+hi)>>1;if(cumulative[m]<d)lo=m;else hi=m;}
    const span=cumulative[hi]-cumulative[lo]||1,r=(d-cumulative[lo])/span;
    return {x:boundary[lo].x+(boundary[hi].x-boundary[lo].x)*r,y:boundary[lo].y+(boundary[hi].y-boundary[lo].y)*r};
  };
  const nearest=(px,py)=>{
    let best=0,d2=Infinity;
    for(let i=0;i<boundary.length;i++){
      const dd=(boundary[i].x-px)**2+(boundary[i].y-py)**2;
      if(dd<d2){d2=dd;best=i;}
    }
    return cumulative[best];
  };
  const satTempForH=h=>{
    if(h<enthalpy(min,ws(min,p))||h>enthalpy(max,ws(max,p)))return null;
    let lo=min,hi=max;
    for(let i=0;i<48;i++){const m=(lo+hi)/2;if(enthalpy(m,ws(m,p))<h)lo=m;else hi=m;}
    return (lo+hi)/2;
  };
  const anchorFor=(node)=>{
    const v=Number(node.textContent.trim());
    if(node.getAttribute('fill')===wet){
      if(v<min){
        const sw=ws(v,p);
        const w=v>=32?((1093-.556*v)*sw-1680*(min-v))/(1093+.444*min-v):((1220-.04*v)*sw-1680*(min-v))/(1220+.444*min-.48*v);
        return {x:x(min),y:y(Math.max(0,Math.min(200,gr(w))))};
      }
      if(gr(ws(v,p))<=200)return {x:x(v),y:y(gr(ws(v,p)))};
      // Wet-bulb line crossing the 200-grain ceiling.
      const sw=ws(v,p),fn=t=>v>=32?((1093-.556*v)*sw-1680*(t-v))/(1093+.444*t-v):((1220-.04*v)*sw-1680*(t-v))/(1220+.444*t-.48*v);
      let lo=v,hi=max;
      for(let i=0;i<44;i++){const m=(lo+hi)/2;if(gr(fn(m))>200)lo=m;else hi=m;}
      return {x:x((lo+hi)/2),y:y(200)};
    }
    const leftW=(v-.24*min)/(0.15157142857142858+.00006342857142857143*min),leftG=gr(leftW);
    if(leftG>=0&&leftG<=leftMax)return {x:x(min),y:y(leftG)};
    const t=satTempForH(v);
    if(t!==null&&gr(ws(t,p))<=200)return {x:x(t),y:y(gr(ws(t,p)))};
    const topW=200,topT=(v-0.15157142857142858*topW)/(.24+.00006342857142857143*topW);
    return {x:x(Math.max(min,Math.min(max,topT))),y:y(200)};
  };
  const numerals=Array.from(bg.querySelectorAll('text')).filter(node=>
    (node.getAttribute('fill')===wet||node.getAttribute('fill')===hColor)&&
    /^-?\d+(?:\.\d+)?$/.test((node.textContent||'').trim()));
  const entries=numerals.map(node=>({node,target:nearest(...Object.values(anchorFor(node)))})).sort((a,b)=>a.target-b.target);
  const box=node=>{const size=Number(node.getAttribute('font-size')||12);if(measure)measure.font=`${size}px Arial`;const width=measure?.measureText?measure.measureText(node.textContent).width:node.textContent.length*size*.65;return {x:Number(node.getAttribute('x'))-width/2-3,y:Number(node.getAttribute('y'))-size-3,w:width+6,h:size+6};};
  const collide=(a,b)=>a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y;
  const occupied=[];
  // Prefer the physical tick anchor. Search short tangent shifts in both
  // directions; do not drop labels or push them far from their own tick.
  for(const {node,target} of entries){
    node.removeAttribute('transform');
    node.setAttribute('text-anchor','middle');
    let chosen=null;
    for(let step=0;step<=Math.ceil(limit);step++){
      const delta=step===0?0:(step%2?1:-1)*Math.ceil(step/2)*2;
      const pt=at(target+delta);
      node.setAttribute('x',pt.x);node.setAttribute('y',pt.y+3);
      const b=box(node);
      if(b.x<2||b.y<2||b.x+b.w>W-2||b.y+b.h>H-2)continue;
      if(!occupied.some(o=>collide(o,b))){chosen=b;break;}
    }
    // Keep every label visible even when the local edge is extremely crowded.
    if(!chosen){
      const pt=at(target);
      node.setAttribute('x',Math.max(14,Math.min(W-14,pt.x)));
      node.setAttribute('y',Math.max(12,Math.min(H-12,pt.y+3)));
      chosen=box(node);
    }
    occupied.push(chosen);
  }
}
const chartEnd=vectorNodes.length;
const overlay=add('g',{'data-layer':'hvac-points'},chartContent);
for(const point of points){
  const temp=Number(point.dbF);
  let w;
  if(point.rhPct!=null)w=hum(temp,Number(point.rhPct)/100,p);
  else if(point.humidityRatioGrains!=null)w=Number(point.humidityRatioGrains);
  else if(point.humidityRatio!=null)w=Number(point.humidityRatio);
  else continue;
  const grains=gr(w);
  if(!Number.isFinite(temp)||!Number.isFinite(grains)||temp<min||temp>max||grains<0||grains>200||w>ws(temp,p)+1e-9)continue;
  const px=x(temp),py=y(grains),color=point.color||'#d12635';
  if(point.guideLines){
    add('line',{x1:px,y1:py,x2:px,y2:y(0),stroke:color,'stroke-width':1.2,'stroke-dasharray':'4 4'},overlay);
    add('line',{x1:px,y1:py,x2:W-R,y2:py,stroke:color,'stroke-width':1.2,'stroke-dasharray':'4 4'},overlay);
  }
  add('circle',{cx:px,cy:py,r:point.radius||6,fill:color,stroke:'white','stroke-width':2},overlay);
  if(point.label) add('text',{x:px+10,y:py-9,fill:color,'font-size':12,'font-weight':'700'},overlay,String(point.label));
}
add('text',{x:(L+W-R)/2,y:H-41,'text-anchor':'middle','font-size':12,'font-weight':'600',fill:'#334155'},bg,'DRY-BULB TEMPERATURE (°F)');let cy=(T+H-B)/2;add('text',{x:W-35,y:cy,transform:`rotate(-90 ${W-35} ${cy})`,'text-anchor':'middle','font-size':11,'font-weight':'600',fill:'#334155'},bg,'HUMIDITY-RATIO (GRAINS/LB DRY AIR)');
const muted=value=>{if(!/^#[0-9a-f]{6}$/i.test(value))return value;const c=[1,3,5].map(i=>parseInt(value.slice(i,i+2),16)),gray=.2126*c[0]+.7152*c[1]+.0722*c[2];return '#'+c.map(v=>Math.round(255+(gray+(v-gray)*.75-255)*.325).toString(16).padStart(2,'0')).join('');};
for(const [index,node]of vectorElements.entries()){const data=vectorNodes[index];for(const key of ['fill','stroke']){const value=data.attrs[key];if(!value||value==='none'||value==='white'||value==='#ffffff')continue;if(index<informationEnd&&index>2)node.setAttribute(key,'#000000');else if(index>=informationEnd)node.setAttribute(key,muted(value));}}
}
  draw();
  return {svg,elevationFt,points,vector:vectorNodes};
}
global.PsychrometricChart={render};
})(window);
