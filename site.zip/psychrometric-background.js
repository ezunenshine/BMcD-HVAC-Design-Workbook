/* BMcD psychrometric chart — standalone SVG renderer. No dependencies. */
(function(global){
'use strict';
let instanceCount=0;
function render({container,elevationFt=0,points=[]}={}){
  if(typeof container==='string')container=document.querySelector(container);
  if(!container)throw new Error('PsychrometricChart: container not found');
  elevationFt=Number(elevationFt);
  if(!Number.isFinite(elevationFt)||elevationFt< -1000||elevationFt>15000)throw new RangeError('Elevation must be between -1000 and 15000 ft');
  const NS='http://www.w3.org/2000/svg';
  let svg=container.tagName.toLowerCase()==='svg'?container:container.querySelector('svg[data-psychrometric-chart]');
  if(!svg){svg=document.createElementNS(NS,'svg');svg.setAttribute('data-psychrometric-chart','');container.appendChild(svg)}
  svg.setAttribute('viewBox','0 0 1100 750');
  svg.setAttribute('xmlns',NS);
  svg.setAttribute('role','img');
  svg.setAttribute('aria-label','Psychrometric chart');
  svg.style.width='100%';svg.style.height='auto';svg.style.display='block';
  const clipId='psych-valid-'+(++instanceCount);

const LOGO='BurnsMcDonnell_Stacked_Black_R.png';
const sat=t=>{const k=(t-32)*5/9+273.15;return Math.exp(k<273.16?(-5674.5359/k+6.3925247-.009677843*k+6.2215701e-7*k*k+2.0747825e-9*k**3-9.484024e-13*k**4+4.1635019*Math.log(k)):(-5800.2206/k+1.3914993-.048640239*k+4.1764768e-5*k*k-1.4452093e-8*k**3+6.5459673*Math.log(k)))/1000};
const pressure=z=>101.325*Math.pow(1-2.25577e-5*z*.3048,5.25588);const hum=(t,r,p)=>{let pv=Math.min(.999*p,sat(t)*r);return .621945*pv/(p-pv)};const ws=(t,p)=>hum(t,1,p);const gr=w=>w*7000;const enthalpy=(t,w)=>.24*t+w*(1061+.444*t);
const vectorNodes=[],vectorIndex=new WeakMap(),measure=document.createElement('canvas').getContext('2d');
const labelWidth=(text,font)=>{if(measure?.measureText){measure.font=`600 ${font}px Arial`;return measure.measureText(text).width+12;}return text.length*font*.62+12;};
const add=(tag,attrs={},parent=svg,txt)=>{let e=document.createElementNS(NS,tag);vectorIndex.set(e,vectorNodes.length);vectorNodes.push({tag,attrs,text:txt??'',parent:vectorIndex.get(parent)??-1});for(const [k,v] of Object.entries(attrs))e.setAttribute(k,v);if(txt!==undefined)e.textContent=txt;parent.appendChild(e);return e};
function draw(){const elev=elevationFt,max=120,p=pressure(elev),min=30,W=1100,H=750,L=125,R=82,T=65,B=85;const x=t=>L+(t-min)/(max-min)*(W-L-R),y=g=>H-B-g/200*(H-T-B);const blue='#59636e',wet='#dfa900',rhColor='#237fbd',major=1.7;svg.replaceChildren();add('rect',{width:W,height:H,fill:'white'});const bg=add('g',{'font-family':'Arial, sans-serif',opacity:.6});
const logo=add('image',{x:L,y:65,width:245,height:93,href:LOGO,preserveAspectRatio:'xMidYMid meet'},bg);add('text',{x:L,y:167,'text-anchor':'start','font-size':15,'font-weight':'700',fill:'#30465a'},bg,'PSYCHOMETRIC CHART');add('text',{x:L,y:188,'text-anchor':'start','font-size':12,'font-weight':'600',fill:'#30465a'},bg,`BAROMETRIC PRESSURE: ${(p*.145037738).toFixed(3)} PSIA`);add('text',{x:L,y:221,'text-anchor':'start','font-size':29,'font-weight':'700',fill:'#30465a'},bg,`ELEVATION: ${elev.toLocaleString()} FT`);
add('text',{x:L,y:251,'text-anchor':'start','font-size':15,'font-weight':'700',fill:'#30465a'},bg,'Qₜ = Qₛ + Qₗ');add('text',{x:L,y:276,'text-anchor':'start','font-size':13,fill:'#30465a'},bg,'Qₛ = Cₛ · V̇ · ΔT / 1000');add('text',{x:L,y:298,'text-anchor':'start','font-size':13,fill:'#30465a'},bg,'Qₗ = Cₗ · V̇ · (ΔW / 7000) / 1000');
add('text',{x:L,y:333,'text-anchor':'start','font-size':14,'font-weight':'700',fill:'#30465a'},bg,'MIXED AIR');
add('text',{x:L,y:357,'text-anchor':'start','font-size':13,fill:'#30465a'},bg,'ṁ = V̇ / v');
add('text',{x:L,y:379,'text-anchor':'start','font-size':13,fill:'#30465a'},bg,'Wₘ = (ṁ₁W₁ + ṁ₂W₂) / (ṁ₁ + ṁ₂)');
add('text',{x:L,y:401,'text-anchor':'start','font-size':13,fill:'#30465a'},bg,'hₘ = (ṁ₁h₁ + ṁ₂h₂) / (ṁ₁ + ṁ₂)');
const defs=add('defs'),clip=add('clipPath',{id:clipId},defs);let region=`M${x(min)} ${y(0)} L${x(max)} ${y(0)} L${x(max)} ${y(200)}`;for(let i=600;i>=0;i--){let t=min+(max-min)*i/600;region+=` L${x(t)} ${y(Math.min(200,gr(ws(t,p))))}`}region+=' Z';add('path',{d:region},clip);const grid=add('g',{'clip-path':`url(#${clipId})`},bg);
for(let t=min;t<=max;t++){let m=t%5===0;add('line',{x1:x(t),x2:x(t),y1:y(0),y2:y(200),stroke:m?blue:'#9ca5ae','stroke-width':m?major:.4},grid);add('line',{x1:x(t),x2:x(t),y1:y(0),y2:y(0)+(m?10:4),stroke:blue,'stroke-width':m?major:.5},bg);if(m)add('text',{x:x(t),y:y(0)+24,'text-anchor':'middle','font-size':10,fill:blue},bg,String(t))}
for(let g=0;g<=200;g+=2){let m=g%10===0;add('line',{x1:L,x2:W-R,y1:y(g),y2:y(g),stroke:m?blue:'#9ca5ae','stroke-width':m?major:.4},grid);add('line',{x1:W-R,x2:W-R+(m?10:4),y1:y(g),y2:y(g),stroke:blue,'stroke-width':m?major:.5},bg);if(m)add('text',{x:W-R+16,y:y(g)+3,'font-size':10,fill:blue},bg,String(g))}
function curve(fn,color,width=1,a=min,b=max){let d='',on=false;for(let i=0;i<=700;i++){let t=a+(b-a)*i/700,g=gr(fn(t));let valid=Number.isFinite(g)&&g>=0&&g<=200&&g<=gr(ws(t,p))+1e-6;if(valid){d+=(on?'L':'M')+x(t).toFixed(2)+' '+y(g).toFixed(2)+' ';on=true}else on=false}add('path',{d,stroke:color,'stroke-width':width,fill:'none'},grid)}
for(let pct=10;pct<=90;pct+=10){let r=pct/100;curve(t=>hum(t,r,p),rhColor,1);let valid=[];for(let i=0;i<=500;i++){let t=min+(max-min)*i/500,g=gr(hum(t,r,p));if(g>=3&&g<=195)valid.push(t)}if(valid.length){let text=pct===10?'10% RELATIVE HUMIDITY':pct+'%',font=pct===10?9:10,width=labelWidth(text,font),t=valid[Math.floor((valid.length-1)*.95)];t=Math.min(t,max-(width*.56+9)/(W-L-R)*(max-min));let gg=gr(hum(t,r,p)),d=.15,angle=Math.atan2(y(gr(hum(t+d,r,p)))-y(gr(hum(t-d,r,p))),x(t+d)-x(t-d))*180/Math.PI;let group=add('g',{transform:`translate(${x(t)} ${y(gg)}) rotate(${angle})`},bg);add('rect',{x:-width/2,y:-font-1,width,height:font+6,fill:'white'},group);add('text',{x:0,y:1,'text-anchor':'middle','font-size':font,'font-weight':'600',fill:rhColor},group,text)}}
for(let tw=-50;tw<=max;tw++){
 const sw=ws(tw,p),g=gr(sw),m=tw%5===0,fn=t=>tw>=32?((1093-.556*tw)*sw-.24*(t-tw))/(1093+.444*t-tw):((1220-.04*tw)*sw-.24*(t-tw))/(1220+.444*t-.48*tw);
 curve(t=>t<tw?NaN:fn(t),wet,m?1.15:.32,Math.max(min,tw),max);
 let tx,ty,nx,ny;
 if(tw<min){const initial=gr(fn(min));if(initial>=0&&initial<=gr(ws(min,p))){tx=x(min);ty=y(initial);nx=-1;ny=0;}}
 else if(g<=200){const d=.12,dx=x(tw+d)-x(tw-d),dy=y(gr(ws(tw+d,p)))-y(gr(ws(tw-d,p))),len=Math.hypot(dx,dy)||1;tx=x(tw);ty=y(g);nx=dy/len;ny=-dx/len;if(nx>0){nx=-nx;ny=-ny}}
 else if(gr(fn(max))<=200){let lo=tw,hi=max;for(let i=0;i<45;i++){let t=(lo+hi)/2;if(gr(fn(t))>200)lo=t;else hi=t}const t=(lo+hi)/2;tx=x(t);ty=y(200);nx=0;ny=-1;add('line',{x1:tx,y1:ty,x2:x(t+.2),y2:y(gr(fn(t+.2))),stroke:wet,'stroke-width':m?1.15:.32},bg);}
 if(tx!==undefined){add('line',{x1:tx,y1:ty,x2:tx+nx*(m?11:5),y2:ty+ny*(m?11:5),stroke:wet,'stroke-width':m?1.3:.6},bg);if(m)add('text',{x:tx+nx*24,y:ty+ny*24+3,'text-anchor':'middle','font-size':9,fill:wet},bg,String(tw));}
}
const lt=77.5,lg=gr(ws(lt,p));if(lg<=200){let d=.15,dx=x(lt+d)-x(lt-d),dy=y(gr(ws(lt+d,p)))-y(gr(ws(lt-d,p))),len=Math.hypot(dx,dy)||1,nx=dy/len,ny=-dx/len;if(nx>0){nx=-nx;ny=-ny}let tx=x(lt)+nx*36,ty=y(lg)+ny*36,angle=Math.atan2(dy,dx)*180/Math.PI;add('text',{x:tx,y:ty,transform:`rotate(${angle} ${tx} ${ty})`,'text-anchor':'middle','font-size':10,'font-weight':'600',fill:wet},bg,'WET-BULB TEMPERATURE (°F)')}
let satPath='',started=false;for(let i=0;i<=1000;i++){let t=min+(max-min)*i/1000,g=gr(ws(t,p));if(g>200){let lo=t-(max-min)/1000,hi=t;for(let j=0;j<45;j++){const mid=(lo+hi)/2;if(gr(ws(mid,p))>200)hi=mid;else lo=mid}satPath+='L'+x((lo+hi)/2).toFixed(3)+' '+y(200).toFixed(3)+' ';break;}satPath+=(started?'L':'M')+x(t).toFixed(3)+' '+y(g).toFixed(3)+' ';started=true}add('path',{d:satPath,fill:'none',stroke:blue,'stroke-width':major,'stroke-linejoin':'round'},bg);add('line',{x1:L,y1:y(0),x2:W-R,y2:y(0),stroke:blue,'stroke-width':major},bg);add('line',{x1:L,y1:y(0),x2:L,y2:y(Math.min(200,gr(ws(min,p)))),stroke:blue,'stroke-width':major},bg);add('line',{x1:W-R,y1:y(0),x2:W-R,y2:y(200),stroke:blue,'stroke-width':major},bg);if(gr(ws(max,p))>=200){let lo=min,hi=max;for(let i=0;i<45;i++){let mid=(lo+hi)/2;if(gr(ws(mid,p))>200)hi=mid;else lo=mid}add('line',{x1:x((lo+hi)/2),y1:y(200),x2:x(max),y2:y(200),stroke:blue,'stroke-width':major},bg)}
// Overlay points in the SAME coordinate system as the background chart.
const overlay=add('g',{'data-layer':'hvac-points'});
for(const point of points){
  const temp=Number(point.dbF);
  let w;
  if(point.rhPct!=null)w=hum(temp,Number(point.rhPct)/100,p);
  else if(point.humidityRatioGrains!=null)w=Number(point.humidityRatioGrains)/7000;
  else if(point.humidityRatio!=null)w=Number(point.humidityRatio);
  else continue;
  const grains=gr(w);
  if(!Number.isFinite(temp)||!Number.isFinite(grains)||temp<min||temp>max||grains<0||grains>200||w>ws(temp,p)+1e-9)continue;
  const px=x(temp),py=y(grains),color=point.color||'#d12635';
  if(point.guideLines){
    add('line',{x1:px,y1:py,x2:px,y2:y(0),stroke:color,'stroke-width':1.2,'stroke-dasharray':'4 4'},overlay);
    add('line',{x1:px,y1:py,x2:W-R,y2:py,stroke:color,'stroke-width':1.2,'stroke-dasharray':'4 4'},overlay);
  }
  add('circle',{cx:px,cy:py,r:point.radius||6,fill:color,stroke:'white','stroke-width':2},overlay);
  if(point.label) add('text',{x:px+10,y:py-9,fill:color,'font-size':12,'font-weight':'700'},overlay,String(point.label));
}
add('text',{x:(L+W-R)/2,y:H-41,'text-anchor':'middle','font-size':12,'font-weight':'600',fill:'#334155'},bg,'DRY-BULB TEMPERATURE (°F)');let cy=(T+H-B)/2;add('text',{x:W-35,y:cy,transform:`rotate(-90 ${W-35} ${cy})`,'text-anchor':'middle','font-size':11,'font-weight':'600',fill:'#334155'},bg,'HUMIDITY RATIO (GRAINS/LB DRY AIR)');
}
  draw();
  return {svg,elevationFt,points,vector:vectorNodes};
}
global.PsychrometricChart={render};
})(window);
