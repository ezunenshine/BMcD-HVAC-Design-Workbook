/* Browser project storage. Legacy localStorage is retained as migration recovery.
   Each IndexedDB commit atomically saves changed projects and their previous revision. */
class WorkbookProjectStore {
 constructor(adapter=null){this.adapter=adapter;this.records=new Map();this.persisted=new Map();this.dirty=new Set();this.pending=new Map();this.running=null;this.error=null;this.mode='local';this.loaded=false;}
 async open(){
  let legacy=[];try{const raw=localStorage.getItem('hvac-projects-v1');if(raw){legacy=JSON.parse(raw);if(!Array.isArray(legacy))throw Error('Invalid legacy project catalog.');}}catch(error){this.report(error);throw error;}
  this.records=new Map(legacy.map(p=>[p.id,JSON.stringify(p)]));
  if(!this.adapter&&typeof indexedDB!=='undefined')try{this.adapter=await workbookIndexedDB();}catch(error){this.report(error);}
  if(this.adapter){try{const saved=await this.adapter.read();const by=new Map(saved.map(p=>[p.id,p]));const missing=legacy.filter(p=>!by.has(p.id));if(missing.length){await this.adapter.write(missing,legacy);const verified=await this.adapter.read();for(const p of missing)if(!verified.some(v=>v.id===p.id))throw Error('Project migration could not be verified; original local data is retained.');by.clear();for(const p of verified)by.set(p.id,p);}this.records=new Map([...by].map(([id,p])=>[id,JSON.stringify(p)]));this.mode='indexeddb';}catch(error){this.report(error);throw error;}}
  else this.records=new Map(legacy.map(p=>[p.id,JSON.stringify(p)]));
  this.persisted=new Map(this.records);this.loaded=true;return this.catalog();
 }
 catalog(){return [...this.records.values()].map(s=>JSON.parse(s));}
 snapshot(){return '['+[...this.records.values()].join(',')+']';}
 save(catalog){
  for(const p of catalog){const json=JSON.stringify(p);if(this.records.get(p.id)!==json){this.records.set(p.id,json);this.pending.set(p.id,json);this.dirty.add(p.id);}}
  if(this.mode==='local'){try{localStorage.setItem('hvac-projects-v1',this.snapshot());this.pending.clear();this.dirty.clear();this.report(null);}catch(error){this.report(error);}return Promise.resolve(!this.error);}
  if(!this.running)this.running=Promise.resolve().then(()=>this.drain());return this.running;
 }
 async drain(){
  try{while(this.pending.size){const batch=new Map(this.pending);await this.adapter.write([...batch.values()].map(s=>JSON.parse(s)),undefined,new Map(this.persisted));for(const [id,json]of batch)this.persisted.set(id,json);for(const [id,json]of batch)if(this.pending.get(id)===json){this.pending.delete(id);this.dirty.delete(id);}try{localStorage.setItem('hvac-projects-revision',String(Date.now())+':'+Math.random());}catch{} }this.report(null);return true;}
  catch(error){this.report(error);return false;}finally{this.running=null;}
 }
 async reload(){if(this.mode==='indexeddb'){try{for(const p of await this.adapter.read())if(!this.dirty.has(p.id)){this.records.set(p.id,JSON.stringify(p));this.persisted.set(p.id,JSON.stringify(p));}}catch(error){this.report(error);}}else{try{const saved=JSON.parse(localStorage.getItem('hvac-projects-v1')||'[]');for(const p of saved)if(!this.dirty.has(p.id)){this.records.set(p.id,JSON.stringify(p));this.persisted.set(p.id,JSON.stringify(p));}}catch(error){this.report(error);}}return this.catalog();}
 report(error){this.error=error;if(typeof document!=='undefined')workbookStorageNotice(error,this);}
}
async function workbookIndexedDB(){
 const db=await new Promise((resolve,reject)=>{const request=indexedDB.open('hvac-workbook-projects',1);request.onupgradeneeded=()=>{for(const name of ['projects','recovery'])if(!request.result.objectStoreNames.contains(name))request.result.createObjectStore(name,{keyPath:'id'});};request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error);request.onblocked=()=>reject(Error('Project storage is blocked by another window. Close older workbook windows and retry.'));});
 const transaction=(mode,run)=>new Promise((resolve,reject)=>{const tx=db.transaction(['projects','recovery'],mode);let result;try{run(tx,value=>{result=value;});}catch(error){tx.abort();reject(error);return;}tx.oncomplete=()=>resolve(result);tx.onerror=()=>reject(tx.error||Error('Project storage failed.'));tx.onabort=()=>reject(tx.error||Error('Project save was cancelled or this project changed in another window. Download recovery before reloading.'));});
 return {read:()=>transaction('readonly',(tx,done)=>{const request=tx.objectStore('projects').getAll();request.onsuccess=()=>done(request.result);}),write:(projects,legacy,expected)=>transaction('readwrite',tx=>{const store=tx.objectStore('projects'),recovery=tx.objectStore('recovery');if(legacy)recovery.put({id:'legacy-migration',projects:legacy,at:new Date().toISOString()});for(const project of projects){const get=store.get(project.id);get.onsuccess=()=>{if(legacy&&get.result)return;if(expected&&JSON.stringify(get.result)!==expected.get(project.id)){tx.abort();return;}if(get.result)recovery.put({id:project.id,project:get.result,at:new Date().toISOString()});store.put(project);};}})};
}
function workbookStorageNotice(error,store){
 if(!document.body)return;let banner=document.querySelector('#project-save-error');if(!error){banner?.remove();return;}
 if(!banner){banner=document.createElement('div');banner.id='project-save-error';banner.setAttribute('role','alert');document.body.appendChild(banner);}banner.replaceChildren();
 const text=document.createElement('span');text.textContent='Project save failed. Keep this window open; current changes remain in memory. Download recovery before closing. '+error.message;
 const download=document.createElement('button');download.type='button';download.textContent='Download recovery';download.onclick=()=>{const data=typeof projects!=='undefined'&&projects.length?projects:store.catalog();downloadWorkbookFile(new Blob([JSON.stringify({format:'hvac-project-recovery-v1',projects:data},null,2)],{type:'application/json'}),'HVAC-project-recovery.json');};
 const retry=document.createElement('button');retry.type='button';retry.textContent='Retry save';retry.onclick=()=>store.loaded?store.save(typeof projects!=='undefined'?projects:store.catalog()):startStoredWorkbook();banner.append(text,download,retry);
}
const workbookStorage=new WorkbookProjectStore();
if(typeof window!=='undefined')window.addEventListener?.('beforeunload',event=>{if(workbookStorage.dirty.size){event.preventDefault();event.returnValue='';}});
async function importWorkbookRecovery(file){
 const data=JSON.parse(await file.text());if(data.format!=='hvac-project-recovery-v1'||!Array.isArray(data.projects)||!data.projects.length||data.projects.some(p=>!p||typeof p.id!=='string'||!p.independentTables||typeof p.independentTables!=='object'))throw Error('This is not a workbook project recovery file.');
 // Restore as separate projects; never replace an existing saved project.
 for(const source of data.projects){const p=structuredClone(source);p.id=createProjectId();p.number=String(p.number||'Recovered')+' (recovered '+new Date().toISOString()+')';projects.push(p);}await workbookStorage.save(projects);renderProjectList();
}
