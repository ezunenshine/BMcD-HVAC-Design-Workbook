/* v3.184 application changes. Stored humidity ratios remain lb/lb dry air.
 * Conversion to/from gr/lb happens once, at the input/display/export boundary.
 * Appended storage columns and explicit display order preserve existing keys. */
const APPENDIX_D_REFERENCE='ASHRAE 62.1-2016 - Appendix D.';
function workbookTable(id){return independentTables.find(t=>t.id===id);}
function presentNumber(x){return x!==''&&x!=null&&x!=='-'&&Number.isFinite(Number(x));}
function moistAirEnthalpy(db,w){return presentNumber(db)&&presentNumber(w)&&Number(w)>=0?.240*Number(db)+Number(w)*(1061+.444*Number(db)):'';}
function moistAirVolume(db,w,p){return presentNumber(db)&&presentNumber(w)&&presentNumber(p)&&Number(p)>0&&Number(w)>=0?.370486*(Number(db)+459.67)*(1+1.607858*Number(w))/Number(p):'';}
function dryBulbFromHW(h,w){return presentNumber(h)&&presentNumber(w)&&Number(w)>=0?(Number(h)-1061*Number(w))/(.240+.444*Number(w)):'';}
function massWeightedAir(streams,pressure){
 if(!presentNumber(pressure)||Number(pressure)<=0)throw Error("A positive project barometric pressure is required for mixing.");
 let mass=0,w=0,h=0;
 for(const s of streams){
  if(!presentNumber(s.flow)||Number(s.flow)<0)throw Error('Airflow must be a nonnegative number.');
  if(Number(s.flow)===0)continue;
  const v=s.v??moistAirVolume(s.db,s.w,pressure),enthalpy=s.h??moistAirEnthalpy(s.db,s.w);
  if(!presentNumber(v)||Number(v)<=0||!presentNumber(enthalpy)||!presentNumber(s.w)||Number(s.w)<0)throw Error('An active airstream has missing or invalid dry-bulb, humidity ratio, enthalpy, or specific volume.');
  const m=Number(s.flow)/Number(v);mass+=m;w+=m*Number(s.w);h+=m*Number(enthalpy);
 }
 if(!(mass>0))throw Error('No positive dry-air mass flow is available for mixing.');
 w/=mass;h/=mass;const db=dryBulbFromHW(h,w),v=moistAirVolume(db,w,pressure),wb=wetBulbFromState(db,w,pressure);if(!presentNumber(v)||Number(v)<=0||!presentNumber(wb))throw Error("The mixed state is outside the valid psychrometric range.");return {db,w,h,v,wb,mass};
}
function scheduleNumber(value,which=0){
 if(value==null||String(value).trim()==='')return '';
 if(presentNumber(value))return which===0?Number(value):'';
 const text=String(value).replace(/^Two-value\s*:\s*/i,''),fields=text.split(';');
 if(which===1&&fields.length>1){const second=fields[1].trim().match(/^[-+]?(?:\d+\.?\d*|\.\d+)(?:e[-+]?\d+)?/i);return second?Number(second[0]):'';}
 const values=text.match(/[-+]?(?:\d+\.?\d*|\.\d+)(?:e[-+]?\d+)?/gi)||[];
 return values[which]===undefined?'':Number(values[which]);
}
function appendWorkbookColumn(table,header,name){
 const c=table.headers.length;table.headers.push(header);table.columns.push(name||header.label);table.columnTypes.push('number');
 for(const r of [...table.rows,...Object.values(table.sourceRows||{})])while(r.length<=c)r.push('');return c;
}
function configureWorkbookRelease(){
 // Several legacy coil views share schema arrays. Isolate them before appending
 // room-only fields so the ventilation and other coil schemas stay unchanged.
 for(const table of independentTables){for(const [key,value]of Object.entries(table))if(Array.isArray(value))table[key]=value.map(item=>Array.isArray(item)?[...item]:item&&typeof item==='object'?{...item}:item);for(const key of ['headerClasses','headerLinks','displayEquations','formulaColumnAliases'])if(table[key])table[key]={...table[key]};}

 const sp=workbookTable('calc-space-condition-setpoints');
 for(const [c,label]of [[3,'Dry-Bulb Setpoint'],[4,'Dry-Bulb Setback'],[5,'Hum-Ratio'],[8,'Dry-Bulb Setpoint'],[9,'Dry-Bulb Setback'],[10,'Hum-Ratio']])sp.headers[c].label=label;
 for(const [side,color]of [['Heating','heating-load-header'],['Cooling','sensible-cooling-header']]){
  for(const [label,unit]of [['Enthalpy','Btu/lb'],['Specific Volume','ft³/lb']]){const c=appendWorkbookColumn(sp,{label,unit},side+' '+label);sp.calculatedColumns.push(c);sp.headerClasses[c]=color;}
 }
 sp.displayColumnOrder=[0,1,2,3,4,5,12,13,6,7,8,9,10,14,15,11];
 sp.headerGroups=[{label:'General',columns:[0,1,2],start:0,span:3},{label:'Heating',columns:[3,4,5,12,13,6],start:3,span:6,className:'heating-load-header'},{label:'Cooling',columns:[7,8,9,10,14,15,11],start:7,span:7,className:'sensible-cooling-header'}];
 sp.autoColumns=[6,11];sp.conditionalCalculatedColumns={};
 Object.assign(sp.formulaColumnAliases,{'Heating Dry-Bulb Setpoint':3,'Heating Dry-Bulb Setback':4,'Heating Hum-Ratio':5,'Cooling Dry-Bulb Setpoint':8,'Cooling Dry-Bulb Setback':9,'Cooling Hum-Ratio':10,'Heating Enthalpy':12,'Heating Specific Volume':13,'Cooling Enthalpy':14,'Cooling Specific Volume':15});
 const imp='[Imported IESVE Space Data]',lookup=field=>`XLOOKUP(@Space,${imp}@[Space Name],${imp}@[${field}],"")`;
 Object.assign(sp.displayEquations,{2:`=LET(rh,${lookup('% Saturation Upper Limit')},IF(rh="","",rh/100))`,3:`=SCHEDULEFIRST(${lookup('Heating Setpoint')})`,4:`=SCHEDULESECOND(${lookup('Heating Setpoint')})`,8:`=IF(@Ventilated Temperature Rise<>"",[Model Inputs]@Cooling Design Dry-Bulb+@Ventilated Temperature Rise,SCHEDULEFIRST(${lookup('Cooling Setpoint')}))`,9:`=IF(@Ventilated Temperature Rise<>"","",SCHEDULESECOND(${lookup('Cooling Setpoint')}))`,5:'=HUMIDITY_RATIO(@Heating Dry-Bulb Setpoint,@Relative Humidity,[Model Inputs]@Barometric Pressure)',10:'=HUMIDITY_RATIO(@Cooling Dry-Bulb Setpoint,@Relative Humidity,[Model Inputs]@Barometric Pressure)',12:'=0.240*@Heating Dry-Bulb Setpoint+@Heating Hum-Ratio*(1061+0.444*@Heating Dry-Bulb Setpoint)',13:'=0.370486*(@Heating Dry-Bulb Setpoint+459.67)*(1+1.607858*@Heating Hum-Ratio)/[Model Inputs]@Barometric Pressure',14:'=0.240*@Cooling Dry-Bulb Setpoint+@Cooling Hum-Ratio*(1061+0.444*@Cooling Dry-Bulb Setpoint)',15:'=0.370486*(@Cooling Dry-Bulb Setpoint+459.67)*(1+1.607858*@Cooling Hum-Ratio)/[Model Inputs]@Barometric Pressure'});
 for(const [column,required]of [[5,['Heating Dry-Bulb Setpoint','Relative Humidity']],[10,['Cooling Dry-Bulb Setpoint','Relative Humidity']],[12,['Heating Dry-Bulb Setpoint','Heating Hum-Ratio']],[13,['Heating Dry-Bulb Setpoint','Heating Hum-Ratio']],[14,['Cooling Dry-Bulb Setpoint','Cooling Hum-Ratio']],[15,['Cooling Dry-Bulb Setpoint','Cooling Hum-Ratio']]])sp.displayEquations[column]='=IF(OR('+[...required.map(name=>'@'+name+'=""'),'[Model Inputs]@Barometric Pressure=""'].join(',')+'),"",'+sp.displayEquations[column].slice(1)+')';
 for(const c of [2,3,4,8,9])delete sp.displayEquations[c];sp.conditionalCalculatedColumns={8:{whenColumn:7}};sp.displayEquations[8]='=[Model Inputs]@Cooling Design Dry-Bulb+@Ventilated Temperature Rise';
 const rawHeaders=[{label:'Space Name'},{label:'% Saturation Upper Limit'},{label:'Heating Setpoint'},{label:'Cooling Setpoint'}];
 independentTables.push({id:'iesve-imported-space-data',name:'Imported IESVE Space Data',standard:'Imported IESVE Space Data',headers:rawHeaders,columns:rawHeaders.map(h=>h.label),rows:[],columnTypes:['text','number','text','text'],calculatedColumns:[0,1,2,3],fixedRows:true,importedTabularSource:true,spaceColumn:0});
 const misc=workbookTable('calc-misc-gains');misc.calculatedColumns=misc.calculatedColumns.filter(c=>c!==3);misc.autoColumns=[...new Set([...(misc.autoColumns||[]),3])];misc.headers[3].calculated=false;
 const thermal=workbookTable('iesve-thermal-template');thermal.headers[0].label='Thermal Template';thermal.columns[0]='Thermal Template';thermal.formulaColumnAliases={...thermal.formulaColumnAliases,'Space Type':0,'Thermal Template':0,Type:0};thermal.equations[1]=thermal.displayEquations[1]='=COUNTIF([Space Condition Setpoints]@Thermal Template,@Thermal Template)';thermal.headers[1].calculated=true;thermal.frozenColumns=2;
 appendWorkbookColumn(thermal,{label:'Metabolic Rate',unit:'met'});thermal.displayColumnOrder=[0,1,2,3,4,5,6,7,8,14,9,10,11,12,13];thermal.calculatedColumns.push(14);thermal.autoColumns=thermal.autoColumns.filter(c=>c!==14);delete thermal.headerLinks[14];thermal.displayEquations[14]='=XLOOKUP(@Location - Degree of Activity,[Occupant Heat Gain]@Location - Degree of Activity,[Occupant Heat Gain]@Metabolic Rate,"")';
 const people=workbookTable('ashrae-fundamentals-people-heat');appendWorkbookColumn(people,{label:'Metabolic Rate',unit:'met'});people.autoColumns=[4];people.displayColumnOrder=[0,1,2,4,3];people.oneDecimalColumns=[4];people.displayEquations={};people.fixedReferences=[...new Set([...(people.fixedReferences||[]),APPENDIX_D_REFERENCE,'MET values are project engineering assumptions; they are not tabulated ASHRAE heat-gain values.'])];INDEPENDENT_REFERENCE_TEXT[people.id]=[...people.fixedReferences];
 for(const id of ['selected-misc-loads','selected-general-exhaust','selected-exhaust-equipment','selected-transfer-air'])workbookTable(id).summaryColumns=[];
 configureCo2Monitoring();
 const ventRequirements=workbookTable("calc-ventilation-exhaust");for(const c of [10,12])ventRequirements.displayEquations[c]='=IF(@Space Type="No Ventilation Requirements","-",'+ventRequirements.displayEquations[c].slice(1)+')';
 const settings=workbookTable('airside-settings');settings.headers[10].label=settings.columns[10]='Economizer';settings.dropdownColumns[10]={options:['TRUE']};settings.formulaColumnAliases={...settings.formulaColumnAliases,Energy:10,Economizer:10};
 const econ=workbookTable('calc-ahu-economizing-air-balance');econ.hiddenColumns=[...new Set([...(econ.hiddenColumns||[]),econ.balanceFields.indexOf('requiredVentilation')])];
 const af=workbookTable('airside-airflows');
 for(const g of af.headerGroups)if(g.label==='Exhaust'){g.className='exhaust-header';for(const c of groupColumns(g))af.headerClasses[c]='exhaust-header';}
 for(let i=0;i<3;i++){const c=appendWorkbookColumn(af,{...af.headers[7+i]},'Ventilation '+af.headers[7+i].label);af.headerClasses[c]='ventilation-header';af.headerLinks[c]='calc-ventilation-exhaust';af.zeroDecimalColumns.push(c);if(i===0)af.autoColumns.push(c);else af.calculatedColumns.push(c);af.displayEquations[c]=i===2?'=0':`=SUMIF([ASHRAE 62.1 Ventilation Requirements]@Ventilation Equipment,@Equipment,[ASHRAE 62.1 Ventilation Requirements]@Vot)*XLOOKUP(@Equipment,[Settings]@Equipment,[Settings]@Load Percentage,1)`;}
 af.displayColumnOrder=[0,1,2,3,4,5,6,16,17,18,7,8,9,10,11,12,13,14,15];af.headerGroups.splice(af.headerGroups.findIndex(g=>g.label==='Relief'),0,{label:'Ventilation',start:16,span:3,columns:[16,17,18],className:'ventilation-header'});af.sectionStartColumns.push(16);
 configureMixedAirTable();
 for(const id of ['airside-room-cooling','airside-room-heating']){const t=workbookTable(id),db=id.includes('cooling')?33:11,hr=db+1,c=appendWorkbookColumn(t,{label:'Enthalpy',unit:'Btu/lb'},'Entering Enthalpy');t.calculatedColumns.push(c);t.headerClasses[c]=t.headerClasses[db];t.formulaColumnAliases['Entering Enthalpy']=c;t.sectionStartColumns=t.sectionStartColumns.map(i=>i===db?hr:i);t.headerLinks={...t.headerLinks,[hr]:'calc-space-condition-setpoints',[c]:'calc-space-condition-setpoints',[db]:'calc-space-condition-setpoints'};t.displayColumnOrder=Array.from({length:c},(_,i)=>i).filter(i=>i!==db&&i!==hr);const at=t.displayColumnOrder.findIndex(i=>i===db+2);t.displayColumnOrder.splice(at,0,hr,c,db);for(const g of t.headerGroups){g.columns=groupColumns(g);if(g.columns.includes(db)){g.columns=g.columns.filter(i=>i!==db&&i!==hr);g.columns.unshift(hr,c,db);if(g.start===db)g.start=hr;g.span=g.columns.length;}}t.displayEquations[c]=roomMassFormula(id.includes('cooling'),'h');t.displayEquations[hr]=roomMassFormula(id.includes('cooling'),'w');t.displayEquations[db]=`=(@Entering Enthalpy-1061*@Entering HR)/(0.240+0.444*@Entering HR)`;}
 const vent=workbookTable('airside-ventilation-cooling');
 for(const [c,field,side]of [[15,'DB','Cooling'],[16,'HR','Cooling'],[24,'DB','Dehumidification'],[25,'HR','Dehumidification']])vent.displayEquations[c]=`=IF(XLOOKUP(@Equipment,[Settings]@Equipment,[Settings]@Economizer,"")="TRUE",XLOOKUP(@Equipment,[Mixed-Air]@Equipment,[Mixed-Air]@${side} Mixed ${field},"INVALID"),[Model Inputs]@${side} Design ${field==='DB'?'Dry-Bulb':'Hum-Ratio'})`; for(const g of vent.headerGroups)g.label=g.label.replace('Dehum Mode','Dehumidification Mode');
 for(const t of independentTables){
  for(let c=0;c<t.headers.length;c++){const h=t.headers[c];if(h.unit==='lb/lb'){h.storageUnit='lb/lb';h.unit='gr/lb';t.oneDecimalColumns=[...new Set([...(t.oneDecimalColumns||[]),c])];for(const key of ['zeroDecimalColumns','threeDecimalColumns','fourDecimalColumns','fiveDecimalColumns','decimalColumns'])if(t[key])t[key]=t[key].filter(i=>i!==c);}if(h.label==='Enthalpy')t.zeroDecimalColumns=[...new Set([...(t.zeroDecimalColumns||[]),c])];if(h.label==='Specific Volume')t.oneDecimalColumns=[...new Set([...(t.oneDecimalColumns||[]),c])];}
  for(const field of ['displayEquations','equations'])for(const [c,formula]of Object.entries(t[field]||{}))t[field][c]=formula.replaceAll('[Settings]@Energy','[Settings]@Economizer').replaceAll('="Econ"','="TRUE"');
 }
 for(const group of modules)for(const item of group.items||[])if(item[3]==='calc-co2-monitoring')item[0]='CO₂ Monitoring';
}
function activityMET(name){const s=requirementKey(name);if(/bowling|moderate dancing/.test(s))return 3.5;if(/department store|drug store|bank/.test(s))return 1.6;if(/heavy machine|lifting/.test(s))return 4;if(/heavy work/.test(s))return 3.8;if(/light bench/.test(s))return 2.2;if(/walking 3 mph|light machine/.test(s))return 3.8;if(/athletics|gymnasium/.test(s))return 5;if(/moderately active office/.test(s))return 1.3;if(/very light|sedentary|restaurant/.test(s))return 1.2;if(/theater/.test(s))return 1;return '';}
function importedSetpointRows(project){const imp=project.clipboardImports?.['iesve-tabular-space-data'];if(!imp)return [];return (imp.rawRows||[]).map(r=>{const headers=imp.rawHeaders.map(normalizedTabularHeader),at=pattern=>r[headers.findIndex(h=>pattern.test(h))]??'';return [at(/^(space|room) name$/),at(/^(saturation upper limit|relative humidity)( percent)?$/),at(/^heating setpoint( f| degf)?$/),at(/^cooling setpoint( f| degf)?$/)];});}
function setpointDefaults(project,row){const meta=tabularMetadata(project,row[0])||{},rise=row[7],v={2:meta.relativeHumidity??'',3:meta.heatingSetpoint??'',4:meta.heatingSetback??'',8:meta.coolingSetpoint??'',9:meta.coolingSetback??''};if(rise!==''&&rise!=null){v[8]=presentNumber(project.modelInputs?.coolingDb)&&presentNumber(rise)?Number(project.modelInputs.coolingDb)+Number(rise):'';v[9]='';}return v;}
function releaseProjectRows(project,table){
 project.release184Migrations||={};const first=!project.release184Migrations[table.id];let rows=project.independentTables[table.id];
 if(first){
  if(table.id==='calc-co2-monitoring'&&rows)project.independentTables[table.id]=rows=rows.map(r=>[r[0],...Array(12).fill('')]);
  if(['calc-space-condition-setpoints','iesve-thermal-template','ashrae-fundamentals-people-heat','airside-room-cooling','airside-room-heating','airside-airflows'].includes(table.id))for(const r of rows||[])while(r.length<table.headers.length)r.push('');
  if(table.id==='calc-space-condition-setpoints'&&rows){project.setpointOverrides||={};for(const r of rows){const defaults=setpointDefaults(project,r);for(const [c,v]of Object.entries(defaults))if(r[c]!==''&&r[c]!=null&&String(r[c])!==String(v))project.setpointOverrides[requirementKey(r[0])+'::'+c]=r[c];}}
  if(table.id==='airside-settings')for(const r of rows||[])if(r[10]==='Econ')r[10]='TRUE';
  project.release184Migrations[table.id]=true;
 }
 if(project.blankProject184&&table.id==='project-inputs'&&!Array.isArray(rows))project.independentTables[table.id]=table.rows.map(r=>r.map((v,c)=>c===2?'':v));
 if(project.blankProject184&&!Array.isArray(rows)&&table.schemaVersion)project.independentTableSchemaVersions[table.id]=table.schemaVersion;
 if(table.thermalTemplateCalculation){preloadThermalTemplates(project);rows=project.independentTables[table.id];}
 if(project.blankProject184&&!Array.isArray(rows)&&!table.thermalTemplateCalculation&&!table.referencePolicy&&!table.energySummary&&!table.importedTabularSource&&table.id!=='schedule-grouped-equipment-sensible-gain'&&table.id!=='project-inputs')project.independentTables[table.id]=[];
}
function recalculateReleaseSetpoints(table,rows,project){
 const pressure=modelInputCalculations(project.modelInputs||{}).pressure,overrides=project.setpointOverrides||={};project.conditionScheduleAutos||={};table.autoCellStates=new Map();table.lockedCellStates=new Map();table.lockedCellMessages=new Map();
 project.setpointsInitialized185||={};
 rows.forEach((r,i)=>{const auto=new Set(),key=requirementKey(r[0]);
  if(!project.setpointsInitialized185[key]){
   // Only a wholly empty input row may initialize from this project's source.
   const inputColumns=[2,3,4,6,7,8,9,11],empty=inputColumns.every(c=>r[c]===''||r[c]==null),meta=tabularMetadata(project,r[0]);
   if(empty&&meta){const defaults=setpointDefaults(project,r);for(const c of [2,3,4,8,9])r[c]=defaults[c]??'';}
   if(meta||!empty)project.setpointsInitialized185[key]=true;
  }
  if(presentNumber(r[7]))r[8]=presentNumber(project.modelInputs?.coolingDb)?Number(project.modelInputs.coolingDb)+Number(r[7]):'';
  for(const [c,s]of [[6,4],[11,9]]){const k=requirementKey(r[0])+'::'+c;project.conditionScheduleAutos[k]=project.calcSettings?.twoValueSchedule||table.twoValueScheduleDefault;if(r[s]===''||r[s]==null){r[c]='';table.lockedCellStates.set(i,new Set([...(table.lockedCellStates.get(i)||[]),c]));}else if(!project.conditionScheduleOverrides?.[k]){r[c]=project.calcSettings?.twoValueSchedule||table.twoValueScheduleDefault;auto.add(c);}}
  for(const [db,w,h,v]of [[3,5,12,13],[8,10,14,15]]){r[w]=presentNumber(r[db])&&presentNumber(r[2])&&presentNumber(project.modelInputs?.elevation)?humidityRatioForPressure(r[db],r[2],pressure):'';r[h]=moistAirEnthalpy(r[db],r[w]);r[v]=moistAirVolume(r[db],r[w],pressure);}table.autoCellStates.set(i,auto);
 });
}
function recordReleaseOverride(table,row,column,value,project){
 const clean=String(value??'').trim(),key=requirementKey(row[0])+'::'+column;
 if(table.conditionScheduleCalculation&&[2,3,4,8,9].includes(column)){row[column]=normalizedTableInput(table,column,clean);if(project.setpointOverrides)delete project.setpointOverrides[key];}
 if(table.id==='calc-misc-gains'&&column===3){project.gainDensityOverrides||={};if(clean===''||Number(clean)===Number(project.gainDensityAutos?.[key]))delete project.gainDensityOverrides[key];else project.gainDensityOverrides[key]=Number(clean);}
 if(table.id==='ashrae-fundamentals-people-heat'&&column===4){project.metOverrides||={};if(clean===''||Number(clean)===activityMET(row[0]))delete project.metOverrides[key];else project.metOverrides[key]=Number(clean);}
}
function recalculateMetabolicRates(table,rows,project){table.autoCellStates=new Map();table.cellDisplayEquations=new Map();rows.forEach((r,i)=>{const key=requirementKey(r[0])+'::4',v=activityMET(r[0]);table.cellDisplayEquations.set(i,new Map([[4,presentNumber(v)?'='+Number(v).toFixed(1):'=\"\"']]));if(project.metOverrides?.[key]===v)delete project.metOverrides[key];r[4]=project.metOverrides?.[key]??v;table.autoCellStates.set(i,new Set(project.metOverrides?.[key]===undefined?[4]:[]));});}
function configureCo2Monitoring(){
 const t=workbookTable('calc-co2-monitoring'),labels=[['Space'],['Thermal Template'],['People'],['Area','ft²'],['People Density','People/1000 ft²'],['Monitoring Required'],['Metabolic Rate','met'],['CO₂ per Person','CFM/person'],['People CO₂ Entering Space','CFM'],['Ventilation Entering Space','CFM'],['People CO₂ Concentration','ppm'],['Space CO₂ Concentration','ppm'],['CO₂ Concentration Alarm Setpoint','ppm']];
 Object.assign(t,{name:'CO₂ Monitoring',standard:'CO₂ Monitoring',headers:labels.map(([label,unit])=>({label,unit})),columns:labels.map(([label])=>label),columnTypes:labels.map((_,c)=>[0,1,5].includes(c)?'text':'number'),rows:t.rows.map(r=>[r[0],...Array(12).fill('')]),calculatedColumns:Array.from({length:13},(_,i)=>i),lockedColumns:[0],co2MonitoringCalculation:true,preserveImportedValues:false,zeroDecimalColumns:[2,3,10,11,12],oneDecimalColumns:[4,6],fiveDecimalColumns:[7,8],displayEquations:{1:'=XLOOKUP(@Space,[Space Condition Setpoints]@Space,[Space Condition Setpoints]@Thermal Template,"")',2:'=XLOOKUP(@Space,[People Gains]@Space,[People Gains]@Actual People,"")',3:'=XLOOKUP(@Space,[People Gains]@Space,[People Gains]@Area,"")',4:'=IF(OR(@Area="",@Area<=0),"",1000*@People/@Area)',5:'=IF(@People Density="","",IF(@People Density>[CO₂ Density Threshold],TRUE,""))',6:'=IF(@Monitoring Required="","",XLOOKUP(@Thermal Template,[Thermal Templates]@Space Type,[Thermal Templates]@Metabolic Rate,""))',7:'=IF(@Monitoring Required="","",0.01095*@Metabolic Rate/1.2)',8:'=IF(@Monitoring Required="","",@People*@CO₂ per Person)',9:'=IF(@Monitoring Required="","",'+co2VentilationFormula()+')',10:'=IF(@Monitoring Required="","",IFERROR(IF(OR(@Ventilation Entering Space="",@Ventilation Entering Space<=0,@Ventilation Entering Space="-"),"-",1e6*@People CO₂ Entering Space/@Ventilation Entering Space),"-"))',11:'=IF(@Monitoring Required="","",IF(@People CO₂ Concentration="-","-",[Outside CO₂]+@People CO₂ Concentration))',12:'=IF(@Monitoring Required="","",IF(@Space CO₂ Concentration="-","-",@Space CO₂ Concentration*(1+[CO₂ Alarm Allowance])))'}});
 t.formulaColumnAliases={'Area':3,'People Density':4,'CO₂ per Person':7};
}
function co2Criteria(project){const saved=project?.co2Criteria||{};return {outside:saved.outside??400,density:saved.density??25,allowance:saved.allowance??.1};}
function co2VentilationFormula(){const specs=[['calc-doas-zone-air-balance','occupiedVentilation',1],['calc-ahu-oa-air-balance','minimumOccupiedSupply',1],['calc-ahu-economizing-air-balance','minimumOccupiedSupply',2/3],['calc-doas-ahu-air-balance','occupiedVentilation',1]],parts=[];for(let i=0;i<specs.length;i++){const[id,field,ratio]=specs[i],t=workbookTable(id),c=t.balanceFields.indexOf(field);parts.push(`x${i+1},XLOOKUP(@Space,[${t.name}]@Space,[${t.name}]@[${spaceFilterColumnLabel(t,c)}],"")`);}return `LET(${parts.join(',')},IF(x1<>"",x1,IF(x2<>"",x2,IF(x3<>"",x3*2/3,IF(x4<>"",x4,"-")))))`;}
function recalculateCo2(table,rows,project){
 const people=workbookTable('calc-people-gains'),prs=ensureProjectTableRows(project,people);recalculateGainTable(people,prs,project);const thermal=workbookTable('iesve-thermal-template'),trs=ensureProjectTableRows(project,thermal);recalculateThermalTemplates(thermal,trs,project);const pby=new Map(prs.map(r=>[requirementKey(r[0]),r])),tby=new Map(trs.map(r=>[thermalTypeKey(r[0]),r])),criteria=co2Criteria(project),sources=[];
 for(const [id,field,ratio]of [['calc-doas-zone-air-balance','occupiedVentilation',1],['calc-ahu-oa-air-balance','minimumOccupiedSupply',1],['calc-ahu-economizing-air-balance','minimumOccupiedSupply',2/3],['calc-doas-ahu-air-balance','occupiedVentilation',1]]){const t=workbookTable(id),rs=ensureProjectTableRows(project,t);recalculateSystemAirBalance(t,rs,project);sources.push({by:new Map(rs.map(r=>[requirementKey(r[0]),r])),c:t.balanceFields.indexOf(field),ratio});}
 table.equationErrorStates=new Map();for(const [i,r]of rows.entries()){const p=pby.get(requirementKey(r[0]))||[];r[1]=p[1]??'';r[2]=presentNumber(p[5])?Number(p[5]):0;r[3]=p[2]??'';r[4]=presentNumber(r[3])&&Number(r[3])>0&&presentNumber(r[2])?1000*Number(r[2])/Number(r[3]):'';r[5]=presentNumber(r[4])&&r[4]>criteria.density?'TRUE':'';for(let c=6;c<13;c++)r[c]='';if(!r[5])continue;r[6]=tby.get(thermalTypeKey(r[1]))?.[14]??'';if(!presentNumber(r[6]))continue;r[7]=.01095*Number(r[6])/1.2;r[8]=Number(r[2])*r[7];for(const s of sources){const x=s.by.get(requirementKey(r[0]));if(x&&x[s.c]!==''&&x[s.c]!=null){r[9]=presentNumber(x[s.c])?Number(x[s.c])*s.ratio:'-';break;}}if(r[9]===''||r[9]==null)r[9]='-';if(!presentNumber(r[9])||r[9]<=0){for(let c=10;c<13;c++)r[c]='-';continue;}r[10]=1e6*r[8]/r[9];r[11]=Number(criteria.outside)+r[10];r[12]=r[11]*(1+Number(criteria.allowance));}
}
function roomMassFormula(cooling,kind){
 const peak='calc-peak-airflows',sp='calc-space-condition-setpoints',ref=c=>scheduleSourceReference(peak,c),sref=c=>scheduleSourceReference(sp,c);
 const spaces=cooling?`VSTACK(${ref(0)})`:`VSTACK(${ref(0)},${ref(0)})`,equipment=cooling?`VSTACK(${ref(1)})`:`VSTACK(${ref(6)},${ref(14)})`,flow=cooling?`VSTACK(${ref(4)})`:`VSTACK(${ref(10)},${ref(18)})`;
 return `=LET(spaces,${spaces},equipment,${equipment},flows,${flow},served,FILTER(spaces,(equipment=@Equipment)*(flows>0),""),q,FILTER(flows,(equipment=@Equipment)*(flows>0),0),v,XLOOKUP(served,${sref(0)},${sref(cooling?15:13)},""),values,XLOOKUP(served,${sref(0)},${sref(kind==='h'?(cooling?14:12):(cooling?10:5))},""),IF(SUM(q)=0,"INVALID",SUMPRODUCT(q/v,values)/SUM(q/v)))`;
}
function configureMixedAirTable(){
 const groups=[['Return Airstream','space-group-header'],['Ventilation Airstream — Cooling Design Day','sensible-cooling-header'],['Ventilation Airstream — Dehumidification Design Day','latent-cooling-header'],['Mixed-Air — Cooling Design Day','sensible-cooling-header'],['Mixed-Air — Dehumidification Design Day','latent-cooling-header']],headers=[{label:'Equipment'}],columns=['Equipment'],headerGroups=[{label:'General',start:0,span:1}],headerClasses={0:'space-group-header'},formulas={};
 for(const [label,color]of groups){const start=headers.length;headerGroups.push({label,start,span:6,className:color});for(const [name,unit]of [['Airflow','CFM'],['Dry-Bulb','°F'],['Wet-Bulb','°F'],['Hum-Ratio','lb/lb'],['Enthalpy','Btu/lb'],['Specific Volume','ft³/lb']]){headerClasses[headers.length]=color;headers.push({label:name,unit});columns.push(label+' '+name);}}
 const t={id:'airside-mixed-air',name:'Mixed-Air',standard:'Mixed-Air',description:'Project assumption: one-third return and two-thirds ventilation airflow. This ratio is not an ASHRAE requirement.',headers,columns,rows:[],columnTypes:headers.map((_,c)=>c?'number':'text'),headerGroups,headerClasses,frozenColumns:1,identityColumns:[0],lockedColumns:[0],calculatedColumns:Array.from({length:30},(_,i)=>i+1),zeroDecimalColumns:[1,7,13,19,25,5,11,17,23,29],oneDecimalColumns:[2,3,6,8,9,12,14,15,18,20,21,24,26,27,30],displayEquations:formulas,readonlyEquations:true,fixedRows:true,airsideSection:true,mixedAirCalculation:true,sectionStartColumns:[1,7,13,19,25],formulaColumnAliases:{}};
 for(const [name,start]of [['Return',1],['Cooling Ventilation',7],['Dehumidification Ventilation',13],['Cooling Mixed',19],['Dehumidification Mixed',25]])for(const [offset,label]of ['Airflow','DB','WB','HR','Enthalpy','Specific Volume'].entries())t.formulaColumnAliases[name+' '+label]=start+offset;
 const af='XLOOKUP(@Equipment,[Airflows]@Equipment,[Airflows]@Design Cooling Airflow,"")';formulas[1]='='+af+'/3';formulas[7]=formulas[13]='=2*'+af+'/3';formulas[19]=formulas[25]='='+af;
 for(const [start,name]of [[7,'Cooling'],[13,'Dehumidification']]){formulas[start+1]=`=[Model Inputs]@${name} Design Dry-Bulb`;formulas[start+3]=`=[Model Inputs]@${name} Design Hum-Ratio`;}
 const econ=workbookTable('calc-ahu-economizing-air-balance'),flow=scheduleSourceReference(econ.id,econ.balanceFields.indexOf('returnToCentral')),zone='[Equipment Zoning]',sp='[Space Condition Setpoints]';
 for(const [offset,field]of [[3,'Cooling Hum-Ratio'],[4,'Cooling Enthalpy']])formulas[1+offset]=`=LET(spaces,FILTER(${zone}@Space,${zone}@Central Equipment=@Equipment,""),allq,XLOOKUP(spaces,[${econ.name}]@Space,${flow},0),served,FILTER(spaces,allq>0,""),q,FILTER(allq,allq>0,0),v,XLOOKUP(served,${sp}@Space,${sp}@Cooling Specific Volume,""),values,XLOOKUP(served,${sp}@Space,${sp}@${field},""),IF(SUM(q)=0,"INVALID",SUMPRODUCT(q/v,values)/SUM(q/v)))`;
 for(const start of [19,25]){const vent=start===19?'Cooling Ventilation':'Dehumidification Ventilation';for(const [off,field]of [[3,'HR'],[4,'Enthalpy']])formulas[start+off]=`=LET(mr,@Return Airflow/@Return Specific Volume,mv,@${vent} Airflow/@${vent} Specific Volume,IF(mr+mv<=0,"INVALID",(mr*@Return ${field}+mv*@${vent} ${field})/(mr+mv)))`;}
 for(const [start,name]of [['1','Return'],['7','Cooling Ventilation'],['13','Dehumidification Ventilation'],['19','Cooling Mixed'],['25','Dehumidification Mixed']]){const s=Number(start);if([1,19,25].includes(s))formulas[s+1]=`=(@${name} Enthalpy-1061*@${name} HR)/(0.240+0.444*@${name} HR)`;else formulas[s+4]=`=0.240*@${name} DB+@${name} HR*(1061+0.444*@${name} DB)`;formulas[s+2]=`=WETBULB(@${name} DB,@${name} HR,[Model Inputs]@Barometric Pressure)`;formulas[s+5]=`=0.370486*(@${name} DB+459.67)*(1+1.607858*@${name} HR)/[Model Inputs]@Barometric Pressure`;}
 independentTables.push(t);const m=modules.find(m=>m.items.some(i=>i[3]==='airside-airflows'));if(m)m.items.splice(m.items.findIndex(i=>i[3]==='airside-airflows')+1,0,['Mixed-Air','Airside','Dry-air mass-weighted return and ventilation mixing.',t.id]);
}
function mixedAirForEquipment(project,equipment,sharedContext,allowPartial=false){
 if(!activeCalculationCache)return withWorkbookPass(project,()=>mixedAirForEquipment(project,equipment,sharedContext,allowPartial));
 const context=sharedContext||coilCalculationContext(project),tag=requirementKey(equipment),setting=context.settingsByEquipment.get(tag);
 if(String(setting?.[10]).toUpperCase()!=='TRUE'||!context.zoningRows.some(z=>requirementKey(z[3])===tag))return null;
 // During Airflows' convergence pass the airflow map deliberately returns null to
 // avoid recursion. Read the already-computed peak airflow rows as the solver seed
 // rather than invalidating every Mixed-Air airstream. Use the finalized Airflows
 // result when the map is available outside that convergence pass.
 let q;
 if(!activeCalculationCache?.buildingEquipmentAirflows){
  const flow=equipmentAirflowMap(project)?.get(tag);
  if(presentNumber(flow?.[4]))q=Number(flow[4]);
 }
 if(!presentNumber(q)){
  const peak=workbookTable('calc-peak-airflows');
  if(peak){
   const peaks=ensureProjectTableRows(project,peak);
   const total=peaks.reduce((sum,r)=>sum+(requirementKey(r[1])===tag?requirementNumber(r[4]):0),0);
   const factor=setting?.[5]===''||setting?.[5]==null?1:Number(setting[5]);
   if(Number.isFinite(factor)&&factor>=0)q=total*factor;
  }
 }
 const errors={},result={errors};
 const attempt=(name,fn)=>{try{const value=fn();if(!value||!presentNumber(value.db)||!presentNumber(value.w)||!presentNumber(value.h)||!presentNumber(value.v)||!presentNumber(value.wb))throw Error('Incomplete or invalid psychrometric state.');result[name]=value;}catch(e){errors[name]=String(e?.message||e);}};
 if(!presentNumber(q)||Number(q)<=0){const message='Mixed-Air requires a positive Cooling Design Airflow in Airflows.';for(const name of ['returned','cooling','dehum','mixedCooling','mixedDehum'])errors[name]=message;}
 else{
  // Ventilation design-day states do not depend on the return-air calculation.
  const ventilation=(db,w)=>({db,w,h:moistAirEnthalpy(db,w),v:moistAirVolume(db,w,context.pressure),wb:wetBulbFromState(db,w,context.pressure),flow:2*Number(q)/3});
  attempt('cooling',()=>ventilation(context.model.coolingDb,context.calculated.coolingHr));
  attempt('dehum',()=>ventilation(context.model.dehumidificationDb,context.calculated.dehumidificationHr));
  attempt('returned',()=>{
   const t=workbookTable('calc-ahu-economizing-air-balance'),balance=ensureProjectTableRows(project,t);
   recalculateSystemAirBalance(t,balance,project);
   const by=new Map(balance.map(r=>[requirementKey(r[0]),r]));
   const returnColumn=t.balanceFields.indexOf('returnToCentral');
   if(returnColumn<0)throw Error('The economized air balance has no returnToCentral source column.');
   const streams=[];
   for(const z of context.zoningRows.filter(z=>requirementKey(z[4])===tag)){
    const space=String(z[2]),r=by.get(requirementKey(space)),sp=context.setpointsBySpace.get(space);
    if(!r||!presentNumber(r[returnColumn]))throw Error('Missing return airflow for space '+space+'.');
    streams.push({flow:r[returnColumn],db:sp?.[8],w:sp?.[10],h:sp?.[14],v:sp?.[15]});
   }
   if(!streams.length)throw Error('No spaces with Central Equipment '+equipment+' were found for return-air mixing.');
   return {...massWeightedAir(streams,context.pressure),flow:Number(q)/3};
  });
  for(const [name,vent] of [['mixedCooling','cooling'],['mixedDehum','dehum']]){
   if(!result.returned||!result[vent])errors[name]=errors.returned||errors[vent]||'Missing airstream for mixing.';
   else attempt(name,()=>({...massWeightedAir([result.returned,result[vent]],context.pressure),flow:Number(q)}));
  }
 }
 if(!allowPartial&&Object.keys(errors).length)throw Error(Object.entries(errors).map(([name,message])=>name+': '+message).join('; '));
 return result;
}
function recalculateMixedAir(table,rows,project){
 const context=coilCalculationContext(project);table.equationErrorStates=new Map();
 rows.forEach((r,i)=>{
  let result;
  try{result=mixedAirForEquipment(project,r[0],context,true);}
  catch(e){result={errors:{returned:String(e?.message||e),cooling:String(e?.message||e),dehum:String(e?.message||e),mixedCooling:String(e?.message||e),mixedDehum:String(e?.message||e)}};}
  if(!result){for(let c=1;c<31;c++)r[c]='';return;}
  const errorColumns=new Map();
  for(const [k,name] of ['returned','cooling','dehum','mixedCooling','mixedDehum'].entries()){
   const start=1+6*k,stream=result[name];
   if(stream)r.splice(start,6,stream.flow,stream.db,stream.wb,stream.w,stream.h,stream.v);
   else{for(let c=start;c<start+6;c++){r[c]='INVALID';errorColumns.set(c,result.errors[name]||'Airstream calculation failed.');}}
  }
  if(errorColumns.size)table.equationErrorStates.set(i,errorColumns);
 });
}
function workbookClipboardContext(event){
 const target=event.target,active=document.activeElement;
 if(target?.closest?.('input,textarea,select,[contenteditable="true"],dialog,.formula-bar,.formula-debugger,.equation-viewer')||active?.matches?.('input,textarea,select,[contenteditable="true"]'))return false;
 const selection=window.getSelection();if(selection&&!selection.isCollapsed&&String(selection).length)return false;
 return !!(referenceTable.contains(target)||referenceTable.contains(active)||active===tableScroll)&&!!(selectedTableCells.size||activeCellSelection?.tableId===activeTableId);
}
function workbookCellEditable(table,row,column,index){return !!row&&!referenceCellLocked(table,row,column)&&!table.lockedColumns?.includes(column)&&!table.calculatedColumns?.includes(column)&&!table.lockedCellStates?.get(index)?.has(column)&&!isConditionalCalculatedCell(table,row,column);}
function noteQualifyingEdit(){if(!isWorkbookReadOnly()&&ownsProjectControl()){lastWorkbookActivity=Date.now();updateControlCountdowns();}}
function setCo2Criterion(project,key,raw){
 const defaults={outside:400,density:25,allowance:.1};if(!Object.hasOwn(defaults,key))throw Error('Unknown CO₂ criterion.');
 const text=String(raw??'').trim().replace(/%$/,''),value=text===''?defaults[key]:Number(text)/(key==='allowance'?100:1);
 if(!Number.isFinite(value)||value<0)throw Error('Enter a nonnegative number.');
 project.co2Criteria||={};if(value===defaults[key])delete project.co2Criteria[key];else project.co2Criteria[key]=value;return value;
}
function renderCo2Criteria(table){
 if(!table.co2MonitoringCalculation)return;document.querySelector('#co2-criteria')?.remove();const project=activeProject(),values=co2Criteria(project),root=document.createElement('section');root.id='co2-criteria';root.className='co2-criteria';
 for(const [key,label,defaultValue]of [['outside','Outside Air CO₂ Concentration [ppm]',400],['density','CO₂ Monitoring Required Above Occupant Density [People/1000 ft²]',25],['allowance','Permitted Increase Over Expected CO₂ Concentration [%]',.1]]){
  const field=document.createElement('label'),caption=document.createElement('span'),input=document.createElement('input');caption.textContent=label;input.value=key==='allowance'?values[key]*100+'%':String(values[key]);input.className=values[key]===defaultValue?'auto-populated-input':'';input.readOnly=isWorkbookReadOnly();input.dataset.co2Criterion=key;
  input.oninput=()=>input.setCustomValidity('');
  input.onchange=()=>{if(isWorkbookReadOnly()||activeProject().id!==project.id)return;try{setCo2Criterion(project,key,input.value);}catch(error){input.setCustomValidity(error.message);input.reportValidity();return;}clearSelectedEquation();noteQualifyingEdit();saveProjects();renderReferenceTable(table.id);};
  input.onfocus=()=>{selectStandaloneControl(input);const overridden=values[key]!==defaultValue,equation='=Autopopulate('+defaultValue+(overridden?',Userinput()':'')+')';selectedEquationContext={model:true,equation,userInputValue:values[key],values:{}};selectedAutoRestore=overridden?()=>{input.value=key==='allowance'?defaultValue*100+'%':String(defaultValue);input.onchange();}:null;selectedEquation.value=equation;displayFormulaFunctions(equation);formulaBar.hidden=false;editEquationButton.hidden=true;restoreAutoButton.hidden=false;restoreAutoButton.disabled=isWorkbookReadOnly()&&overridden;restoreAutoButton.textContent=overridden?'Restore':'Evaluate';formulaBar.classList.toggle('formula-overridden',overridden);document.querySelector('#evaluate-cell-equation').hidden=false;restoreAutoButton.hidden=!overridden;};field.append(caption,input);root.append(field);
 }
 referenceTable.closest('.table-scroll').before(root);
}
let pendingWorkbookCut=null;
function captureWorkbookCut(text){
 if(isWorkbookReadOnly()){pendingWorkbookCut=null;return;}
 const table=workbookTable(activeTableId),rows=projectTableRows(table),cells=[...selectedTableCells].map(key=>{const [r,c]=key.split(':').map(Number);return {r,c,value:rows[r]?.[c]};});
 if(cells.some(x=>!workbookCellEditable(table,rows[x.r],x.c,x.r))){pendingWorkbookCut=null;showTablePasteError('Cut includes locked or calculated cells. Copy these cells instead.');return;}
 const bounds=selectedCellBounds();const columns=bounds?.visibleColumns.filter(c=>c>=bounds.column&&c<=bounds.maxColumn)||[];for(const x of cells){x.gridR=bounds?bounds.visibleRows.findIndex(r=>Number(r.dataset.sourceIndex)===x.r)-bounds.row:0;x.gridC=columns.findIndex(c=>storedColumnIndex(c)===x.c);}
 pendingWorkbookCut={projectId:activeProjectId,tableId:table.id,text,cells};
}
function validateWorkbookCut(text){
 const cut=pendingWorkbookCut;if(!cut||cut.text!==text)return true;
 const table=workbookTable(cut.tableId),rows=projectTableRows(table);
 if(cut.projectId!==activeProjectId||cut.cells.some(x=>!workbookCellEditable(table,rows[x.r],x.c,x.r)||rows[x.r][x.c]!==x.value)){
  showTablePasteError('The cut source has changed or is locked. Cut the source again before pasting.');return false;
 }return true;
}
function commitWorkbookCut(text,destination,changes,project){
 const cut=pendingWorkbookCut;if(!cut||cut.text!==text)return;const table=workbookTable(cut.tableId),rows=projectTableRows(table),dest=new Set(changes.map(x=>rows.indexOf(x.row)+':'+x.column));
 const applied=new Set(changes.map(c=>c.rowOffset+':'+c.columnOffset));for(const x of cut.cells){if(x.gridR!==undefined&&!applied.has(x.gridR+':'+x.gridC))continue;if(table===destination&&dest.has(x.r+':'+x.c))continue;const r=rows[x.r];for(const fn of [recordZoningOverride,recordNetworkZoningOverride,recordAirsideOverride,recordCoilOverride,recordPlantOverride,recordSpaceLoadFactorOverride,recordPressurizationOverride,recordScheduleOverride])fn(table,r,x.c,'',project);r[x.c]='';}
 pendingWorkbookCut=null;if(table!==destination)recalculateTable(table,rows,project);
}
function initializeWorkbookDragScroll(){
 let pointer=null,frame=0,last=0;
 const tick=now=>{frame=0;if(!pointer||(!cellDragSelection&&!fillDrag))return;const r=tableScroll.getBoundingClientRect(),header=referenceTable.tHead?.getBoundingClientRect().height||0,zone=38,dt=Math.min(32,now-(last||now));last=now;
  const speed=(p,lo,hi)=>p<lo+zone?-Math.min(1400,70+Math.max(0,lo+zone-p)**1.45):p>hi-zone?Math.min(1400,70+Math.max(0,p-(hi-zone))**1.45):0;
  const x=speed(pointer.x,r.left,r.right),y=speed(pointer.y,r.top+header,r.bottom);tableScroll.scrollBy(x*dt/1000,y*dt/1000);
  const el=document.elementFromPoint(Math.max(r.left+2,Math.min(r.right-2,pointer.x)),Math.max(r.top+header+2,Math.min(r.bottom-2,pointer.y)))?.closest('td[data-source-index]');
  if(fillDrag)updateFillPreview(pointer.x,pointer.y);else if(el&&referenceTable.contains(el))selectTableCell(activeTableId,Number(el.dataset.sourceIndex),Number(el.dataset.columnIndex),{shiftKey:true});
  frame=requestAnimationFrame(tick);
 };
 document.addEventListener('pointermove',e=>{if(!cellDragSelection&&!fillDrag)return;pointer={x:e.clientX,y:e.clientY};if(!frame){last=0;frame=requestAnimationFrame(tick);}},{passive:true});
 const stop=()=>{pointer=null;last=0;if(frame)cancelAnimationFrame(frame);frame=0;};document.addEventListener('pointerup',stop);document.addEventListener('pointercancel',stop);window.addEventListener('blur',stop);
}
if(typeof document!=='undefined')document.addEventListener('DOMContentLoaded',initializeWorkbookDragScroll);
function mixedPsychData(project,equipment){
 const t=workbookTable('airside-mixed-air'),rows=withWorkbookPass(project,()=>{const r=ensureProjectTableRows(project,t);recalculateTable(t,r,project);return r;});const index=rows.findIndex(r=>requirementKey(r[0])===requirementKey(equipment));if(index<0)return null;const row=rows[index],error=t.equationErrorStates?.get(index)?.values().next().value,conditions=[{name:'Cooling Design Day',vent:7,mix:19,color:'#0066ff'},{name:'Dehumidification Design Day',vent:13,mix:25,color:'#008577'}],lines=[];
 const state=s=>({db:row[s+1],wb:row[s+2],hr:row[s+3]});
 if(!error)for(const c of conditions){const mixed=state(c.mix);lines.push({enter:state(1),leave:mixed,mixing:true,mixingColor:'#8549c7',mixedColor:c.color,day:c.name},{enter:state(c.vent),leave:mixed,mixing:true,mixingColor:c.color,mixedColor:c.color,day:c.name});}
 return {table:t,index,row,conditions,lines,error};
}
function mixedPsychRows(data){return data.conditions.map(c=>({values:['Mixed-Air / '+c.name,...[2,3,4,5,c.vent+1,c.vent+2,c.vent+3,c.vent+4,c.mix+1,c.mix+2,c.mix+3,c.mix+4].map(i=>formatTableValue(data.row[i],data.table,i))],outlineGroups:[{start:1,end:4,color:'#8549c7',dashed:true},{start:5,end:8,color:c.color,dashed:true},{start:9,end:12,color:c.color,dashed:false}]}));}
function mixedPsychColumns(){return [{label:'Airstream',group:'Airstream',numeric:false,color:'#003b8c'},...['Return Conditions','Ventilation Conditions','Mixed-Air Conditions'].flatMap((group,i)=>[['Dry-Bulb','°F'],['Wet-Bulb','°F'],['Hum-Ratio','gr/lb'],['Enthalpy','Btu/lb']].map(([label,unit],c)=>({label,unit,group,numeric:true,color:'#003b8c',groupIcon:c===0?(i===2?'filled':'hollow'):null,divider:c===0})))];}
function renderMixedPsych(project,equipment){
 document.querySelector('#psych-mixed-summary')?.remove();const data=mixedPsychData(project,equipment);if(!data)return;const root=document.createElement('section');root.id='psych-mixed-summary';root.className='psych-mixed-summary';const title=document.createElement('h3');title.textContent='Mixed-Air';root.append(title);
 const scroll=document.createElement('div');scroll.className='psych-mixed-scroll';const table=document.createElement('table');table.className='psych-mixed-table';const head=document.createElement('thead'),groups=document.createElement('tr'),labels=document.createElement('tr');
 for(const [label,span]of [['Airstream',1],['Return Conditions ○',4],['Ventilation Conditions ○',4],['Mixed-Air Conditions ●',4]]){const th=document.createElement('th');th.colSpan=span;th.textContent=label;groups.append(th);}for(const c of mixedPsychColumns()){const th=document.createElement('th');th.textContent=c.label+(c.unit?' ['+c.unit+']':'');labels.append(th);}head.append(groups,labels);table.append(head);
 const body=document.createElement('tbody');mixedPsychRows(data).forEach((r,i)=>{const tr=document.createElement('tr'),day=data.conditions[i];r.values.forEach((value,c)=>{const td=document.createElement('td');td.textContent=value;td.tabIndex=0;if(c){const side=c<5?0:c<9?1:2,position=(c-1)%4,s=side===0?1:side===1?day.vent:day.mix,source=s+1+position;td.title=data.table.displayEquations[source]||data.error||'';td.onclick=()=>openFormulaEvaluator({table:data.table,column:source,sourceIndex:data.index,equation:data.table.displayEquations[source]});td.dataset.outlineGroup=String(side);td.style.setProperty('--outline-color',side===0?'#8549c7':day.color);td.classList.add(side<2?'mix-input-condition':'mix-result-condition');if(position===0)td.classList.add('mix-condition-first');if(position===3)td.classList.add('mix-condition-last');}tr.append(td);});body.append(tr);});table.append(body);scroll.append(table);root.append(scroll);
 if(data.error){const p=document.createElement('p');p.textContent=data.error;root.append(p);}else{const chart=document.createElement('div');const svg=window.PsychrometricChart.render({container:chart,elevationFt:Number(project.modelInputs.elevation),points:[]}).svg;drawMixedPsychOverlay(svg,data.lines);root.append(chart);}
 const note=document.createElement('p');note.className='mixed-air-assumption';note.textContent='Project assumption: 1/3 return air and 2/3 ventilation air; this ratio is not an ASHRAE requirement.';root.append(note);tableView.before(root);
}
function mixedPsychMarkers(lines){
 const markers=[],seenReturn=new Set();
 for(const line of lines){const color=line.mixingColor;if(color==='#8549c7'){const key=line.enter.db+':'+line.enter.hr;if(!seenReturn.has(key)){markers.push({...line.enter,enter:[color],leave:[]});seenReturn.add(key);}}else{markers.push({...line.enter,enter:[color],leave:[]});markers.push({...line.leave,enter:[],leave:[line.mixedColor||color]});}}
 return markers;
}
function drawMixedPsychOverlay(svg,lines){
 const ns='http://www.w3.org/2000/svg',add=(tag,attrs)=>{const n=document.createElementNS(ns,tag);for(const[k,v]of Object.entries(attrs))n.setAttribute(k,String(v));svg.append(n);return n;},markers=mixedPsychMarkers(lines),geometry=psychProcessGeometry(lines.map(l=>({color:l.mixingColor,dashed:true,points:[psychChartPoint(l.enter.db,l.enter.hr),psychChartPoint(l.leave.db,l.leave.hr)]})),markers);
 for(const part of geometry.strokes)add('line',{x1:part.a.x,y1:part.a.y,x2:part.b.x,y2:part.b.y,stroke:part.color,'stroke-width':part.width,'stroke-dasharray':'9 6'});
 const path=points=>points.map((p,i)=>`${i?'L':'M'}${p.x},${p.y}`).join(' ')+' Z';
 for(const arrow of geometry.arrows){for(const band of arrow.bands)add('path',{d:path(band.points),fill:band.color});add('path',{d:path(arrow.points),fill:'none',stroke:'white','stroke-width':1.2});}
 for(const marker of markers){const p=psychChartPoint(marker.db,marker.hr);add('circle',{cx:p.x,cy:p.y,r:marker.enter.length?8:6.5,fill:marker.enter.length?'white':marker.leave[0],stroke:marker.enter[0]||'none','stroke-width':marker.enter.length?3:0});}
}
function printMixedPsychModel(project,equipment,vector,pressure){const data=mixedPsychData(project,equipment);if(!data)return null;return {portrait:true,minFontSize:7,title:equipment+' Mixed-Air Psychrometric Chart',section:'Psychrometric Calculations',columns:mixedPsychColumns(),rows:mixedPsychRows(data),topLines:data.error?[data.error]:[],topFields:[],notes:{reference:['Project assumption: one-third return and two-thirds ventilation air; not an ASHRAE requirement.']},chart:data.error?null:{vector,bounds:psychChartBounds(data.lines,pressure),markers:mixedPsychMarkers(data.lines).map(m=>({...m,point:psychChartPoint(m.db,m.hr)})),lines:data.lines.map(l=>({color:l.mixingColor,dashed:true,points:[psychChartPoint(l.enter.db,l.enter.hr),psychChartPoint(l.leave.db,l.leave.hr)]}))}};}
function co2Excel(project,table,rows){
 const xml=x=>String(x??'').replace(/[<>&"']/g,c=>({'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;',"'":'&apos;'}[c])),letter=n=>String.fromCharCode(65+n),cell=(value,c,r,style=0)=>`<c r="${letter(c)}${r}" s="${style}"${typeof value==='number'&&Number.isFinite(value)?'><v>'+value+'</v>':' t="inlineStr"><is><t xml:space="preserve">'+xml(value)+'</t></is>'}</c>`,criteria=co2Criteria(project),line=(values,r,style)=>`<row r="${r}" ht="${r===6?64:22}" customHeight="1">${values.map((v,c)=>cell(v,c,r,style)).join('')}</row>`;
 const content=[line(['Outside Air CO₂ Concentration [ppm]',criteria.outside],2,2),line(['CO₂ Monitoring Required Above Occupant Density [People/1000 ft²]',criteria.density],3,2),line(['Permitted Increase Over Expected CO₂ Concentration [%]',criteria.allowance*100+'%'],4,2),line(table.headers.map(h=>h.label+(h.unit?' ['+h.unit+']':'')),6,1),...rows.map((r,i)=>line(r.slice(0,13),7+i,0)),line(['References'],rows.length+8,1),line([APPENDIX_D_REFERENCE],rows.length+9,0)].join('');
 const sheet=`<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetPr><pageSetUpPr fitToPage="1"/></sheetPr><sheetViews><sheetView workbookViewId="0"><pane xSplit="1" ySplit="6" topLeftCell="B7" state="frozen"/></sheetView></sheetViews><cols>${Array.from({length:13},(_,c)=>`<col min="${c+1}" max="${c+1}" width="${c<2?26:13}" customWidth="1"/>`).join('')}</cols><sheetData>${content}</sheetData><mergeCells count="2"><mergeCell ref="A${rows.length+8}:M${rows.length+8}"/><mergeCell ref="A${rows.length+9}:M${rows.length+9}"/></mergeCells><printOptions horizontalCentered="1"/><pageMargins left="0.25" right="0.25" top="0.35" bottom="0.35" header="0.15" footer="0.15"/><pageSetup paperSize="8" orientation="portrait" fitToWidth="1" fitToHeight="0"/></worksheet>`;
 const styles='<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="10"/><name val="Aptos"/></font><font><b/><sz val="10"/><name val="Aptos"/><color rgb="FFFFFFFF"/></font></fonts><fills count="4"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF152E5B"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFE5F3E9"/></patternFill></fill></fills><borders count="1"><border/></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="3"><xf fontId="0" fillId="0" borderId="0" numFmtId="0"/><xf fontId="1" fillId="2" borderId="0" numFmtId="0" applyAlignment="1"><alignment wrapText="1" vertical="center"/></xf><xf fontId="0" fillId="3" borderId="0" numFmtId="0"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>';
 const files={'[Content_Types].xml':'<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>','_rels/.rels':'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>','xl/workbook.xml':'<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="CO₂ Monitoring" sheetId="1" r:id="rId1"/></sheets><definedNames><definedName name="_xlnm.Print_Area" localSheetId="0">\'CO₂ Monitoring\'!$A$1:$M$'+(rows.length+9)+'</definedName><definedName name="_xlnm.Print_Titles" localSheetId="0">\'CO₂ Monitoring\'!$6:$6</definedName></definedNames></workbook>','xl/_rels/workbook.xml.rels':'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>','xl/worksheets/sheet1.xml':sheet,'xl/styles.xml':styles};
 return WorkbookPrintPDF.zip(Object.entries(files).map(([name,value])=>({name,bytes:new TextEncoder().encode(value)})));
}
function co2ExportRows(project){
 const table=workbookTable('calc-co2-monitoring'),rows=ensureProjectTableRows(project,table);recalculateCo2(table,rows,project);const filter=prepareSharedSpaceFilter(table,rows,project);
 return rows.filter(row=>!filter||sharedSpaceSearchMatches(table,row,project)&&rowMatchesSpaceSet(table,row,filter.matchingSpaces)&&(!filter.matchingRows||filter.matchingRows.has(row))).sort((a,b)=>String(a[0]??'').localeCompare(String(b[0]??''),undefined,{numeric:true,sensitivity:'base'}));
}
function exportCo2Monitoring(project=structuredClone(activeProject())){downloadWorkbookFile(co2Excel(project,workbookTable('calc-co2-monitoring'),co2ExportRows(project)),'CO2-Monitoring.xlsx');}

function projectFormulaOverrides(project=activeProject()){if(!project)return equationOverrides;return project.equationOverrides||={};}
async function takeLocalProjectControl(){
 const requestedProject=activeProjectId;await workbookStorage.reload();if(requestedProject!==activeProjectId)return false;
 const id=activeProjectId,existing=readControlLease();if(existing?.owner&&existing.owner!==projectControlOwner){const alive=await localOwnerAlive186(existing);if(!alive){try{const latest=readControlLease();if(latest?.owner===existing.owner)localStorage.removeItem(controlLeaseKey(id));}catch{}}}
 const claim=()=>{if(id!==activeProjectId)return false;const held=readControlLease();if(held&&held.owner!==projectControlOwner&&Date.now()-held.at<CONTROL_DISCONNECT_MS)return false;localStorage.setItem(controlLeaseKey(id),JSON.stringify({projectId:id,owner:projectControlOwner,at:Date.now(),mode:'local'}));return readControlLease()?.owner===projectControlOwner;};
 let acquired;try{acquired=typeof navigator!=='undefined'&&navigator.locks?await navigator.locks.request(controlLeaseKey(id)+':claim',claim):claim();}catch(error){projectControlMessage='Unable to store local editing lease: '+error.message;updateArchiveControls();return false;}
 if(id!==activeProjectId)return false;
 if(!acquired){serverLeaseStatus=readControlLease();projectControlMessage='Another tab in this browser is editing this project. Release control in that tab first.';updateArchiveControls();return false;}
 serverLeaseGeneration++;serverLease={projectId:id,owner:projectControlOwner,mode:'local'};serverLeaseStatus=readControlLease();refreshStoredProjects();archiveView=null;projectViewOnly=false;viewOnlyProject=null;lastWorkbookActivity=Date.now();lastHeartbeatSuccess=0;connectivityLostAt=null;projectControlMessage='';fillProjectFields();renderTree(search.value);renderProjectList();applyArchiveReadOnly();return true;
}
function appendHeaderWords(element,text){String(text??'').split(/(\s+)/).forEach(word=>{if(/^\s+$/.test(word)){element.append(document.createTextNode(' '));return;}const span=document.createElement('span');span.style.whiteSpace='nowrap';appendFormattedText(span,word);element.append(span);});}

// Convert stored numbers to editor/clipboard input units without display rounding.
function workbookInputValue(table,column,value){
 if(typeof value==='number'&&Number.isFinite(value))return String(value*(isPercentageColumn(table,column)?100:table.headers[column]?.storageUnit==='lb/lb'?7000:1));
 return String(value??'');
}
function migrateReleaseSetpointStorage(project,table){
 if(!table.conditionScheduleCalculation)return;
 const rows=project.independentTables[table.id];if(!Array.isArray(rows)||!rows.some(r=>r.length===10))return;
 project.independentTables[table.id]=rows.map(r=>r.length===10?[...r.slice(0,6),'',...r.slice(6),'']:r);
 const mapped=c=>c>=6?c+1:c;
 if(project.cellNotes)project.cellNotes=Object.fromEntries(Object.entries(project.cellNotes).map(([key,value])=>{const m=key.startsWith(table.id+'::')&&key.match(/::(\d+)$/);return[m?key.replace(/::\d+$/,'::'+mapped(Number(m[1]))):key,value];}));
 const overrides=project.equationOverrides?.[table.id];if(overrides)project.equationOverrides[table.id]=Object.fromEntries(Object.entries(overrides).map(([key,value])=>[mapped(Number(key)),value]));
 const filter=project.sharedSpaceFilter;if(filter?.field?.startsWith('col:'+table.id+':'))filter.field='col:'+table.id+':'+mapped(Number(filter.field.split(':').at(-1)));
 const order=project.tableViewOrders?.[table.id];if(order&&order.column>=0)order.column=mapped(order.column);
 const headers=project.independentTableHeaders?.[table.id];if(headers?.length===10){headers.splice(6,0,{...table.headers[6]});headers.push({...table.headers[11]});}
}
function preciseWetBulbEquation([db,hr,p='[Model Inputs]@Barometric Pressure']){
 const terms=['TDB',db,'HR',hr,'P',p,'LOW0',-148,'HIGH0','TDB'];
 for(let i=0;i<36;i++){
  const wb='WB'+i,tr='TR'+i,pv='PV'+i,ws='WS'+i,wc='WC'+i,lo='LOW'+i,hi='HIGH'+i;
  terms.push(wb,`(${lo}+${hi})/2`,tr,`${wb}+459.67`,pv,`IF(${wb}>=32,EXP(-10440.397/${tr}-11.29465-.027022355*${tr}+.00001289036*${tr}^2-2.4780681E-9*${tr}^3+6.5459673*LN(${tr})),EXP(-10214.165/${tr}-4.8932428-.0053765794*${tr}+1.9202377E-7*${tr}^2+3.5575832E-10*${tr}^3-9.0344688E-14*${tr}^4+4.1635019*LN(${tr})))`,ws,`.621945*${pv}/(P-${pv})`,wc,`IF(${wb}>=32,((1093-.556*${wb})*${ws}-.240*(TDB-${wb}))/(1093+.444*TDB-${wb}),((1220-.04*${wb})*${ws}-.240*(TDB-${wb}))/(1220+.444*TDB-.48*${wb}))`,'LOW'+(i+1),`IF(${wc}<HR,${wb},${lo})`,'HIGH'+(i+1),`IF(${wc}<HR,${hi},${wb})`);
 }
 return `IF(OR(${db}="",${hr}="",${p}=""),"",IF(OR(${p}<=0,${db} < -148,${hr}<0,${hr}>.621945*SATURATIONPRESSURE(${db})/((${p})-SATURATIONPRESSURE(${db}))+1e-8),"INVALID",LET(${terms.join(',')},(LOW36+HIGH36)/2)))`;
}

function preloadThermalTemplates(project){
 project.independentTables||={};const table=workbookTable('iesve-thermal-template');if(!table)return;
 const rows=project.independentTables[table.id]||=[],names=new Set(rows.map(r=>thermalTypeKey(r[0])));
 for(const source of table.thermalDefaultRows||table.rows){if(isProjectThermalType(source[0]))continue;if(!names.has(thermalTypeKey(source[0]))){const row=[...source];while(row.length<table.columns.length)row.push('');rows.push(row);names.add(thermalTypeKey(row[0]));}}
 project.independentTables[table.id]=rows;
}
function isFrozenThermalTemplate(table,row){return Boolean(table?.thermalTemplateCalculation&&row&&!isProjectThermalType(row[0])&&table.thermalDefaultRows?.some(r=>thermalTypeKey(r[0])===thermalTypeKey(row[0])));}
