/* Native grains/lb workbook. Conversion factors occur only in legacy-data migration.
   Keep full numerical precision; three decimals is a display rule for latent constants. */
function grainAverageFormula(table,kind){
 const cooling=table.id==='airside-room-cooling'||table.id==='airside-mixed-air',mixed=table.mixedAirCalculation;
 const z='[Equipment Zoning]',sp='[Space Condition Setpoints]';
 const match=mixed?`${z}@Central Equipment=@Equipment`:cooling?`IF((${z}@Cooling Equipment="")+(${z}@Cooling Equipment="-"),${z}@Central Equipment,${z}@Cooling Equipment)=@Equipment`:`${z}@Heating Equipment=@Equipment`;
 const field=(cooling?'Cooling':'Heating')+(kind==='w'?' Hum-Ratio':' Enthalpy');
 return `=LET(served,UNIQUE(FILTER(${z}@Space,${match},"")),values,XLOOKUP(served,${sp}@Space,${sp}@${field},""),IFERROR(AVERAGE(FILTER(values,ISNUMBER(values))),"INVALID"))`;
}
function configureGrainWorkbook(){
 for(const t of independentTables){
  t.grainColumns=t.headers.map((h,c)=>h.unit==='gr/lb'?c:-1).filter(c=>c>=0);
  t.latentConstantColumns=t.headers.map((h,c)=>/latent constant/i.test(h.label)?c:-1).filter(c=>c>=0);
  for(const c of t.grainColumns)t.headers[c].storageUnit='gr/lb';
  for(const c of t.latentConstantColumns){
   for(const key of ['zeroDecimalColumns','oneDecimalColumns','decimalColumns','fourDecimalColumns','fiveDecimalColumns'])t[key]=(t[key]||[]).filter(x=>x!==c);
   t.threeDecimalColumns=[...new Set([...(t.threeDecimalColumns||[]),c])];
  }
  convertLegacyGrainRows(t,[...new Set([...t.rows,...Object.values(t.sourceRows||{})])]);
  for(const key of ['displayEquations','equations'])for(const [c,e] of Object.entries(t[key]||{}))t[key][c]=e.replaceAll('0.621945','4353.615');
 }
 for(const id of ['airside-mixed-air','airside-mixed-air-heating','airside-room-cooling','airside-room-heating']){
  const t=workbookTable(id),mixed=!!t.mixedAirCalculation,w=mixed?4:id==='airside-room-cooling'?34:12,h=mixed?5:id==='airside-room-cooling'?47:20;
  t.averageColumns={w,h};t.weightedColumns={};
  if(mixed)t.description='Return conditions use editable arithmetic room averages. Weighted room averages are diagnostic only; return and ventilation airstreams mix by dry-air mass flow.';
  for(const [kind,c,label,unit]of [['w',w,'Weighted Average Hum-Ratio','gr/lb'],['h',h,'Weight Average Enthalpy','Btu/lb']]){
   const n=appendWorkbookColumn(t,{label,unit,storageUnit:unit});t.weightedColumns[kind]=n;
   t.displayEquations[n]=t.displayEquations[c];t.calculatedColumns.push(n);
   t.formulaColumnAliases[label]=n;t.headerClasses[n]=t.headerClasses[c];
   t.displayColumnOrder.splice(t.displayColumnOrder.indexOf(c),0,n);
   for(const g of t.headerGroups){const columns=groupColumns(g);if(columns.includes(c)){g.columns=[...columns];g.columns.splice(g.columns.indexOf(c),0,n);g.span=g.columns.length;}}
   t.calculatedColumns=t.calculatedColumns.filter(x=>x!==c);t.lockedColumns=(t.lockedColumns||[]).filter(x=>x!==c);t.headers[c].calculated=false;
   t.autoColumns=[...new Set([...(t.autoColumns||[]),c])];t.displayEquations[c]=grainAverageFormula(t,kind);
   if(kind==='w')t.oneDecimalColumns=[...new Set([...(t.oneDecimalColumns||[]),n])];else t.zeroDecimalColumns=[...new Set([...(t.zeroDecimalColumns||[]),n])];
  }
 }
 // Derive borders from the displayed groups, including their first visible column.
 for(const t of independentTables){
  const order=(t.displayColumnOrder||t.headers.map((_,c)=>c)).filter(c=>!t.hiddenColumns?.includes(c));
  const stale=new Set(Object.values(t.averageColumns||{}));
  const starts=new Set((t.sectionStartColumns||[]).filter(c=>!stale.has(c)));
  for(const g of t.headerGroups||[]){const first=order.find(c=>columnInGroup(g,c));if(first!==undefined&&first!==order[0])starts.add(first);}
  t.sectionStartColumns=[...starts];
 }
}
function averageDiffersFromWeighted(table,row,column){
 const kind=Object.keys(table.averageColumns||{}).find(k=>table.averageColumns[k]===column);
 if(!kind)return false;const weighted=row[table.weightedColumns[kind]],actual=row[column];
 if(actual===''||actual==null)return false;
 if(!presentNumber(actual)||!presentNumber(weighted))return String(actual)!==String(weighted);
 return Math.abs(Number(actual)-Number(weighted))>1e-9*Math.max(1,Math.abs(Number(actual)),Math.abs(Number(weighted)));
}
function convertLegacyGrainRows(t,rows){
 for(const r of rows||[]){for(const c of t.grainColumns||[])if(presentNumber(r[c]))r[c]=Number(r[c])*7000;
  for(const c of t.latentConstantColumns||[])if(presentNumber(r[c]))r[c]=Number(r[c])/7000;}
}
function migrateGrainProject(project){
 if(project.nativeGrains247)return;
 for(const t of independentTables){
  convertLegacyGrainRows(t,project.independentTables?.[t.id]);
  const autos=project.coilAutoValues?.[t.id];if(autos)for(const key of Object.keys(autos)){const c=Number(key.split('::').pop());if(t.grainColumns?.includes(c)&&presentNumber(autos[key]))autos[key]*=7000;}
 }
 project.nativeGrains247=true;
}
function averageConditionValues(table,context,equipment){
 const cooling=table.id==='airside-room-cooling'||table.id==='airside-mixed-air',tag=requirementKey(equipment),states=new Map([...context.setpointsBySpace].map(([k,v])=>[requirementKey(k),v]));
 const zones=context.zoningRows.filter(z=>requirementKey(table.mixedAirCalculation?z[4]:cooling?firstAssignedEquipment(z[9],z[4]):z[10])===tag);
 const spaces=[...new Set(zones.map(z=>requirementKey(z[2])))],mean=c=>{const a=spaces.map(k=>states.get(k)?.[c]).filter(v=>typeof v==='number'&&Number.isFinite(v));return a.length?a.reduce((s,v)=>s+v,0)/a.length:'INVALID';};
 return {w:mean(cooling?10:5),h:mean(cooling?14:12),spaces};
}
function averagedCoilCondition(table,row,context,project,cooling,autoCells,applyAuto){
 const avg=averageConditionValues(table,context,row[0]),{w,h}=table.averageColumns;
 applyAuto(row,autoCells,w,avg.w);applyAuto(row,autoCells,h,avg.h);
 // Diagnostic only: it never feeds the entering state or its validity.
 const weighted=weightedCoilRoomCondition(context,row[0],project.independentTables?.['calc-peak-airflows']||[],cooling);
 row[table.weightedColumns.w]=presentNumber(weighted.humidityRatio)?weighted.humidityRatio:'INVALID';row[table.weightedColumns.h]=presentNumber(weighted.enthalpy)?weighted.enthalpy:'INVALID';
 return {dryBulb:dryBulbFromHW(row[h],row[w]),humidityRatio:row[w],enthalpy:row[h],spaces:avg.spaces};
}
function averagedReturnCondition(project,equipment,context,heating){
 const table=workbookTable(heating?'airside-mixed-air-heating':'airside-mixed-air'),avg=averageConditionValues(table,context,equipment);
 const row=project.independentTables?.[table.id]?.find(r=>requirementKey(r[0])===requirementKey(equipment));
 project.coilAutoValues||={};const autos=project.coilAutoValues[table.id]||={};
 const value=(kind)=>{const c=table.averageColumns[kind],key=airsideCellKey([equipment],c);autos[key]=avg[kind];return project.coilOverrides?.[table.id]?.[key]?row?.[c]:avg[kind];};
 const w=value('w'),h=value('h'),db=dryBulbFromHW(h,w);
 return {w,h,db,wb:wetBulbFromState(db,w,context.pressure),v:moistAirVolume(db,w,context.pressure)};
}
function populateWeightedReturn(table,row,project,context,index){
 table.autoCellStates.set(index,new Set(Object.values(table.averageColumns).filter(c=>!project.coilOverrides?.[table.id]?.[airsideCellKey(row,c)])));
 try{
 const heating=table.mixedAirHeating,t=workbookTable('calc-ahu-economizing-air-balance'),rows=ensureProjectTableRows(project,t);
 recalculateSystemAirBalance(t,rows,project);
 const by=new Map(rows.map(r=>[requirementKey(r[0]),r])),states=new Map([...context.setpointsBySpace].map(([k,v])=>[requirementKey(k),v])),c=t.balanceFields.indexOf('returnToCentral');
 const streams=context.zoningRows.filter(z=>requirementKey(z[4])===requirementKey(row[0])).map(z=>{const s=states.get(requirementKey(z[2]));return {flow:by.get(requirementKey(z[2]))?.[c],w:s?.[heating?5:10],h:s?.[heating?12:14],v:s?.[heating?13:15]};});const weighted=massWeightedAir(streams,context.pressure);row[table.weightedColumns.w]=weighted.w;row[table.weightedColumns.h]=weighted.h;}catch(error){row[table.weightedColumns.w]=row[table.weightedColumns.h]='INVALID';const errors=table.equationErrorStates.get(index)||new Map();for(const c of Object.values(table.weightedColumns))errors.set(c,String(error.message||error));table.equationErrorStates.set(index,errors);}
}
