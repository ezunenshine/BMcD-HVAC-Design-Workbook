/* October workbook extensions. Stored column indices remain stable for saved projects. */
const EQUIPMENT_GAIN_REFERENCES=['8B','8C','8D','8E','8F','9','10','11A','11B','11C','11D','12','13'].map(n=>`ASHRAE Fundamentals-2025 - Table ${n}.`);
const HOT_WATER_REFERENCES=['ASHRAE Handbook - HVAC Applications-2023 - Chapter 51, Table 6.','National Laboratory of the Rockies.'];
const ASHRAE_HOT_WATER_ROWS=[["Men's dormitory",13.1,'BLDG: Health - DHW'],["Women's dormitory",12.3,'BLDG: Health - DHW'],['Nursing home',18.4,'BLDG: Health - DHW'],['Office building',1,'BLDG: Office - DHW'],['Elementary school',.6,'BLDG: School - DHW'],['Junior and senior high school',1.8,'BLDG: School - DHW']];
function noCalculationReferences(id){return ['schedule-grouped-equipment-sensible-gain','schedule-pressurization-types','schedule-lighting','psych-active'].includes(id)||String(id).startsWith('psych:');}
function groupColumns(group){return group.columns||Array.from({length:group.span},(_,i)=>group.start+i);}
function columnInGroup(group,column){return groupColumns(group).includes(column);}
function configureWorkbookThirdUpdates(){
 const get=id=>independentTables.find(t=>t.id===id),blue='sensible-cooling-header',green='latent-cooling-header',red='heating-load-header';
 const label=(t,c,name)=>{t.headers[c].label=name;t.columns[c]=name;};
 const add=(t,name,unit='',type='number')=>{const c=t.columns.length;t.headers.push({label:name,...(unit?{unit}:{})});t.columns.push(name);t.columnTypes.push(type);t.rows.forEach(r=>r[c]='');return c;};
 const groups=(t,list)=>{t.headerGroups=list.map(([name,cols,color])=>({label:name,columns:cols,start:cols[0],span:cols.length,className:color||'space-group-header'}));t.sectionStartColumns=list.slice(1).map(g=>g[1][0]);t.headerClasses||={};for(const [,cols,color]of list)for(const c of cols)t.headerClasses[c]=color||'space-group-header';};
 const rename=(t,name)=>{t.aliases=[...new Set([...(t.aliases||[]),t.name,t.standard])];t.name=t.standard=name;for(const m of modules)for(const item of m.items)if(item[3]===t.id)item[0]=name;};
 const people=get('calc-people-gains');people.sectionStartColumns=people.sectionStartColumns.filter(c=>c!==5);people.headerClasses[6]=blue;people.headerClasses[7]=green;
 const lighting=get('calc-lighting-gains');for(const c of [3,4,5,6])lighting.headerClasses[c]=blue;
 const misc=get('calc-misc-gains');misc.formulaColumnAliases={...misc.formulaColumnAliases,'Detailed Equipment Gain':4,'Misc Sensible Gain':5};label(misc,4,'Detailed Sensible Heat Gain');label(misc,5,'Sensible Heat Gain');add(misc,'Latent Heat Gain','Btu/h');misc.calculatedColumns.push(6);misc.headerLinks[6]='selected-misc-loads';misc.headerClasses={...misc.headerClasses,3:blue,4:blue,5:blue,6:green};misc.sectionStartColumns=[];misc.summaryColumns.push(6);misc.displayEquations[6]='=SUMIF([Detailed Equipment Gains]@Space,@Space,[Detailed Equipment Gains]@[Latent Total])';
 label(get('selected-lighting-loads'),0,'Space');get('selected-lighting-loads').formulaColumnAliases={...get('selected-lighting-loads').formulaColumnAliases,'Space Name':0};
 const detail=get('selected-misc-loads');label(detail,0,'Space');label(detail,5,'Gain');label(detail,6,'Add');label(detail,7,'Add');label(detail,8,'Total');add(detail,'Gain','Btu/h');add(detail,'Add','kW');add(detail,'Add','Btu/h');add(detail,'Total','Btu/h');detail.frozenColumns=5;detail.calculatedColumns=[3,5,8,9,12];detail.summaryColumns=[8,12];detail.formulaScopes={'Sensible Heat':[5,9],'Latent Heat':[9,13]};detail.formulaColumnAliases={...detail.formulaColumnAliases,'Space Name':0,'Sens Heat Gain':5,'Gain':8,'Sensible Gain':5,'Sensible Total':8,'Latent Gain':9,'Latent Total':12,'Sensible Add kW':6,'Sensible Add Btuh':7,'Latent Add kW':10,'Latent Add Btuh':11};groups(detail,[['General',[0,1,2,3,4]],['Sensible Heat',[5,6,7,8],blue],['Latent Heat',[9,10,11,12],green]]);
 const eq=get('schedule-equipment-sensible-gain');eq.legacyRows=eq.rows.map(r=>[...r]);label(eq,5,'Gain');add(eq,'Type','','text');add(eq,'Load','Btu/h');add(eq,'Load','kW');add(eq,'Gain','Btu/h');add(eq,'Reference Row Status','','text');add(eq,'Lookup Key','','text');eq.referencePolicy='equipment';eq.schemaVersion=3;eq.referenceMarkerColumn=11;eq.hiddenColumns=[11,12];eq.lockedColumns=[11,12];eq.identityColumns=[];eq.calculatedColumns=[5,6,10,12];eq.displayColumnOrder=[6,7,0,1,2,3,4,5,8,9,10,11,12];eq.frozenColumns=0;eq.formulaColumnAliases={'Heat Gain':5,'Sensible Gain':5,'Latent Gain':10,'Sensible Load Btuh':1,'Sensible Load kW':2,'Latent Load Btuh':8,'Latent Load kW':9,'Lookup Key':12};eq.formulaScopes={'Sensible Heat Gain':[1,6],'Latent Heat Gain':[8,11]};groups(eq,[['General',[6,7,0]],['Sensible Heat Gain',[1,2,3,4,5],blue],['Latent Heat Gain',[8,9,10],green]]);eq.fixedReferences=INDEPENDENT_REFERENCE_TEXT[eq.id]=EQUIPMENT_GAIN_REFERENCES;
 eq.rows=EQUIPMENT_REFERENCE_ROWS.map(([type,name,sens,latent])=>[name,sens??'','',0,1,sens??'',0,type,latent??'','',latent??'','standard',`${type} - ${name}`]);
 eq.displayEquations={5:'=(@[Sensible Load Btuh]+@[Sensible Load kW]*3412.142)*(1-@Efficiency)*IF(@Percent of Space="",1,@Percent of Space)',10:'=IF(AND(@[Latent Load Btuh]="",@[Latent Load kW]=""),"",@[Latent Load Btuh]+@[Latent Load kW]*3412.142)',6:'=SUMIF([Detailed Equipment Gains]@Equipment,@[Lookup Key],[Detailed Equipment Gains]@Quantity)+SUMPRODUCT(N([Grouped Equipment Sensible Gain Schedule]@Equipment=@[Lookup Key]),[Grouped Equipment Sensible Gain Schedule]@[Equipment Quantity],[Grouped Equipment Sensible Gain Schedule]@[Group Quantity])'};eq.equations={...eq.displayEquations};
 const grouped=get('schedule-grouped-equipment-sensible-gain');grouped.legacyRows=grouped.rows.map(r=>[...r]);label(grouped,4,'Group Quantity');label(grouped,2,'Gain');label(grouped,3,'Summed Gain');add(grouped,'Equipment Quantity');add(grouped,'Gain','Btu/h');add(grouped,'Summed Gain','Btu/h');grouped.displayColumnOrder=[4,0,1,5,2,3,6,7];grouped.summaryColumns=[];grouped.frozenColumns=0;grouped.identityColumns=[];grouped.autoColumns=[5];grouped.calculatedColumns=[2,3,4,6,7];grouped.formulaColumnAliases={'Group':0,'Equipment':1,'Quantity':4,'Heat Gain':2,'Summed Heat Gain':3,'Sensible Gain':2,'Sensible Summed Gain':3,'Latent Gain':6,'Latent Summed Gain':7};groups(grouped,[['General',[4,0,1,5]],['Sensible Heat Gain',[2,3],blue],['Latent Heat Gain',[6,7],green]]);const laptop=EQUIPMENT_REFERENCE_ROWS.find(r=>r[0]==='Laptops and Docking Stations'&&/^Laptop with docking station/i.test(r[1])),monitor=EQUIPMENT_REFERENCE_ROWS.find(r=>r[0]==='Computer Monitors'&&/LED/i.test(r[1]));grouped.rows=[['Office Workstation',`${laptop[0]} - ${laptop[1]}`,'','','',1,'',''],['Office Workstation',`${monitor[0]} - ${monitor[1]}`,'','','',2,'','']];
 grouped.displayEquations={2:'=XLOOKUP(@Equipment,[Equipment Sensible Gain Schedule]@[Lookup Key],[Equipment Sensible Gain Schedule]@[Sensible Gain],0)*@Equipment Quantity',3:'=SUMIF([Grouped Equipment Sensible Gain Schedule]@Group,@Group,[Grouped Equipment Sensible Gain Schedule]@[Sensible Gain])',4:'=SUMIF([Detailed Equipment Gains]@Equipment,@Group,[Detailed Equipment Gains]@Quantity)',5:'=1',6:'=XLOOKUP(@Equipment,[Equipment Sensible Gain Schedule]@[Lookup Key],[Equipment Sensible Gain Schedule]@[Latent Gain],0)*@Equipment Quantity',7:'=SUMIF([Grouped Equipment Sensible Gain Schedule]@Group,@Group,[Grouped Equipment Sensible Gain Schedule]@[Latent Gain])'};
 detail.dropdownColumns[1]={choiceKind:'equipment',includeGroups:true};grouped.dropdownColumns[1]={choiceKind:'equipment'};
 for(const [c,kind]of [[5,'Sensible'],[9,'Latent']])detail.displayEquations[c]=`=IFERROR(XLOOKUP(@Equipment,[Grouped Equipment Sensible Gain Schedule]@Group,[Grouped Equipment Sensible Gain Schedule]@[${kind} Summed Gain]),XLOOKUP(@Equipment,[Equipment Sensible Gain Schedule]@[Lookup Key],[Equipment Sensible Gain Schedule]@[${kind} Gain],0))`;
 for(const [c,kind]of [[8,'Sensible'],[12,'Latent']])detail.displayEquations[c]=`=IF(@Per Person="TRUE",@People,1)*@Quantity*@[${kind} Gain]+@[${kind} Add kW]*3412.142+@[${kind} Add Btuh]`;
 detail.displayEquations[4]='=1';
 const loads=get('calc-room-loads');label(loads,9,'Internal Gains');loads.formulaColumnAliases={...loads.formulaColumnAliases,'People':9};loads.displayEquations[9]='=([People Gains]@Latent Gain+[Equipment Gains]@Latent Heat Gain)/1000';loads.displayEquations[13]=loads.displayEquations[13].replace('@People','@Internal Gains');
 rename(misc,'Equipment Gains');
 for(const t of independentTables.filter(t=>t.plantCalculation)){t.headerClasses[t.glycolTypeColumn]=t.plantCalculation==='cooling'?blue:red;const water=t.plantCalculation==='cooling'?12:10;for(const [c,property]of [[water+4,'Cp'],[water+5,'Density']])t.displayEquations[c]=plantPropertyFormulaThird(property);}
 const water=get('water-nist-properties');water.rows=water.rows.filter(r=>Math.abs(Number(r[0])-211.97)>.00001);
 for(const t of independentTables.filter(t=>/^water-(ethylene|propylene)-/.test(t.id))){const prop=t.id.endsWith('density')?'Density':'Cp';t.calculatedColumns=[...new Set([...(t.calculatedColumns||[]),1])];t.displayEquations={...t.displayEquations,1:`=XLOOKUP(@Temperature,[${water.name}]@Temperature,[${water.name}]@${prop},"-")`};t.equations={...t.equations,1:t.displayEquations[1]};}
 const press=get('schedule-pressurization-types');press.lockedColumns=[];press.identityColumns=[];press.autoColumns=[0,1];add(press,'Default Type','','text');add(press,'Default Ratio');press.hiddenColumns=[2,3];press.rows.forEach(r=>{r[2]=r[0];r[3]=r[1];});
 const dhw=get('femp-shw-calculator');rename(dhw,'Hot-Water Demands Table');add(dhw,'Source','','text');add(dhw,'Reference Row Status','','text');dhw.referencePolicy='hotwater';dhw.referenceMarkerColumn=4;dhw.hiddenColumns=[4];dhw.displayColumnOrder=[3,0,1,2,4];dhw.identityColumns=[];dhw.lockedColumns=[3,4];dhw.frozenColumns=0;dhw.fixedReferences=INDEPENDENT_REFERENCE_TEXT[dhw.id]=HOT_WATER_REFERENCES;dhw.rows=[...ASHRAE_HOT_WATER_ROWS.map(r=>[...r,'ASHRAE','standard']),...dhw.rows.map(r=>[r[0],r[1],r[2],'NLR','standard'])];get('calc-dhw').dropdownColumns[1]={sourceTableId:dhw.id,sourceColumn:0,choiceKind:'hotwater'};
 const names={'doas-zone':'Constant Ventilation & Zone Conditioning','ahu-oa':'Ventilation/Central Conditioning','ahu-economizing':'Economized Ventilation/Central Conditioning','doas-ahu':'Constant Ventilation & Central Conditioning'};for(const t of independentTables.filter(t=>t.systemAirBalanceMode))rename(t,names[t.systemAirBalanceMode]);
 const ab=get('calc-ahu-oa-air-balance'),source=get('calc-doas-ahu-air-balance');for(const field of ['heatingEquipment','heatingSupply','heatingReturn']){const c=source.balanceFields.indexOf(field),n=add(ab,source.headers[c].label,source.headers[c].unit,source.columnTypes[c]);ab.balanceFields.push(field);ab.headerClasses[n]=red;ab.calculatedColumns.push(n);ab.displayEquations[n]=source.displayEquations[c];ab.headerLinks[n]=source.headerLinks?.[c];}ab.displayEquations[18]='=@[Maximum Supply Airflow (2)]';ab.sectionStartColumns=[...new Set([1,...ab.sectionStartColumns,16])];
 for(const t of independentTables.filter(t=>t.systemAirBalanceMode)){const c=t.balanceFields.indexOf('heatingEquipment');t.exportOptionalHeatingColumns=c<0?[]:[c,c+1,c+2];if(c>=0)t.displayEquations[c+2]=`=@[${t.columns[c+1]}${t.balanceFields.indexOf('maximumSupply')>=0||t.balanceFields.indexOf('centralSupply')>=0||t.balanceFields.indexOf('coolingSupply')>=0?' (2)':''}]`;}
 for(const t of independentTables)for(const field of ['equations','displayEquations'])for(const [c,equation]of Object.entries(t[field]||{}))if(typeof equation==='string')t[field][c]=equation.replaceAll('[FEMP SHW Calculator Table]','[Hot-Water Demands Table]');
 const preheat=get('airside-preheat');preheat.formulaColumnAliases={...preheat.formulaColumnAliases,'Leaving Dry-Bulb':1,'Leaving Hum-Ratio':2};
 const unit=get('airside-in-unit-reheat');unit.displayEquations[5]=unit.displayEquations[5].replace('[Preheat Coils]@Leaving Dry-Bulb',`XLOOKUP(@Equipment,[${get('airside-preheat').name}]@Equipment,[${get('airside-preheat').name}]@Leaving Dry-Bulb,"")`);
}
function initializeThirdUpdateRows(project,table){
 project.thirdUpdateMigrations||={};const id=table.id;let rows=project.independentTables[id];
 if(!project.thirdUpdateMigrations[id]){
  if(id==='schedule-equipment-sensible-gain'){
   const old=rows||(project.newEquipmentDefaults?[]:table.legacyRows.map(r=>[...r]));rows=project.independentTables[id]=[...old.map(r=>{const n=[...r];n[7]=n[7]||'User-Inputs';n[11]='user';n[12]=n[0];return n;}),...table.rows.map(r=>[...r])];
  }else if(id==='femp-shw-calculator'){
   const old=rows||table.rows.filter(r=>r[3]==='NLR');rows=project.independentTables[id]=[...ASHRAE_HOT_WATER_ROWS.map(r=>[...r,'ASHRAE','standard']),...old.map(r=>{const standard=table.rows.some(t=>t[3]==='NLR'&&t[0]===r[0]);return [r[0],r[1],r[2],standard?'NLR':'User-Input',standard?'standard':'user'];})];
  }else if(id==='schedule-grouped-equipment-sensible-gain'){
   if(!rows||JSON.stringify(rows)===JSON.stringify(table.legacyRows))rows=project.independentTables[id]=table.rows.map(r=>[...r]);else for(const r of rows)if(r[5]==null||r[5]==='')r[5]=1;
  }else if(id==='schedule-pressurization-types'){
   rows=project.independentTables[id]=rows||table.rows.map(r=>[...r]);for(const r of rows){const preset=table.rows.find(x=>x[0]===r[0]);if(preset){r[2]=preset[0];r[3]=preset[1];}}project.pressurizationTypesComplete=true;
  }
  if(id==='water-nist-properties'&&rows)rows=project.independentTables[id]=rows.filter(r=>Math.abs(Number(r[0])-211.97)>.00001);
  project.thirdUpdateMigrations[id]=true;
 }
 if(Array.isArray(rows))for(const r of rows)while(r.length<table.columns.length)r.push('');
 if(['schedule-equipment-sensible-gain','femp-shw-calculator','schedule-grouped-equipment-sensible-gain'].includes(id)&&table.schemaVersion)project.independentTableSchemaVersions[id]=table.schemaVersion;
}
function thirdCellLocked(table,row,column){if(table.referencePolicy==='hotwater')return [3,4].includes(column)||row[4]==='standard'&&column!==2;if(table.referencePolicy==='equipment')return [11,12].includes(column)||row[11]==='standard';return null;}
function workbookChoiceRecords(config,project){
 const rows=id=>ensureProjectTableRows(project,independentTables.find(t=>t.id===id));
 let choices=[];
 if(config.choiceKind==='equipment'){
  if(config.includeGroups)for(const r of rows('schedule-grouped-equipment-sensible-gain'))if(r[0])choices.push({value:String(r[0]),label:String(r[0]),group:'Grouped Equipment'});
  for(const r of rows('schedule-equipment-sensible-gain'))if(r[0])choices.push({value:String(r[12]||r[0]),label:String(r[0]),group:r[11]==='standard'?r[7]:'User-Inputs'});
 }else if(config.choiceKind==='hotwater')choices=rows('femp-shw-calculator').filter(r=>r[0]).map(r=>({value:String(r[0]),label:String(r[0]),group:r[3]==='User-Input'?'User-Inputs':r[3]}));
 else if(config.groupBySource)choices=rows(config.sourceTableId).filter(r=>r[0]).map(r=>({value:String(r[config.sourceColumn]),label:String(r[0]),group:r[8]==='User-Input'?'User-Inputs':r[8]}));
 const rank=g=>g==='Grouped Equipment'?0:g==='User-Inputs'?1:g==='ASHRAE'||g==='ASHRAE 62.1'?2:g==='NLR'||g==='IMC'?3:4;
 return choices.sort((a,b)=>rank(a.group)-rank(b.group)||a.group.localeCompare(b.group)||a.label.localeCompare(b.label));
}
function recalculateEquipmentGainSchedule(table,rows,project){
 const detail=ensureProjectTableRows(project,independentTables.find(t=>t.id==='selected-misc-loads')),groups=ensureProjectTableRows(project,independentTables.find(t=>t.id==='schedule-grouped-equipment-sensible-gain')),n=requirementNumber;
 for(const r of rows){r[7]||='User-Inputs';r[12]=r[11]==='standard'?`${r[7]} - ${r[0]}`:r[0];r[5]=(n(r[1])+n(r[2])*3412.142)*(1-n(r[3]))*(r[4]===''||r[4]==null?1:n(r[4]));r[10]=(r[8]===''||r[8]==null)&&(r[9]===''||r[9]==null)?'':n(r[8])+n(r[9])*3412.142;const key=requirementKey(r[12]);r[6]=detail.reduce((s,d)=>s+(requirementKey(d[1])===key?n(d[4]):0),0)+groups.reduce((s,g)=>s+(requirementKey(g[1])===key?detail.reduce((z,d)=>z+(requirementKey(d[1])===requirementKey(g[0])?n(d[4]):0),0)*n(g[5]??1):0),0);}
}
function recalculateGroupedGainScheduleThird(table,rows,project){
 const source=independentTables.find(t=>t.id==='schedule-equipment-sensible-gain'),equipment=ensureProjectTableRows(project,source);recalculateEquipmentGainSchedule(source,equipment,project);const byName=new Map(equipment.map(r=>[requirementKey(r[12]),r])),detail=ensureProjectTableRows(project,independentTables.find(t=>t.id==='selected-misc-loads')),n=requirementNumber;table.autoCellStates=new Map();
 rows.forEach((r,i)=>{if(r[5]===''||r[5]==null)r[5]=1;table.autoCellStates.set(i,new Set(n(r[5])===1?[5]:[]));const equipment=byName.get(requirementKey(r[1]))||[];r[2]=n(equipment[5])*n(r[5]);r[6]=n(equipment[10])*n(r[5]);r[4]=detail.reduce((s,d)=>s+(requirementKey(d[1])===requirementKey(r[0])?n(d[4]):0),0);});for(const r of rows){r[3]=rows.reduce((s,g)=>s+(requirementKey(g[0])===requirementKey(r[0])?n(g[2]):0),0);r[7]=rows.reduce((s,g)=>s+(requirementKey(g[0])===requirementKey(r[0])?n(g[6]):0),0);}
}
function recalculateThirdReferenceTable(table,rows,project){
 if(table.id==='schedule-equipment-sensible-gain'){recalculateEquipmentGainSchedule(table,rows,project);return true;}
 if(/^water-(ethylene|propylene)-/.test(table.id)){const water=independentTables.find(t=>t.id==='water-nist-properties'),source=ensureProjectTableRows(project,water),c=table.id.endsWith('density')?2:8,byTemp=new Map(source.map(r=>[Number(r[0]),r[c]]));for(const r of rows)r[1]=byTemp.get(Number(r[0]))??'-';return true;}
 if(table.id==='schedule-pressurization-types'){table.autoCellStates=new Map();rows.forEach((r,i)=>table.autoCellStates.set(i,new Set([0,1].filter(c=>r[c+2]!==''&&r[c+2]!=null&&r[c]===r[c+2]))));return true;}return false;
}
function plantPropertyFormulaThird(property){
 const water=independentTables.find(t=>t.id==='water-nist-properties');
 const block=kind=>{const t=independentTables.find(t=>t.id===`water-${kind}-${property==='Cp'?'specific-heat':'density'}`),cols=t.headers.map((h,c)=>({c,x:parseFloat(h.label)})).filter(v=>v.c>0&&/^\d+%$/.test(t.headers[v.c].label));
 const values=cols.map(v=>`[${t.name}]@[${t.headers[v.c].label}]`),temps=`[${t.name}]@Temperature`,xs=`VSTACK(${cols.map(v=>v.x).join(',')})`;
 // INTERPOLATE brackets each axis and handles an exact temperature/concentration without division by zero.
 return `LET(x,MAX(0,MIN(100,@Glycol*100)),y,@EWT,temperatures,VSTACK(${temps}),concentrations,${xs},columnValues,VSTACK(${values.map(v=>`INTERPOLATE(temperatures,${v},y)`).join(',')}),INTERPOLATE(concentrations,columnValues,x))`;};
 return `=IF(@Water="TRUE",IF(@Glycol=0,INTERPOLATE([${water.name}]@Temperature,[${water.name}]@${property},@EWT),IF(@Glycol Type="Propylene",${block('propylene')},${block('ethylene')}))${property==='Density'?'/7.48052':''},"")`;
}
// Action deltas allow an undo entry to be reversed without rolling back unrelated edits.
function historyProject(snapshot){return JSON.parse(snapshot).find(p=>p.id===activeProjectId);}
function historyPatch(current,from,to){
 if(JSON.stringify(from)===JSON.stringify(to))return current;
 if(!from||!to||typeof from!=='object'||typeof to!=='object'||Array.isArray(from)!==Array.isArray(to))return structuredClone(to);
 if(Array.isArray(from)&&from.length!==to.length)return structuredClone(to);
 const result=current&&typeof current==='object'?structuredClone(current):Array.isArray(to)?[]:{};
 for(const key of new Set([...Object.keys(from),...Object.keys(to)])){if(key==='changeLog')continue;if(!(key in to))delete result[key];else if(!(key in from))result[key]=structuredClone(to[key]);else result[key]=historyPatch(result[key],from[key],to[key]);}
 return result;
}
function completeHistoryActions(){for(let i=0;i<undoStack.length;i++){const a=undoStack[i];a.afterSnapshot||=undoStack[i+1]?.snapshot||JSON.stringify(projects);}}
function changeLogUndoIds(changeId){const history=activeProject()?.changeLog||[],i=history.findIndex(e=>e.changeId===changeId);return new Set(history.slice(0,i+1).map(e=>e.changeId).filter(id=>undoStack.some(a=>a.changeId===id)));}
function performChangeLogUndo(changeId){
 if(isWorkbookReadOnly()||!ownsProjectControl())return;completeHistoryActions();
 const ids=changeLogUndoIds(changeId),history=[...(activeProject().changeLog||[])],selected=undoStack.filter(a=>ids.has(a.changeId));if(!selected.length)return;
 let current=structuredClone(activeProject());const compensation=new Map(),actions=[];
 for(const a of [...selected].reverse()){
  const from=historyProject(a.afterSnapshot),to=historyProject(a.snapshot);if(!from||!to)continue;
  const before=JSON.stringify(projects.map(p=>p.id===activeProjectId?current:p));current=historyPatch(current,from,to);
  const after=JSON.stringify(projects.map(p=>p.id===activeProjectId?current:p)),id=createProjectId(),original=history.find(e=>e.changeId===a.changeId);
  const message=original?.message||'workbook change',entry={at:new Date().toISOString(),message:/^Undid /i.test(message)?'Redid '+message.slice(6):/^Redid /i.test(message)?'Undid '+message.slice(6):'Undid '+message,changeId:id};compensation.set(a.changeId,entry);actions.push({snapshot:before,afterSnapshot:after,changeId:id});
 }
 for(let i=undoStack.length-1;i>=0;i--)if(ids.has(undoStack[i].changeId))undoStack.splice(i,1);
 undoStack.push(...actions);redoStack.length=0;
 const entries=history.filter(e=>compensation.has(e.changeId)).map(e=>compensation.get(e.changeId));
 restoreProjectHistory(JSON.stringify(projects.map(p=>p.id===activeProjectId?current:p)),{changeLog:[...entries,...history]});
}
function performKeyboardUndo(redo=false){
 if(isWorkbookReadOnly()||!ownsProjectControl())return;completeHistoryActions();const source=redo?redoStack:undoStack,dest=redo?undoStack:redoStack,action=source.pop();if(!action)return;
 const history=[...(activeProject().changeLog||[])];if(!redo)action.logEntry=history.find(e=>e.changeId===action.changeId);
 const current=historyPatch(activeProject(),historyProject(redo?action.snapshot:action.afterSnapshot),historyProject(redo?action.afterSnapshot:action.snapshot));
 const nextHistory=redo?(action.logEntry?[action.logEntry,...history]:history):history.filter(e=>e.changeId!==action.changeId);
 dest.push(action);restoreProjectHistory(JSON.stringify(projects.map(p=>p.id===activeProjectId?current:p)),{changeLog:nextHistory});
}
