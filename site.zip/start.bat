@echo off
cd /d %~dp0
start "IESVE Web App" http://127.0.0.1:8000
py app.py
pause
