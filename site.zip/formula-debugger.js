/* Formula evaluation inspector. Restores the missing Evaluate dialog without
   mutating workbook data or re-running calculations as a side effect. */
(function () {
  function text(value) { return value == null ? '' : String(value); }
  function make(tag, cls, content) {
    const node = document.createElement(tag);
    if (cls) node.className = cls;
    if (content !== undefined) node.textContent = text(content);
    return node;
  }
  function fmt(value) {
    if (typeof value === 'number') return Number.isFinite(value) ? String(value) : 'Not available';
    if (typeof value === 'object') { try { return JSON.stringify(value, null, 2); } catch (_) { return String(value); } }
    return text(value);
  }
  window.openFormulaEvaluator = function openFormulaEvaluator(options = {}) {
    const context = typeof selectedEquationContext !== 'undefined' ? selectedEquationContext : null;
    const equation = text(options.equation || (typeof selectedEquation !== 'undefined' ? selectedEquation.value : '') || context?.equation);
    let dlg = document.getElementById('restored-formula-evaluator');
    if (!dlg) {
      dlg = make('dialog', 'formula-evaluator');
      dlg.id = 'restored-formula-evaluator';
      document.body.appendChild(dlg);
    }
    dlg.replaceChildren();
    const head = make('header');
    head.append(make('h2', '', 'Evaluate Formula'));
    const close = make('button', 'evaluation-close', '\u00d7');
    close.type = 'button'; close.setAttribute('aria-label', 'Close');
    close.addEventListener('click', () => dlg.close());
    head.append(close); dlg.append(head);
    const body = make('div', 'evaluation-layout');
    const left = make('section');
    left.append(make('h3', '', 'Equation'));
    left.append(make('pre', 'evaluation-code', equation || 'No formula selected'));
    const right = make('section');
    right.append(make('h3', '', 'Current calculated result'));
    const result = make('div', 'evaluation-result');
    let value;
    let location = '';
    try {
      if (options.model) {
        value = options.values;
        location = 'Model input';
      } else if (context?.table && Number.isInteger(context.sourceIndex)) {
        const table = context.table;
        const project = typeof activeProject === 'function' ? activeProject() : null;
        const rows = project?.independentTables?.[table.id] || table.rows || [];
        const row = rows[context.sourceIndex];
        value = row?.[context.column];
        location = `${table.title || table.label || table.id} | Row ${context.sourceIndex + 1} | ${table.headers?.[context.column]?.label || 'Column ' + (context.column + 1)}`;
      } else if (context && Object.prototype.hasOwnProperty.call(context, 'value')) {
        value = context.value;
      }
    } catch (error) {
      value = `Could not read current value: ${error.message}`;
    }
    result.append(make('output', '', value === undefined ? 'No calculated result available for this selection.' : fmt(value)));
    right.append(result);
    if (location) right.append(make('p', 'evaluation-location', location));
    right.append(make('p', 'evaluation-help', 'Shows the selected formula and its current workbook result. This inspector does not change or recalculate cells.'));
    body.append(left, right); dlg.append(body);
    const foot = make('footer');
    const copy = make('button', '', 'Copy equation'); copy.type = 'button';
    copy.addEventListener('click', () => navigator.clipboard?.writeText(equation));
    const done = make('button', '', 'Close'); done.type = 'button'; done.addEventListener('click', () => dlg.close());
    foot.append(copy, done); dlg.append(foot);
    if (!dlg.open) dlg.showModal();
  };
})();
