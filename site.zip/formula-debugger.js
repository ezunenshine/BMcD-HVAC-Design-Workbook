/* Formula inspection is deliberately independent of project mutations. */
function formulaDebugColumn(table,name,column=0){
  if(!table)return -1;const key=v=>String(v).replace(/[^a-z0-9]/gi,'').toLowerCase();
  for(const [alias,index] of Object.entries(table.formulaColumnAliases||{}))if(key(alias)===key(name))return index;
  const hits=table.headers.map((h,i)=>key(h.label)===key(name)||key(h.label+(h.subscript||''))===key(name)?i:-1).filter(i=>i>=0);
  const group=table.headerGroups?.find(g=>column>=g.start&&column<g.start+g.span);
  const scope=Object.values(table.formulaScopes||{}).find(([a,b])=>column>=a&&column<b);
  return hits.find(i=>scope?i>=scope[0]&&i<scope[1]:group&&i>=group.start&&i<group.start+group.span)??hits[0]??equationColumnIndex(table,name);
}
function formulaDebugReferences(context){
  const project=activeProject(),table=context.table,rows=table?ensureProjectTableRows(project,table):[],row=rows[context.sourceIndex]||[],refs=new Map();
  const add=(name,value)=>refs.set(name,value);
  const model={...modelInputDefaults,...project?.modelInputs},computed=modelInputCalculations(model);
  for(const [name,value] of Object.entries(context.values||{})){add('@'+name,value);add('['+name+']',value);}
  for(const [key,value] of Object.entries(model)){add('[Model Inputs]@'+key,value);add('@'+key.replace(/([a-z])([A-Z])/g,'$1 $2'),value);}
  for(const [name,value] of Object.entries({'Barometric Pressure':computed.pressure,'Elevation':model.elevation,'Cooling Dry-Bulb':model.coolingDb,'Cooling Hum-Ratio':computed.coolingHr,'Heating Dry-Bulb':model.heatingDb,'Heating Hum-Ratio':computed.heatingHr,'Dehumidification Dry-Bulb':model.dehumidificationDb,'Dehumidification Hum-Ratio':computed.dehumidificationHr}))add('[Model Inputs]@'+name,value);
  if(table){
    const visible=new Set([...referenceTable.querySelectorAll('tbody tr[data-source-index]')].map(r=>Number(r.dataset.sourceIndex)));
    for(const name of [...table.headers.map(h=>h.label),...Object.keys(table.formulaColumnAliases||{})]){const col=formulaDebugColumn(table,name,context.column);if(col<0)continue;add('@'+name,row[col]);const values=rows.filter((_,i)=>!context.summary||visible.has(i)).map(r=>r[col]);add('['+name+']',values);add('[@'+name+']',values);}
    add('[Visible Rows]',rows.map((_,i)=>visible.has(i)));
  }
  const expression=context.equation||'';
  for(const source of independentTables){
    for(const name of [source.id,source.name,source.standard,...source.aliases||[]]){
      if(!expression.includes('['+name+']@'))continue;const data=ensureProjectTableRows(project,source);
      for(const label of [...source.headers.map(h=>h.label),...Object.keys(source.formulaColumnAliases||{})]){const col=formulaDebugColumn(source,label,source===table?context.column:0);if(col>=0){add('['+name+']@'+label,data.map(r=>r[col]));add('['+name+']@['+label+']',data.map(r=>r[col]));}}
    }
  }
  return refs;
}
function evaluateDebugFormula(expression,refs=new Map(),steps=[]){
  const source=String(expression).trim().replace(/^=/,''),tokens=[],names=[...refs.keys()].sort((a,b)=>b.length-a.length);let i=0;
  while(i<source.length){if(/\s/.test(source[i])){i++;continue;}
    if(source[i]==='"'){let value='';i++;let closed=false;while(i<source.length){if(source[i]==='"'){if(source[i+1]==='"'){value+='"';i+=2;continue;}i++;closed=true;break;}value+=source[i++];}if(!closed)throw Error('Missing closing quote');tokens.push({type:'value',value});continue;}
    const ref=names.find(n=>source.slice(i,i+n.length).toLowerCase()===n.toLowerCase()&&!/[a-z0-9_]/i.test(source[i+n.length]||''));if(ref){tokens.push({type:'ref',value:ref});i+=ref.length;continue;}
    const number=source.slice(i).match(/^(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?/i);if(number){tokens.push({type:'value',value:Number(number[0])});i+=number[0].length;continue;}
    const word=source.slice(i).match(/^[A-Za-z_][A-Za-z0-9_.]*/);if(word){tokens.push({type:'name',value:word[0]});i+=word[0].length;continue;}
    const op=source.slice(i).match(/^(?:>=|<=|<>|!=|==|[+\-*/^&=><(),%])/);if(op){tokens.push({type:op[0],value:op[0]});i+=op[0].length;continue;}
    throw Error('Cannot resolve '+source.slice(i, i+65));
  }
  let pos=0;const take=t=>{if(tokens[pos]?.type!==t)throw Error('Expected '+t);return tokens[pos++];};
  const precedence={'=':1,'==':1,'<>':1,'!=':1,'<':1,'>':1,'<=':1,'>=':1,'&':2,'+':3,'-':3,'*':4,'/':4,'^':5};
  function parse(min=0){let node,t=tokens[pos++];if(!t)throw Error('Expected a value');
    if(t.type==='value'||t.type==='ref')node=t;
    else if(t.type==='+'||t.type==='-')node={type:'unary',op:t.type,node:parse(6)};
    else if(t.type==='('){node=parse();take(')');}
    else if(t.type==='name'){if(tokens[pos]?.type==='('){pos++;const args=[];if(tokens[pos]?.type!==')'){args.push(parse());while(tokens[pos]?.type===','){pos++;args.push(parse());}}take(')');node={type:'call',name:t.value.toUpperCase(),args};}else node=t;}
    else throw Error('Expected a value');
    while(tokens[pos]?.type==='%'){pos++;node={type:'binary',op:'/',left:node,right:{type:'value',value:100}};}
    while(precedence[tokens[pos]?.type]>=min){const op=tokens[pos++].type;node={type:'binary',op,left:node,right:parse(precedence[op]+(op==='^'?0:1))};}return node;
  }
  const ast=parse();if(pos!==tokens.length)throw Error('Unexpected '+tokens[pos].value);
  const flat=v=>Array.isArray(v)?v.flat(Infinity):[v],num=v=>{if(v===''||v==null||v==='-')return 0;const n=Number(v);if(!Number.isFinite(n))throw Error('Not numeric: '+v);return n;};
  const pair=(a,b,fn)=>Array.isArray(a)||Array.isArray(b)?Array.from({length:Math.max(flat(a).length,flat(b).length)},(_,i)=>fn(Array.isArray(a)?flat(a)[i]:a,Array.isArray(b)?flat(b)[i]:b)):fn(a,b);
  const eq=(a,b)=>String(a??'').toLowerCase()===String(b??'').toLowerCase();
  const criteria=(v,c)=>{const m=String(c).match(/^(>=|<=|<>|>|<|=)(.*)$/);if(!m)return eq(v,c);const a=Number.isFinite(Number(v))?Number(v):String(v),b=Number.isFinite(Number(m[2]))?Number(m[2]):m[2];return {'>':a>b,'<':a<b,'>=':a>=b,'<=':a<=b,'<>':!eq(a,b),'=':eq(a,b)}[m[1]];};
  function run(node,env={}){
    if(node.type==='value')return node.value;
    if(node.type==='ref'){const value=refs.get(node.value);steps.push({label:node.value,value});return value;}
    if(node.type==='name'){const name=node.value.toUpperCase();if(name==='TRUE')return true;if(name==='FALSE')return false;if(name in env)return env[name];throw Error('Unknown name '+node.value);}
    if(node.type==='unary'){const value=run(node.node,env);return pair(value,node.op==='-'?-1:1,(a,b)=>num(a)*b);}
    if(node.type==='binary'){const a=run(node.left,env),b=run(node.right,env);return pair(a,b,(x,y)=>{switch(node.op){case '+':return num(x)+num(y);case '-':return num(x)-num(y);case '*':return num(x)*num(y);case '/':if(num(y)===0)throw Error('Division by zero');return num(x)/num(y);case '^':return num(x)**num(y);case '&':return String(x??'')+String(y??'');case '=':case '==':return eq(x,y);case '<>':case '!=':return !eq(x,y);case '>':return x>y;case '<':return x<y;case '>=':return x>=y;case '<=':return x<=y;}});}
    const {name,args}=node;let value;
    if(name==='IF'){value=run(args[run(args[0],env)?1:2]||{type:'value',value:''},env);}
    else if(name==='IFERROR'){try{value=run(args[0],env);}catch{value=run(args[1],env);}}
    else if(name==='LET'){const scope={...env};for(let k=0;k<args.length-1;k+=2){if(args[k].type!=='name')throw Error('LET requires a name');scope[args[k].value.toUpperCase()]=run(args[k+1],scope);}value=run(args.at(-1),scope);}
    else {const a=args.map(arg=>run(arg,env)),all=flat(a),n=a.map(v=>Array.isArray(v)?v:v);switch(name){
      case 'SUM':value=all.reduce((s,v)=>s+num(v),0);break;case 'N':value=num(a[0]);break;
      case 'MIN':case 'MAX':value=Math[name.toLowerCase()](...all.map(num));break;
      case 'ABS':case 'LN':case 'EXP':case 'SQRT':value=Math[{ABS:'abs',LN:'log',EXP:'exp',SQRT:'sqrt'}[name]](num(a[0]));break;
      case 'ROUND':case 'ROUNDUP':case 'ROUNDDOWN':{const scale=10**num(a[1]||0),v=num(a[0])*scale;value=(name==='ROUND'?Math.round(v):name==='ROUNDUP'?Math.sign(v)*Math.ceil(Math.abs(v)):Math.trunc(v))/scale;break;}
      case 'CEILING':case 'CEILING.MATH':value=Math.ceil(num(a[0])/num(a[1]||1))*num(a[1]||1);break;
      case 'FLOOR':value=Math.floor(num(a[0])/num(a[1]||1))*num(a[1]||1);break;
      case 'AND':value=all.every(Boolean);break;case 'OR':value=all.some(Boolean);break;case 'NOT':value=!a[0];break;
      case 'SUMPRODUCT':value=flat(a[0]).reduce((s,_,i)=>s+a.reduce((p,v)=>p*num(Array.isArray(v)?flat(v)[i]:v),1),0);break;
      case 'COUNTIF':case 'SUMIF':value=flat(a[0]).reduce((s,v,i)=>s+(criteria(v,a[1])?(name==='COUNTIF'?1:num(flat(a[2]??a[0])[i])):0),0);break;
      case 'SUMIFS':value=flat(a[0]).reduce((s,v,i)=>s+(a.slice(1).every((range,k)=>k%2?true:criteria(flat(range)[i],a[k+2]))?num(v):0),0);break;
      case 'XLOOKUP':{const index=flat(a[1]).findIndex(v=>eq(v,a[0]));value=index<0?a[3]??'':flat(a[2])[index];break;}
      case 'FILTER':value=flat(a[0]).filter((_,i)=>flat(a[1])[i]);if(!value.length)value=a[2]??[];break;
      case 'UNIQUE':value=[...new Set(all)];break;case 'VSTACK':case 'TOCOL':value=all;break;
      case 'ROWS':case 'COUNT':value=flat(a[0]).length;break;
      case 'INDEX':value=flat(a[0])[num(a[1])-1];break;
      case 'SUBTOTAL':value=num(a[0])===103?flat(a[1]).filter(v=>v!==''&&v!=null).length:flat(a[1]).reduce((s,v)=>s+num(v),0);break;
      case 'TEXTJOIN':value=flat(a.slice(2)).filter(v=>!a[1]||v!==''&&v!=null).join(a[0]);break;
      case 'TRIM':value=Array.isArray(a[0])?flat(a[0]).map(v=>String(v).trim()):String(a[0]).trim();break;
      case 'TEXTSPLIT':value=String(a[0]).split(a[1]);break;
      case 'COALESCE':value=a.find(v=>v!==''&&v!=null)??'';break;
      case 'WETBULB':value=wetBulbFromState(...a);break;
      case 'SENSIBLECONSTANT':value=airConstantsForState(...a).sensible;break;
      case 'LATENTCONSTANT':value=airConstantsForState(...a).latent;break;
      default:throw Error('Step evaluation is not available for '+name);
    }}
    if(typeof value==='number'&&!Number.isFinite(value))throw Error('Non-finite result in '+name);
    steps.push({label:name,value});return value;
  }
  return run(ast);
}
function openFormulaEvaluator(explicit){
  document.querySelector('.formula-evaluator')?.remove();
  const context={...(explicit||selectedEquationContext||{}),equation:explicit?.equation||selectedEquationContext?.equation||selectedEquation.value};
  const dialog=document.createElement('dialog');dialog.className='formula-evaluator';dialog.setAttribute('aria-labelledby','evaluation-title');
  const head=document.createElement('header'),title=document.createElement('h2'),close=document.createElement('button');title.id='evaluation-title';title.textContent='Evaluate Formula';close.type='button';close.className='evaluation-close';close.textContent='×';close.setAttribute('aria-label','Close evaluator');head.append(title,close);
  const main=document.createElement('div');main.className='evaluation-single';const formula=document.createElement('pre');formula.className='evaluation-code';formula.textContent=context.equation||'No formula selected.';const result=document.createElement('output');result.className='evaluation-result';const detail=document.createElement('pre');detail.className='evaluation-code';main.append(formula,result,detail);
  const footer=document.createElement('footer'),position=document.createElement('span');position.className='evaluation-position';footer.append(position);
  const steps=[];let final,error;
  const format=value=>typeof value==='string'?JSON.stringify(value):JSON.stringify(value,null,2)??'blank';
  try{
    if(context.table?.apacheControllersCalculation){const rows=ensureProjectTableRows(activeProject(),context.table);recalculateTable(context.table,rows);final=rows[context.sourceIndex]?.[context.column];steps.push({label:'Zone calculation',value:final});}
    else final=evaluateDebugFormula(context.equation,formulaDebugReferences(context),steps);
  }catch(e){error=e.message;}
  let index=0;
  const draw=()=>{const step=steps[index];position.textContent=steps.length?`Step ${index+1} of ${steps.length}`:'Formula';detail.textContent=step?step.label+' → '+format(step.value):'';result.textContent=error?'Evaluation detail: '+error:'Result: '+format(final);result.classList.toggle('is-error',Boolean(error));previous.disabled=index<=0;next.disabled=index>=steps.length-1;};
  const button=(text,fn)=>{const b=document.createElement('button');b.type='button';b.textContent=text;b.onclick=fn;footer.appendChild(b);return b;};
  const previous=button('Previous',()=>{index=Math.max(0,index-1);draw();}),next=button('Next',()=>{index=Math.min(steps.length-1,index+1);draw();});button('Final',()=>{index=Math.max(0,steps.length-1);draw();});button('Restart',()=>{index=0;draw();});
  if(error&&context.table&&!context.summary){const rows=ensureProjectTableRows(activeProject(),context.table),stored=rows[context.sourceIndex]?.[context.column];const current=document.createElement('p');current.textContent='Workbook calculated value: '+format(stored);main.append(current);}
  close.onclick=()=>dialog.close();dialog.addEventListener('close',()=>dialog.remove());dialog.append(head,main,footer);document.body.appendChild(dialog);draw();dialog.showModal();close.focus();
}
