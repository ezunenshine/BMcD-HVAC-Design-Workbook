/* A read-only formula interpreter. It never executes JavaScript from a formula. */
(() => {
  const flat=x=>Array.isArray(x)?x.flat(Infinity):[x];
  const number=x=>x===''||x==null||x==='-'?0:typeof x==='boolean'?Number(x):Number(x);
  const truth=x=>typeof x==='string'?x.toUpperCase()==='TRUE'||(x!==''&&x!=='-'&&Number(x)!==0&&!Number.isNaN(Number(x))):Boolean(x);
  const same=(a,b)=>String(a??'').toLowerCase()===String(b??'').toLowerCase();
  const broadcast=(fn,a,b)=>Array.isArray(a)||Array.isArray(b)?Array.from({length:Math.max(Array.isArray(a)?a.length:0,Array.isArray(b)?b.length:0)},(_,i)=>broadcast(fn,Array.isArray(a)?a[i]:a,Array.isArray(b)?b[i]:b)):fn(a,b);
  const unary=(fn,a)=>Array.isArray(a)?a.map(v=>unary(fn,v)):fn(a);
  function expand(source,definitions) {
    let result=String(source||'').replace(/^=/,'');
    for(let pass=0;pass<12;pass++) {
      let changed=false;const pattern=/\b([A-Z_][A-Z0-9_]*)\s*\(/gi;let m;
      while((m=pattern.exec(result))) {
        const fn=definitions[m[1].toUpperCase()];if(!fn)continue;
        const start=m.index,open=pattern.lastIndex-1;let depth=1,quote=false,end=open+1,args=[],argStart=end;
        for(;end<result.length;end++) {
          const c=result[end];if(c==='"')quote=!quote;if(quote)continue;
          if(c==='(')depth++;
          if(c===')'){depth--;if(!depth){args.push(result.slice(argStart,end).trim());break;}}
          if(c===','&&depth===1){args.push(result.slice(argStart,end).trim());argStart=end+1;}
        }
        if(depth)throw Error('Unclosed '+m[1]+' call');
        const body=String(fn(args)).replace(/^=/,'');
        const lines=body.split('\n').map(x=>x.trim()).filter(Boolean),assignments=[];let value='';
        for(const line of lines){const a=line.match(/^([\p{L}\p{N}_°]+)\s*=\s*(.+)$/u);if(a){assignments.push(a[1],a[2]);value=a[1];}else value=line;}
        const unfolded=assignments.length?`LET(${assignments.join(',')},${value})`:body;
        result=result.slice(0,start)+'('+unfolded+')'+result.slice(end+1);changed=true;break;
      }
      if(!changed)return result;
    }
    throw Error('Custom function expansion contains a cycle');
  }
  function parse(source,referenceNames=()=>[]) {
    source=String(source).replace(/^=/,'').replace(/(\d)°F\b/g,'$1');let p=0;const tokens=[];
    const bracket=()=>{const start=++p;let depth=1;for(;p<source.length;p++){if(source[p]==='[')depth++;if(source[p]===']'&&!--depth)return source.slice(start,p++);}throw Error('Unclosed reference');};
    const field=scope=>{
      if(source[p]==='[')return bracket();
      const choices=referenceNames(scope).filter(Boolean).sort((a,b)=>b.length-a.length);
      for(const name of choices){if(source.slice(p,p+name.length).toLowerCase()===name.toLowerCase()&&!/[\p{L}\p{N}_]/u.test(source[p+name.length]||'')){p+=name.length;return name;}}
      const start=p;while(p<source.length&&!/[,+*/^&=<>()[\]]/.test(source[p]))p++;
      const raw=source.slice(start,p).trim();if(!raw)throw Error('Missing column name');return raw;
    };
    while(p<source.length){if(/\s/.test(source[p])){p++;continue;}const start=p,c=source[p];
      if(c==='"'){p++;let v='';while(p<source.length){if(source[p]==='"'){if(source[p+1]==='"'){v+='"';p+=2;continue;}p++;break;}v+=source[p++];}tokens.push({type:'literal',value:v,start,end:p});continue;}
      if(c==='['||c==='@'){let scope='',name;if(c==='['){scope=bracket();if(source[p]==='@'){p++;name=field(scope);}else {name=scope;scope='';}}else{p++;name=field('');if(source[p]==='@'){scope=name;p++;name=field(scope);}}tokens.push({type:'ref',scope,name,start,end:p});continue;}
      const n=source.slice(p).match(/^(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?/i);if(n){p+=n[0].length;tokens.push({type:'literal',value:Number(n[0]),start,end:p});continue;}
      const id=source.slice(p).match(/^[\p{L}_][\p{L}\p{N}_.°]*/u);if(id){p+=id[0].length;tokens.push({type:'identifier',value:id[0],start,end:p});continue;}
      const op=source.slice(p,p+2);if(['>=','<=','<>','!=','=='].includes(op)){p+=2;tokens.push({type:op,start,end:p});continue;}
      if('+-*/^&=><(),%'.includes(c)){p++;tokens.push({type:c,start,end:p});continue;}
      throw Error(`Cannot read “${source.slice(p,p+24)}”`);
    }
    tokens.push({type:'end',start:p,end:p});let i=0;const cur=()=>tokens[i],take=t=>{if(cur().type!==t)throw Error(`Expected ${t} at ${cur().start+1}`);return tokens[i++];};
    const precedence={'=':1,'==':1,'<>':1,'!=':1,'<':1,'>':1,'<=':1,'>=':1,'&':2,'+':3,'-':3,'*':4,'/':4,'^':5};
    function primary(){const t=cur();let node;
      if(['+','-'].includes(t.type)){i++;const child=expression(5);node={type:'unary',op:t.type,child,start:t.start,end:child.end};}
      else if(t.type==='literal'||t.type==='ref'){i++;node={...t};}
      else if(t.type==='identifier'){i++;if(cur().type==='('){i++;const args=[];if(cur().type!==')'){args.push(expression(0));while(cur().type===','){i++;args.push(expression(0));}}const end=take(')').end;node={type:'call',name:t.value.toUpperCase(),args,start:t.start,end};}else node={type:'variable',name:t.value,start:t.start,end:t.end};}
      else if(t.type==='('){i++;node=expression(0);take(')');}
      else throw Error(`Expected a value at ${t.start+1}`);
      while(cur().type==='%'){node={type:'percent',child:node,start:node.start,end:tokens[i++].end};}return node;
    }
    function expression(min){let left=primary();while((precedence[cur().type]||0)>min){const op=tokens[i++].type,level=precedence[op],right=expression(op==='^'?level-1:level);left={type:'binary',op,left,right,start:left.start,end:right.end};}return left;}
    const ast=expression(0);if(cur().type!=='end')throw Error(`Unexpected text at ${cur().start+1}`);return {ast,source};
  }
  function evaluate(parsed,resolve) {
    const steps=[];const record=(node,value,depth,extra={})=>{steps.push({expression:parsed.source.slice(node.start,node.end),value,depth,...extra});return value;};
    const criterion=(v,c)=>{if(typeof c!=='string')return same(v,c);const m=c.match(/^(<>|>=|<=|>|<|=)(.*)$/);if(m){const a=Number.isNaN(Number(m[2]))?String(v):number(v),b=Number.isNaN(Number(m[2]))?m[2]:Number(m[2]);return ({'<>':()=>!same(a,b),'=':()=>same(a,b),'>':()=>a>b,'<':()=>a<b,'>=':()=>a>=b,'<=':()=>a<=b})[m[1]]();}return same(v,c);};
    const numericList=xs=>flat(xs).filter(x=>x!==''&&x!=null&&x!=='-'&&!Number.isNaN(number(x))).map(number);
    function walk(n,env=new Map(),range=false,depth=0){let v,extra={};
      if(n.type==='literal')return n.value;
      if(n.type==='variable'){if(env.has(n.name.toLowerCase()))v=env.get(n.name.toLowerCase());else if(['TRUE','FALSE'].includes(n.name.toUpperCase()))v=n.name.toUpperCase()==='TRUE';else {const result=resolve('',n.name,range);v=result.value;extra.reference=result;}return record(n,v,depth,extra);}
      if(n.type==='ref'){const result=resolve(n.scope,n.name,range);return record(n,result.value,depth,{reference:result});}
      if(n.type==='unary'||n.type==='percent'){const x=walk(n.child,env,range,depth+1);v=unary(a=>n.type==='percent'?number(a)/100:n.op==='-'?-number(a):number(a),x);}
      if(n.type==='binary'){const a=walk(n.left,env,range,depth+1),b=walk(n.right,env,range,depth+1);v=broadcast((x,y)=>{switch(n.op){case '+':return number(x)+number(y);case '-':return number(x)-number(y);case '*':return number(x)*number(y);case '/':if(number(y)===0)throw Error('Division by zero');return number(x)/number(y);case '^':return number(x)**number(y);case '&':return String(x??'')+String(y??'');case '=':case '==':return same(x,y);case '<>':case '!=':return !same(x,y);case '>':return x>y;case '<':return x<y;case '>=':return x>=y;case '<=':return x<=y;}},a,b);}
      if(n.type==='call'){
        const f=n.name,args=n.args,at=(i,r=range)=>walk(args[i],env,r,depth+1);
        if(f==='IF'){const c=at(0);if(Array.isArray(c)){const a=at(1),b=args[2]?at(2):false;v=c.map((x,i)=>truth(x)?Array.isArray(a)?a[i]:a:Array.isArray(b)?b[i]:b);}else v=truth(c)?at(1):args[2]?at(2):false;}
        else if(f==='IFERROR'){try{v=at(0);if(flat(v).some(x=>typeof x==='number'&&!Number.isFinite(x)))throw Error('Nonfinite result');}catch(error){steps.push({expression:'IFERROR: '+error.message,value:'Using fallback',depth:depth+1});v=at(1);}}
        else if(f==='LET'){const local=new Map(env);for(let i=0;i<args.length-1;i+=2){const name=args[i].name;if(!name)throw Error('LET requires a variable name');const value=walk(args[i+1],local,range,depth+1);local.set(name.toLowerCase(),value);record(args[i],value,depth+1,{label:`Set ${name}`});}v=walk(args.at(-1),local,range,depth+1);}
        else if(['SUMIF','COUNTIF','SUMIFS','COUNTIFS'].includes(f)){
          if(f==='SUMIF'||f==='COUNTIF'){const values=flat(at(0,true)),c=at(1,false),sums=f==='COUNTIF'?values:args[2]?flat(at(2,true)):values;const total=k=>values.reduce((sum,x,i)=>sum+(criterion(x,k)?f==='COUNTIF'?1:number(sums[i]):0),0);v=Array.isArray(c)?c.map(total):total(c);}
          else {const sums=f==='SUMIFS'?flat(at(0,true)):null,start=sums?1:0,pairs=[];for(let i=start;i<args.length;i+=2)pairs.push([flat(at(i,true)),at(i+1,false)]);v=(sums||pairs[0][0]).reduce((sum,x,i)=>sum+(pairs.every(([xs,c])=>criterion(xs[i],c))?sums?number(x):1:0),0);}
        }
        else if(f==='XLOOKUP'){const key=at(0,false),xs=flat(at(1,true)),ys=flat(at(2,true)),get=k=>{const i=xs.findIndex(x=>same(x,k));if(i>=0)return ys[i];return args[3]?at(3,false):(()=>{throw Error('XLOOKUP did not find '+k);})();};v=Array.isArray(key)?key.map(get):get(key);}
        else if(f==='FILTER'){const xs=flat(at(0,true)),include=flat(at(1,true));v=xs.filter((_,i)=>truth(include[i]));if(!v.length)v=args[2]?at(2,false):[];}
        else {
          const allRange=['SUM','SUMPRODUCT','MAX','MIN','AVERAGE','UNIQUE','ROWS','COUNTA','SUBTOTAL','TEXTJOIN'].includes(f);
          const a=args.map((_,i)=>at(i,allRange?true:range));
          const math=(fn)=>unary(x=>fn(number(x)),a[0]);
          switch(f){
            case 'SUM':v=numericList(a).reduce((n,x)=>n+x,0);break;
            case 'MAX':v=Math.max(0,...numericList(a));if(numericList(a).length)v=Math.max(...numericList(a));break;
            case 'MIN':v=numericList(a).length?Math.min(...numericList(a)):0;break;
            case 'AVERAGE':{const x=numericList(a);if(!x.length)throw Error('AVERAGE has no numeric values');v=x.reduce((n,x)=>n+x,0)/x.length;break;}
            case 'SUMPRODUCT':{let x=a[0];for(const next of a.slice(1))x=broadcast((x,y)=>number(x)*number(y),x,next);v=numericList(x).reduce((n,x)=>n+x,0);break;}
            case 'N':v=math(x=>x);break;case 'ABS':v=math(Math.abs);break;case 'SQRT':v=math(Math.sqrt);break;case 'EXP':v=math(Math.exp);break;case 'LN':v=math(Math.log);break;case 'LOG10':v=math(Math.log10);break;case 'ATAN':v=math(Math.atan);break;
            case 'ROUND':case 'ROUNDDOWN':case 'ROUNDUP':{const k=10**number(a[1]||0);v=unary(x=>{const n=number(x)*k;return (f==='ROUNDDOWN'?Math.trunc(n):f==='ROUNDUP'?Math.sign(n)*Math.ceil(Math.abs(n)):Math.sign(n)*Math.round(Math.abs(n)))/k;},a[0]);break;}
            case 'CEILING':case 'CEILING.MATH':case 'FLOOR':case 'FLOOR.MATH':{const k=number(a[1]??1);v=math(x=>(f.startsWith('CEILING')?Math.ceil(x/k):Math.floor(x/k))*k);break;}
            case 'AND':v=flat(a).every(truth);break;case 'OR':v=flat(a).some(truth);break;case 'NOT':v=unary(x=>!truth(x),a[0]);break;
            case 'ISNUMBER':v=unary(x=>typeof x==='number'&&Number.isFinite(x),a[0]);break;
            case 'UNIQUE':v=[...new Set(flat(a[0]))];break;case 'ROWS':v=flat(a[0]).length;break;case 'COUNTA':v=flat(a).filter(x=>x!==''&&x!=null).length;break;
            case 'SUBTOTAL':v=number(a[0])===103?flat(a.slice(1)).filter(x=>x!==''&&x!=null).length:numericList(a.slice(1)).reduce((n,x)=>n+x,0);break;
            case 'TEXTJOIN':v=flat(a.slice(2)).filter(x=>!truth(a[1])||x!=='').join(String(a[0]));break;
            case 'TEXTSPLIT':v=String(a[0]).split(String(a[1]));break;case 'TOCOL':case 'TOROW':v=flat(a[0]);break;
            case 'TRIM':v=unary(x=>String(x??'').trim(),a[0]);break;case 'LEN':v=unary(x=>String(x??'').length,a[0]);break;
            case 'SUBSTITUTE':v=unary(x=>String(x??'').split(String(a[1])).join(String(a[2])),a[0]);break;
            case 'SEARCH':v=unary(x=>{const i=String(x).toLowerCase().indexOf(String(a[0]).toLowerCase());return i<0?null:i+1;},a[1]);break;
            default:throw Error('No evaluation handler for '+f);
          }
        }
      }
      if(flat(v).some(x=>typeof x==='number'&&!Number.isFinite(x)))throw Error('The expression produces a nonfinite result');
      return record(n,v,depth);
    }
    try{return {value:walk(parsed.ast),steps};}catch(error){steps.push({expression:error.message,error:true,depth:0});return {error:error.message,steps};}
  }
  function format(source){let out='',indent=0,quote=false,brackets=0;const line=()=>{out=out.trimEnd()+'\n'+'  '.repeat(Math.max(0,indent));};for(const c of source){if(c==='"')quote=!quote;if(!quote){if(c==='[')brackets++;if(c===']')brackets--;if(!brackets&&c==='('){out+=c;indent++;line();continue;}if(!brackets&&c===')'){indent--;line();out+=c;continue;}if(!brackets&&c===','){out+=c;line();continue;}}out+=c;}return out;}
  globalThis.WorkbookFormulaDebugger={expand,parse,evaluate,format};
})();
function formulaDebugContext(options={}) {
  const project=activeProject(),table=options.model?null:options.table||selectedEquationContext?.table||independentTables.find(t=>t.id===activeTableId);
  const column=options.column??selectedEquationContext?.column??0,sourceIndex=options.sourceIndex??selectedEquationContext?.sourceIndex??0;
  const rowsOf=t=>project?.independentTables?.[t.id]||t.rows;
  const row=table?rowsOf(table)[sourceIndex]||[]:[];
  const norm=s=>String(s??'').replace(/[^a-z0-9]/gi,'').toLowerCase();
  const aliases={'Space Loads':'calc-room-loads','Space Condition Setpoints':'calc-space-condition-setpoints','Equipment Zoning':'calc-equipment-zoning','Ventilation Cooling Coils':'airside-ventilation-cooling','Ventilation Cooling Coil':'airside-ventilation-cooling','Room Air Cooling Coils':'airside-room-cooling','Room Air Cooling Coil':'airside-room-cooling','Preheat Coil':'airside-preheat','Airflows':'airside-airflows','Settings':'airside-settings','Peak Airflows':'calc-peak-airflows','Air Balancing Requirements':'calc-air-balancing-requirements','Latent Loads':'calc-latent-loads','Plant':table?.coilCalculation?.includes('cooling')?'cooling-plant':'heating-plant'};
  const namedTable=scope=>{const id=aliases[scope];return independentTables.find(t=>t.id===id)||independentTables.find(t=>[t.name,t.standard].some(n=>norm(n)===norm(scope)));};
  const columnAliases=t=>{
    if(!t)return {};
    if(t.id==='calc-room-loads')return {'Cooling Latent Load':13,'Sensible Cooling Load':7,'Heating Load':17};
    if(t.id==='calc-space-condition-setpoints')return {'Cooling Hum-Ratio':10,'Heating Hum-Ratio':5,'Cooling Setpoint':8,'Heating Setpoint':3};
    if(t.id==='calc-peak-airflows')return {'Primary Cooling Peak':4,'Primary Heating Peak':10,'Secondary Heating Peak':17};
    if(t.equipmentAirflowsCalculation)return {'Maximum Supply Airflow':1,'Minimum Occupied Supply Airflow':2,'Minimum Unoccupied Supply Airflow':3,'Design Cooling Airflow':4,'Design Heating Airflow':5,'Maximum Return Airflow':6,'Minimum Occupied Return Airflow':7,'Minimum Unoccupied Return Airflow':8};
    if(t.id==='calc-air-balancing-requirements')return {'Ventilation':10,'Relief':11};
    if(t.coilCalculation?.includes('cooling'))return {'Leaving Dry-Bulb':9,'Leaving Hum-Ratio':11,'Leaving Latent Constant':14,'Leaving Sensible Constant':13,'Dehumidification Dry-Bulb':3,'Dehumidification Hum-Ratio':5,'Dehumidification Latent Constant':8,'Dehumidification Rel-Hum':4};
    return {};
  };
  const groups=t=>[...(t?.headerGroups||[]),...Object.entries(t?.formulaScopes||{}).map(([label,[start,end]])=>({label,start,span:end-start}))];
  const groupFor=(t,scope)=>groups(t).find(g=>norm(g.label)===norm(scope))||groups(t).find(g=>norm(g.label).includes(norm(scope)));
  function findColumn(t,name,scope='',current=false){
    const normalized=norm(name),alias=Object.entries(columnAliases(t)).find(([a])=>norm(a)===normalized);if(alias)return alias[1];
    if(current&&t.coilCalculation){
      const cooling=t.coilCalculation.includes('cooling'),room=t.coilCalculation==='room-air-heating';
      const enter=cooling?column>=33?33:column>=24?24:15:room||column>=11&&column<=16?11:5;
      const leave=cooling?column>=24&&column<=32?3:9:1;
      const relative={'enteringdb':enter,'enteringdrybulb':enter,'enteringhr':enter+1,'enteringhumratio':enter+1,'enteringsensibleconstant':enter+3,'enteringlatentconstant':enter+4,'leavingdb':leave,'leavingdrybulb':leave,'leavinghr':cooling?leave+2:2,'leavinghumratio':cooling?leave+2:2,'leavingsensibleconstant':cooling?leave+4:4,'leavinglatentconstant':leave+5};
      if(normalized in relative)return relative[normalized];
      if(normalized==='totalcapacity')return cooling?44:17;
    }
    const group=scope?groupFor(t,scope):current?groups(t).find(g=>column>=g.start&&column<g.start+g.span):null;
    let candidates=t.headers.map((h,i)=>({h,i})).filter(({h})=>[h.label,`${h.label} [${h.unit||''}]`,`${h.label}${h.subscript||''}`].some(x=>norm(x)===normalized));
    if(!candidates.length && ['drybulb','db','humratio','hr'].includes(normalized))candidates=t.headers.map((h,i)=>({h,i})).filter(({h})=>norm(h.label).includes(['db','drybulb'].includes(normalized)?'drybulb':'humratio'));
    if(group){const within=candidates.filter(({i})=>i>=group.start&&i<group.start+group.span);if(within.length)candidates=within;}
    if(!candidates.length)throw Error(`Cannot resolve ${scope?`[${scope}]`:t.name}@${name}`);
    if(current){const previous=candidates.filter(({i})=>i<=column);if(previous.length)return previous.at(-1).i;}
    return candidates[0].i;
  }
  const model={...modelInputDefaults,...project?.modelInputs},calculated=modelInputCalculations(model);
  const modelValues={'UFC':model.ufc,'Climate Zone':model.climateZone,'Barometric Pressure':calculated.pressure,'Elevation':model.elevation,'Cooling Design Dry-Bulb':model.coolingDb,'Cooling Design Hum-Ratio':calculated.coolingHr,'Heating Design Dry-Bulb':model.heatingDb,'Heating Design Hum-Ratio':calculated.heatingHr,'Dehumidification Design Dry-Bulb':model.dehumidificationDb,'Dehumidification Design Hum-Ratio':calculated.dehumidificationHr};
  const locals={...modelValues,...options.values};
  function referenceNames(scope){const t=namedTable(scope)||table;return [...(t?.headers||[]).flatMap(h=>[h.label,h.unit?`${h.label} [${h.unit}]`:'']),...Object.keys(columnAliases(t)),...Object.keys(locals),'Entering Sensible Constant','Entering Latent Constant','Entering DB','Entering HR','Entering Dry-Bulb','Entering Hum-Ratio','Leaving DB','Leaving HR','Leaving Dry-Bulb','Leaving Hum-Ratio','Total Capacity','HR [gr/lb]'];}
  function resolve(scope,name,range){
    const normalized=norm(name),local=Object.keys(locals).find(k=>norm(k)===normalized);
    if((!scope||scope==='Model Inputs')&&local!==undefined)return {value:locals[local],label:name};
    if(scope==='Model Inputs')throw Error('Model input not found: '+name);
    if(!scope && /^(ventilation|supply|exhaust)minimum$/.test(normalized))return {value:airflowMinimum(project,table.id,normalized.startsWith('supply')?50:25)};
    let t=namedTable(scope),isGroup=!t&&scope&&groupFor(table,scope);if(!t)t=table;
    if(!t)throw Error('Select a table cell to resolve '+name);
    const c=findColumn(t,name,isGroup?scope:'',t===table);
    let records=rowsOf(t);
    if(options.summary&&t===table){const indexes=[...referenceTable.querySelectorAll('tbody tr')].map(r=>Number(r.dataset.sourceIndex));records=indexes.map(i=>rowsOf(t)[i]).filter(Boolean);}
    if(range&&!isGroup&&(scope||options.summary))return {value:records.map(r=>r[c]),label:`${t.name}: ${name}`};
    let index=sourceIndex;
    if(t!==table){
      let key=Number.isInteger(table?.spaceColumn)?row[table.spaceColumn]:row[0];
      if(t.plantCalculation && table?.coilCalculation)key=row[table.coilCalculation.includes('cooling')?45:table.coilCalculation==='preheat'?11:18];
      if(t.airsideSection&&Number.isInteger(table?.spaceColumn)){
        const zones=rowsOf(independentTables.find(x=>x.id==='calc-equipment-zoning')),z=zones.find(r=>sameDebug(r[2],key));
        key=t.id==='airside-ventilation-cooling'?z?.[3]:t.id==='airside-room-cooling'?z?.[9]||z?.[4]:key;
      }
      const keyColumn=t.spaceColumn??0;index=records.findIndex(r=>sameDebug(r[keyColumn],key));
    }
    if(index<0)return {value:'',label:`No matching row in ${t.name}`};
    return {value:records[index]?.[c]??'',table:t,column:c,sourceIndex:index,label:`${t.name} · ${name}`};
  }
  return {project,table,column,sourceIndex,row,referenceNames,resolve};
}
function sameDebug(a,b){return String(a??'').trim().toLowerCase()===String(b??'').trim().toLowerCase();}
function openFormulaEvaluator(options={}) {
  document.querySelector('.formula-evaluator')?.remove();
  options={...(selectedEquationContext?.summary?{summary:true}:{}),...options};
  const initialEquation=options.equation??selectedEquation.value;if(!initialEquation)return;
  const dialog=document.createElement('dialog');dialog.className='formula-evaluator';dialog.setAttribute('aria-label','Evaluate formula');
  dialog.innerHTML='<header><div><h2>Evaluate formula</h2><p class="evaluation-location"></p></div><button type="button" class="evaluation-close" aria-label="Close evaluator">×</button></header><div class="evaluation-layout"><section><h3>Expanded formula</h3><pre class="evaluation-code"></pre></section><section class="evaluation-trace"><h3>Evaluation steps</h3><div class="evaluation-result" aria-live="polite"></div><ol class="evaluation-steps"></ol></section></div><footer><span class="evaluation-position"></span><button type="button" data-action="restart">Restart</button><button type="button" data-action="previous">← Previous</button><button type="button" data-action="next">Next →</button><button type="button" data-action="in">Step In ↓</button><button type="button" data-action="out">Step Out ↑</button><span class="evaluation-help">Esc to close</span></footer>';
  const frames=[];let frame;
  const display=v=>Array.isArray(v)?`[${v.slice(0,30).map(display).join(', ')}${v.length>30?`, … (${v.length} values)`:''}]`:v===''?'(blank)':v===null?'not found':typeof v==='number'?Number(v.toPrecision(12)).toString():String(v);
  const enter=(eq,contextOptions)=>{
    const context=formulaDebugContext(contextOptions);let expanded=eq,result;
    try{expanded=WorkbookFormulaDebugger.expand(eq,formulaFunctionDefinitions);const parsed=WorkbookFormulaDebugger.parse(expanded,context.referenceNames);result=WorkbookFormulaDebugger.evaluate(parsed,context.resolve);}catch(error){result={error:error.message,steps:[{expression:error.message,error:true,depth:0}]};}
    if(!result.steps.length)result.steps.push({expression:expanded,value:result.value,depth:0});
    frame={eq,context,contextOptions,expanded,result,index:0};frames.push(frame);render();
  };
  const render=()=>{
    const step=frame.result.steps[frame.index];dialog.querySelector('.evaluation-location').textContent=frame.context.table&&!frame.contextOptions.values?`${frame.context.table.name} · ${frame.context.table.headers[frame.context.column]?.label||''} · ${frame.context.row[frame.context.table.spaceColumn??0]||''}`:'Model Inputs';
    dialog.querySelector('.evaluation-code').textContent=WorkbookFormulaDebugger.format(frame.expanded);
    const result=dialog.querySelector('.evaluation-result');result.replaceChildren();result.classList.toggle('is-error',Boolean(step.error));const title=document.createElement('strong');title.textContent=step.error?'Evaluation stopped':step.label||step.reference?.label||'Resolve expression';const expr=document.createElement('code');expr.textContent=step.expression;const value=document.createElement('output');value.textContent=step.error?'This reference or expression could not be evaluated. Review the formula and its source.':display(step.value);result.append(title,expr,value);
    const list=dialog.querySelector('.evaluation-steps');list.replaceChildren();frame.result.steps.forEach((s,i)=>{const li=document.createElement('li'),b=document.createElement('button');b.type='button';b.textContent=`${s.label||s.expression} ${s.error?'':`→ ${display(s.value)}`}`;b.classList.toggle('current-step',i===frame.index);b.classList.toggle('error-step',Boolean(s.error));b.setAttribute('aria-current',i===frame.index?'step':'false');b.addEventListener('click',()=>{frame.index=i;render();});li.appendChild(b);list.appendChild(li);});list.querySelector('.current-step')?.scrollIntoView({block:'nearest'});
    dialog.querySelector('.evaluation-position').textContent=`Step ${frame.index+1} of ${frame.result.steps.length}${frames.length>1?` · depth ${frames.length}`:''}`;
    dialog.querySelector('[data-action="previous"]').disabled=frame.index===0;dialog.querySelector('[data-action="next"]').disabled=frame.index>=frame.result.steps.length-1;
    dialog.querySelector('[data-action="out"]').disabled=frames.length===1&&!frame.result.steps.slice(frame.index+1).some(s=>s.depth<step.depth);
  };
  const act=action=>{
    const steps=frame.result.steps,current=steps[frame.index];
    if(action==='previous')frame.index=Math.max(0,frame.index-1);
    if(action==='next')frame.index=Math.min(steps.length-1,frame.index+1);
    if(action==='restart')frame.index=0;
    if(action==='in'){
      const ref=current.reference,t=ref?.table,eq=t&&(t.cellDisplayEquations?.get(ref.sourceIndex)?.get(ref.column)||t.displayEquations?.[ref.column]||t.equations?.[ref.column]);
      if(eq&&frames.length<12){enter(eq,{table:t,column:ref.column,sourceIndex:ref.sourceIndex});return;}
      for(let i=frame.index-1;i>=0;i--){if(steps[i].depth>current.depth){while(i>0&&steps[i-1].depth>current.depth)i--;frame.index=i;break;}}
    }
    if(action==='out'){if(frames.length>1){frames.pop();frame=frames.at(-1);}else{const next=steps.findIndex((s,i)=>i>frame.index&&s.depth<current.depth);if(next>=0)frame.index=next;}}
    render();
  };
  dialog.querySelector('.evaluation-close').addEventListener('click',()=>dialog.close());dialog.addEventListener('close',()=>dialog.remove());dialog.querySelectorAll('[data-action]').forEach(b=>b.addEventListener('click',()=>act(b.dataset.action)));
  dialog.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();e.stopPropagation();dialog.close();}else if(['ArrowRight','ArrowLeft'].includes(e.key)){e.preventDefault();e.stopPropagation();act(e.key==='ArrowRight'?'next':'previous');}});
  document.body.appendChild(dialog);dialog.showModal();enter(initialEquation,options);dialog.querySelector('[data-action="next"]').focus();
}
