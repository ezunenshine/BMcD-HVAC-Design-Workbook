# HVAC Design Workbook v3.185.0 — completion report

Built from the supplied v3.184.0 website. The application, assets, calculations, and original Evaluate implementation are retained. `formula-debugger.js` is byte-for-byte unchanged from that baseline (SHA-256 `3e2b39f21a12e3c2ebf9ef2f0bcb68849023106df9cbd06e00882b7e0df819e2`).

## Implemented and tested with automated models or generated files

These results are automated model, DOM-adapter, native-file, and source checks. They are not browser acceptance results.

| Requirement | Source change / resulting behavior | Verification |
|---|---|---|
| PB-01, PB-02 | Rename/Delete share bold dimensions, padding, border, radius, and independent blue/red hover styles; excluded from global button restyling. Rename dialog has one “Rename Project Number” heading. | Syntax/source checks; browser appearance pending. |
| PB-04 | New projects immediately receive all built-in frozen Thermal Templates. Existing/custom rows are preserved. Built-in names cannot be edited and their rows cannot be removed. Grouped Equipment and construction exceptions remain. | Preload, protection, no-overwrite, and import regression assertions. |
| PB-08 | Pointer movement (throttled to once per second), clicks, keys, selection, and input reset Activity. No project save or heartbeat is triggered by pointer movement. | Event-registration and 500-event activity model; ownership timer regressions. |
| PB-09, PB-10 | Authenticated acknowledgments still require matching project, owner, and token; failures do not reset the timer. Fifteen-second heartbeat, 60-second disconnect release, and 30-minute inactivity release are retained. Pending edits are preserved before View Only. | Mock service ownership/timeout tests and editing-state tests. Actual backend/client behavior remains incomplete/unverified below. |
| MI-02 | Heating design humidity ratio initializes to 0.0 gr/lb with green automatic styling; existing nonzero manual values remain. | Calculation/configuration regressions and source checks. |
| MI-05 | Design weather columns have equal flexible widths; units use a second header line and words are not split. | Source checks; browser width/layout pending. |
| MI-06, SC-01 | Source imports remain project-specific. A wholly empty Space Condition input row initializes once from its current IESVE data as blue manual inputs. Later imports do not replace saved temperatures/RH or refill cleared inputs. No imported lookup equations appear in those manual cells. Ventilated rise logic and calculated humidity/enthalpy/volume remain. | Import/reimport, partial-row, blank/manual, migration, formula, and project-isolation tests. |
| GA-02, additional 12 | Shared editor clears underlying text while editing, anchors the input to its own cell, restores visibility, commits once, and shows the saved value after recalculation. Manual People starts blank and remains editable. | People, Equipment, and Lighting editor adapters; commit/Escape, JSON reopen, and downstream gain calculations. Actual typing/overlays pending in browser. |
| GA-04, GA-05 | MET defaults expose per-row literals such as `=4.0`; overrides remain blue/project-specific and feed Thermal Templates and CO₂. Thermal MET no longer has a hyperlink. | All activity defaults, override/reload, thermal/CO₂ and equation regressions. |
| AF-02, AF-03 | Airflows Ventilation uses the existing `ventilation-header` token; every Exhaust group/column uses `exhaust-header`. | Exact class/configuration assertions; calculation regressions. |
| PC-07 | “MIXED-AIR” reference block uses single-line humidity and enthalpy equations. The V dot is drawn above the glyph; native PDF circle support preserves the dot. | Six SVG elevations, six-page native vector PDF, text/symbol checks, visual PDF review. |
| PC-08 | Calculation view uses normal column flow, independent table/chart sizing, chart spacing, and horizontal overflow for narrow widths. Existing print chart bounds are retained. | Source/layout-model checks; actual overlap and responsive behavior remain browser-unverified. |
| CO-01 | CO₂ criteria use a shared validated setter and stable focus/change path, compact rounded bold inputs, and green/default versus blue/override styling. Page Excel button, historical explanation, and extra header reference row are removed. | All three actual focus/input/change callbacks with DOM adapters, invalid-input preservation, recalculation, JSON reopen; actual browser crash reproduction pending. |
| CO-07 | Appendix D initializes in the ordinary References panel, stays editable/removable, supports Restore, and does not replace additional project references. | Reference initialization/customization assertions; export model. |
| CO-08 | CO₂ PDF exports remain portrait and sort by Space. CO₂ Excel is available inside the existing Export window, respects its filters, sorts by Space, and puts the reference in a References section. | Export model sorting/filter path; real generated XLSX/PDF parsed with openpyxl/pypdf. Download clicks pending. |
| Additional 8 | Heartbeat is directly below Open Export Window, with a white outline heart. Read-only/archive/deleted timers show --:--; deleted heart is broken and does not pulse. Active pulse follows one-second countdown boundaries. | State/countdown/pulse models; browser appearance pending. |
| Additional 9 | Construction controls alone use + and − in a left gutter; Assembly aligns with the other fields. | Source checks; browser alignment pending. |
| Additional 10 | Equipment gain density becomes grey while Detailed Equipment Gains is present; value/override remains and normal color returns when cleared. | Mute-state and value-preservation assertions; PDF text-color path. |
| Additional 11 | Thermal Template replaces Space Type; Number of Spaces refers to the new name. Legacy aliases/lookups remain supported. | Column/alias/count/evaluator and thermal regressions. |
| Additional 13 | Room/Zone importer reads all worksheets, accepts single-row or legacy merged sensible-percent/Btu/h headers, keeps the first data row, carries group/zone names, converts explicitly labeled kW/MBH/W, and rejects missing headers or invalid numeric values. | Generated native XLSX integration plus positive/negative parsing fixtures. Exact reported workbook unavailable. |
| Additional 14 | Browser-local explanatory notice removed from the Project Browser; no replacement notice. | Source check. Connectivity itself still honestly reports Unavailable without a server. |
| Additional 15 | Fourth CO₂ ventilation fallback returns dash when empty. Missing, zero, or invalid ventilation makes People/Space/Alarm concentration return dash; Monitoring Required blank remains blank. | All four lookup sources, zero/missing cases, calculation and original evaluator tests. |
| Additional 16 | Totals removed only from Detailed Equipment Gains, General Exhaust Requirements, Exhaust Equipment Requirements, and Transfer Air. | Explicit table configuration regression; other totals retained. |
| Additional 17, 19 | Add permission is recalculated from the active table and editing state. Disabled state from View Only cannot remain stuck on plants or schedules. Fixed-row tables remain protected. | Both plants, Lighting, Equipment Sensible, General Exhaust, and Exhaust Equipment state-transition models. |
| Additional 18 | Average Baseline Electricity/Natural Gas equations wrap the existing AVERAGE/SUM calculations in IFERROR(..., ""). | Equation assertions and energy/table audits. |
| Additional 20 | New transactional IndexedDB project store loads before the workbook starts. Only changed projects are committed; each keeps its previous durable revision. Legacy localStorage is retained, copied into migration recovery, and the migrated catalog is reread before use. Failed saves keep current data in memory, show a persistent error with Retry/Download recovery, and guard navigation away. Recovery JSON imports as separate projects. Dirty records cannot be replaced by refresh; stale concurrent writes abort. Source schema fallback no longer replaces imported rows with defaults. | Eleven migration/quota/concurrency storage-model checks, 20,000-row (>5 MB) save/reopen, 10,000-room source/schema test, failed-save/View Only preservation, and historical project fixtures. Actual browser IndexedDB/disk-quota behavior pending. |

All 148 distinct assertions passed. The 73-table audit passed in both fresh and imported project contexts; supply-factor and formula diagnostics passed. All 32 JS/MJS files passed syntax checks, all 116 HTML IDs are unique, local resources resolve, and all 41 original application/assets/license files remain. Native XLSX/PDF structural checks passed. Duplicate core assertions executed by dependent suites are counted once.

## Preserved and retested; no rebuild

GL-04 multi-cell paste/cut remains tested with atomic locked-cell rejection, rectangular ranges, and deferred clearing. MX-01 through MX-08 retain six table sections, mass-weighted return HR/enthalpy, cooling/dehumidification outdoor states, mixed states, economizer-dependent coil entering conditions, room mass weighting, and derived dry-bulb. PC-04/05/06/09 retain economizer visibility, independent mixed-air points, dashed mixing/solid coil geometry, and display precision. Automated models pass; pointer/clipboard permissions and visual chart behavior still require browser QA.

## Implemented but not browser-tested

All browser UI changes above, actual CO₂ crash regression, plant/schedule Add clicks, People/Equipment/Lighting typing and blur, native clipboard and Ctrl+X, project switching/reload with real saved data, actual IndexedDB migration/rollback/recovery import, footer animation, responsive chart overlap, export/download clicks, and browser print preview.

Playwright is installed but its Chromium executable is absent. The launch attempt failed with “Executable doesn't exist ... chromium_headless_shell-1234 ...”. No browser run is counted as passing. Native PDF rendering and DOM adapters do not substitute for browser acceptance.

## Still incomplete / cannot verify from supplied materials

- **PB-09 production connectivity:** no authenticated backend endpoint, credentials, or lease/storage service was supplied. The static ZIP cannot provide a real successful server acknowledgment. It continues to show Connectivity Unavailable while editing locally; no success is simulated. The planned corporate Azure project storage is not implemented in this browser-only release.
- **PB-10 actual ownership verification:** live multi-client ownership, Request Control, revocation, lease expiry, inactivity, and real connection-loss release are unverified. Mock service tests pass, but this is not completion of real-system acceptance.
- **Exact Room/Zone workbook regression:** compatibility was repaired for identifiable supported layouts and generated XLSX files; the user's formerly accepted failing Excel file was not supplied, so that exact file remains untested.

## Known issues and operational limits

- Browser storage remains quota-limited and origin-specific. IndexedDB is larger bulk storage, not unlimited storage or server synchronization. Keep the same site origin to see existing projects.
- Original localStorage is intentionally retained for migration recovery; this release does not delete it. If even small local lease/settings writes cannot fit, editing control can fail with an explicit error. Download recovery before clearing any browser data.
- If IndexedDB is unavailable, the smaller localStorage fallback catches quota errors, retains pending changes in the open window, and offers recovery. Closing after an unresolved failed save can still lose in-memory edits; the warning and recovery download are provided for that reason.
- Concurrent stale writes stop with a visible save error. Download recovery, refresh the latest project, and import recovery as a separate project when reconciliation is needed. The application does not silently overwrite the other window.
- Session undo snapshots are bounded to approximately 16 MiB, with at least the newest action retained; the textual change log and explicit archives remain. Large imports may reduce available session undo depth.
- Real saved-project exports, real browser quotas/private mode, and the reported Excel file were not available. No failing automated checks remain, but browser defects cannot be ruled out.

See QA_CHECKLIST.md for manual acceptance and AUTOMATED_TEST_RESULTS.txt for suite results. Extract the entire ZIP together and serve index.html over HTTP/HTTPS.
