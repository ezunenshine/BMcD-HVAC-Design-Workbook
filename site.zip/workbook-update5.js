/* Current schemas preserve stored column positions and user-entered rows. */
function withWorkbookPass(project,fn){const previous=activeCalculationCache;if(previous?.project!==project)activeCalculationCache={project};try{return fn();}finally{activeCalculationCache=previous;}}
function configureWorkbookFifthUpdates(){
 const get=id=>independentTables.find(t=>t.id===id),heat='heating-load-header';
 const settings=get('airside-settings');settings.hiddenColumns=[...new Set([...settings.hiddenColumns,8,9])];
 const ventilation=get('calc-ventilation-exhaust');ventilation.displayEquations[10]='=1.0';ventilation.displayEquations[12]='=IF(AND(@Ventilation Equipment=XLOOKUP(@Space,[Equipment Zoning]@Space,[Equipment Zoning]@Central Equipment,""),XLOOKUP(@Space,[Equipment Zoning]@Space,[Equipment Zoning]@Reheat Coil,"")<>""),0.8,1.0)';
 const econ=get('calc-ahu-economizing-air-balance'),c=econ.headers.length;econ.headers.push({label:'Reheat Coil'});econ.columns.push('Reheat Coil');econ.columnTypes.push('text');econ.balanceFields.push('reheatCoil');econ.calculatedColumns.push(c);econ.headerLinks[c]='calc-equipment-zoning';econ.headerClasses[c]=heat;econ.displayEquations[c]=get('calc-ahu-oa-air-balance').displayEquations[3];econ.displayColumnOrder=[0,1,2,3,4,c,...Array.from({length:12},(_,i)=>i+5)];
 for(const group of econ.headerGroups){group.columns=groupColumns(group);if(group.columns.includes(4))group.columns.splice(group.columns.indexOf(4)+1,0,c);}
 for(const col of [4,5,6,7])econ.headerClasses[col]='space-group-header';
 const af=get('airside-airflows');af.headerGroups.find(g=>g.start===7).label='Relief';
 for(const [label,start]of [['Return',10],['Exhaust',13]]){af.headerGroups.push({label,start,span:3,className:af.headerGroups.find(g=>g.start===7).className});af.sectionStartColumns.push(start);for(let k=0;k<3;k++){const at=start+k;af.headers.push({...af.headers[7+k]});af.columns.push(label+' '+af.headers[7+k].label);af.columnTypes.push('number');af.headerClasses[at]=af.headerClasses[7+k];af.headerLinks[at]=af.headerLinks[7+k];af.zeroDecimalColumns.push(at);if(k===0)af.autoColumns.push(at);else af.calculatedColumns.push(at);af.displayEquations[at]=af.displayEquations[7+k];af.formulaColumnAliases[label+' '+af.headers[7+k].label]=at;}}
 for(let c=1;c<=3;c++)af.displayEquations[c]=supplyPriorityEquation(c);
 for(const id of MULTI_SPACE_TABLES)get(id).whiteLockedColumns=[0];
 for(const table of independentTables){for(const field of ['displayEquations','equations'])if(table[field])for(const c of Object.keys(table[field]))table[field][c]=canonicalFormulaNames(table[field][c]);}

}
function canonicalFormulaNames(formula){if(typeof formula!=='string')return formula;const names=new Map();for(const t of independentTables)for(const alias of t.aliases||[])names.set(alias.toLowerCase(),t.name);return formula.replace(/\[([^\[\]]+)\](?=@)/g,(match,name)=>names.has(name.toLowerCase())?'['+names.get(name.toLowerCase())+']':match);}
function supplyPriorityRules(column){
 const dz='calc-doas-zone-air-balance',oa='calc-ahu-oa-air-balance',econ='calc-ahu-economizing-air-balance',central='calc-doas-ahu-air-balance';
 const three=(id,flow)=>['centralEquipment','supplyValve','reheatCoil'].map(tag=>[id,tag,flow]);
 if(column===1)return [[dz,'ventilationEquipment','occupiedVentilation'],[dz,'coolingEquipment','coolingSupply'],[dz,'heatingEquipment','heatingSupply'],...three(oa,'maximumSupply'),[oa,'heatingEquipment','heatingSupply'],...three(econ,'maximumSupply'),[econ,'heatingEquipment','heatingSupply'],[central,'ventilationEquipment','occupiedVentilation'],...three(central,'centralSupply'),[central,'heatingEquipment','heatingSupply']];
 if(column===2)return [[dz,'ventilationEquipment','occupiedVentilation'],...three(oa,'minimumOccupiedSupply'),...three(econ,'minimumOccupiedSupply'),[central,'ventilationEquipment','occupiedVentilation']];
 return three(oa,'minimumUnoccupiedSupply');
}
function supplyPriorityEquation(column){
 const rules=supplyPriorityRules(column);let result='0';
 for(let i=rules.length-1;i>=0;i--){const [id,key,flow]=rules[i],t=independentTables.find(t=>t.id===id),ref=field=>`[${t.name}]@[${spaceFilterColumnLabel(t,t.balanceFields.indexOf(field))}]`,x=i?'x'+i:'x';const term=column===1&&i===7?"[Airflows]@Design Cooling Airflow":`SUMIF(${ref(key)},@Equipment,${ref(flow)})`;result=`LET(${x},${term},IF(${x}>0,${x},${result}))`;}
 return `=(${result})*IF(XLOOKUP(@Equipment,[Settings]@Equipment,[Settings]@Load Percentage,1)="",1,XLOOKUP(@Equipment,[Settings]@Equipment,[Settings]@Load Percentage,1))`;
}
function supplyPriorityValue(tag,column,sources){if(!tag)return 0;for(const [i,[id,key,flow]]of supplyPriorityRules(column).entries()){const total=column===1&&i===7?(sources.designCooling?.get(tag)??0):(sources[id]||[]).reduce((n,r)=>n+(requirementKey(r[key])===tag?requirementNumber(r[flow]):0),0);if(total>0)return total;}return 0;}
function newWorkbookProject(number){const project={id:createProjectId(),number,blankProject184:true,equationOverrides:{},modelInputs:{heatingHrGr:0},client:'',name:'',date:'',made_by:'',checked_by:'',submittal:'',newEquipmentDefaults:true,newProjectDefaultsFourth:true,independentTables:{'schedule-lighting':[],'schedule-exhaust-equipment':[],'schedule-general-exhaust':[]}};preloadThermalTemplates(project);
 for(const [id,names]of [['cooling-plant',['Chillers']],['heating-plant',['Boilers','Electric Resistance']]]){const table=workbookTable(id);project.independentTables[id]=names.map(name=>[name,...Array(table.headers.length-1).fill('')]);project.independentTableSchemaVersions||={};project.independentTableSchemaVersions[id]=table.schemaVersion;}
 return project;}

function canonicalizeWorkbookFormulaDefinitions(){
 if(localStorage.getItem("hvac-fifth-equation-schema")!=="1"){for(const [id,cols]of [["airside-airflows",[1,2,3]],["calc-ventilation-exhaust",[10,12]]])for(const c of cols)if(equationOverrides[id])delete equationOverrides[id][c];localStorage.setItem("hvac-fifth-equation-schema","1");}

 for(const id of Object.keys(equationOverrides))for(const c of Object.keys(equationOverrides[id]))equationOverrides[id][c]=canonicalFormulaNames(equationOverrides[id][c]);
 localStorage.setItem(EQUATION_OVERRIDES_KEY,JSON.stringify(equationOverrides));
 for(const name of Object.keys(formulaFunctionDefinitions)){const original=formulaFunctionDefinitions[name];if(typeof original==='function')formulaFunctionDefinitions[name]=args=>canonicalFormulaNames(original(args));}
}

let projectRestoreTarget=null;
function isProjectDeleted(){return Boolean(projects.find(p=>p.id===activeProjectId)?.deletedAt);}
function configureProjectNumberDialog(restoring){projectDialog.querySelector('.section-label').textContent=restoring?'RESTORE PROJECT':'NEW PROJECT';projectDialog.querySelector('h2').textContent=restoring?'Project Number already in use. Provide new project number.':'Add a project number';projectDialog.querySelector('.dialog-submit').textContent=restoring?'Restore Project':'Add Project';}
function writeProjectCatalog(){return workbookStorage.save(projects);}
function projectNumberExists(number,exceptId){return projects.some(p=>p.id!==exceptId&&!p.deletedAt&&String(p.number).trim().toLowerCase()===number.trim().toLowerCase());}
function projectListMatches(project,query,showDeleted){if(project.deletedAt&&!showDeleted)return false;return [project.number,project.name,project.client,project.deletedAt?'Deleted: '+archiveTimestamp(project.deletedAt):''].some(v=>String(v||'').toLowerCase().includes(query.trim().toLowerCase()));}
function closeProjectContextMenu(){document.querySelector('#project-context-menu')?.remove();}
function showProjectContextMenu(event,id){event.preventDefault();closeProjectContextMenu();const project=projects.find(p=>p.id===id);if(!project||project.deletedAt)return;
 const menu=document.createElement('div');menu.id='project-context-menu';menu.className='project-context-menu';menu.setAttribute('role','menu');
 for(const [text,action]of [['Rename',()=>renameProjectDialog(id)],['Delete',()=>deleteWorkbookProject(id)]]){const b=document.createElement('button');b.type='button';b.textContent=text;b.setAttribute('role','menuitem');b.onclick=()=>{closeProjectContextMenu();action();};menu.appendChild(b);}
 document.body.appendChild(menu);menu.style.left=Math.max(8,Math.min(event.clientX,window.innerWidth-menu.offsetWidth-8))+'px';menu.style.top=Math.max(8,Math.min(event.clientY,window.innerHeight-menu.offsetHeight-8))+'px';menu.querySelector('button').focus();
}
function renameWorkbookProject(id,number){refreshStoredProjects();const p=projects.find(p=>p.id===id);if(!p||p.deletedAt)return false;const next=number.trim();if(!next||projectNumberExists(next,id))return false;p.number=next;writeProjectCatalog();if(id===activeProjectId){if(viewOnlyProject)viewOnlyProject.number=p.number;fillProjectFields();}renderProjectList();return true;}
function renameProjectDialog(id){const p=projects.find(p=>p.id===id);if(!p||p.deletedAt)return;const dialog=document.createElement('dialog');dialog.className='project-dialog';dialog.innerHTML='<form><h2>Rename Project Number</h2><label><span>Project number</span><input name="number" autocomplete="off"></label><div class="dialog-actions"><button type="button" class="dialog-cancel">Cancel</button><button type="submit" class="dialog-submit">Rename</button></div></form>';document.body.appendChild(dialog);const input=dialog.querySelector('input');input.value=p.number||'';input.addEventListener('input',()=>input.setCustomValidity(''));dialog.querySelector('.dialog-cancel').onclick=()=>dialog.close();dialog.querySelector('form').onsubmit=e=>{e.preventDefault();if(renameWorkbookProject(id,input.value))dialog.close();else{input.setCustomValidity('That project number already exists or is blank.');input.reportValidity();}};dialog.addEventListener('close',()=>dialog.remove());dialog.showModal();input.focus();input.select();}
function deleteWorkbookProject(id){refreshStoredProjects();const project=projects.find(p=>p.id===id);if(!project||project.deletedAt)return;project.deletedAt=new Date().toISOString();expandedArchiveProjects.delete(id);writeProjectCatalog();if(id===activeProjectId){archiveView=null;enterProjectViewOnly('',true);}renderProjectList();}
async function restoreDeletedProject(id,number){refreshStoredProjects();const p=projects.find(p=>p.id===id);if(!p?.deletedAt)return false;const next=String(number??p.number).trim();if(!next||projectNumberExists(next,id))return false;p.number=next;delete p.deletedAt;writeProjectCatalog();projectRestoreTarget=null;selectProject(id);await takeProjectControl();return true;}
async function requestDeletedProjectRestore(){refreshStoredProjects();const p=projects.find(p=>p.id===activeProjectId);if(!p?.deletedAt)return;if(!projectNumberExists(String(p.number),p.id)){await restoreDeletedProject(p.id);return;}projectRestoreTarget=p.id;projectForm.reset();configureProjectNumberDialog(true);projectDialogError.textContent='Project Number already in use. Provide new project number.';projectDialog.showModal();newProjectNumber.focus();}
async function restoreDeletedProjectWithNumber(){const number=newProjectNumber.value.trim();if(!number){projectDialogError.textContent='Enter a project number.';return;}refreshStoredProjects();if(projectNumberExists(number,projectRestoreTarget)){projectDialogError.textContent='Project Number already in use. Provide new project number.';return;}const id=projectRestoreTarget;projectDialog.close();await restoreDeletedProject(id,number);}
function initializeProjectLifecycle(){
 document.querySelector('#show-deleted-projects').addEventListener('change',()=>renderProjectList());
 document.addEventListener('pointerdown',event=>{if(!event.target.closest?.('#project-context-menu'))closeProjectContextMenu();});document.addEventListener('keydown',event=>{if(event.key==='Escape')closeProjectContextMenu();});
}
function controlCountdowns(now=Date.now()){
 const format=ms=>{const s=Math.max(0,Math.ceil(ms/1000));return String(Math.floor(s/60)).padStart(2,'0')+':'+String(s%60).padStart(2,'0');};
 return isWorkbookReadOnly()?{activity:'--:--',connectivity:'--:--'}:{activity:format(CONTROL_IDLE_MS-1000*(Math.floor(now/1000)-Math.floor(lastWorkbookActivity/1000))),connectivity:serverLease?.mode==="local"?format(CONTROL_DISCONNECT_MS-(now-Number(readControlLease()?.at||now))):format(CONTROL_DISCONNECT_MS-1000*(Math.floor(now/1000)-Math.floor(lastHeartbeatSuccess/1000)))};
}
let previousHeartbeatDisplay='';
function updateControlCountdowns(now=Date.now()){
 const state=controlCountdowns(now);for(const key of ['activity','connectivity']){const el=document.querySelector('#'+key+'-countdown');if(el)el.textContent=key[0].toUpperCase()+key.slice(1)+' '+state[key];}
 const key=String(Math.floor(now/1000)),heart=document.querySelector('.editor-heartbeat__heart svg');
 if(heart){heart.classList.toggle('broken-heart',isProjectDeleted());if(isWorkbookReadOnly())heart.classList.remove('beat');}
 if(heart&&previousHeartbeatDisplay&&key!==previousHeartbeatDisplay&&!isWorkbookReadOnly()){heart.classList.remove('beat');void heart.getBoundingClientRect();heart.classList.add('beat');}
 previousHeartbeatDisplay=key;
}

function initializeFifthUpdateRows(project,table){
 if(table.equipmentAirflowsCalculation){for(const row of project.independentTables?.[table.id]||[])if(row.length===10)row.push(...Array(6).fill(''));for(const row of Object.values(table.sourceRows||{}))if(row.length===10)row.push(...Array(6).fill(''));}
}
