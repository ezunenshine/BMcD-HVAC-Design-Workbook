(function initializeXlsxReader(global) {
  const textDecoder = new TextDecoder("utf-8");
  const maximumEntrySize = 64 * 1024 * 1024;

  function findEndOfCentralDirectory(bytes) {
    const minimum = Math.max(0, bytes.length - 65557);
    for (let offset = bytes.length - 22; offset >= minimum; offset -= 1) {
      if (bytes[offset] === 0x50 && bytes[offset + 1] === 0x4b && bytes[offset + 2] === 0x05 && bytes[offset + 3] === 0x06) return offset;
    }
    throw new Error("This file is not a readable Excel workbook.");
  }

  function openZip(arrayBuffer) {
    const bytes = new Uint8Array(arrayBuffer);
    const view = new DataView(arrayBuffer);
    const endOffset = findEndOfCentralDirectory(bytes);
    const entryCount = view.getUint16(endOffset + 10, true);
    let offset = view.getUint32(endOffset + 16, true);
    const entries = new Map();

    for (let entryIndex = 0; entryIndex < entryCount; entryIndex += 1) {
      if (view.getUint32(offset, true) !== 0x02014b50) throw new Error("The Excel workbook ZIP directory is invalid.");
      const flags = view.getUint16(offset + 8, true);
      const method = view.getUint16(offset + 10, true);
      const compressedSize = view.getUint32(offset + 20, true);
      const uncompressedSize = view.getUint32(offset + 24, true);
      const nameLength = view.getUint16(offset + 28, true);
      const extraLength = view.getUint16(offset + 30, true);
      const commentLength = view.getUint16(offset + 32, true);
      const localOffset = view.getUint32(offset + 42, true);
      const name = textDecoder.decode(bytes.slice(offset + 46, offset + 46 + nameLength));
      if (flags & 1) throw new Error("Password-protected Excel workbooks are not supported.");
      entries.set(name, { method, compressedSize, uncompressedSize, localOffset });
      offset += 46 + nameLength + extraLength + commentLength;
    }

    async function readEntry(name) {
      const entry = entries.get(name);
      if (!entry) return null;
      if (entry.uncompressedSize > maximumEntrySize) throw new Error("The selected Excel worksheet is too large to import.");
      const localNameLength = view.getUint16(entry.localOffset + 26, true);
      const localExtraLength = view.getUint16(entry.localOffset + 28, true);
      const start = entry.localOffset + 30 + localNameLength + localExtraLength;
      const compressed = bytes.slice(start, start + entry.compressedSize);
      if (entry.method === 0) return textDecoder.decode(compressed);
      if (entry.method !== 8 || typeof DecompressionStream === "undefined") {
        throw new Error("This browser cannot decompress the Excel workbook.");
      }
      const stream = new Blob([compressed]).stream().pipeThrough(new DecompressionStream("deflate-raw"));
      const decompressed = await new Response(stream).arrayBuffer();
      if (decompressed.byteLength > maximumEntrySize) throw new Error("The Excel workbook contains an oversized worksheet.");
      return textDecoder.decode(decompressed);
    }

    return { entries, readEntry };
  }

  function decodeXml(value) {
    return String(value ?? "")
      .replace(/&lt;/g, "<")
      .replace(/&gt;/g, ">")
      .replace(/&quot;/g, '"')
      .replace(/&apos;/g, "'")
      .replace(/&#(\d+);/g, (_, number) => String.fromCodePoint(Number(number)))
      .replace(/&#x([0-9a-f]+);/gi, (_, number) => String.fromCodePoint(parseInt(number, 16)))
      .replace(/&amp;/g, "&");
  }

  function attribute(source, name) {
    const match = String(source).match(new RegExp(`(?:^|\\s)${name.replace(":", "\\:")}=(?:"([^"]*)"|'([^']*)')`));
    return decodeXml(match?.[1] ?? match?.[2] ?? "");
  }

  function normalizePath(base, target) {
    if (target.startsWith("/")) return target.replace(/^\//, "");
    const parts = `${base}/${target}`.split("/");
    const normalized = [];
    parts.forEach((part) => {
      if (!part || part === ".") return;
      if (part === "..") normalized.pop();
      else normalized.push(part);
    });
    return normalized.join("/");
  }

  function parseRelationships(xml) {
    const relationships = new Map();
    for (const match of String(xml).matchAll(/<(?:\w+:)?Relationship\b([^>]*)\/?\s*>/g)) {
      relationships.set(attribute(match[1], "Id"), attribute(match[1], "Target"));
    }
    return relationships;
  }

  function parseWorkbookSheets(xml, relationships) {
    const sheets = [];
    for (const match of String(xml).matchAll(/<(?:\w+:)?sheet\b([^>]*)\/?\s*>/g)) {
      const relationshipId = attribute(match[1], "r:id");
      const target = relationships.get(relationshipId);
      if (target) sheets.push({ name: attribute(match[1], "name"), path: normalizePath("xl", target) });
    }
    return sheets;
  }

  function parseSharedStrings(xml) {
    if (!xml) return [];
    return [...String(xml).matchAll(/<(?:\w+:)?si\b[^>]*>([\s\S]*?)<\/(?:\w+:)?si>/g)].map((item) => {
      return [...item[1].matchAll(/<(?:\w+:)?t\b[^>]*>([\s\S]*?)<\/(?:\w+:)?t>/g)]
        .map((text) => decodeXml(text[1]))
        .join("");
    });
  }

  function parseCreatedAt(xml) {
    const value = String(xml || "").match(/<(?:\w+:)?created\b[^>]*>([^<]+)<\/(?:\w+:)?created>/)?.[1] || "";
    const date = new Date(decodeXml(value));
    return Number.isFinite(date.getTime()) ? date.toISOString() : "";
  }

  function columnIndex(reference) {
    const letters = String(reference).match(/^[A-Z]+/i)?.[0]?.toUpperCase() || "";
    return [...letters].reduce((total, letter) => total * 26 + letter.charCodeAt(0) - 64, 0) - 1;
  }

  function parseCellValue(attributes, body, sharedStrings) {
    const type = attribute(attributes, "t");
    if (type === "inlineStr") {
      return [...body.matchAll(/<(?:\w+:)?t\b[^>]*>([\s\S]*?)<\/(?:\w+:)?t>/g)]
        .map((text) => decodeXml(text[1]))
        .join("");
    }
    const valueMatch = body.match(/<(?:\w+:)?v\b[^>]*>([\s\S]*?)<\/(?:\w+:)?v>/);
    const value = decodeXml(valueMatch?.[1] ?? "");
    if (type === "s") return sharedStrings[Number(value)] ?? "";
    if (type === "str" || type === "e") return value;
    if (type === "b") return value === "1";
    if (value === "") return "";
    const number = Number(value);
    return Number.isFinite(number) ? number : value;
  }

  function parseWorksheet(xml, sharedStrings) {
    const rows = [];
    for (const rowMatch of String(xml).matchAll(/<(?:\w+:)?row\b([^>]*)>([\s\S]*?)<\/(?:\w+:)?row>/g)) {
      const rowNumber = Number(attribute(rowMatch[1], "r"));
      const row = [];
      for (const cellMatch of rowMatch[2].matchAll(/<(?:\w+:)?c\b([^>]*?)(?:\/\s*>|>([\s\S]*?)<\/(?:\w+:)?c>)/g)) {
        const reference = attribute(cellMatch[1], "r");
        const index = columnIndex(reference);
        if (index >= 0) row[index] = parseCellValue(cellMatch[1], cellMatch[2] || "", sharedStrings);
      }
      rows[Math.max(0, rowNumber - 1)] = row;
    }
    return rows;
  }

  async function read(arrayBuffer, options = {}) {
    const zip = openZip(arrayBuffer);
    const createdAt = parseCreatedAt(await zip.readEntry("docProps/core.xml"));
    const workbookXml = await zip.readEntry("xl/workbook.xml");
    const relationshipsXml = await zip.readEntry("xl/_rels/workbook.xml.rels");
    if (!workbookXml || !relationshipsXml) throw new Error("The Excel workbook structure is incomplete.");
    const relationships = parseRelationships(relationshipsXml);
    const sheetDefinitions = parseWorkbookSheets(workbookXml, relationships);
    const sharedStrings = parseSharedStrings(await zip.readEntry("xl/sharedStrings.xml"));
    const matchingSheets = options.sheetNamePattern
      ? sheetDefinitions.filter((definition) => options.sheetNamePattern.test(definition.name))
      : sheetDefinitions;
    const selectedSheets = matchingSheets.length
      ? matchingSheets
      : options.sheetNamePattern ? sheetDefinitions.slice(0, 1) : sheetDefinitions;
    const sheets = [];
    for (const definition of selectedSheets) {
      const worksheetXml = await zip.readEntry(definition.path);
      if (worksheetXml) sheets.push({ name: definition.name, rows: parseWorksheet(worksheetXml, sharedStrings) });
    }
    return { sheets, createdAt };
  }

  global.XlsxReader = { read };
}(globalThis));
