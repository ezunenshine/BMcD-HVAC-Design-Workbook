/* Import validation and consistent command buttons. */
function tabularImportIssues(headers,rows,columnMap,templateRows){
  const names=new Map();for(const row of rows){const name=String(row[columnMap[tabularColumn.space]]??'').trim(),key=requirementKey(name);if(!names.has(key))names.set(key,{name,ids:[]});names.get(key).ids.push(String(row[columnMap[tabularColumn.id]]??'').trim());}
  const duplicates=[...names.values()].filter(item=>item.ids.length>1);
  const column=headers.findIndex(h=>normalizedTabularHeader(h)==='thermal template');
  const existing=new Set(templateRows.map(r=>thermalTypeKey(r[0]))),missing=new Map();
  if(column>=0)for(const row of rows){const name=String(row[column]??'').trim(),key=thermalTypeKey(name);if(name&&!existing.has(key))missing.set(key,name);}
  return {duplicates,missingTemplates:[...missing.values()]};
}
function showTabularValidationDialog(title,entries,message,actions){
  document.querySelector('#tabular-validation-error')?.remove();
  const dialog=document.createElement('dialog');dialog.id='tabular-validation-error';dialog.className='paste-format-error tabular-validation-error';dialog.setAttribute('aria-labelledby','tabular-validation-title');
  const head=document.createElement('header'),icon=document.createElement('span'),heading=document.createElement('h2');icon.className='import-error-symbol';icon.textContent='!';icon.setAttribute('aria-hidden','true');heading.id='tabular-validation-title';heading.textContent=title;head.append(icon,heading);
  const list=document.createElement('ul');for(const entry of entries){const item=document.createElement('li');item.textContent=entry;list.appendChild(item);}const text=document.createElement('p');text.textContent=message;const footer=document.createElement('div');footer.className='import-error-actions';
  for(const action of actions){const button=document.createElement('button');button.type='button';button.textContent=action.label;button.className='wb-action '+(action.kind||'action-add');button.onclick=()=>{dialog.close();dialog.remove();action.run?.();};footer.appendChild(button);}
  dialog.append(head,list,text,footer);document.body.appendChild(dialog);dialog.showModal();footer.firstElementChild.focus();
}
function validateTabularImport(headers,rows,columnMap,project){
  const template=independentTables.find(t=>t.id==='iesve-thermal-template'),templates=ensureProjectTableRows(project,template),issues=tabularImportIssues(headers,rows,columnMap,templates);
  if(issues.duplicates.length){showTabularValidationDialog('Multiple spaces with the same name',issues.duplicates.map(item=>`${item.name} — Space IDs: ${item.ids.join(', ')}`),'All spaces must have unique names to continue. Correct the source data and paste it again.',[{label:'OK'}]);return false;}
  if(issues.missingTemplates.length){showTabularValidationDialog('Thermal templates not in Thermal Templates',issues.missingTemplates,'All thermal templates must be in the Thermal Templates table to continue. Add the missing templates, complete their values, then paste the space data again.',[
    {label:'Add Thermal Templates',run:()=>{if(isProjectArchive())return;const existing=new Set(templates.map(r=>thermalTypeKey(r[0])));for(const name of issues.missingTemplates){if(existing.has(thermalTypeKey(name)))continue;const row=Array(template.columns.length).fill('');row[0]=name;templates.push(row);existing.add(thermalTypeKey(name));}recalculateTable(template,templates,project);project.thermalTableSearch='';project.thermalTableFilter={field:'col:iesve-thermal-template:0',values:null};saveProjects();openLinkedTable(template.id);}},
    {label:'Cancel',kind:'action-remove'}]);return false;}
  return true;
}
function excludeNonRoomSourceRows(project,table,rows){
  const upload=project.clipboardImports?.[table.id];if(!upload?.rawHeaders||!upload.rawRows)return;
  const column=upload.rawHeaders.findIndex(h=>normalizedTabularHeader(h)==='space sub type');if(column<0)return;
  const id=upload.rawHeaders.findIndex(h=>normalizedTabularHeader(h)==='space id');if(id<0)return;
  const allowed=new Set(upload.rawRows.filter(r=>requirementKey(r[column])==='room').map(r=>requirementKey(r[id])));
  for(let i=rows.length-1;i>=0;i--)if(!allowed.has(requirementKey(rows[i][tabularColumn.id])))rows.splice(i,1);
}
function workbookCommandStyle(button){
  if(button.matches('.cell-dropdown-arrow,.print-filter-toggle,.tree-leaf,.group-link,.group-expander,.project-list-item,.project-archive-item,.column-sort-button,.header-link,.cell-note-flag')||button.closest('#reference-table thead'))return;
  const text=button.textContent.trim().replace(/^[+−-]\s*/,''),id=button.id;let kind='';
  if(button.matches('.construction-add,.add-row-button'))kind='add';
  else if(button.matches('.construction-remove,.remove-row-button'))kind='remove';
  else if(/restore|recover/i.test(text))kind='restore';
  else if(/^(remove|delete|select none|unselect|clear|cancel)\b/i.test(text))kind='remove';
  else if(/^(paste|import)\b/i.test(text)||/^import-|^paste-/.test(id))kind='import';
  else if(/^(export|copy|copied|add|archive|select all|evaluate|restart|previous|next|final|apply|save|ok)\b/i.test(text)||id==='archive-project')kind='add';
  if(!kind)return;button.classList.add('wb-action');for(const name of ['add','remove','restore','import'])button.classList.toggle('action-'+name,name===kind);
}
function initializeWorkbookCommands(){
  const style=root=>{if(root.nodeType!==1)return;if(root.tagName==='BUTTON')workbookCommandStyle(root);root.querySelectorAll('button').forEach(workbookCommandStyle);};style(document.body);
  new MutationObserver(records=>{const changed=new Set();for(const record of records){const parent=record.target.nodeType===1?record.target:record.target.parentElement;const button=parent?.closest('button');if(button)changed.add(button);for(const node of record.addedNodes)if(node.nodeType===1)changed.add(node);}changed.forEach(style);}).observe(document.body,{childList:true,subtree:true,characterData:true});
}
if(typeof document!=='undefined')document.addEventListener('DOMContentLoaded',initializeWorkbookCommands);
