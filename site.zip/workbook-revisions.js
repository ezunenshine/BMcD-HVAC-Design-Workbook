/* Import validation and consistent command buttons. */
function tabularImportIssues(headers,rows,columnMap,templateRows){
  const names=new Map();for(const row of rows){const name=String(row[columnMap[tabularColumn.space]]??'').trim(),key=requirementKey(name);if(!names.has(key))names.set(key,{name,ids:[]});names.get(key).ids.push(String(row[columnMap[tabularColumn.id]]??'').trim());}
  const duplicates=[...names.values()].filter(item=>item.ids.length>1);
  const column=headers.findIndex(h=>normalizedTabularHeader(h)==='thermal template');
  const existing=new Set(templateRows.map(r=>thermalTypeKey(r[0]))),missing=new Map();
  if(column>=0)for(const row of rows){const name=String(row[column]??'').trim(),key=thermalTypeKey(name);if(name&&!existing.has(key))missing.set(key,name);}
  return {duplicates,missingTemplates:[...missing.values()]};
}
function showTabularValidationDialog(title,entries,message,actions){
  document.querySelector('#tabular-validation-error')?.remove();
  const dialog=document.createElement('dialog');dialog.id='tabular-validation-error';dialog.className='paste-format-error tabular-validation-error';dialog.setAttribute('aria-labelledby','tabular-validation-title');
  const head=document.createElement('header'),icon=document.createElement('span'),heading=document.createElement('h2');icon.className='import-error-symbol';icon.textContent='!';icon.setAttribute('aria-hidden','true');heading.id='tabular-validation-title';heading.textContent=title;head.append(icon,heading);
  const list=document.createElement('ul');for(const entry of entries){const item=document.createElement('li');item.textContent=entry;list.appendChild(item);}const text=document.createElement('p');text.textContent=message;const footer=document.createElement('div');footer.className='import-error-actions';
  for(const action of actions){const button=document.createElement('button');button.type='button';button.textContent=action.label;button.className='wb-action '+(action.kind||'action-add');button.onclick=()=>{dialog.close();dialog.remove();action.run?.();};footer.appendChild(button);}
  dialog.append(head,list,text,footer);document.body.appendChild(dialog);dialog.showModal();footer.firstElementChild.focus();
}
function validateTabularImport(headers,rows,columnMap,project){
  const template=independentTables.find(t=>t.id==='iesve-thermal-template'),templates=ensureProjectTableRows(project,template),issues=tabularImportIssues(headers,rows,columnMap,templates);
  if(issues.duplicates.length){showTabularValidationDialog('Multiple spaces with the same name',issues.duplicates.map(item=>`${item.name} — Space IDs: ${item.ids.join(', ')}`),'All spaces must have unique names to continue. Correct the source data and paste it again.',[{label:'OK'}]);return false;}
  if(issues.missingTemplates.length){showTabularValidationDialog('Thermal templates not in Thermal Templates',issues.missingTemplates,'All thermal templates must be in the Thermal Templates table to continue. Add the missing templates, complete their values, then paste the space data again.',[
    {label:'Add Thermal Templates',run:()=>{
      if(isProjectArchive())return;
      orderTableRows(template,templates,templates.map((row,sourceIndex)=>({row,sourceIndex})),project);releaseTableSort(template,project);
      const existing=new Set(templates.map(r=>thermalTypeKey(r[0]))),added=[];
      for(const name of issues.missingTemplates){if(existing.has(thermalTypeKey(name)))continue;const row=Array(template.columns.length).fill('');row[0]=name;added.push(templates.length);templates.push(row);existing.add(thermalTypeKey(name));}
      recalculateTable(template,templates,project);project.thermalTableSearch='';project.thermalTableFilter={field:'col:iesve-thermal-template:0',values:null};saveProjects();openLinkedTable(template.id);
      selectedTableId=template.id;selectedTableRowIndexes=new Set(added);selectedTableCells.clear();renderReferenceTable(template.id,'',{skipRecalculation:true});
      requestAnimationFrame(()=>referenceTable.querySelector(`tbody tr[data-source-index="${added[0]}"]`)?.scrollIntoView({block:'nearest'}));
    }},
    {label:'Cancel',kind:'action-remove'}]);return false;}
  return true;
}
function excludeNonRoomSourceRows(project,table,rows){
  const upload=project.clipboardImports?.[table.id];if(!upload?.rawHeaders||!upload.rawRows)return;
  const column=upload.rawHeaders.findIndex(h=>normalizedTabularHeader(h)==='space sub type');if(column<0)return;
  const id=upload.rawHeaders.findIndex(h=>normalizedTabularHeader(h)==='space id');if(id<0)return;
  const allowed=new Set(upload.rawRows.filter(r=>requirementKey(r[column])==='room').map(r=>requirementKey(r[id])));
  for(let i=rows.length-1;i>=0;i--)if(!allowed.has(requirementKey(rows[i][tabularColumn.id])))rows.splice(i,1);
}
function workbookCommandStyle(button){
  if(button.matches('.cell-dropdown-arrow,.print-filter-toggle,.tree-leaf,.group-link,.group-expander,.project-list-item,.project-archive-item,.column-sort-button,.header-link,.cell-note-flag')||button.closest('#reference-table thead'))return;
  const text=button.textContent.trim().replace(/^[+−-]\s*/,''),id=button.id;let kind='';
  if(button.matches('.construction-add,.add-row-button')||id==='open-print')kind='add';
  else if(button.matches('.construction-remove,.remove-row-button'))kind='remove';
  else if(/restore|recover/i.test(text))kind='restore';
  else if(/^(remove|delete|select none|unselect|clear|cancel)\b/i.test(text))kind='remove';
  else if(/^(paste|import)\b/i.test(text)||/^import-|^paste-/.test(id))kind='import';
  else if(/^(export|copy|copied|add|archive|select all|evaluate|restart|previous|next|final|apply|save|ok)\b/i.test(text)||id==='archive-project')kind='add';
  if(!kind)return;button.classList.add('wb-action');for(const name of ['add','remove','restore','import'])button.classList.toggle('action-'+name,name===kind);
}
function initializeWorkbookCommands(){
  document.addEventListener('pointerdown',event=>{if(!event.target.closest?.('#calculation-documentation'))document.querySelectorAll('.workbook-reference-table .selected-cell').forEach(c=>c.classList.remove('selected-cell'));});
  const style=root=>{if(root.nodeType!==1)return;if(root.tagName==='BUTTON')workbookCommandStyle(root);root.querySelectorAll('button').forEach(workbookCommandStyle);};style(document.body);
  new MutationObserver(records=>{const changed=new Set();for(const record of records){const parent=record.target.nodeType===1?record.target:record.target.parentElement;const button=parent?.closest('button');if(button)changed.add(button);for(const node of record.addedNodes)if(node.nodeType===1)changed.add(node);}changed.forEach(style);}).observe(document.body,{childList:true,subtree:true,characterData:true});
}
if(typeof document!=='undefined')document.addEventListener('DOMContentLoaded',initializeWorkbookCommands);

// Shared single-line editor used by calculation cells and reference cells.
function configureTextCellEditor(cell,{value,label,commit,afterKey}){
  let editor=null;
  const finishEdit=(cancel=false)=>{if(!editor)return;const node=editor,raw=node.value.replace(/[\r\n]+/g,' '),previous=cell.dataset.originalValue;editor=null;node.remove();cell.classList.remove('editing-cell');delete cell.dataset.originalValue;if(!cancel&&raw!==previous)commit(raw);};
  const startEdit=replacement=>{if(isProjectArchive()||editor)return;cell.dataset.originalValue=String(value()??'');editor=document.createElement('input');editor.type='text';editor.className='table-inline-editor';editor.value=String(replacement!==undefined?replacement:value()??'').replace(/[\r\n]+/g,' ');editor.setAttribute('aria-label',label);cell.classList.add('editing-cell');cell.appendChild(editor);
    editor.addEventListener('pointerdown',e=>e.stopPropagation());editor.addEventListener('click',e=>e.stopPropagation());editor.addEventListener('blur',()=>finishEdit());
    editor.addEventListener('paste',e=>{const text=e.clipboardData?.getData('text/plain');if(text==null)return;e.preventDefault();editor.setRangeText(text.replace(/[\r\n]+/g,' '),editor.selectionStart,editor.selectionEnd,'end');});
    editor.addEventListener('keydown',e=>{e.stopPropagation();if(['Enter','Escape','Tab'].includes(e.key)){e.preventDefault();finishEdit(e.key==='Escape');afterKey?.(e);}});
    editor.focus({preventScroll:true});editor.setSelectionRange(editor.value.length,editor.value.length);
  };
  return {startEdit,finishEdit};
}

function weightedCoilRoomCondition(context,equipment,peaks,cooling){
  const key=requirementKey(equipment),states=new Map([...context.setpointsBySpace].map(([name,row])=>[requirementKey(name),row]));let total=0,db=0,rh=0;const spaces=[];
  for(const row of peaks){const weight=cooling?(requirementKey(row[1])===key?Number(row[4])||0:0):(requirementKey(row[6])===key?Number(row[10])||0:0)+(requirementKey(row[14])===key?Number(row[17])||0:0);if(weight<=0)continue;const state=states.get(requirementKey(row[0]));if(!state)continue;const dryBulb=Number(state[cooling?8:3]),relative=Number(state[2]);if(!Number.isFinite(dryBulb)||!Number.isFinite(relative))continue;total+=weight;db+=weight*dryBulb;rh+=weight*relative;spaces.push(row[0]);}
  const dryBulb=total?db/total:0,relativeHumidity=total?rh/total:0;
  return {dryBulb,relativeHumidity,humidityRatio:total?humidityRatioForPressure(dryBulb,relativeHumidity,context.pressure):0,spaces};
}
function roomCoilWeightedFormula(cooling,relative=false){
  const peak='calc-peak-airflows',conditions='calc-space-condition-setpoints',ref=c=>scheduleSourceReference(peak,c);
  const spaces=cooling?`VSTACK(${ref(0)})`:`VSTACK(${ref(0)},${ref(0)})`,equipment=cooling?`VSTACK(${ref(1)})`:`VSTACK(${ref(6)},${ref(14)})`,flow=cooling?`VSTACK(${ref(4)})`:`VSTACK(${ref(10)},${ref(17)})`;
  const formula=`IFERROR(LET(spaces,${spaces},equipment,${equipment},peak,${flow},weights,FILTER(peak,equipment=@Equipment,0),values,XLOOKUP(FILTER(spaces,equipment=@Equipment,""),${scheduleSourceReference(conditions,0)},${scheduleSourceReference(conditions,relative?2:cooling?8:3)},0),SUMPRODUCT(weights,values)/SUM(weights)),0)`;
  return relative?`=HUMIDITYRATIO(@Entering DB,${formula},[Model Inputs]@Barometric Pressure)`:'='+formula;
}
function configureRoomCoilWeightedConditions(){
  for(const [id,cooling] of [['airside-room-cooling',true],['airside-room-heating',false]]){
    const table=independentTables.find(t=>t.id===id);table.displayEquations[cooling?33:11]=roomCoilWeightedFormula(cooling);table.displayEquations[cooling?34:12]=roomCoilWeightedFormula(cooling,true);
    if(!cooling)table.displayEquations[2]='=@Entering HR';
  }
}
