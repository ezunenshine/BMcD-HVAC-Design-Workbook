# HVAC Design Workbook v3.185.0

Updated the v3.184.0 website in place. The original formula-debugger.js is unchanged and its Evaluate trace remains available.

This release implements the static-site handoff changes: transactional project storage with recovery, import/schema preservation, shared editor visibility, one-time blue Space Condition initialization, frozen default Thermal Templates, MET literals, CO₂ editing/criteria/fallbacks/references/export, plant and schedule Add permissions, header colors, heartbeat states, construction controls, totals, energy equation guards, and psychrometric equations/layout.

148 distinct automated assertions passed, plus all-table/formula audits, 32 JavaScript syntax checks, generated Excel/PDF checks, and native PDF visual review. Browser tests could not run because Chromium is unavailable.

Production authenticated connectivity, real multi-client ownership acceptance, and planned Azure storage remain incomplete because no backend was supplied. The exact failing Room/Zone Excel file was not supplied; supported layout fixtures pass. Browser interaction/layout and real IndexedDB behavior require manual QA.

COMPLETION_REPORT.md gives requirement-by-requirement changes, tested versus untested status, incomplete items, and known limitations. QA_CHECKLIST.md lists manual acceptance steps. AUTOMATED_TEST_RESULTS.txt records the automated suite results.
