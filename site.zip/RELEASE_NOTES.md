# HVAC Design Workbook — v3.184.0

Updated from the latest supplied `site(1).zip`. This is the requested complete static website package for manual QA. Browser acceptance testing has not been performed; this package is not represented as browser-verified.

The original `formula-debugger.js` parser, evaluation trace, dialog, and Previous/Next/Restart/Final controls are retained. Its resolver is extended for the new columns, grains display, and imported setpoint equations. It has not been replaced by a simplified inspector. All 41 original application/assets/license files are retained. Application changes are contained in the existing application files and the added `workbook-release.js`; no hosting or Azure configuration was added or changed.

## Implemented changes and before/after checklist

| Handoff | Previous paths / behavior | Delivered changes |
|---|---|---|
| A — selection | Existing table selection, edit, and key handlers | Whole selected rows, purple selected cells, locked/calculated navigation, Shift ranges, locked/conditional Delete protection, selected-row removal from any selected column, native equation text copying, inclusive clipboard ranges, atomic validation, deferred cut, hidden/reordered columns, drag/fill scrolling, canceled/read-only fill protection, and viewport alignment. |
| A — display | Existing sizing, freezing, and positional schemas | Single-line cell sizing; headers wrap at spaces only, including PDF headers; visible display-order frozen offsets and stacked headers; Add row / Remove row(s) labels, including construction controls; full unit-aware equation hover. |
| A — new projects | Existing sample rows and schema migrations | Independent blank manual inputs, no inherited CSV/formula state, preserved two Grouped Equipment seed rows and twelve construction assemblies. Fixed legacy migrations that could restore sample weather/plant inputs. Existing project inputs and overrides use migration paths rather than reset-to-default initialization. |
| A — units | Existing full-precision lb/lb calculations | Every table humidity-ratio display uses gr/lb at 0.1 precision; enthalpy displays whole Btu/lb; specific volume displays 0.1 ft³/lb. Storage remains full-precision lb/lb to preserve saved indices/data. Input, clipboard, formula display, and print boundaries convert once. |
| B — browser | Existing project list and context menu | Active projects default; Show All removed; number-only Rename with blank/duplicate validation; Rename/Delete only in the context menu with blue/red hover states; browser notice is `© ezunenshine | v3.184.0`. |
| B — control/footer | Existing browser-local control and supplied heartbeat reference | View Only on open/switch; local coordination retained; optional authenticated host lease adapter with 15-second heartbeat, 60-second acknowledgment expiry, 30-minute editing inactivity, stale-response guards, and Request Control hook. Compact navy heartbeat footer uses timestamps and pulses only when displayed countdowns change. See the unimplemented server requirement below. |
| C — gains/templates | Existing gain/template engines | Equipment density is genuinely editable with green automatic/default-equivalent values, blue overrides, clearing-to-default, and project persistence. CSV never fills Manual People. Space Type remains editable, number of spaces calculated, first two thermal columns frozen, project-specific templates retained. |
| D — IESVE import | Existing paste validation and source metadata | Yes adds unique missing templates and resumes the original paste; No applies neither templates nor data. Reimport preserves manual people and setpoint overrides. Current Real/Proposed/Baseline source selection and ±0.01 Btu/h comparisons retained. |
| E — ventilation | Existing Ez and ventilation calculations | No Ventilation Requirements returns a dash first for both Ez values, without replacing the existing ventilation minimum calculation. |
| F — setpoints | Existing 10/12-column setpoint records | Current import supplies RH and first/second schedule temperatures through inspectable equations. Separate manual overrides; blank rise; cooling-rise priority; renamed headings; heating/cooling enthalpy and specific volume; appended storage columns with explicit display order. Legacy rows, notes, filters, sort columns, and equation keys migrate before padding. Empty sources stay empty. |
| G — settings | Existing Energy/Econ setting and role checks | Economizer blank/TRUE migration, noncentral locked blank, central-only locked TRUE, combined central/vent editable. CLG/HTG Recirc is allowed; incompatible role duplication warns. Ez numeric-equivalent defaults stay automatic. |
| H — airflows/mixing | Existing airflow and air-balance engines | Ventilation section inserted before Relief; exhaust headers brown; required ventilation hidden while retaining its calculation. New Mixed-Air table follows Airflows with return, two ventilation states, and two mixed states. Uses dry-air mass (`CFM/v`) and explicit errors for missing/zero/invalid active inputs. |
| I — coils | Existing coil capacity, plant, and source logic | Economized ventilation coils use Mixed-Air entering states; other ventilation coils keep design weather. Only room-coil entering sections add/reorder HR, enthalpy, DB. Room and downstream-reheat mixtures now conserve dry-air-mass enthalpy/humidity. Heating/cooling plant dropdown associations and existing plant manual inputs remain intact. |
| J — charts/PDF | Supplied chart background and existing process renderer | Mixed-Air table above the original coil table; mixed-only chart with dashed purple/blue/green processes and independent day endpoints. Solid coil processes retained. Singular coil labels and smaller symbols; supplied background colors, PSIA/elevation labels, dynamic SV range, and reference equations. Screen/PDF mixing uses shared geometry. Native PDFs embed math glyphs and vector fractions; no ASCII substitution. |
| K — Evaluate | Original supplied debugger | Original evaluator preserved, new equations resolve to current-project values, explicit grains conversions, full-precision wet-bulb formula, and native text selection/copy bypasses table interception. Actual button/selection browser tests remain unverified. |
| M — weather | Existing Model Inputs weather grid | Humidification line and redundant lb/lb display removed; Cooling/Dehumidification/Heating use grains plus calculated enthalpy/specific volume; cooling HR uses existing DB/WB at project pressure; invalid weather does not silently become a negative humidity ratio. |
| N — MET/references | Existing occupant heat reference and thermal lookup | All 13 specified MET assumptions, editable effective overrides, Thermal Template MET after latent heat, and protected Appendix D reference rows. |
| O — CO₂ | Existing monitoring and export paths | Exact 13-column table; editable green default criteria 400 ppm / 25 people per 1000 ft² / 10%; effective people and MET; ordered x1/x2/x3/x4 ventilation fallback; economizer 2/3 factor only on a matched source; zero/missing ventilation explicitly invalid. Appendix D source and criteria included in portrait PDF and 13-column portrait-configured Excel. |
| P — supply x7 | Existing Supply Maximum priority equation | Only x7 changes to Airflows Design Cooling Airflow in the displayed equation and calculation. Other priority terms and the existing outer load multiplier remain. |
| L / Q — verification | Required engine and browser acceptance | Automated checks below pass. A manual browser checklist is included because the browser is unavailable here. |

## Automated results

All available scripted suites completed successfully. Distinct model/integration assertions:

| Suite | Passing checks |
|---|---:|
| Core calculation, project independence, persistence, psychrometrics | 19 |
| Import/reimport integration | 6 |
| Clipboard, fill, Delete, native-text scoping, row removal | 19 |
| Lease adapter/local mode, timeouts, display pulse, stale acquisition | 9 |
| Legacy schemas, blanks, unit/column/formula regressions | 8 |
| Final gains/settings/mass mixing/MET/CO₂/plant/formula cases | 25 |
| Frozen-column/header and viewport models | 4 |
| **Total distinct assertions** | **90** |

Additional checks passed: all 73 tables calculate without exceptions for a blank and an imported project (146 table/scenario passes); all 31 JS/MJS files pass syntax; all 115 HTML IDs are unique; direct event targets and HTML-linked local resources resolve; all original files remain; native CO₂ XLSX/PDF, mixed-air PDF, and vector chart PDFs were generated and inspected. Native chart rendering was exercised at 0, 1000, 2000, 4000, 10000, and 15000 ft. CO₂ schema/orientation/source/constants/numeric cells and PDF math text were checked programmatically. Final CO₂/mixed-air pages and all six elevation background pages were visually reviewed as native PDF renders.

Psychrometric numeric checks include independent published PsychroLib IP test cases (0.03% relative tolerance for the specified coefficient choices), six-elevation wet-bulb round trips, full-precision Evaluate agreement, mass/enthalpy conservation, and zero/missing input handling. Repeated core PASS lines in suites that import the fixture do not increase the distinct assertion total.

## Not implemented / not tested

**A real server-side editing lease service is not implemented or bundled.** Static hosting cannot provide atomic, authenticated ownership across different computers. No server or ownership API was supplied. The website retains browser-local editing and an integration adapter, rather than pretending local state or a successful HTML fetch is a server acknowledgment. In static editing mode the Connectivity footer reads **Unavailable**; cross-computer Request Control is unavailable. The authenticated countdown and timeout paths were tested only against a test API model.

The host adapter hook is `window.WorkbookLeaseAPI`, with `acquire`, `heartbeat`, `release`, optional `status`, and optional `requestControl`. Acquire receives projectId/owner/idleMs/disconnectMs and must return acquired/projectId/owner/leaseToken. Heartbeat must return acknowledged/projectId/owner/leaseToken or revoked. Production authentication, atomic ownership, expiry, project persistence, and authorization must be enforced by the host service; the adapter is not a replacement for that service.

**No real browser tests ran.** Playwright launch confirms its Chromium executable is unavailable. No button clicks, actual keyboard/clipboard permissions, drag gestures, real CSS layout, focus behavior, browser print preview, download actions, IndexedDB archive/restore, browser tab concurrency, or server deployment were verified. DOM/interaction/layout models are explicitly not browser tests. No actual user saved-project JSON was supplied; saved-project verification uses synthetic historical records and JSON reloads.

## Known behaviors for QA

- The explicit one-third return / two-thirds ventilation split is a project assumption, not an ASHRAE requirement.
- Supply Maximum retains its outer load multiplier. Because x7 now reads the already scaled Design Cooling Airflow, non-100% settings can multiply that candidate again. Automated checks confirm runtime and displayed formula agree at 50%, 80%, 100%, and 120%; other terms were deliberately preserved as requested.
- Full-precision wet-bulb Evaluate traces contain many bisection steps; the existing Final button jumps to the result. Runtime calculations retain full numeric precision.
- A coupled airflow/coil solve reports INVALID if its convergence limit or input validity checks fail; no unverified fallback state is silently substituted.
- Browser/native-print layout may still expose issues that model and native PDF tests cannot detect. Follow `QA_CHECKLIST.md` before production use.
