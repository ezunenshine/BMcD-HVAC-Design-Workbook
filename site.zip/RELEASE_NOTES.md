# HVAC Design Workbook v3.186.0

Implements the v3.186.0 handoff: local editing/control recovery, compact heartbeat, natural project sorting, positional paste across locked cells, semantic Evaluate behavior, authoritative System Type classification, conditional zoning/exhaust locks, exhaust overlap calculations, VC task/general-valve breakdown and conditional exports, revised Return/Ventilation/Relief/Exhaust calculations, gain activation, template-import navigation, chart equation/layout corrections, and CO₂ main-export integration.

The supplied 139-room Excel file imports unchanged MBH loads. Its kBtu/h labels represent MBH; the destination is MBH, so no multiplication is applied.

The original Evaluate debugger remains in use with semantic input/default support. Existing assets, project storage, calculations, and previous regression coverage are retained. Removed visible columns retain compatibility slots where needed for saved arrays and original engineering calculations.

All runnable automated checks passed; see AUTOMATED_TEST_RESULTS.txt for counts and scope. Browser tests remain blocked by the missing Chromium executable. Future Azure collaboration is outside this release; local Connectivity reads Local rather than faking a server acknowledgment.

COMPLETION_REPORT.md maps every handoff requirement to its implementation and validation. QA_CHECKLIST.md lists the remaining browser acceptance steps. Extract the complete ZIP together and serve index.html over HTTP/HTTPS.
