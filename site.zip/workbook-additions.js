/* Project-owned calculation notes and equipment schedule exports. */
function downloadableCalculation(id){return id==='model-inputs'||String(id).startsWith('psych:')||modules.some(g=>g.group!=='IESVE 2025'&&!/independent/i.test(g.group)&&g.items.some(i=>i[3]===id))&&id!=='airside-schedules';}
function defaultCalculationReferences(id){
  const handbook=['ASHRAE Handbook - Fundamentals, 2025.','NIST Chemistry WebBook.','Load output reports.'];
  if(['cooling-plant','heating-plant','airside-preheat','airside-ventilation-cooling','airside-room-cooling','airside-in-unit-reheat','airside-downstream-reheat','airside-room-heating'].includes(id))return [...handbook,...(['airside-preheat','airside-ventilation-cooling'].includes(id)?['Project weather data.']:[])];
  if(independentTables.find(t=>t.id===id&&(t.energySimulation||t.energySummary)))return ['Integrated Environmental Solutions Virtual Environment 2025','Energy simulation reports.'];
  return ({
    'model-inputs':['Project weather data.','ASHRAE Standard 90.1-2019 - Table G3.1.','ASHRAE Standard 90.1-2019 - Table G3.1.1-3.','ASHRAE Standard 90.1-2019 - Table 5.5.','ASHRAE Standard 90.1-2019 - Table G3.4.'],
    'calc-space-condition-setpoints':['Project weather data.'],
    'calc-dhw':['FEMP SHW calculator.'],
    'calc-lighting-gains':['ASHRAE Standard 90.1-2019 - Table G3.7.','ASHRAE Standard 90.1-2019 - Table 9.6.1.'],
    'calc-people-gains':['ASHRAE Standard 62.1-2016 - Table 6.2.2.1.','ASHRAE Fundamentals-2025 - Chapter 18, Table 4.'],
    'calc-room-loads':['Load output reports.','ASHRAE Standard 90.1-2019 - Table 9.6.1.','ASHRAE Fundamentals-2025 - Chapter 18, Table 4.'],
    'calc-ventilation-exhaust':['ASHRAE Standard 62.1-2016 - Table 6.2.2.1.','ASHRAE Standard 62.1-2016 - Table 6.2.2.2.'],
    'calc-exhaust-requirements':['ASHRAE Standard 62.1-2016 - Table 6.5.'],
    'selected-general-exhaust':['ASHRAE Standard 62.1-2016 - Table 6.5.'],
    'calc-airflow-requirements':['Load output reports.','ASHRAE Fundamentals-2025.'],
    'calc-pressurization':['ASHRAE Standard 62.1-2016 - Section 6.2.4.3.2.','ASHRAE Standard 90.1-2019 - Section 6.5.2.1.'],
    'calc-latent-loads':['Load output reports.','ASHRAE Fundamentals-2025.'],
    'calc-condition-baseline':['ASHRAE Standard 90.1-2019 - Chapter 3.','ASHRAE Standard 90.1-2019 - Table 3.2.','ASHRAE Standard 90.1-2019 - Table G3.1.1-3.'],
    'airside-settings':['ASHRAE Standard 62.1-2016 - Table 6.2.2.2.','ASHRAE Standard 90.1-2019 - Table G3.1.2.6.']
  })[id]||[];
}
function referenceTextKey(value){return String(value??'').trim().replace(/\s+/g,' ');}
function missingCalculationReferences(notes,id){const present=new Set((notes.reference||[]).map(referenceTextKey));return defaultCalculationReferences(id).filter(v=>!present.has(referenceTextKey(v)));}
function restoreCalculationReferences(notes,id){const missing=missingCalculationReferences(notes,id);notes.reference=[...missing,...(notes.reference||[])];return missing.length;}
function ensureCalculationDocumentation(project,id){
  project.calculationDocumentation||={};const notes=project.calculationDocumentation[id]||={reference:[]};notes.reference||=[];notes.reference=notes.reference.map(v=>String(v??'').replace(/[\r\n]+/g,' '));
  if(!notes.defaultsInitialized33){restoreCalculationReferences(notes,id);notes.defaultsInitialized33=true;}
  return notes;
}
function calculationDocumentation(project,id){const notes=ensureCalculationDocumentation(project,id);return {reference:notes.reference.filter(v=>String(v).trim()),assumption:[]};}
function renderCalculationDocumentation(data){
  document.querySelector('#calculation-documentation')?.remove();
  const id=data.view==='psych-chart'?'psych:'+data.equipment:data.table||data.view;if(!downloadableCalculation(id))return;
  const project=activeProject(),notes=ensureCalculationDocumentation(project,id),defaults=new Set(defaultCalculationReferences(id).map(referenceTextKey));
  const root=document.createElement('div');root.id='calculation-documentation';root.className='calculation-documentation';
  const section=document.createElement('section'),heading=document.createElement('div'),title=document.createElement('h3'),add=document.createElement('button'),remove=document.createElement('button'),restore=document.createElement('button'),table=document.createElement('table');
  heading.className='documentation-heading row-actions';title.textContent='References';add.textContent='Add row';remove.textContent='Remove row';restore.textContent='Restore';add.type=remove.type=restore.type='button';add.className='wb-action action-add';remove.className='wb-action action-remove';restore.className='wb-action action-restore';table.className='workbook-reference-table zero-frozen-columns';table.setAttribute('aria-label','References');let selected=-1;
  const updateRestore=()=>{restore.disabled=isProjectArchive()||!missingCalculationReferences(notes,id).length;restore.title=restore.disabled?'All default references are present':'Insert missing default references above existing rows';};
  const choose=(i,cell)=>{clearTableSelection();selected=i;table.querySelectorAll('.selected-cell').forEach(c=>c.classList.remove('selected-cell'));cell.classList.add('selected-cell');remove.disabled=isProjectArchive();};
  const move=(i,delta)=>{const cell=table.querySelector(`tbody tr[data-source-index="${i+delta}"] td[data-column-index="1"]`);if(cell){cell.focus();choose(i+delta,cell);}};
  table.addEventListener('pointerover',e=>hoverTableCell(e,table));table.addEventListener('pointerleave',()=>clearTableHover(table));
  const draw=()=>{
    table.replaceChildren();const head=document.createElement('thead'),tr=document.createElement('tr');for(const value of ['#','References']){const th=document.createElement('th'),content=document.createElement('div'),label=document.createElement('span');th.className='space-group-header';content.className='table-header-content';label.className='column-label';label.textContent=value;content.appendChild(label);th.appendChild(content);tr.appendChild(th);}head.appendChild(tr);const colgroup=document.createElement('colgroup');for(const width of ['38px','auto']){const col=document.createElement('col');col.style.width=width;colgroup.append(col);}const body=document.createElement('tbody');
    notes.reference.forEach((value,i)=>{const row=document.createElement('tr'),num=document.createElement('td'),cell=document.createElement('td');row.dataset.sourceIndex=i;num.dataset.columnIndex=0;cell.dataset.columnIndex=1;num.className='identity-cell numeric-cell';num.textContent=i+1;cell.tabIndex=0;cell.className='editable-cell';cell.textContent=String(value).replace(/[\r\n]+/g,' ');cell.setAttribute('aria-label',`Reference ${i+1}. Type or press F2 to edit`);
      const style=()=>{const auto=defaults.has(referenceTextKey(notes.reference[i]));cell.classList.toggle('auto-populated-cell',auto);cell.title=auto?'Autopopulated reference: '+notes.reference[i]:'User-input reference';paintTableTones(table);};
      const {startEdit}=configureTextCellEditor(cell,{value:()=>notes.reference[i],label:`Reference ${i+1}`,commit:raw=>{notes.reference[i]=raw;cell.textContent=raw;style();updateRestore();saveProjects();},afterKey:e=>{cell.focus({preventScroll:true});choose(i,cell);if(e.key==='Enter'||e.key==='Tab')move(i,e.shiftKey?-1:1);}});cell.startCellEdit=startEdit;
      cell.onclick=()=>{if(selected===i&&cell.classList.contains('selected-cell'))startEdit();else choose(i,cell);};cell.ondblclick=()=>startEdit();num.onclick=()=>{cell.focus();choose(i,cell);};
      cell.onkeydown=e=>{if(e.target!==cell)return;if(e.key==='Enter'||e.key==='ArrowDown'||e.key==='ArrowUp'||e.key==='Tab'){e.preventDefault();move(i,e.key==='ArrowUp'||e.shiftKey?-1:1);}else if(e.key==='F2'){e.preventDefault();startEdit();}else if(['Delete','Backspace'].includes(e.key)&&!isProjectArchive()){e.preventDefault();notes.reference[i]='';cell.textContent='';style();updateRestore();saveProjects();}else if(e.key.length===1&&!e.ctrlKey&&!e.metaKey){e.preventDefault();startEdit(e.key);}};
      row.append(num,cell);body.appendChild(row);style();
    });table.append(colgroup,head,body);paintTableTones(table);remove.disabled=isProjectArchive()||selected<0||selected>=notes.reference.length;add.disabled=isProjectArchive();updateRestore();
  };
  add.onclick=()=>{if(isProjectArchive())return;notes.reference.push('');selected=notes.reference.length-1;saveProjects();draw();const cell=table.querySelector(`tbody tr[data-source-index="${selected}"] td[data-column-index="1"]`);cell.focus();choose(selected,cell);cell.startCellEdit();};
  remove.onclick=()=>{if(isProjectArchive()||selected<0)return;notes.reference.splice(selected,1);selected=-1;saveProjects();draw();};
  restore.onclick=()=>{if(isProjectArchive())return;restoreCalculationReferences(notes,id);selected=-1;saveProjects();draw();};
  heading.append(title,add,remove,restore);section.append(heading,table);root.appendChild(section);draw();
  const anchor=data.view==='psych-chart'?document.querySelector('#psych-chart-view'):data.view==='model-inputs'?modelInputsView:tableView;anchor.after(root);
}
function scheduleHeaderClass(color){return color==='clg blue'?'sensible-cooling-header':color==='htg red'?'heating-load-header':color==='preheat orange'?'preheat-header':'space-group-header';}
function configureEquipmentSchedules(){
  const template=EQUIPMENT_SCHEDULE_TEMPLATE,headers=template.columns.map((c,i)=>{const text=c.label.replace(/\n/g,' ').replace(/\s+/g,' ').trim(),unit=text.match(/\[([^\]]+)\]/)?.[1];return {label:i===0?'Equipment':text.replace(/\s*\[[^\]]+\]/,'').replace(/\bMax\b/g,'Maximum').replace(/\bMin\b/g,'Minimum').replace(/\bOcc\b/g,'Occupied').replace(/\bUnocc\b/g,'Unoccupied'),...(unit?{unit}:{})};});
  const inputs=template.columns.map((c,i)=>/user.?input/i.test(c.instruction)?i:-1).filter(i=>i>=0),calculated=template.columns.map((_,i)=>i).filter(i=>!inputs.includes(i)&&i!==91);
  const table={id:'airside-schedules',name:'Schedules',standard:'Schedules',description:'Equipment schedules populated from airflow and coil calculations.',headers:[...headers,{label:'Instance Key'}],columns:[...headers.map(h=>h.label),'Instance Key'],columnTypes:headers.map((h,i)=>i===0||[9,10,63,64,67,68,74,75,78,79,84,86].includes(i)?'text':'number').concat('text'),rows:[],calculatedColumns:calculated,lockedColumns:[0,93],identityColumns:[0],hiddenColumns:[93],frozenColumns:1,fixedRows:true,airsideSection:true,equipmentScheduleCalculation:true,readonlyEquations:true,autoColumns:[91],summaryColumns:[],zeroDecimalColumns:[1,2,3,4,5,6,7,8,65,66,76,77,83,85,87,88,89,90,92],oneDecimalColumns:headers.map((h,i)=>h.unit==='°F'?i:-1).filter(i=>i>=0),decimalColumns:headers.map((h,i)=>['MBH','GPM','inWC','ftWC'].includes(h.unit)?i:-1).filter(i=>i>=0),headerClasses:Object.fromEntries(template.columns.map((c,i)=>[i,scheduleHeaderClass(c.color)])),headerGroups:template.groups.map(g=>({...g,label:g.start===0?'General':g.label,className:scheduleHeaderClass(template.columns[g.start].color)})),sectionStartColumns:template.groups.map(g=>g.start).slice(1),displayEquations:{91:'=10%',92:'=@Weight * (1 + @Safety Factor)'}};
  table.displayEquations=equipmentScheduleEquations();table.formulaColumnAliases={'Input Weight':90,'Safety Factor':91};
  independentTables.push(table);modules.find(g=>g.group==='Airside Equipment Calculations').items.push(['Schedules','Airside','Equipment airflow, coil, fan, filter, and electrical schedules.',table.id]);
}
function scheduleSourceReference(id,column){
  const t=independentTables.find(t=>t.id===id),h=t.headers[column],g=t.headerGroups?.find(g=>column>=g.start&&column<g.start+g.span);
  const label=t.headers.filter(x=>x.label===h.label).length>1&&g?`${g.label} ${h.label}`:h.label;
  t.formulaColumnAliases||={};t.formulaColumnAliases[label]=column;return `[${t.name}]@${label}`;
}
function scheduleLookup(id,column,key='@Equipment'){return `XLOOKUP(${key},${scheduleSourceReference(id,0)},${scheduleSourceReference(id,column)},"")`;}
function scheduleWaterFormula(coil,cooling,column){const plantId=cooling?'cooling-plant':'heating-plant',offset=cooling?12:10,plantColumn=coil==='airside-preheat'?11:coil.includes('cooling')?45:18,key=scheduleLookup(coil,plantColumn);return `=IF(${scheduleLookup(plantId,offset,key)}="TRUE",${scheduleLookup(plantId,offset+column,key)},"")`;}
function scheduleRoomFormula(cooling,wet=false){
  const balance='calc-doas-zone-air-balance',exhaust='calc-exhaust-requirements',condition='calc-space-condition-setpoints';
  const match=`${scheduleSourceReference(balance,3)}=@Equipment`;
  const spaces=`FILTER(${scheduleSourceReference(balance,0)},${match},"")`,flows=`FILTER(${scheduleSourceReference(balance,4)},${match},0)-XLOOKUP(spaces,${scheduleSourceReference(exhaust,2)},${scheduleSourceReference(exhaust,3)},0)`,db=`XLOOKUP(spaces,${scheduleSourceReference(condition,0)},${scheduleSourceReference(condition,cooling?8:3)},0)`,hr=`XLOOKUP(spaces,${scheduleSourceReference(condition,0)},${scheduleSourceReference(condition,cooling?10:5)},0)`;
  return `IFERROR(LET(spaces,${spaces},airflow,${flows},drybulb,${db},${wet?`ratio,${hr},WETBULB(SUMPRODUCT(drybulb,airflow)/SUM(airflow),SUMPRODUCT(ratio,airflow)/SUM(airflow),[Model Inputs]@Barometric Pressure)`:'SUMPRODUCT(drybulb,airflow)/SUM(airflow)'}),"")`;
}
function scheduleWeightedReturn(tag,cooling,balanceRows,exhaustRows,states,pressure){
  const bySpace=new Map(exhaustRows.map(r=>[requirementKey(r[2]),Number(r[3])||0]));let total=0,db=0,hr=0;
  for(const r of balanceRows){if(requirementKey(r[3])!==tag)continue;const state=states.get(requirementKey(r[0]));if(!state)continue;const weight=(Number(r[4])||0)-(bySpace.get(requirementKey(r[0]))||0);total+=weight;db+=weight*Number(state[cooling?8:3]);hr+=weight*Number(state[cooling?10:5]);}
  return total?[db/total,wetBulbFromState(db/total,hr/total,pressure)]:['',''];
}
function equipmentScheduleEquations(coolingId='airside-ventilation-cooling',enter=15,leave=9,heatingId='airside-room-heating'){
  const eq={0:'=[Settings]@Equipment',91:'=10%',92:'=@Input Weight * (1 + @Safety Factor)'},ref=(id,c)=>'='+scheduleLookup(id,c);
  for(let c=1;c<=8;c++)eq[c]=ref('airside-airflows',c);
  const er=`${scheduleLookup('airside-settings',10)}="ER"`;
  for(const [c,formula] of [[11,'[Model Inputs]@Cooling Design Dry-Bulb'],[12,'[Model Inputs]@Cooling Design Wet-Bulb'],[15,scheduleRoomFormula(true)],[16,scheduleRoomFormula(true,true)],[21,'[Model Inputs]@Heating Design Dry-Bulb'],[22,'WETBULB([Model Inputs]@Heating Design Dry-Bulb,[Model Inputs]@Heating Design Hum-Ratio,[Model Inputs]@Barometric Pressure)'],[25,scheduleRoomFormula(false)],[26,scheduleRoomFormula(false,true)]])eq[c]=`=IF(${er},${formula},"")`;
  for(const [c,source] of [[31,10],[32,5],[33,1],[38,12]])eq[c]=ref('airside-preheat',source);
  eq[36]=scheduleWaterFormula('airside-preheat',false,1);eq[37]=scheduleWaterFormula('airside-preheat',false,2);
  for(const [c,source] of [[40,44],[41,42],[42,enter],[43,enter+2],[44,leave],[45,leave+3],[50,46]])eq[c]=ref(coolingId,source);
  eq[48]=scheduleWaterFormula(coolingId,true,1);eq[49]=scheduleWaterFormula(coolingId,true,2);
  for(const [c,source] of [[52,17],[53,heatingId==='airside-room-heating'?11:5],[54,1],[59,19]])eq[c]=ref(heatingId,source);
  eq[57]=scheduleWaterFormula(heatingId,false,1);eq[58]=scheduleWaterFormula(heatingId,false,2);
  return eq;
}
function loadEquipmentScheduleRows(project,table){
  if(!project)return table.rows;project.independentTables||={};project.scheduleSavedRows||={};
  for(const r of project.independentTables[table.id]||[])project.scheduleSavedRows[r[93]]=[...r];
  const settings=independentTables.find(t=>t.id==='airside-settings'),source=ensureProjectTableRows(project,settings);recalculateAirsideSettings(settings,source,project);const flows=equipmentAirflowMap(project),rows=[];
  for(const setting of source){const flow=flows.get(requirementKey(setting[0]));if(!Number(flow?.[1])&&!Number(flow?.[6]))continue;const quantity=Math.max(0,Math.floor(Number(setting[4])||0));for(let instance=1;instance<=quantity;instance++){const key=requirementKey(setting[0])+'::'+instance,row=project.scheduleSavedRows[key]?[...project.scheduleSavedRows[key]]:Array(94).fill('');row[0]=setting[0];row[93]=key;rows.push(row);}}
  return project.independentTables[table.id]=rows;
}
function recalculateEquipmentSchedule(table,rows,project){
  const owns=!activeCalculationCache;if(owns)activeCalculationCache={project};
  try{const context=coilCalculationContext(project),flows=equipmentAirflowMap(project),maps={};for(const id of ['airside-preheat','airside-ventilation-cooling','airside-room-cooling','airside-in-unit-reheat','airside-downstream-reheat','airside-room-heating']){const t=independentTables.find(t=>t.id===id),rs=ensureProjectTableRows(project,t,context);if(!context.calculatedCoils?.has(id))recalculateCoilTable(t,rs,project,context);maps[id]=new Map(rs.map(r=>[requirementKey(r[0]),r]));}
    const settings=new Map(ensureProjectTableRows(project,independentTables.find(t=>t.id==='airside-settings')).map(r=>[requirementKey(r[0]),r]));
    const plant=(name,cooling)=>{const t=independentTables.find(t=>t.id===(cooling?'cooling-plant':'heating-plant')),r=(project.independentTables?.[t.id]||t.rows).find(r=>requirementKey(r[0])===requirementKey(name)),offset=cooling?12:10;return r&&String(r[offset]).toUpperCase()==='TRUE'?[r[offset+1],r[offset+2]]:['',''];};
    const balanceRows=project.independentTables?.['calc-doas-zone-air-balance']||[],exhaustRows=project.independentTables?.['calc-exhaust-requirements']||[];
    const states=new Map([...context.setpointsBySpace].map(([space,state])=>[requirementKey(space),state]));
    const room=(tag,cooling)=>scheduleWeightedReturn(tag,cooling,balanceRows,exhaustRows,states,context.pressure);
    table.autoCellStates=new Map();table.lockedCellStates=new Map();table.lockedCellMessages=new Map();table.cellDisplayEquations=new Map();project.scheduleDisabledInputs||={};project.scheduleSavedRows||={};
    rows.forEach((r,i)=>{for(const c of table.calculatedColumns)if(c)r[c]='';const key=requirementKey(r[0]),flow=flows.get(key);if(flow)for(let c=1;c<=8;c++)r[c]=flow[c];const sr=room(key,true),wr=room(key,false);r[11]=Number(context.model.coolingDb);r[12]=Number(context.model.coolingWb);r[15]=sr[0];r[16]=sr[1];r[21]=Number(context.model.heatingDb);r[22]=wetBulbFromState(r[21],context.calculated.heatingHr,context.pressure);r[25]=wr[0];r[26]=wr[1];
      const ph=maps['airside-preheat'].get(key);if(ph){r[31]=ph[10];r[32]=ph[5];r[33]=ph[1];[r[36],r[37]]=plant(ph[11],false);r[38]=ph[12];}
      const vc=maps['airside-ventilation-cooling'].get(key),cc=vc||maps['airside-room-cooling'].get(key),coolingId=vc?'airside-ventilation-cooling':'airside-room-cooling',enter=vc?(Number(cc[23])>=Number(cc[32])?15:24):33,leave=enter===24?3:9;
      if(cc){r[40]=cc[44];r[41]=cc[42];r[42]=cc[enter];r[43]=cc[enter+2];r[44]=cc[leave];r[45]=cc[leave+3];[r[48],r[49]]=plant(cc[45],true);r[50]=cc[46];}
      const heatingId=['airside-in-unit-reheat','airside-downstream-reheat','airside-room-heating'].find(id=>maps[id].has(key))||'airside-room-heating',hc=maps[heatingId].get(key);
      if(hc){r[52]=hc[17];r[53]=heatingId==='airside-room-heating'?hc[11]:hc[5];r[54]=hc[1];[r[57],r[58]]=plant(hc[18],false);r[59]=hc[19];}
      const locked=new Set(),messages=new Map(),disable=(from,to,why)=>{for(let c=from;c<=to;c++){locked.add(c);messages.set(c,why);}};
      if(String(settings.get(key)?.[10]).toUpperCase()!=='ER')disable(11,30,'Energy recovery is not selected in Settings.');
      if(!ph)disable(31,39,'No preheat coil is assigned.');if(!cc)disable(40,51,'No cooling coil is assigned.');if(!hc)disable(52,60,'No reheat or heating coil is assigned.');
      const reheat=context.zoningRows.some(z=>requirementKey(z[6])===key)||maps['airside-in-unit-reheat'].has(key)||maps['airside-downstream-reheat'].has(key);
      const supplyEquipment=context.zoningRows.some(z=>[3,4,5].some(c=>requirementKey(z[c])===key));
      if(reheat&&!supplyEquipment)disable(61,71,'Reheat coils do not have a supply fan unless also assigned as ventilation equipment, central equipment or a supply air valve.');
      if(!Number(r[1])){disable(61,71,'No maximum supply airflow.');disable(83,86,'No maximum supply airflow.');}if(!Number(r[6]))disable(72,82,'No maximum return/exhaust airflow.');
      const dormant=project.scheduleDisabledInputs[r[93]]||={};for(let c=1;c<93;c++){if(locked.has(c)){if(!table.calculatedColumns.includes(c)&&!(c in dormant))dormant[c]=r[c];r[c]='';}else if(c in dormant){r[c]=dormant[c];delete dormant[c];}}
      table.lockedCellStates.set(i,locked);table.lockedCellMessages.set(i,messages);table.cellDisplayEquations.set(i,new Map(Object.entries(equipmentScheduleEquations(coolingId,enter,leave,heatingId)).map(([c,e])=>[Number(c),e])));
      if(r[91]===''||r[91]==null)r[91]=.1;table.autoCellStates.set(i,new Set(Number(r[91])===.1?[91]:[]));r[92]=r[90]===''?'':Number(r[90])*(1+Number(r[91]));project.scheduleSavedRows[r[93]]=[...r];
    });
  }finally{if(owns)activeCalculationCache=null;}
}
function configureScheduleExportButton(table){let button=document.querySelector('#export-equipment-schedules');if(!button){button=document.createElement('button');button.id='export-equipment-schedules';button.type='button';button.className='copy-data-button';button.textContent='Export to Excel';copyDataButton.after(button);button.onclick=exportEquipmentSchedules;}button.hidden=!table.equipmentScheduleCalculation;copyDataButton.hidden=pasteDataButton.hidden=Boolean(table.equipmentScheduleCalculation);if(table.equipmentScheduleCalculation)clipboardActions.hidden=false;}
function downloadWorkbookFile(blob,name){const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);}
function exportEquipmentSchedules(){const table=independentTables.find(t=>t.id==='airside-schedules'),rows=projectTableRows(table),visible=[...referenceTable.querySelectorAll('tbody tr[data-source-index]')].map(tr=>rows[Number(tr.dataset.sourceIndex)]);downloadWorkbookFile(equipmentScheduleExcel(visible,visible.map(r=>table.lockedCellStates?.get(rows.indexOf(r)))),'Schedules.xlsx');}
function equipmentScheduleExcel(rows,locks=[]){
  const xml=v=>String(v??'').replace(/[\x00-\x08\x0b\x0c\x0e-\x1f]/g,'').replace(/[<>&"']/g,c=>({'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;',"'":'&apos;'}[c]));
  const letter=n=>{let s='';for(n++;n>0;n=Math.floor((n-1)/26))s=String.fromCharCode(65+(n-1)%26)+s;return s;},template=EQUIPMENT_SCHEDULE_TEMPLATE,colors=['003B8C','0066FF','BD3818','CE6F09'],colorIndex=c=>c==='clg blue'?1:c==='htg red'?2:c==='preheat orange'?3:0;
  const cell=(value,c,r,style)=>`<c r="${letter(c)}${r}" s="${style}"${typeof value==='number'&&Number.isFinite(value)?'><v>'+value+'</v>':' t="inlineStr"><is><t xml:space="preserve">'+xml(value)+'</t></is>'}</c>`;
  const headerRows=[1,2].map(r=>'<row r="'+r+'" ht="'+(r===1?28:48)+'" customHeight="1">'+template.columns.map((c,i)=>cell(r===1?c.top:c.label,i,r,1+colorIndex(c.color))).join('')+'</row>');
  const dataRows=rows.map((row,i)=>'<row r="'+(i+3)+'" ht="20" customHeight="1">'+row.slice(0,93).map((v,c)=>cell(v,c,i+3,locks[i]?.has(c)?5:c===91?(Number(v)===.1?8:9):[19,29].includes(c)?9:/user.?input/i.test(template.columns[c].instruction)?6:5)).join('')+'</row>');
  const sheet=`<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView workbookViewId="0"><pane xSplit="1" ySplit="2" topLeftCell="B3" activePane="bottomRight" state="frozen"/></sheetView></sheetViews><cols>${template.columns.map((c,i)=>`<col min="${i+1}" max="${i+1}" width="${i===0?22:[9,10,63,64,67,68,74,75,78,79,84,86].includes(i)?16:12}" customWidth="1"/>`).join('')}</cols><sheetData>${headerRows.join('')}${dataRows.join('')}</sheetData><mergeCells count="${template.merges.length}">${template.merges.map(m=>`<mergeCell ref="${m}"/>`).join('')}</mergeCells></worksheet>`;
  const styles=`<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Aptos"/></font><font><b/><color rgb="FFFFFFFF"/><sz val="11"/><name val="Aptos"/></font></fonts><fills count="9"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>${[...colors,'E4E9EC','E9F2FF','E5F3E9'].map(c=>`<fill><patternFill patternType="solid"><fgColor rgb="FF${c}"/><bgColor indexed="64"/></patternFill></fill>`).join('')}</fills><borders count="2"><border/><border><left style="thin"><color rgb="FFB9C7D1"/></left><right style="thin"><color rgb="FFB9C7D1"/></right><top style="thin"><color rgb="FFB9C7D1"/></top><bottom style="thin"><color rgb="FFB9C7D1"/></bottom></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="10"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/>${colors.map((_,i)=>`<xf numFmtId="0" fontId="1" fillId="${i+2}" borderId="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>`).join('')}<xf numFmtId="0" fontId="0" fillId="6" borderId="1"/><xf numFmtId="0" fontId="0" fillId="7" borderId="1"/><xf numFmtId="0" fontId="0" fillId="8" borderId="1"/><xf numFmtId="9" fontId="0" fillId="8" borderId="1"/><xf numFmtId="9" fontId="0" fillId="7" borderId="1"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>`;
  const files={'[Content_Types].xml':'<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>','_rels/.rels':'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>','xl/workbook.xml':'<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Schedules" sheetId="1" r:id="rId1"/></sheets></workbook>','xl/_rels/workbook.xml.rels':'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>','xl/worksheets/sheet1.xml':sheet,'xl/styles.xml':styles};return new Blob([WorkbookPrintPDF.zip(Object.entries(files).map(([name,value])=>({name,bytes:new TextEncoder().encode(value)})))],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
}
