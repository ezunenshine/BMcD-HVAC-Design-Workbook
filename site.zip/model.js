export function cloneRows(rows) {
  return rows.map((row) => row.slice());
}

export function blankRow(table) {
  return table.headers.map((_, index) => table.computed.includes(index) ? 0 : null);
}

function numeric(value) {
  if (value === null || value === undefined || value === "" || value === "-") return 0;
  const number = Number(value);
  return Number.isFinite(number) ? number : 0;
}

function columnName(header) {
  return String(header ?? "").split("\n")[0].trim();
}

export function columnReference(header) {
  const parts = String(header ?? "").split("\n").filter((part, index) => index === 0 || !/^[[(]/.test(part.trim()));
  return `@${parts.join(" ").replace(/[^A-Za-z0-9]+/g, "")}`;
}

function columnIndex(table, name) {
  const normalized = String(name).replace(/^@/, "").replace(/[^A-Za-z0-9]+/g, "").toLocaleLowerCase();
  return table.headers.findIndex((header) => {
    const full = String(header ?? "").replace(/[^A-Za-z0-9]+/g, "").toLocaleLowerCase();
    const short = columnName(header).replace(/[^A-Za-z0-9]+/g, "").toLocaleLowerCase();
    return full === normalized || short === normalized;
  });
}

function tokenize(expression) {
  const source = String(expression || "").trim().replace(/^=/, "");
  const tokens = [];
  let index = 0;
  while (index < source.length) {
    const character = source[index];
    if (/\s/.test(character)) { index += 1; continue; }
    if (character === "@") {
      const reference = source.slice(index + 1).match(/^[A-Za-z_][A-Za-z0-9_]*/);
      if (!reference) throw new Error("Enter a column reference after @");
      tokens.push({ type: "reference", value: reference[0] });
      index += reference[0].length + 1;
      continue;
    }
    if (character === "[") {
      const end = source.indexOf("]", index + 1);
      if (end < 0) throw new Error("Missing ] in column reference");
      tokens.push({ type: "reference", value: source.slice(index + 1, end) });
      index = end + 1;
      continue;
    }
    if (character === '"') {
      let value = "";
      index += 1;
      while (index < source.length && source[index] !== '"') {
        value += source[index];
        index += 1;
      }
      if (source[index] !== '"') throw new Error("Missing closing quote");
      tokens.push({ type: "string", value });
      index += 1;
      continue;
    }
    const number = source.slice(index).match(/^(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?/i);
    if (number) {
      tokens.push({ type: "number", value: Number(number[0]) });
      index += number[0].length;
      continue;
    }
    const identifier = source.slice(index).match(/^[A-Za-z_][A-Za-z0-9_]*/);
    if (identifier) {
      tokens.push({ type: "identifier", value: identifier[0].toUpperCase() });
      index += identifier[0].length;
      continue;
    }
    const pair = source.slice(index, index + 2);
    if ([">=", "<=", "<>", "!=", "=="].includes(pair)) {
      tokens.push({ type: "operator", value: pair });
      index += 2;
      continue;
    }
    if ("+-*/&=><(),".includes(character)) {
      tokens.push({ type: character === "(" || character === ")" || character === "," ? character : "operator", value: character });
      index += 1;
      continue;
    }
    throw new Error(`Unsupported character: ${character}`);
  }
  tokens.push({ type: "end", value: "" });
  return tokens;
}

function evaluateExpression(expression, context) {
  const tokens = tokenize(expression);
  let position = 0;
  const current = () => tokens[position];
  const take = (type) => {
    if (current().type !== type) throw new Error(`Expected ${type}`);
    return tokens[position++];
  };

  const functions = {
    SOURCE: () => context.sourceValue,
    IF: (condition, yes, no) => condition ? yes : no,
    N: (value) => numeric(value),
    ROUND: (value, digits = 0) => {
      const factor = 10 ** numeric(digits);
      return Math.round(numeric(value) * factor) / factor;
    },
    MIN: (...values) => Math.min(...values.map(numeric)),
    MAX: (...values) => Math.max(...values.map(numeric)),
    ABS: (value) => Math.abs(numeric(value)),
    LOOKUP: (tableId, matchColumn, matchValue, resultColumn) => {
      const target = context.tableById[String(tableId)];
      if (!target) return 0;
      const matchIndex = columnIndex(target, matchColumn);
      const resultIndex = columnIndex(target, resultColumn);
      const match = (context.rowsById[String(tableId)] || []).find((candidate) => String(candidate[matchIndex] ?? "") === String(matchValue ?? ""));
      return match && resultIndex >= 0 ? match[resultIndex] : 0;
    },
    SUMIF: (tableId, matchColumn, matchValue, sumColumn) => {
      const target = context.tableById[String(tableId)];
      if (!target) return 0;
      const matchIndex = columnIndex(target, matchColumn);
      const sumIndex = columnIndex(target, sumColumn);
      return (context.rowsById[String(tableId)] || []).reduce((sum, candidate) => (
        String(candidate[matchIndex] ?? "") === String(matchValue ?? "") ? sum + numeric(candidate[sumIndex]) : sum
      ), 0);
    },
    COUNTIF: (tableId, matchColumn, matchValue) => {
      const target = context.tableById[String(tableId)];
      if (!target) return 0;
      const matchIndex = columnIndex(target, matchColumn);
      return (context.rowsById[String(tableId)] || []).filter((candidate) => String(candidate[matchIndex] ?? "") === String(matchValue ?? "")).length;
    },
  };

  function primary() {
    const token = current();
    if (token.type === "number" || token.type === "string") { position += 1; return token.value; }
    if (token.type === "reference") {
      position += 1;
      const index = columnIndex(context.table, token.value);
      if (index < 0) throw new Error(`Unknown column [${token.value}]`);
      return context.row[index];
    }
    if (token.type === "identifier") {
      position += 1;
      if (token.value === "TRUE") return true;
      if (token.value === "FALSE") return false;
      const fn = functions[token.value];
      if (!fn) throw new Error(`Unsupported function ${token.value}`);
      take("(");
      const args = [];
      if (current().type !== ")") {
        args.push(comparison());
        while (current().type === ",") { position += 1; args.push(comparison()); }
      }
      take(")");
      return fn(...args);
    }
    if (token.type === "(") {
      position += 1;
      const value = comparison();
      take(")");
      return value;
    }
    throw new Error("Expected a value");
  }

  function unary() {
    if (current().type === "operator" && ["+", "-"].includes(current().value)) {
      const operator = tokens[position++].value;
      const value = numeric(unary());
      return operator === "-" ? -value : value;
    }
    return primary();
  }

  function multiply() {
    let value = unary();
    while (current().type === "operator" && ["*", "/"].includes(current().value)) {
      const operator = tokens[position++].value;
      const right = numeric(unary());
      value = operator === "*" ? numeric(value) * right : numeric(value) / right;
    }
    return value;
  }

  function add() {
    let value = multiply();
    while (current().type === "operator" && ["+", "-"].includes(current().value)) {
      const operator = tokens[position++].value;
      const right = numeric(multiply());
      value = operator === "+" ? numeric(value) + right : numeric(value) - right;
    }
    return value;
  }

  function concatenate() {
    let value = add();
    while (current().type === "operator" && current().value === "&") {
      position += 1;
      value = String(value ?? "") + String(add() ?? "");
    }
    return value;
  }

  function comparison() {
    let value = concatenate();
    if (current().type === "operator" && ["=", "==", "!=", "<>", ">", "<", ">=", "<="].includes(current().value)) {
      const operator = tokens[position++].value;
      const right = concatenate();
      if (["=", "=="].includes(operator)) return value == right;
      if (["!=", "<>"].includes(operator)) return value != right;
      if (operator === ">") return value > right;
      if (operator === "<") return value < right;
      if (operator === ">=") return value >= right;
      return value <= right;
    }
    return value;
  }

  const result = comparison();
  if (current().type !== "end") throw new Error("Unexpected text after formula");
  return result;
}

export function validateEquation(table, expression) {
  evaluateExpression(expression, {
    table,
    row: table.headers.map(() => 0),
    sourceValue: 0,
    tableById: { [table.id]: table },
    rowsById: { [table.id]: [] },
  });
  return true;
}

export function recalculate(table, rows, tableRowsById, equations = table.equations || {}, sourceRowsById = {}) {
  const next = cloneRows(rows);
  const tableById = Object.fromEntries(Object.keys(tableRowsById).map((id) => [id, null]));
  tableById[table.id] = table;
  if (table.tableById) Object.assign(tableById, table.tableById);
  const rowsById = { ...tableRowsById, [table.id]: next };

  Object.entries(equations)
    .map(([column, expression]) => [Number(column), expression])
    .sort(([left], [right]) => left - right)
    .forEach(([column, expression]) => {
      next.forEach((row, rowIndex) => {
        const sourceRows = sourceRowsById[table.id] || [];
        const sourceRow = sourceRows.find((candidate) => String(candidate[0] ?? "") === String(row[0] ?? "")) || sourceRows[rowIndex];
        const sourceValue = sourceRow?.[column] ?? 0;
        row[column] = evaluateExpression(expression, { table, row, sourceValue, tableById, rowsById });
      });
    });
  return next;
}

export function recalculateAll(tables, rowsById, equationsById = {}, sourceRowsById = {}) {
  const tableById = Object.fromEntries(tables.map((table) => [table.id, table]));
  const nextRows = Object.fromEntries(Object.entries(rowsById).map(([id, rows]) => [id, cloneRows(rows)]));
  tables.forEach((table) => {
    table.tableById = tableById;
    nextRows[table.id] = recalculate(table, nextRows[table.id], nextRows, equationsById[table.id] || table.equations, sourceRowsById);
    delete table.tableById;
  });
  return nextRows;
}

export function formatValue(value, type) {
  if (value === null || value === undefined || value === "") return "";
  if (value === "-") return value;
  if (type === "percent" && Number.isFinite(Number(value))) return `${(Number(value) * 100).toFixed(1)}%`;
  if (type === "number" && Number.isFinite(Number(value))) {
    return new Intl.NumberFormat("en-US", { maximumFractionDigits: 6 }).format(Number(value));
  }
  return String(value);
}

export function parseValue(value, type) {
  if (value.trim() === "") return null;
  if (value.trim() === "-") return "-";
  if (type === "percent") {
    const cleaned = value.replace("%", "").trim();
    const parsed = Number(cleaned);
    if (!Number.isFinite(parsed)) return value;
    return value.includes("%") || parsed > 1 ? parsed / 100 : parsed;
  }
  if (type === "number") {
    const parsed = Number(value.replaceAll(",", ""));
    return Number.isFinite(parsed) ? parsed : value;
  }
  return value;
}

export function filterRows(rows, query) {
  const needle = query.trim().toLocaleLowerCase();
  if (!needle) return rows.map((row, index) => ({ row, index }));
  return rows
    .map((row, index) => ({ row, index }))
    .filter(({ row }) => row.some((cell) => String(cell ?? "").toLocaleLowerCase().includes(needle)));
}
