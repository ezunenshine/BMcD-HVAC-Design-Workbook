# HVAC Design Workbook

Browser-based prototype migrated from `01-185021-IESVE-ENERGY-MODEL-CALCULATIONS.xlsm`.

## Run locally on Windows

1. Extract the ZIP.
2. Double-click `start.bat`.
3. Keep the command window open while using the application.

The launcher opens <http://127.0.0.1:8000>. Python 3 is the only local requirement; no packages are installed.

## Deploy with GitHub Pages

Upload the **contents** of this folder to the repository root, including `.github/workflows/main.yml`, then commit to `main`. In the repository's **Settings > Pages**, set **Source** to **GitHub Actions**. The workflow deploys the existing site directly and does not create an `_site` staging folder.

If an older failed workflow is still visible, open the newest run associated with the commit containing this package. Re-running an old run uses that old commit's workflow and can repeat its original failure.

## Scope and safety

This prototype exposes 17 independent workbook tables with local editing, shared equations, JSON import/export, and workbook sheet/range traceability. It is an engineering aid; results require review and acceptance by a qualified HVAC professional.
