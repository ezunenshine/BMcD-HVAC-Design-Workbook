import { blankRow, cloneRows, columnReference, filterRows, formatValue, parseValue, recalculateAll, validateEquation } from "./model.js";

const STORAGE_PREFIX = "iesve-independent-v1:";
const PROJECT_KEY = `${STORAGE_PREFIX}project`;
const NAVIGATION_KEY = `${STORAGE_PREFIX}navigation-collapsed`;
const EQUATIONS_KEY = "iesve-independent:shared-equations-v2";
const state = { data: null, activeId: null, rows: {}, equations: {}, selectedRows: {}, query: "", saveTimer: null };

const NAV_SECTIONS = [
  {
    label: "Model",
    items: [
      { label: "Spaces", icon: "□", tableIds: ["ventilation-rates", "people-heat-gain", "pressurization"] },
      { label: "Thermal Templates", icon: "▥", tableIds: ["baseline-lighting", "proposed-lighting", "baseline-systems"] },
    ],
  },
  {
    label: "Systems",
    items: [
      { label: "Airside", icon: "≋", tableIds: [] },
      { label: "Plantside", icon: "◎", tableIds: ["femp-hot-water-use", "ethylene-glycol-density", "propylene-glycol-density", "ethylene-glycol-specific-heat", "propylene-glycol-specific-heat", "water-properties"] },
    ],
  },
  {
    label: "Loads",
    items: [
      { label: "Lighting", icon: "☼", tableIds: ["light-schedule"] },
      { label: "Misc Loads", icon: "◇", tableIds: ["equipment-schedule", "grouped-equipment-schedule"] },
      { label: "Exhaust", icon: "↗", tableIds: ["general-exhaust", "exhaust-equipment"] },
      { label: "Transfer Air", icon: "⇄", tableIds: [] },
    ],
  },
  {
    label: "Results",
    items: [
      { label: "Energy", icon: "◓", tableIds: [] },
      { label: "Air Schedule", icon: "▤", tableIds: [] },
    ],
  },
];

const elements = {
  groups: document.querySelector("#workbookNavigation"),
  title: document.querySelector("#tableTitle"),
  description: document.querySelector("#tableDescription"),
  sheet: document.querySelector("#sheetName"),
  source: document.querySelector("#sourceRange"),
  breadcrumb: document.querySelector("#breadcrumbTable"),
  table: document.querySelector("#dataTable"),
  search: document.querySelector("#tableSearch"),
  rowSummary: document.querySelector("#rowSummary"),
  empty: document.querySelector("#emptyState"),
  addRow: document.querySelector("#addRow"),
  removeRows: document.querySelector("#removeRows"),
  editEquations: document.querySelector("#editEquations"),
  resetTable: document.querySelector("#resetTable"),
  exportAll: document.querySelector("#exportAll"),
  importAll: document.querySelector("#importAll"),
  resetAll: document.querySelector("#resetAll"),
  projectName: document.querySelector("#projectName"),
  projectNumber: document.querySelector("#projectNumber"),
  submittal: document.querySelector("#submittal"),
  submittalDate: document.querySelector("#submittalDate"),
  saveText: document.querySelector("#saveText"),
  toast: document.querySelector("#toast"),
  menuButton: document.querySelector("#menuButton"),
  sidebarClose: document.querySelector("#sidebarClose"),
  drawerScrim: document.querySelector("#drawerScrim"),
  equationDialog: document.querySelector("#equationDialog"),
  equationForm: document.querySelector("#equationForm"),
  equationTitle: document.querySelector("#equationTitle"),
  equationFields: document.querySelector("#equationFields"),
  equationReferences: document.querySelector("#equationReferences"),
  equationError: document.querySelector("#equationError"),
  equationCancel: document.querySelector("#equationCancel"),
  equationReset: document.querySelector("#equationReset"),
};

function activeTable() {
  return state.data.tables.find((table) => table.id === state.activeId);
}

function storageKey(id) {
  return `${STORAGE_PREFIX}table:${id}`;
}

function readRows(table) {
  try {
    const saved = JSON.parse(localStorage.getItem(storageKey(table.id)) || "null");
    if (Array.isArray(saved) && saved.every((row) => Array.isArray(row) && row.length === table.headers.length)) return saved;
  } catch (_) {}
  return cloneRows(table.rows);
}

function saveRows(table) {
  localStorage.setItem(storageKey(table.id), JSON.stringify(state.rows[table.id]));
  elements.saveText.textContent = "Saved locally";
}

function scheduleSave(table) {
  elements.saveText.textContent = "Saving...";
  window.clearTimeout(state.saveTimer);
  state.saveTimer = window.setTimeout(() => saveRows(table), 180);
}

function recalculateTable(table) {
  const sourceRows = Object.fromEntries(state.data.tables.map((item) => [item.id, item.rows]));
  state.rows = recalculateAll(state.data.tables, state.rows, state.equations, sourceRows);
  if (table.id === "equipment-schedule" && state.rows["grouped-equipment-schedule"]) saveRows(state.data.tables.find((item) => item.id === "grouped-equipment-schedule"));
}

function loadEquations() {
  let saved = {};
  try { saved = JSON.parse(localStorage.getItem(EQUATIONS_KEY) || "{}"); } catch (_) {}
  state.data.tables.forEach((table) => {
    state.equations[table.id] = { ...(table.equations || {}), ...(saved[table.id] || {}) };
  });
}

function saveEquations() {
  localStorage.setItem(EQUATIONS_KEY, JSON.stringify(state.equations));
}

function renderNavigation() {
  const tableById = new Map(state.data.tables.map((table) => [table.id, table]));
  const sections = NAV_SECTIONS.map((section) => {
    const sectionElement = document.createElement("section");
    sectionElement.className = "nav-model-section";
    const heading = document.createElement("p");
    heading.className = "nav-kicker nav-model-heading";
    heading.textContent = section.label;

    const items = section.items.map((item) => {
      const tables = item.tableIds.map((id) => tableById.get(id)).filter(Boolean);
      const wrapper = document.createElement("div");
      wrapper.className = "table-group";
      const button = document.createElement("button");
      button.className = "group-toggle";
      button.type = "button";
      button.disabled = tables.length === 0;
      button.setAttribute("aria-expanded", String(tables.some((table) => table.id === state.activeId)));
      if (tables.length === 1) button.dataset.tableId = tables[0].id;
      const count = tables.reduce((total, table) => total + table.rows.length, 0);
      button.innerHTML = `<span class="nav-icon">${item.icon}</span><span class="group-label">${item.label}</span>${count ? `<span class="nav-count">${count}</span>` : ""}${tables.length > 1 ? '<span class="chevron down"></span>' : ""}`;

      const links = document.createElement("div");
      links.className = "group-links";
      if (tables.length > 1) tables.forEach((table) => {
        const link = document.createElement("a");
        link.className = "table-link";
        link.href = `#${table.id}`;
        link.dataset.tableId = table.id;
        link.textContent = table.title;
        links.append(link);
      });
      button.addEventListener("click", () => {
        if (tables.length === 1) return;
        const expanded = button.getAttribute("aria-expanded") === "true";
        button.setAttribute("aria-expanded", String(!expanded));
      });
      wrapper.append(button, links);
      return wrapper;
    });
    sectionElement.append(heading, ...items);
    return sectionElement;
  });
  elements.groups.replaceChildren(...sections);
}

function cellEditor(table, row, rowIndex, columnIndex) {
  const cell = document.createElement("td");
  const type = table.columnTypes[columnIndex] || "text";
  if (table.computed.includes(columnIndex)) {
    cell.className = "computed-cell";
    const value = document.createElement("input");
    value.className = "cell-input computed-input";
    value.value = formatValue(row[columnIndex], type);
    value.readOnly = true;
    value.setAttribute("aria-readonly", "true");
    value.setAttribute("aria-label", `${String(table.headers[columnIndex])}, calculated`);
    value.title = "Calculated by the shared equation";
    cell.append(value);
    return cell;
  }

  cell.className = "editable-cell";

  let editor;
  if (type.startsWith("lookup:")) {
    editor = document.createElement("select");
    editor.className = "cell-select";
    const sourceId = type.split(":")[1];
    const options = [...new Set((state.rows[sourceId] || []).map((candidate) => candidate[0]).filter(Boolean))];
    editor.append(new Option("", ""), ...options.map((option) => new Option(option, option)));
    editor.value = row[columnIndex] ?? "";
  } else {
    editor = document.createElement("input");
    editor.className = "cell-input";
    editor.type = "text";
    editor.inputMode = ["number", "percent"].includes(type) ? "decimal" : "text";
    editor.value = formatValue(row[columnIndex], type);
  }
  editor.setAttribute("aria-label", String(table.headers[columnIndex]));
  editor.addEventListener("change", () => {
    state.rows[table.id][rowIndex][columnIndex] = parseValue(editor.value, type);
    recalculateTable(table);
    scheduleSave(table);
    renderTable();
  });
  cell.append(editor);
  return cell;
}

function renderTable() {
  const table = activeTable();
  const rows = state.rows[table.id];
  const visibleRows = filterRows(rows, state.query);
  const headRow = document.createElement("tr");
  table.headers.forEach((header, index) => {
    const th = document.createElement("th");
    th.textContent = String(header ?? "");
    if (table.computed.includes(index)) th.className = "computed-header";
    headRow.append(th);
  });
  const actionHeader = document.createElement("th");
  actionHeader.className = "selection-header";
  const selectAll = document.createElement("input");
  selectAll.type = "checkbox";
  selectAll.title = "Select all visible rows";
  selectAll.setAttribute("aria-label", "Select all visible rows");
  const selected = state.selectedRows[table.id] || new Set();
  selectAll.checked = visibleRows.length > 0 && visibleRows.every(({ index }) => selected.has(index));
  selectAll.indeterminate = !selectAll.checked && visibleRows.some(({ index }) => selected.has(index));
  selectAll.addEventListener("change", () => {
    visibleRows.forEach(({ index }) => selectAll.checked ? selected.add(index) : selected.delete(index));
    state.selectedRows[table.id] = selected;
    renderTable();
  });
  actionHeader.append(selectAll);
  headRow.append(actionHeader);
  elements.table.tHead.replaceChildren(headRow);

  const bodyRows = visibleRows.map(({ row, index: rowIndex }) => {
    const tr = document.createElement("tr");
    row.forEach((_, columnIndex) => tr.append(cellEditor(table, row, rowIndex, columnIndex)));
    tr.classList.toggle("selected-row", selected.has(rowIndex));
    const actionCell = document.createElement("td");
    actionCell.className = "selection-cell";
    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.checked = selected.has(rowIndex);
    checkbox.setAttribute("aria-label", `Select row ${rowIndex + 1}`);
    checkbox.addEventListener("change", () => {
      checkbox.checked ? selected.add(rowIndex) : selected.delete(rowIndex);
      state.selectedRows[table.id] = selected;
      renderTable();
    });
    actionCell.append(checkbox);
    tr.append(actionCell);
    return tr;
  });
  elements.table.tBodies[0].replaceChildren(...bodyRows);
  elements.empty.hidden = visibleRows.length > 0;
  elements.table.hidden = visibleRows.length === 0;
  elements.rowSummary.textContent = state.query ? `${visibleRows.length} of ${rows.length} rows` : `${rows.length} rows`;
  const selectedCount = selected.size;
  elements.removeRows.disabled = selectedCount === 0;
  elements.removeRows.innerHTML = `<span>−</span>Remove row${selectedCount === 1 ? "" : "s"}`;
}

function openTable(id, updateHash = true) {
  const table = state.data.tables.find((candidate) => candidate.id === id) || state.data.tables[0];
  state.activeId = table.id;
  state.query = "";
  elements.search.value = "";
  elements.title.textContent = table.title;
  elements.description.textContent = table.description;
  elements.sheet.textContent = table.group;
  elements.source.textContent = `${table.source.sheet} · ${table.source.range}`;
  elements.breadcrumb.textContent = table.title;
  elements.editEquations.hidden = table.computed.length === 0;
  document.querySelectorAll("[data-table-id]").forEach((link) => link.classList.toggle("active", link.dataset.tableId === table.id));
  const activeLink = document.querySelector(`.table-link[data-table-id="${table.id}"]`);
  activeLink?.closest(".table-group")?.querySelector(".group-toggle")?.setAttribute("aria-expanded", "true");
  if (updateHash) history.replaceState(null, "", `#${table.id}`);
  recalculateTable(table);
  renderTable();
  document.body.classList.remove("nav-open");
}

function addRow() {
  const table = activeTable();
  state.rows[table.id].push(blankRow(table));
  recalculateTable(table);
  saveRows(table);
  state.query = "";
  elements.search.value = "";
  renderTable();
  requestAnimationFrame(() => {
    document.querySelector("#tableScroller").scrollTop = document.querySelector("#tableScroller").scrollHeight;
    const inputs = elements.table.querySelectorAll("tbody tr:last-child input, tbody tr:last-child select");
    inputs[0]?.focus();
  });
}

function removeSelectedRows() {
  const table = activeTable();
  const selected = state.selectedRows[table.id] || new Set();
  if (!selected.size) return;
  [...selected].sort((left, right) => right - left).forEach((index) => state.rows[table.id].splice(index, 1));
  selected.clear();
  recalculateTable(table);
  saveRows(table);
  renderTable();
  showToast("Selected rows removed");
}

function renderEquationFields(equations = state.equations[activeTable().id]) {
  const table = activeTable();
  const fields = table.computed.map((column) => {
    const label = document.createElement("label");
    const name = document.createElement("span");
    name.textContent = String(table.headers[column]).replaceAll("\n", " ");
    const input = document.createElement("textarea");
    input.dataset.column = String(column);
    input.value = equations?.[column] || "=SOURCE()";
    input.rows = 3;
    input.spellcheck = false;
    label.append(name, input);
    return label;
  });
  elements.equationFields.replaceChildren(...fields);
}

function openEquationEditor() {
  const table = activeTable();
  elements.equationTitle.textContent = `${table.title} equations`;
  elements.equationError.textContent = "";
  elements.equationReferences.textContent = `Available columns: ${table.headers.map(columnReference).join(", ")}`;
  renderEquationFields();
  elements.equationDialog.showModal();
}

function applyEquations(event) {
  event.preventDefault();
  const table = activeTable();
  const next = { ...state.equations[table.id] };
  try {
    elements.equationFields.querySelectorAll("textarea").forEach((input) => {
      const expression = input.value.trim();
      if (!expression) throw new Error(`${table.headers[Number(input.dataset.column)]} needs an equation.`);
      validateEquation(table, expression);
      next[input.dataset.column] = expression;
    });
    const previous = state.equations[table.id];
    state.equations[table.id] = next;
    try { recalculateTable(table); } catch (error) { state.equations[table.id] = previous; throw error; }
    saveEquations();
    state.data.tables.forEach(saveRows);
    renderTable();
    elements.equationDialog.close();
    showToast("Shared equations updated for all projects");
  } catch (error) {
    elements.equationError.textContent = error.message;
  }
}

function showToast(message) {
  elements.toast.textContent = message;
  elements.toast.classList.add("visible");
  window.setTimeout(() => elements.toast.classList.remove("visible"), 2200);
}

function projectMetadata() {
  return {
    projectName: elements.projectName.value,
    projectNumber: elements.projectNumber.value,
    submittal: elements.submittal.value,
    submittalDate: elements.submittalDate.value,
  };
}

function saveProjectMetadata() {
  localStorage.setItem(PROJECT_KEY, JSON.stringify(projectMetadata()));
}

function restoreProjectMetadata() {
  try {
    const project = JSON.parse(localStorage.getItem(PROJECT_KEY) || "null");
    if (!project) return;
    Object.entries(project).forEach(([key, value]) => { if (elements[key]) elements[key].value = value || ""; });
  } catch (_) {}
}

function exportProject() {
  const payload = { version: 1, workbook: state.data.workbook, project: projectMetadata(), tables: state.rows };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = `${elements.projectNumber.value || "project"}-workbook-tables.json`;
  link.click();
  URL.revokeObjectURL(link.href);
}

async function importProject(file) {
  const payload = JSON.parse(await file.text());
  if (!payload || typeof payload.tables !== "object") throw new Error("This file does not contain workbook table data.");
  state.data.tables.forEach((table) => {
    const rows = payload.tables[table.id];
    if (Array.isArray(rows) && rows.every((row) => Array.isArray(row) && row.length === table.headers.length)) {
      state.rows[table.id] = rows;
      saveRows(table);
    }
  });
  if (payload.project) {
    Object.entries(payload.project).forEach(([key, value]) => { if (elements[key]) elements[key].value = value || ""; });
    saveProjectMetadata();
  }
  openTable(state.activeId, false);
  showToast("Project data imported");
}

function bindEvents() {
  elements.groups.addEventListener("click", (event) => {
    const link = event.target.closest("[data-table-id]");
    if (link) {
      event.preventDefault();
      openTable(link.dataset.tableId);
    }
  });
  document.querySelectorAll(".nav-link[data-shortcut-table-id]").forEach((link) => link.addEventListener("click", (event) => {
    event.preventDefault();
    openTable(link.dataset.shortcutTableId);
  }));
  elements.search.addEventListener("input", () => { state.query = elements.search.value; renderTable(); });
  elements.addRow.addEventListener("click", addRow);
  elements.removeRows.addEventListener("click", removeSelectedRows);
  elements.editEquations.addEventListener("click", openEquationEditor);
  elements.equationCancel.addEventListener("click", () => elements.equationDialog.close());
  elements.equationReset.addEventListener("click", () => renderEquationFields(activeTable().equations || {}));
  elements.equationForm.addEventListener("submit", applyEquations);
  elements.resetTable.addEventListener("click", () => {
    const table = activeTable();
    if (!window.confirm(`Reset ${table.title} to the original Excel values?`)) return;
    state.rows[table.id] = cloneRows(table.rows);
    saveRows(table);
    recalculateTable(table);
    renderTable();
    showToast(`${table.title} reset`);
  });
  elements.menuButton.addEventListener("click", () => {
    if (window.matchMedia("(max-width: 1000px)").matches) {
      document.body.classList.add("nav-open");
    } else {
      document.body.classList.remove("nav-collapsed");
      localStorage.setItem(NAVIGATION_KEY, "false");
    }
  });
  elements.sidebarClose.addEventListener("click", () => {
    if (window.matchMedia("(max-width: 1000px)").matches) {
      document.body.classList.remove("nav-open");
    } else {
      document.body.classList.add("nav-collapsed");
      localStorage.setItem(NAVIGATION_KEY, "true");
    }
  });
  elements.drawerScrim.addEventListener("click", () => document.body.classList.remove("nav-open"));
  elements.exportAll.addEventListener("click", exportProject);
  elements.importAll.addEventListener("change", async () => {
    try { await importProject(elements.importAll.files[0]); } catch (error) { showToast(error.message); }
    elements.importAll.value = "";
  });
  elements.resetAll.addEventListener("click", () => {
    if (!window.confirm("Reset all workbook tables to the original Excel values?")) return;
    state.data.tables.forEach((table) => {
      state.rows[table.id] = cloneRows(table.rows);
      localStorage.removeItem(storageKey(table.id));
    });
    openTable(state.activeId, false);
    showToast("All independent tables reset");
  });
  [elements.projectName, elements.projectNumber, elements.submittal, elements.submittalDate].forEach((input) => input.addEventListener("change", saveProjectMetadata));
  window.addEventListener("hashchange", () => openTable(location.hash.slice(1), false));
}

async function init() {
  const response = await fetch(new URL("./workbook-data.json", import.meta.url));
  if (!response.ok) throw new Error("Workbook table data could not be loaded.");
  state.data = await response.json();
  if (localStorage.getItem(NAVIGATION_KEY) === "true" && !window.matchMedia("(max-width: 1000px)").matches) {
    document.body.classList.add("nav-collapsed");
  }
  state.data.tables.forEach((table) => {
    state.rows[table.id] = readRows(table);
    state.selectedRows[table.id] = new Set();
  });
  loadEquations();
  document.querySelector("#engineeringNotice").textContent = state.data.notice;
  restoreProjectMetadata();
  renderNavigation();
  bindEvents();
  openTable(location.hash.slice(1) || state.data.tables[0].id, false);
}

init().catch((error) => {
  elements.title.textContent = "Unable to load the workbook tables";
  elements.description.textContent = error.message;
});
