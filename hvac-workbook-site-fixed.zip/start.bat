@echo off
setlocal
cd /d "%~dp0"

where py >nul 2>nul
if %errorlevel%==0 (
  set "PYTHON=py"
) else (
  where python >nul 2>nul
  if errorlevel 1 goto no_python
  set "PYTHON=python"
)

start "HVAC Design Workbook" http://127.0.0.1:8000
%PYTHON% -m http.server 8000 --bind 127.0.0.1
goto end

:no_python
echo Python 3 is required to run the local site.
echo Install it from https://www.python.org/downloads/windows/ and try again.
pause

:end
endlocal
